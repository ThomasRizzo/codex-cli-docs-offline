import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

// Only a digest of the canonical IP and route bucket is stored. Keys expire at UTC midnight;
// subsequent requests remove expired keys in bounded batches.
export const demoIpRateLimits = sqliteTable("demo_ip_rate_limits", {
  key: text("key").primaryKey(),
  minuteWindow: integer("minute_window").notNull(),
  minuteCount: integer("minute_count").notNull(),
  dayWindow: integer("day_window").notNull(),
  dayCount: integer("day_count").notNull(),
  expiresAt: integer("expires_at").notNull(),
}, table => [index("demo_ip_rate_limits_expiry_idx").on(table.expiresAt)]);
