import SignalController from "../signal-controller";
export default SignalController;
