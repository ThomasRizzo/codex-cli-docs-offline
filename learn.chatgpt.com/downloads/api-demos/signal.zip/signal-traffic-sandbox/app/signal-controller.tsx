"use client";

import { useCallback, useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import Link from "next/link";
import { ArrowDownTrayIcon, ArrowPathIcon, ArrowUpIcon, Bars3Icon, CheckIcon, ChevronDownIcon, PauseIcon, PlayIcon, QuestionMarkCircleIcon, SpeakerWaveIcon, SpeakerXMarkIcon, StopIcon, XMarkIcon } from "@heroicons/react/16/solid";
import { Intersection } from "./components/intersection";
import { ApiActivityPanel, type ActivityEntry } from "./components/api-activity";
import { createComparison, metrics, POLICIES, SCENARIOS, setPolicy, stepComparison, type PolicyId, type ScenarioId } from "./lib/simulation";
import { apiActivitySchema, controlActionSchema, isPolicyAction } from "./lib/control";
import { useSoundEffects } from "./lib/use-sound-effects";

type Message = { id: number; role: "user" | "assistant"; text: string; status?: "streaming" | "stopped" | "error"; policy?: PolicyId };
type HistoryPoint = { time: number; live: number; baseline: number };
const DEFAULT_SCENARIO: ScenarioId = "morning_rush";
const suggestions = ["Prioritize buses", "Clear the north–south queue", "Give pedestrians more time"];
const directionNames = { north: "N", east: "E", south: "S", west: "W" };

function makeWorld(scenario: ScenarioId) {
  const world = createComparison(scenario, 42);
  stepComparison(world, 45);
  return world;
}
function snapshot(world: ReturnType<typeof createComparison>, history: HistoryPoint[]) {
  return {
    state: { ...world.live, vehicles: world.live.vehicles.map(vehicle => ({...vehicle})), pedestrians: world.live.pedestrians.map(person => ({...person})), waitingPedestrians: {...world.live.waitingPedestrians} },
    live: metrics(world.live), baseline: metrics(world.baseline), history: [...history],
  };
}
function openingMessage(scenarioId: ScenarioId): Message {
  const scenario = SCENARIOS.find(s => s.id === scenarioId)!;
  return { id: 0, role: "assistant", text: `${scenario.description} Tell me what to prioritize, or ask about the intersection.` };
}
function clock(seconds: number) {
  return `${Math.floor(seconds / 60).toString().padStart(2, "0")}:${Math.floor(seconds % 60).toString().padStart(2, "0")}`;
}
function policyLabel(id: PolicyId) { return POLICIES.find(p => p.id === id)?.label || id; }

function QueueHistory({ points }: { points: HistoryPoint[] }) {
  const maximum = Math.max(12, ...points.flatMap(p => [p.live, p.baseline]));
  const path = (key: "live" | "baseline") => points.map((point, index) => `${index ? "L" : "M"}${(index / Math.max(points.length - 1, 1)) * 220},${45 - point[key] / maximum * 38}`).join(" ");
  return <svg viewBox="0 0 220 50" preserveAspectRatio="none" aria-hidden="true" className="queue-chart">
    <path d="M0 46H220" className="chart-axis" />
    {points.length > 1 && <><path d={path("baseline")} className="chart-baseline"/><path d={path("live")} className="chart-live"/></>}
  </svg>;
}

export default function Home() {
  const { soundEnabled, toggleSound, playSound, cancelSounds } = useSoundEffects();
  const worldRef = useRef<ReturnType<typeof createComparison> | null>(null);
  const [frame, setFrame] = useState(() => snapshot(makeWorld(DEFAULT_SCENARIO), []));
  const [scenarioId, setScenarioId] = useState<ScenarioId>(DEFAULT_SCENARIO);
  const [running, setRunning] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [messages, setMessages] = useState<Message[]>([openingMessage(DEFAULT_SCENARIO)]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [elapsed, setElapsed] = useState(0);
  const [showMenu, setShowMenu] = useState(false);
  const [notice, setNotice] = useState("");
  const [dispatchView, setDispatchView] = useState<"chat" | "activity">("chat");
  const [activity, setActivity] = useState<ActivityEntry[]>([]);
  const historyRef = useRef<HistoryPoint[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const autoScroll = useRef(true);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const runIdRef = useRef(0);
  const messageIdRef = useRef(1);
  const startRef = useRef(0);
  const reducedMotion = useRef(false);
  const activityIdRef = useRef(0);
  const requestNumberRef = useRef(0);
  const activeRequestRef = useRef<number | null>(null);
  const queuedPlanRef = useRef<{ policy: PolicyId; run?: number } | null>(null);

  const logSimulation = useCallback((title: string, detail: string, run?: number) => {
    const entry: ActivityEntry = { kind: "simulation", id: `simulation-${++activityIdRef.current}`, at: new Date().toISOString(), title, detail, run };
    setActivity(items => [...items, entry].slice(-80));
  }, []);

  const queuePlan = useCallback((policy: PolicyId, run?: number) => {
    const simulation = worldRef.current!.live;
    const previous = simulation.pendingPolicyId;
    setPolicy(simulation, policy);
    queuedPlanRef.current = simulation.pendingPolicyId ? { policy, run } : null;
    const origin = run === undefined ? "Manual selection" : `API run #${run}`;
    const title = simulation.pendingPolicyId ? previous === policy ? "Plan already queued" : "Plan queued" : previous ? "Queued change canceled" : "Plan already active";
    logSimulation(title, `${policyLabel(policy)} · ${origin}${simulation.pendingPolicyId ? " · next safe changeover" : ""}`, run);
    playSound("plan");
  }, [logSimulation, playSound]);

  useEffect(() => {
    worldRef.current = makeWorld(DEFAULT_SCENARIO);
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    reducedMotion.current = media.matches;
    const startFrame = requestAnimationFrame(() => setRunning(!media.matches));
    const changed = () => { reducedMotion.current = media.matches; if (media.matches) setRunning(false); };
    media.addEventListener("change", changed);
    return () => { cancelAnimationFrame(startFrame); media.removeEventListener("change", changed); abortRef.current?.abort(); };
  }, []);

  useEffect(() => {
    if (!running) return;
    let raf = 0;
    let previous = performance.now();
    let rendered = previous;
    const tick = (now: number) => {
      const dt = Math.min(Math.max((now - previous) / 1000, 0), .12) * speed;
      previous = now;
      if (!document.hidden && worldRef.current) {
        const previousPolicy = worldRef.current.live.policyId;
        const previousPhase = `${worldRef.current.live.phase}/${worldRef.current.live.signal}`;
        stepComparison(worldRef.current, dt);
        const current = worldRef.current.live;
        const time = current.time;
        if (current.policyId !== previousPolicy) {
          const run = queuedPlanRef.current?.policy === current.policyId ? queuedPlanRef.current.run : undefined;
          logSimulation("Plan applied", `${policyLabel(current.policyId)} · simulation ${clock(time)}${run === undefined ? "" : ` · API run #${run}`}`, run);
          queuedPlanRef.current = null;
          playSound("plan");
        } else if (previousPhase !== `${current.phase}/${current.signal}` && current.signal === "green" && current.phase !== "clearance") {
          playSound("phase");
        }
        const lastPoint = historyRef.current.at(-1);
        if (!lastPoint || time - lastPoint.time >= 2) {
          historyRef.current = [...historyRef.current, { time, live: metrics(worldRef.current.live).vehiclesWaiting, baseline: metrics(worldRef.current.baseline).vehiclesWaiting }].slice(-90);
        }
        if (now - rendered > 30) { setFrame(snapshot(worldRef.current, historyRef.current)); rendered = now; }
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [running, speed, logSimulation, playSound]);

  useEffect(() => {
    if (!busy) return;
    const timer = setInterval(() => setElapsed(Math.floor((performance.now() - startRef.current) / 1000)), 400);
    return () => clearInterval(timer);
  }, [busy]);
  useEffect(() => {
    if (autoScroll.current && scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, busy, dispatchView]);

  const {state, live, baseline} = frame;
  const chosenPolicy = state.pendingPolicyId ?? state.policyId;
  const waitDelta = live.meanQueueWaitSeconds - baseline.meanQueueWaitSeconds;
  const showBusWait = chosenPolicy === "bus_priority" || scenarioId === "bus_corridor";
  const showPedestrianWait = chosenPolicy === "pedestrian_priority" || scenarioId === "school_crossing" || scenarioId === "event_traffic";
  const phaseTitle = state.phase === "north_south" ? "North–south" : state.phase === "east_west" ? "East–west" : state.phase === "pedestrians" ? "Pedestrians" : "Safe changeover";

  function cancel() {
    if (abortRef.current) {
      const request = activeRequestRef.current;
      setActivity(items => items.map(item => item.kind === "api" && item.run === request && (item.data.phase === "started" || item.data.phase === "streaming") ? { ...item, interruption: "Stopped locally" } : item));
      logSimulation("Request stopped", "No new plan committed.", request ?? undefined);
      playSound("notice");
    }
    runIdRef.current += 1;
    abortRef.current?.abort();
    abortRef.current = null;
    activeRequestRef.current = null;
    setBusy(false);
    setProgress("");
    setMessages(items => items.map(item => item.status === "streaming" ? { ...item, text: "Stopped. The signal plan hasn’t changed.", status: "stopped" } : item));
  }
  function reset(nextScenario = scenarioId) {
    cancel();
    cancelSounds();
    playSound("tap");
    queuedPlanRef.current = null;
    worldRef.current = makeWorld(nextScenario);
    historyRef.current = [];
    setScenarioId(nextScenario);
    setMessages([openingMessage(nextScenario)]);
    setInput("");
    setNotice("Simulation reset to the same starting conditions.");
    autoScroll.current = true;
    setRunning(!reducedMotion.current);
    setFrame(snapshot(worldRef.current!, historyRef.current));
    logSimulation("Simulation reset", `${SCENARIOS.find(s => s.id === nextScenario)!.label} · balanced plan`);
  }
  function changePlan(id: PolicyId) {
    if (busy) cancel();
    queuePlan(id);
    setNotice(`${policyLabel(id)} ${worldRef.current!.live.pendingPolicyId ? "queued for the next safe changeover" : "is active"}.`);
    setMessages(items => [...items, { id: messageIdRef.current++, role: "assistant", text: `You selected ${policyLabel(id).toLowerCase()}. ${worldRef.current!.live.pendingPolicyId ? "It will take effect at the next safe changeover." : "This plan is active."}`, policy: id }]);
    setFrame(snapshot(worldRef.current!, historyRef.current));
  }

  const send = useCallback(async (override?: string) => {
    const message = (override ?? input).trim();
    if (!message || busy) return;
    playSound("tap");
    const runId = ++runIdRef.current;
    const requestNumber = ++requestNumberRef.current;
    activeRequestRef.current = requestNumber;
    const controller = new AbortController();
    abortRef.current = controller;
    const assistantId = messageIdRef.current++;
    const requestWorld = worldRef.current!;
    const payload = {
      message,
      history: messages.filter(m => !m.status).slice(-12).map(({role, text}) => ({role, content: text.slice(0, 2000)})),
      scenario: scenarioId,
      policy: requestWorld.live.pendingPolicyId ?? requestWorld.live.policyId,
      snapshot: {live: metrics(requestWorld.live), baseline: metrics(requestWorld.baseline)},
    };
    autoScroll.current = true;
    setMessages(items => [...items, {id: messageIdRef.current++, role: "user", text: message}, {id: assistantId, role: "assistant", text: "", status: "streaming"}]);
    setInput("");
    setBusy(true);
    setProgress("Reading the intersection…");
    startRef.current = performance.now();
    setElapsed(0);
    setNotice("");
    let complete = false;
    let streamed = "";
    try {
      const response = await fetch("/api/control", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload), signal:controller.signal});
      if (!response.ok) {
        const body = await response.json().catch(() => null);
        throw new Error(body && typeof body === "object" && "error" in body && typeof body.error === "string" ? body.error : "The traffic controller couldn’t connect. Try again.");
      }
      if (!response.body) throw new Error("The response stream was empty. Try again.");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (!complete) {
        const {value, done} = await reader.read();
        if (runId !== runIdRef.current) { await reader.cancel(); return; }
        if (done) break;
        buffer = (buffer + decoder.decode(value, {stream:true})).replace(/\r\n/g,"\n");
        if (buffer.length > 100000) throw new Error("The response was too large. Try a shorter request.");
        let boundary: number;
        while ((boundary = buffer.indexOf("\n\n")) >= 0) {
          const frame = buffer.slice(0,boundary); buffer = buffer.slice(boundary+2);
          const event = frame.split("\n").find(line => line.startsWith("event:"))?.slice(6).trim();
          const data = frame.split("\n").filter(line=>line.startsWith("data:")).map(line=>line.slice(5).trimStart()).join("\n");
          if (!data) continue;
          const result = JSON.parse(data);
          if (event === "activity") {
            const parsed = apiActivitySchema.safeParse(result);
            if (!parsed.success) throw new Error("The request activity was incomplete. Please try again.");
            const data = parsed.data;
            const id = `${requestNumber}-${data.api}`;
            setActivity(items => {
              const existing = items.find(item => item.id === id);
              return existing ? items.map(item => item.id === id && item.kind === "api" ? { ...item, data: { ...item.data, ...data } } : item)
                : [...items, { kind: "api" as const, id, run: requestNumber, startedAt: data.at, data }].slice(-80);
            });
          }
          if (event === "progress" && typeof result.message === "string") setProgress(result.message);
          if (event === "delta" && typeof result.text === "string") {
            streamed += result.text;
            if (streamed.length > 16000) throw new Error("The response was too long. Try a shorter request.");
            const text = streamed;
            setMessages(items => items.map(item=>item.id===assistantId ? {...item,text} : item));
            setProgress("Writing an update…");
          }
          if (event === "error") throw new Error(result.message || "The request was interrupted. Try again.");
          if (event === "done") {
            if (typeof result.text !== "string" || !result.text.trim() || !controlActionSchema.safeParse(result.action).success) throw new Error("The response was incomplete. Your signal plan hasn’t changed.");
            if (isPolicyAction(result.action)) {
              queuePlan(result.action, requestNumber);
              setNotice(`${policyLabel(result.action)} queued for the next safe changeover.`);
              setFrame(snapshot(worldRef.current!, historyRef.current));
            } else {
              logSimulation("Plan unchanged", result.action === "explain" ? "Question answered without an intervention." : "No traffic change requested or understood.", requestNumber);
              playSound("complete");
            }
            setMessages(items => items.map(item=>item.id===assistantId ? {id:item.id,role:item.role,text:result.text, ...(isPolicyAction(result.action) ? {policy:result.action} : {})} : item));
            setNotice(result.text);
            complete = true;
            await reader.cancel().catch(() => {});
            break;
          }
        }
      }
      if (!complete) throw new Error("The connection ended early. Your signal plan hasn’t changed. Please try again.");
    } catch(error) {
      if (runId !== runIdRef.current) return;
      const text = error instanceof Error ? error.message : "Something went wrong. Try again.";
      setActivity(items => items.map(item => item.kind === "api" && item.run === requestNumber && (item.data.phase === "started" || item.data.phase === "streaming") ? { ...item, interruption: "Connection interrupted" } : item));
      logSimulation("Request incomplete", "No new plan committed. You can retry.", requestNumber);
      playSound("notice");
      setMessages(items => items.map(item=>item.id===assistantId ? {...item,text,status:"error"} : item));
      setNotice(text);
      setInput(current => current || message);
    } finally {
      controller.abort();
      if (runId === runIdRef.current) { setBusy(false); setProgress(""); abortRef.current=null; activeRequestRef.current=null; }
    }
  }, [busy, input, messages, scenarioId, logSimulation, queuePlan, playSound]);
  function submit(event: FormEvent) { event.preventDefault(); if (busy) cancel(); else void send(); }
  function onKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) { event.preventDefault(); if (!busy) void send(); }
  }
  function showHelp() { playSound("tap"); setShowMenu(false); dialogRef.current?.showModal(); }

  return <>
    <main className="signal-app">
      <header className="app-header">
        <Link className="brand" href="/" aria-label="Signal homepage"><img src="/favicon.svg" width="28" height="28" alt=""/><h1>Signal</h1></Link>
        <div className="scenario-control"><label htmlFor="scenario">Scenario</label><div className="select-wrap"><select id="scenario" name="scenario" value={scenarioId} onChange={event=>reset(event.target.value as ScenarioId)}>{SCENARIOS.map(s=><option key={s.id} value={s.id}>{s.label}</option>)}</select><ChevronDownIcon aria-hidden="true"/></div></div>
        <nav className="header-actions" aria-label="Project"><a className="button secondary" href="/signal-project.zip" download><ArrowDownTrayIcon aria-hidden="true"/>Download project</a><button className="button icon-button" type="button" onClick={showHelp} aria-label="How Signal works"><QuestionMarkCircleIcon aria-hidden="true"/></button></nav>
        <button className="button icon-button mobile-menu-toggle" aria-label="Menu" aria-expanded={showMenu} aria-controls="mobile-menu" type="button" onClick={()=>setShowMenu(!showMenu)}>{showMenu ? <XMarkIcon/>:<Bars3Icon/>}</button>
        {showMenu && <nav className="mobile-menu" id="mobile-menu" aria-label="Project"><a className="button" href="/signal-project.zip" download><ArrowDownTrayIcon/>Download project</a><button className="button" type="button" onClick={showHelp}><QuestionMarkCircleIcon/>How it works</button></nav>}
      </header>
      <div className="workspace">
        <section className="map-panel" aria-label="Traffic simulation">
          <div className="map-stage">
            <Intersection state={state}/>
            <div className="map-topline"><div className="map-place"><div className="eyebrow">Junction 01</div><p>Market &amp; Canal</p></div><div className="simulation-clock"><div className={`status-dot ${running ? "active":""}`}/><span>{running ? "Live":"Paused"}</span><time>{clock(state.time)}</time></div></div>
            <div className="compass" aria-hidden="true"><span>N</span><ArrowUpIcon/></div>
            <div className="phase-status"><div className={`phase-dot ${state.phase === "pedestrians" ? "walk" : state.signal}`}/><p>{phaseTitle}</p>{state.phase !== "clearance" && <div className="phase-time">{Math.ceil(state.phaseRemaining)}s</div>}</div>
            <div className="map-controls" aria-label="Simulation controls"><button className="button" type="button" onClick={()=>{cancelSounds();playSound("tap");setRunning(!running);}} aria-label={running ? "Pause simulation":"Play simulation"}>{running ? <PauseIcon/>:<PlayIcon/>}<span>{running ? "Pause":"Play"}</span></button><div className="control-divider"/><div className="speed-control" aria-label="Simulation speed"><button type="button" aria-pressed={speed===1} onClick={()=>{playSound("tap");setSpeed(1);}}>1×</button><button type="button" aria-pressed={speed===3} onClick={()=>{playSound("tap");setSpeed(3);}}>3×</button></div><div className="control-divider"/><button className="button icon-button" type="button" aria-label="Reset simulation" title="Reset simulation" onClick={()=>reset()}><ArrowPathIcon/></button><button className="button icon-button" type="button" aria-label="Sound effects" aria-pressed={soundEnabled} title={soundEnabled ? "Mute sound effects" : "Enable sound effects"} onClick={toggleSound}>{soundEnabled ? <SpeakerWaveIcon/> : <SpeakerXMarkIcon/>}</button></div>
            <div className="map-legend"><div><i className="legend-car"/>Cars</div><div><i className="legend-bus"/>Buses</div><div><i className="legend-person"/>People</div></div>
          </div>
          <div className="metrics-strip" aria-label="Live simulation metrics">
            <div className="metric"><div className="metric-label">Average wait</div><div className="metric-value">{live.meanQueueWaitSeconds.toFixed(1)}<small>s</small></div><p className={waitDelta < -.5 ? "improved" : ""}>{Math.abs(waitDelta) >= .5 ? `${Math.abs(waitDelta).toFixed(1)}s ${waitDelta < 0 ? "less":"more"} than baseline` : `Baseline ${baseline.meanQueueWaitSeconds.toFixed(1)}s`}</p></div>
            <div className="metric"><div className="metric-label">Vehicles through</div><div className="metric-value">{live.vehiclesCompleted}</div><p>Baseline {baseline.vehiclesCompleted}</p></div>
            <div className="metric"><div className="metric-label">{showBusWait ? "Bus wait" : showPedestrianWait ? "Pedestrian wait" : "People waiting"}</div><div className="metric-value">{showBusWait ? live.meanBusWaitSeconds.toFixed(1) : showPedestrianWait ? live.meanPedestrianWaitSeconds.toFixed(1) : live.pedestriansWaiting}{(showBusWait || showPedestrianWait) && <small>s</small>}</div><p>{showBusWait ? `Baseline ${baseline.meanBusWaitSeconds.toFixed(1)}s` : showPedestrianWait ? `Baseline ${baseline.meanPedestrianWaitSeconds.toFixed(1)}s` : `${live.pedestriansCompleted} crossed safely`}</p></div>
            <div className="queue-metric"><div className="metric-label">Traffic queue <strong>{live.vehiclesWaiting}</strong></div><QueueHistory points={frame.history}/><div className="chart-key"><span><i/>Live</span><span><i/>Baseline</span></div></div>
          </div>
          <div className="map-footer"><p>Same arrivals. Two signal plans.</p><p>Simulated time <span>{clock(state.time)}</span></p></div>
        </section>
        <aside className="dispatch" aria-label="Traffic controller">
          <div className="dispatch-heading"><h2>Dispatch</h2><div className="dispatch-number">01 / CONTROL</div></div>
          <div className="policy-control"><div className="policy-label"><label htmlFor="policy">Signal plan</label><p>{state.pendingPolicyId ? "Change queued":"Active"}</p></div><div className="select-wrap"><select id="policy" name="policy" value={chosenPolicy} onChange={event=>changePlan(event.target.value as PolicyId)}>{POLICIES.map(p=><option key={p.id} value={p.id}>{p.label}</option>)}</select><ChevronDownIcon aria-hidden="true"/></div><div className="queue-directions" aria-label="Vehicle queues by direction">{Object.entries(live.queues).map(([direction,count])=><div key={direction}><span>{directionNames[direction as keyof typeof directionNames]}</span><strong>{count}</strong></div>)}</div></div>
          <div className="dispatch-tabs" role="tablist" aria-label="Dispatch view" onKeyDown={event => {
            if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
            event.preventDefault();
            const next = event.key === "Home" ? "chat" : event.key === "End" ? "activity" : dispatchView === "chat" ? "activity" : "chat";
            setDispatchView(next);
            document.getElementById(`${next}-tab`)?.focus();
          }}>
            <button type="button" role="tab" id="chat-tab" aria-controls="chat-panel" aria-selected={dispatchView === "chat"} tabIndex={dispatchView === "chat" ? 0 : -1} onClick={()=>{playSound("tap");setDispatchView("chat");}}>Chat</button>
            <button type="button" role="tab" id="activity-tab" aria-controls="activity-panel" aria-selected={dispatchView === "activity"} tabIndex={dispatchView === "activity" ? 0 : -1} onClick={()=>{playSound("tap");setDispatchView("activity");}}>API activity<span className={`activity-count ${busy ? "receiving" : ""}`}>{activity.filter(entry=>entry.kind === "api" && entry.data.api === "decisions").length}</span></button>
          </div>
          <div className="conversation" id="chat-panel" role="tabpanel" aria-labelledby="chat-tab" hidden={dispatchView !== "chat"} ref={scrollRef} onScroll={event=>{ const target=event.currentTarget; autoScroll.current=target.scrollHeight-target.scrollTop-target.clientHeight<70; }} aria-label="Conversation" tabIndex={0}>
            {messages.map(message=><article className={`message ${message.role} ${message.status || ""}`} key={message.id}><div className="message-author">{message.role === "user" ? "You" : "Signal"}{message.status === "stopped" && <span>Stopped</span>}</div>{message.text ? <p>{message.text}</p>:<div className="thinking-indicator" aria-label="Preparing a response"><span/><span/><span/></div>}{message.policy && <div className="policy-receipt"><CheckIcon aria-hidden="true"/><span>{policyLabel(message.policy)}</span></div>}</article>)}
          </div>
          <ApiActivityPanel entries={activity} hidden={dispatchView !== "activity"}/>
          <div className="composer-area">
            {messages.length === 1 && <div className="suggestions" aria-label="Suggested instructions">{suggestions.map(suggestion=><button className="suggestion" type="button" key={suggestion} onClick={()=>void send(suggestion)}>{suggestion}<ArrowUpIcon aria-hidden="true"/></button>)}</div>}
            {busy && <div className="stream-progress" role="status"><div className="progress-dot"/><p title={progress}>{progress}</p><time>{elapsed}s</time></div>}
            <form className="composer" onSubmit={submit}><label className="sr-only" htmlFor="instruction">Message Signal</label><textarea id="instruction" name="instruction" ref={textareaRef} placeholder="What should we change?" rows={3} value={input} maxLength={1600} onChange={event=>setInput(event.target.value)} onKeyDown={onKeyDown}/><div className="composer-footer"><p>Enter to send</p><button className="button primary send-button" type={busy ? "button":"submit"} disabled={!busy && !input.trim()} onClick={busy ? event=>{event.preventDefault();cancel();}:undefined}>{busy ? <StopIcon/>:<ArrowUpIcon/>}{busy ? "Stop":"Send"}</button></div></form>
            <p className="composer-note">Changes apply at a safe signal changeover.</p>
          </div>
        </aside>
      </div>
      <div role="status" className="sr-only">{notice}</div>
    </main>
    <dialog className="help-dialog" aria-labelledby="help-title" ref={dialogRef} onClick={event=>{if(event.target===event.currentTarget)dialogRef.current?.close();}}><div className="dialog-heading"><h2 id="help-title">How Signal works</h2><button type="button" className="button icon-button" aria-label="Close help" onClick={()=>dialogRef.current?.close()}><XMarkIcon/></button></div><div className="help-body"><p>A small traffic simulation you can steer with a conversation. Ask Signal to prioritize a direction, buses, or pedestrians, then watch the intersection respond.</p><ol><li><strong>Choose a scenario.</strong> Each has a different mix of cars, buses, and people.</li><li><strong>Set an intention.</strong> The OpenAI Decisions API chooses from five bounded signal plans. The Responses API explains the choice and answers questions.</li><li><strong>Watch the tradeoffs.</strong> A second simulation runs the same arrivals with the balanced plan. The metrics compare the two; improvements are measured, never generated by the model.</li></ol><div className="help-details"><p><strong>Live API activity</strong><br/>Send an instruction, then open API activity to see request timing, returned actions, and when a plan takes effect. API calls run on your instructions; the traffic animation runs locally.</p><p><strong>Safe transitions</strong><br/>Every plan keeps amber lights, all-red clearance, and protected pedestrian crossings. Changes wait for a safe phase boundary.</p><p><strong>Reading the metrics</strong><br/>Average wait includes all arriving vehicles, including those still in the queue. The chart shows queued vehicles over the latest three simulated minutes. Both simulations start with 45 seconds of traffic.</p><p><strong>A sandbox, not a real traffic system</strong><br/>Vehicles travel straight through one intersection. The simulation is deliberately simplified and is not connected to real roads. Your work stays in this tab.</p></div></div></dialog>
  </>;
}
