import { enforceIpRateLimit } from "@/app/lib/ip-rate-limit";
import { IP_LIMITS } from "@/app/lib/rate-limit-policy";
import { buildTrafficDecisionRequest, parseTrafficDecision, trafficReceiptSchema, trafficRequestSchema } from "@/app/lib/traffic-contract";
import type { TrafficReceipt, TrafficRequest } from "@/app/lib/traffic-contract";
import { ApiError, boundedText, guardRequest, openAIResponse, parseBody, privateHeaders, publicError } from "@/app/lib/server";
import type { OpenAIPath } from "@/app/lib/server";

type Transport = (path: OpenAIPath, payload: unknown, signal: AbortSignal) => Promise<Response>;

/** One real Decisions request for up to four independently named vehicle questions. */
export async function getTrafficDecisions(input: TrafficRequest, signal: AbortSignal, transport: Transport = openAIResponse): Promise<TrafficReceipt> {
  signal.throwIfAborted();
  const started = performance.now();
  const response = await transport("/decisions", buildTrafficDecisionRequest(input), signal);
  if (!response.ok) {
    await response.body?.cancel().catch(() => undefined);
    throw new ApiError(response.status === 429 ? 429 : 502, "Signal could not obtain vehicle decisions. Please try again.");
  }
  let body: unknown;
  try { body = JSON.parse(await boundedText(response.body, 32_768, signal)); }
  catch (error) {
    if (error instanceof ApiError && error.status === 413) throw new ApiError(502, "The vehicle decision response exceeded its bounds.");
    throw error;
  }
  signal.throwIfAborted();
  const decision = parseTrafficDecision(input, body);
  const id = response.headers.get("x-request-id");
  return trafficReceiptSchema.parse({
    at: new Date().toISOString(),
    durationMs: Math.max(0, Math.round(performance.now() - started)),
    status: response.status,
    ...(id && /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(id) ? { requestId: id } : {}),
    ...decision,
  });
}

export async function handleTrafficRequest(request: Request, transport: Transport = openAIResponse, limit: typeof enforceIpRateLimit = enforceIpRateLimit): Promise<Response> {
  try {
    guardRequest(request);
    const blocked = await limit(request, "traffic", IP_LIMITS.traffic);
    if (blocked) return blocked;
    const signal = AbortSignal.any([request.signal, AbortSignal.timeout(8_000)]);
    // Vinext supplies a Request proxy; Workerd cannot reconstruct it as a native Request.
    const input = await parseBody(request, trafficRequestSchema, signal);
    const receipt = await getTrafficDecisions(input, signal, transport);
    return Response.json(receipt, { headers: privateHeaders });
  } catch (error) {
    const { status, message: original } = publicError(error);
    const message = status === 504 ? "Vehicle decisions took too long. Signal will try again shortly."
      : status === 408 ? "The vehicle decision request was stopped."
      : status === 502 ? "Signal could not obtain valid vehicle decisions. Signal will try again shortly."
      : original;
    return Response.json({ error: message }, { status, headers: { ...privateHeaders, ...(status === 429 ? { "Retry-After": "60" } : {}) } });
  }
}

export async function POST(request: Request): Promise<Response> { return handleTrafficRequest(request); }
