import { enforceIpRateLimit } from "@/app/lib/ip-rate-limit";
import { IP_LIMITS } from "@/app/lib/rate-limit-policy";
import { buildDecisionRequest, buildExplanationRequest, controlRequestSchema, parseDecision, responseTextDeltas } from "@/app/lib/control";
import type { ApiActivity, ControlAction, ControlEvent, ControlRequest } from "@/app/lib/control";
import { ApiError, boundedText, errorResponse, guardRequest, openAIResponse, parseBody, privateHeaders, publicError } from "@/app/lib/server";
import type { OpenAIPath } from "@/app/lib/server";

type Transport = (path: OpenAIPath, payload: unknown, signal: AbortSignal) => Promise<Response>;
type ApiCall = { api: ApiActivity["api"]; model: string; started: number; response?: Response };

function activity(call: ApiCall, phase: ApiActivity["phase"], action?: ControlAction): Extract<ControlEvent, { event: "activity" }> {
  const requestId = call.response?.headers.get("x-request-id");
  const status = call.response?.status;
  return { event: "activity", data: {
    api: call.api, phase, at: new Date().toISOString(), model: call.model,
    ...(phase === "started" ? {} : { durationMs: Math.max(0, Math.round(performance.now() - call.started)) }),
    ...(requestId && /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(requestId) ? { requestId } : {}),
    ...(status && status >= 100 && status <= 599 ? { status } : {}),
    ...(action ? { action } : {}),
  } };
}

/** Exported for deterministic transport tests; production always uses the guarded POST route. */
export async function* controlEvents(input: ControlRequest, signal: AbortSignal, transport: Transport = openAIResponse): AsyncGenerator<ControlEvent> {
  signal.throwIfAborted();
  yield { event: "progress", data: { message: "Reading the intersection…" } };
  let call: ApiCall | undefined;
  try {
    signal.throwIfAborted();
    const decisionRequest = buildDecisionRequest(input);
    call = { api: "decisions", model: decisionRequest.model, started: performance.now() };
    yield activity(call, "started");
    signal.throwIfAborted();
    const response = await transport("/decisions", decisionRequest, signal);
    call.response = response;
    if (!response.ok) {
      await response.body?.cancel().catch(() => undefined);
      throw new ApiError(502, "Signal could not choose a plan. Your signal plan is unchanged; try again.");
    }
    const action = parseDecision(JSON.parse(await boundedText(response.body, 128_000, signal)));
    signal.throwIfAborted();
    const decisionReceipt = activity(call, "completed", action);
    call = undefined;
    yield decisionReceipt;
    signal.throwIfAborted();
    yield { event: "decision", data: { action } };
    signal.throwIfAborted();
    if (action === "redirect") {
      const text = "I'm here to help with this intersection. Ask about traffic, or try a different signal plan.";
      yield { event: "delta", data: { text } };
      signal.throwIfAborted();
      yield { event: "done", data: { action, text } };
      return;
    }
    yield { event: "progress", data: { message: action === "clarify" ? "Checking what you need…" : "Explaining the plan…" } };
    signal.throwIfAborted();
    const explanationRequest = buildExplanationRequest(input, action);
    call = { api: "responses", model: explanationRequest.model, started: performance.now() };
    yield activity(call, "started");
    signal.throwIfAborted();
    const explanation = await transport("/responses", explanationRequest, signal);
    call.response = explanation;
    if (!explanation.ok || !explanation.body || !explanation.headers.get("content-type")?.includes("text/event-stream")) {
      await explanation.body?.cancel().catch(() => undefined);
      throw new ApiError(502, "Signal could not explain this plan. Your signal plan is unchanged; try again.");
    }
    const deltas = responseTextDeltas(explanation.body, signal);
    let streaming = false;
    try {
      while (true) {
        const next = await deltas.next();
        signal.throwIfAborted();
        if (next.done) {
          const explanationReceipt = activity(call, "completed");
          call = undefined;
          yield explanationReceipt;
          signal.throwIfAborted();
          yield { event: "done", data: { action, text: next.value } };
          return;
        }
        if (next.value.length > 0 && !streaming) {
          streaming = true;
          yield activity(call, "streaming");
          signal.throwIfAborted();
        }
        yield { event: "delta", data: { text: next.value } };
      }
    } finally { await deltas.return(""); }
  } catch (error) {
    if (call) yield activity(call, "failed");
    throw error;
  }
}

export async function handleControlRequest(request: Request, transport: Transport = openAIResponse, limit: typeof enforceIpRateLimit = enforceIpRateLimit): Promise<Response> {
  try {
    guardRequest(request);
    const blocked = await limit(request, "control", IP_LIMITS.control);
    if (blocked) return blocked;
    const input = await parseBody(request, controlRequestSchema);
    const cancel = new AbortController();
    const signal = AbortSignal.any([request.signal, cancel.signal, AbortSignal.timeout(60_000)]);
    const encoder = new TextEncoder();
    let closed = false;
    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const emit = (event: ControlEvent) => {
          if (!closed) controller.enqueue(encoder.encode(`event: ${event.event}\ndata: ${JSON.stringify(event.data)}\n\n`));
        };
        try {
          for await (const event of controlEvents(input, signal, transport)) emit(event);
        } catch (error) {
          if (!closed) emit({ event: "error", data: { message: publicError(error).message } });
        } finally {
          if (!closed) { closed = true; controller.close(); }
        }
      },
      cancel() { closed = true; cancel.abort(); },
    });
    return new Response(stream, { headers: { ...privateHeaders, "Cache-Control": "no-store, no-transform", "Content-Type": "text/event-stream; charset=utf-8", "X-Accel-Buffering": "no" } });
  } catch (error) { return errorResponse(error); }
}

export async function POST(request: Request): Promise<Response> { return handleControlRequest(request); }
