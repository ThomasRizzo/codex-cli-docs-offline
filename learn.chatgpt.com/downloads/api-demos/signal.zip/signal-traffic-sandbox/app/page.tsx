import { TrafficLab } from "./components/traffic-lab";
import "./traffic.css";

export default function Home() {
  return <TrafficLab/>;
}
