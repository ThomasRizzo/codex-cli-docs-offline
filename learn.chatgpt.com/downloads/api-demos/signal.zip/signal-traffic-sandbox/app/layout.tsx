import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Signal — Traffic playground",
  description: "Watch individual drivers choose when to merge, advance, or yield with the OpenAI Decisions API.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};

export default function RootLayout({children}: Readonly<{children: React.ReactNode}>) {
  return <html lang="en" className="scheme-only-dark"><body className="antialiased">{children}</body></html>;
}
