export type WorkerBindings = { OPENAI_API_KEY?: string };

/** The portable demo sends server-side requests directly to the public API. */
export function apiTransport(_bindings: WorkerBindings | null, fetcher?: typeof fetch): { send: typeof fetch; origin: string } | null {
  return { send: fetcher ?? fetch, origin: "https://api.openai.com" };
}
