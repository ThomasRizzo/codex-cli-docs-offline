/** Parse either form of Retry-After without shortening a server-imposed wait. */
export function retryAfterMs(value: string | null, now = Date.now()): number {
  if (!value?.trim()) return 0;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(0, seconds * 1_000);
  const date = Date.parse(value);
  return Number.isFinite(date) ? Math.max(0, date - now) : 0;
}

/** The hook retains this object when a run is paused, restarted, or replaced. */
export class RequestCooldown {
  until = 0;
  message = "";
  private now: () => number;
  constructor(now: () => number = () => performance.now()) { this.now = now; }
  get active(): boolean { return this.now() < this.until; }
  defer(delayMs: number, message: string): void {
    const until = this.now() + Math.max(0, delayMs);
    if (until > this.until) { this.until = until; this.message = message; }
  }
}
