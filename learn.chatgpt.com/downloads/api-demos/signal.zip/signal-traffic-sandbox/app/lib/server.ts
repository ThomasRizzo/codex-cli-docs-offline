import { z } from "zod";
import { apiTransport } from "./api-transport";
import type { WorkerBindings } from "./api-transport";
export type { WorkerBindings } from "./api-transport";

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export const privateHeaders = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
export function guardRequest(request: Request): void {
  const url = new URL(request.url);
  if (request.headers.get("origin") !== url.origin || request.headers.get("sec-fetch-site") === "cross-site") {
    throw new ApiError(403, "Open Signal in its own tab and try again.");
  }
}

export async function boundedText(body: ReadableStream<Uint8Array> | null, maxBytes: number, signal?: AbortSignal): Promise<string> {
  if (!body) return "";
  const reader = body.getReader();
  const decoder = new TextDecoder("utf-8", { fatal: true });
  const abort = () => { void reader.cancel().catch(() => undefined); };
  signal?.addEventListener("abort", abort, { once: true });
  let bytes = 0, text = "";
  try {
    while (true) {
      signal?.throwIfAborted();
      const chunk = await reader.read();
      signal?.throwIfAborted();
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > maxBytes) throw new ApiError(413, "This request is too large. Try a shorter message.");
      text += decoder.decode(chunk.value, { stream: true });
    }
    return text + decoder.decode();
  } finally {
    signal?.removeEventListener("abort", abort);
    await reader.cancel().catch(() => undefined);
    reader.releaseLock();
  }
}

export async function parseBody<S extends z.ZodTypeAny>(request: Request, schema: S, deadline?: AbortSignal): Promise<z.output<S>> {
  if (request.headers.get("content-type")?.split(";")[0].trim() !== "application/json") throw new ApiError(415, "Send this request as JSON.");
  if (Number(request.headers.get("content-length") ?? 0) > 65_536) throw new ApiError(413, "This request is too large. Try a shorter message.");
  try {
    const raw = JSON.parse(await boundedText(request.body, 65_536, AbortSignal.any([request.signal, ...(deadline ? [deadline] : []), AbortSignal.timeout(10_000)])));
    const parsed = schema.safeParse(raw);
    if (!parsed.success) throw new ApiError(400, "The simulation state or message could not be read. Try again.");
    return parsed.data;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (error instanceof Error && ["AbortError", "TimeoutError"].includes(error.name)) throw new ApiError(408, "The request was interrupted. Please try again.");
    throw new ApiError(400, "The request could not be read. Please try again.");
  }
}

export type OpenAIPath = "/decisions" | "/responses";
async function workerEnvironment(): Promise<WorkerBindings | null> {
  try { const { env } = await import("cloudflare:workers"); return env as unknown as WorkerBindings; }
  catch { return null; }
}

export async function openAIResponse(
  path: OpenAIPath, payload: unknown, signal: AbortSignal,
  dependencies: { key?: string; fetch?: typeof fetch; bindings?: WorkerBindings | null } = {},
): Promise<Response> {
  if (path !== "/decisions" && path !== "/responses") throw new ApiError(500, "Unsupported API operation.");
  const bindings = dependencies.bindings === undefined ? await workerEnvironment() : dependencies.bindings;
  const key = dependencies.key ?? bindings?.OPENAI_API_KEY ?? (process.env.NODE_ENV === "development" ? process.env.OPENAI_API_KEY : undefined);
  if (!key) throw new ApiError(503, "Signal needs its API key connected. Ask the site owner to check its settings.");
  const transport = apiTransport(bindings, dependencies.fetch);
  if (!transport) throw new ApiError(503, "Signal's API connection is unavailable. Ask the site owner to check its settings.");
  const { send, origin } = transport;
  try {
    const response = await send(`${origin}/v1${path}`, {
      method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` }, body: JSON.stringify(payload), signal, redirect: "manual",
    });
    if (response.status >= 300 && response.status < 400) {
      await response.body?.cancel().catch(() => undefined);
      throw new ApiError(502, "Signal could not finish this request. Your signal plan is unchanged; try again.");
    }
    if (!response.ok) {
      // No upstream body, inputs, or credentials are logged or exposed.
      const requestId = response.headers.get("x-request-id");
      console.error(JSON.stringify({ event: "signal_openai_error", path, status: response.status,
        requestId: requestId && /^req_[A-Za-z0-9]{1,90}$/.test(requestId) ? requestId : null }));
      await response.body?.cancel().catch(() => undefined);
      if (response.status === 429) throw new ApiError(429, "Signal has reached its API limit. Try again shortly, or ask the site owner to check the project quota.");
      if ([401, 403, 404].includes(response.status)) throw new ApiError(503, "Signal cannot access its OpenAI model. Ask the site owner to check the API key and project permissions.");
      throw new ApiError(502, "Signal could not finish this request. Your signal plan is unchanged; try again.");
    }
    return response;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    signal.throwIfAborted();
    throw new ApiError(502, "Signal could not reach OpenAI. Your signal plan is unchanged; try again.");
  }
}

export function publicError(error: unknown): { status: number; message: string } {
  if (error instanceof ApiError) return { status: error.status, message: error.message };
  if (error instanceof Error && error.name === "TimeoutError") return { status: 504, message: "Signal took too long. Your signal plan is unchanged; try again." };
  if (error instanceof Error && error.name === "AbortError") return { status: 408, message: "The request was stopped. Your signal plan is unchanged." };
  return { status: 502, message: "Signal's reply was interrupted. Your signal plan is unchanged; try again." };
}

export function errorResponse(error: unknown): Response {
  const { status, message } = publicError(error);
  return Response.json({ error: message }, { status, headers: { ...privateHeaders, ...(status === 429 ? { "Retry-After": "60" } : {}) } });
}
