export type SSEMessage = { event: string; data: string };

/** Bounded UTF-8 SSE decoding. An unfinished final frame is never a complete event. */
export async function* readSSE(
  body: ReadableStream<Uint8Array>,
  options: { signal?: AbortSignal; maxBytes?: number; maxEventBytes?: number } = {},
): AsyncGenerator<SSEMessage> {
  const reader = body.getReader();
  const decoder = new TextDecoder("utf-8", { fatal: true });
  const encoder = new TextEncoder();
  let pending = "", event = "message", bytes = 0, eventBytes = 0;
  let data: string[] = [];
  const abort = () => { void reader.cancel().catch(() => undefined); };
  options.signal?.addEventListener("abort", abort, { once: true });
  try {
    while (true) {
      options.signal?.throwIfAborted();
      const chunk = await reader.read();
      options.signal?.throwIfAborted();
      bytes += chunk.value?.byteLength ?? 0;
      if (bytes > (options.maxBytes ?? 512_000)) throw new Error("The event stream exceeded its size limit.");
      pending += chunk.done ? decoder.decode() : decoder.decode(chunk.value, { stream: true });
      while (true) {
        options.signal?.throwIfAborted();
        const end = pending.search(/[\r\n]/);
        if (end < 0 || (!chunk.done && pending[end] === "\r" && end === pending.length - 1)) break;
        const line = pending.slice(0, end);
        pending = pending.slice(end + (pending[end] === "\r" && pending[end + 1] === "\n" ? 2 : 1));
        eventBytes += encoder.encode(line).byteLength;
        if (eventBytes > (options.maxEventBytes ?? 128_000)) throw new Error("An event exceeded its size limit.");
        if (line === "") {
          if (data.length) yield { event, data: data.join("\n") };
          data = []; event = "message"; eventBytes = 0;
          continue;
        }
        if (line.startsWith(":")) continue;
        const colon = line.indexOf(":");
        const field = colon < 0 ? line : line.slice(0, colon);
        const value = colon < 0 ? "" : line.slice(colon + 1).replace(/^ /, "");
        if (field === "data") data.push(value);
        if (field === "event") event = value || "message";
      }
      if (encoder.encode(pending).byteLength + eventBytes > (options.maxEventBytes ?? 128_000)) throw new Error("An event exceeded its size limit.");
      if (chunk.done) return;
    }
  } finally {
    options.signal?.removeEventListener("abort", abort);
    await reader.cancel().catch(() => undefined);
    reader.releaseLock();
  }
}
