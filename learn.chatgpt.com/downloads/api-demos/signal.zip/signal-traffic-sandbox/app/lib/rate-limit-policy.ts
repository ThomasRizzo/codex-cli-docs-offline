// Per-IP request allowances. Windows reset at UTC minute/day boundaries.
// Keep simulation allowances large enough for a complete normal run.
export const IP_LIMITS = {
  "traffic": {
    "minute": 180,
    "day": 1000
  },
  "control": {
    "minute": 20,
    "day": 100
  }
} as const;
