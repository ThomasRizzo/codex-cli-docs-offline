/** A deterministic, straight-through junction model. All time values are simulated seconds. */
export type Direction = "north" | "south" | "east" | "west";
export type ScenarioId = "balanced" | "morning_rush" | "evening_rush" | "school_crossing" | "bus_corridor" | "event_traffic";
export type PolicyId = "balanced" | "north_south_priority" | "east_west_priority" | "bus_priority" | "pedestrian_priority";
export type TrafficPhase = "north_south" | "east_west" | "pedestrians" | "clearance";
export type SignalColor = "green" | "amber" | "red";

export const DIRECTIONS: Direction[] = ["north", "south", "east", "west"];
export const WORLD_SIZE = 800;
export const STOP_LINE = 288;
export const CLEAR_LINE = 512;
export const VEHICLE_GAP = 12;
export const VEHICLE_SPEED = 60;
export const PEDESTRIAN_SPEED = 28;
export const FIXED_STEP = 0.05;
const AMBER_SECONDS = 3;
const MIN_CLEARANCE_SECONDS = 1;
const EPSILON = 1e-8;

export interface Scenario {
  id: ScenarioId;
  label: string;
  description: string;
  prompt: string;
  /** Synthetic arrivals per minute, by approach/crossing. */
  vehicleRates: Record<Direction, number>;
  pedestrianRates: Record<Direction, number>;
  busFractions: Record<Direction, number>;
}

const four = (north: number, south = north, east = north, west = east): Record<Direction, number> => ({ north, south, east, west });

export const SCENARIOS: readonly Scenario[] = [
  { id: "balanced", label: "Everyday traffic", description: "Steady demand from every direction.", prompt: "How is this junction performing?", vehicleRates: four(9), pedestrianRates: four(3), busFractions: four(0.04, 0.04, 0.1) },
  { id: "morning_rush", label: "Morning rush", description: "Commuters arrive along the north–south road.", prompt: "Help the north–south traffic during the morning rush.", vehicleRates: four(23, 19, 6), pedestrianRates: four(2), busFractions: four(0.06, 0.06, 0.08) },
  { id: "evening_rush", label: "Evening rush", description: "The east–west road carries the evening rush.", prompt: "Give the east–west road more time.", vehicleRates: four(7, 7, 21, 24), pedestrianRates: four(2), busFractions: four(0.04, 0.04, 0.12) },
  { id: "school_crossing", label: "School crossing", description: "More people are waiting to cross.", prompt: "Make it easier for people to cross the street.", vehicleRates: four(10, 10, 7), pedestrianRates: four(10), busFractions: four(0.03) },
  { id: "bus_corridor", label: "Bus corridor", description: "Frequent buses share the east–west road.", prompt: "Prioritize the buses without stopping cross traffic.", vehicleRates: four(10, 10, 15), pedestrianRates: four(3), busFractions: four(0.03, 0.03, 0.4) },
  { id: "event_traffic", label: "Event letting out", description: "Bursts of traffic and people leave a nearby venue.", prompt: "Help manage traffic leaving the event.", vehicleRates: four(12, 10, 19, 22), pedestrianRates: four(7), busFractions: four(0.04, 0.04, 0.14) },
];

export interface Policy {
  id: PolicyId;
  label: string;
  description: string;
  northSouthGreen: number;
  eastWestGreen: number;
  pedestrianGreen: number;
  maxBusExtension: number;
}

export const POLICIES: readonly Policy[] = [
  { id: "balanced", label: "Balanced", description: "Equal green time for both roads.", northSouthGreen: 18, eastWestGreen: 18, pedestrianGreen: 4, maxBusExtension: 0 },
  { id: "north_south_priority", label: "North–south priority", description: "Longer green for north–south traffic.", northSouthGreen: 30, eastWestGreen: 12, pedestrianGreen: 4, maxBusExtension: 0 },
  { id: "east_west_priority", label: "East–west priority", description: "Longer green for east–west traffic.", northSouthGreen: 12, eastWestGreen: 30, pedestrianGreen: 4, maxBusExtension: 0 },
  { id: "bus_priority", label: "Bus priority", description: "Favor the bus corridor, with a bounded green extension when a bus approaches.", northSouthGreen: 12, eastWestGreen: 22, pedestrianGreen: 4, maxBusExtension: 8 },
  { id: "pedestrian_priority", label: "Pedestrian priority", description: "Shorter vehicle phases and a longer protected crossing window.", northSouthGreen: 10, eastWestGreen: 10, pedestrianGreen: 7, maxBusExtension: 0 },
];

export interface Vehicle {
  id: number;
  direction: Direction;
  kind: "car" | "bus";
  /** Vehicle center, from the approach edge to the opposite edge. */
  progress: number;
  length: number;
  speed: number;
  enteredAt: number;
  waitTime: number;
}

export interface Pedestrian {
  id: number;
  crossing: Direction;
  /** Distance along a 224-unit crossing. */
  progress: number;
  enteredAt: number;
  waitTime: number;
}

interface WaitingVehicle { id: number; direction: Direction; kind: "car" | "bus"; enteredAt: number }
interface WaitingPedestrian { id: number; crossing: Direction; enteredAt: number }
interface ArrivalStream { random: number; nextAt: number }
interface Totals {
  vehiclesArrived: number;
  vehiclesCompleted: number;
  vehicleWaitSeconds: number;
  completedTravelSeconds: number;
  busesArrived: number;
  busesCompleted: number;
  busWaitSeconds: number;
  pedestriansArrived: number;
  pedestriansCompleted: number;
  pedestrianWaitSeconds: number;
}

export interface SimulationState {
  time: number;
  scenarioId: ScenarioId;
  policyId: PolicyId;
  pendingPolicyId: PolicyId | null;
  vehicles: Vehicle[];
  pedestrians: Pedestrian[];
  phase: TrafficPhase;
  signal: SignalColor;
  phaseRemaining: number;
  phaseElapsed: number;
  waitingPedestrians: Record<Direction, number>;
  totals: Totals;
  /** Arrival totals expose that the live and baseline runs receive identical demand. */
  arrivals: Record<Direction, number>;
  seed: number;
  tick: number;
  accumulator: number;
  nextPhase: Exclude<TrafficPhase, "clearance">;
  busExtensionUsed: boolean;
  nextId: number;
  vehicleStreams: Record<Direction, ArrivalStream>;
  pedestrianStreams: Record<Direction, ArrivalStream>;
  vehicleBacklog: Record<Direction, WaitingVehicle[]>;
  pedestrianBacklog: Record<Direction, WaitingPedestrian[]>;
  lastPedestrianEntry: Record<Direction, number>;
}

export interface SimulationMetrics {
  elapsedSeconds: number;
  vehiclesArrived: number;
  vehiclesCompleted: number;
  vehiclesWaiting: number;
  vehiclesInNetwork: number;
  /** Completed vehicles only; null until the first departure. Includes offscreen queue time. */
  meanTravelSeconds: number | null;
  /** Accumulated stationary queue delay divided by ALL vehicle arrivals, including unfinished trips. */
  meanQueueWaitSeconds: number;
  longestWaitSeconds: number;
  busesCompleted: number;
  busesWaiting: number;
  meanBusWaitSeconds: number;
  pedestriansArrived: number;
  pedestriansCompleted: number;
  pedestriansWaiting: number;
  meanPedestrianWaitSeconds: number;
  throughputPerMinute: number;
  queues: Record<Direction, number>;
}

export interface SimulationComparison { live: SimulationState; baseline: SimulationState }

function scenarioById(id: ScenarioId): Scenario {
  const scenario = SCENARIOS.find(item => item.id === id);
  if (!scenario) throw new Error("Unknown traffic scenario.");
  return scenario;
}

function policyById(id: PolicyId): Policy {
  const policy = POLICIES.find(item => item.id === id);
  if (!policy) throw new Error("Unknown traffic policy.");
  return policy;
}

/** One independent PRNG per demand stream. Signal choices never consume demand randomness. */
function random(stream: ArrivalStream): number {
  stream.random = (Math.imul(stream.random, 1664525) + 1013904223) >>> 0;
  return (stream.random + 0.5) / 4294967296;
}

function interval(stream: ArrivalStream, rate: number): number {
  return Math.max(0.25, -Math.log(1 - random(stream)) * 60 / rate);
}

function mapDirections<T>(factory: (direction: Direction, index: number) => T): Record<Direction, T> {
  return Object.fromEntries(DIRECTIONS.map((direction, index) => [direction, factory(direction, index)])) as Record<Direction, T>;
}

export function createSimulation(scenarioId: ScenarioId = "balanced", seed = 42): SimulationState {
  const scenario = scenarioById(scenarioId);
  if (!Number.isFinite(seed)) throw new Error("A finite simulation seed is required.");
  const normalizedSeed = seed >>> 0;
  const streams = (offset: number, rates: Record<Direction, number>) => mapDirections((direction, index) => {
    const stream = { random: (normalizedSeed ^ Math.imul(index + offset, 2654435761)) >>> 0, nextAt: 0 };
    stream.nextAt = interval(stream, rates[direction]);
    return stream;
  });
  const state: SimulationState = {
    time: 0, scenarioId, seed: normalizedSeed, tick: 0, accumulator: 0,
    policyId: "balanced", pendingPolicyId: null,
    vehicles: [], pedestrians: [], phase: "north_south", signal: "green", phaseRemaining: 18, phaseElapsed: 0,
    nextPhase: "east_west", busExtensionUsed: false, nextId: 1,
    waitingPedestrians: four(0), arrivals: four(0),
    vehicleStreams: streams(1, scenario.vehicleRates), pedestrianStreams: streams(9, scenario.pedestrianRates),
    vehicleBacklog: mapDirections(() => []), pedestrianBacklog: mapDirections(() => []), lastPedestrianEntry: four(-Infinity),
    totals: { vehiclesArrived: 0, vehiclesCompleted: 0, vehicleWaitSeconds: 0, completedTravelSeconds: 0, busesArrived: 0, busesCompleted: 0, busWaitSeconds: 0, pedestriansArrived: 0, pedestriansCompleted: 0, pedestrianWaitSeconds: 0 },
  };
  // A visible initial approach, counted as demand at t=0 in both runs.
  for (const direction of DIRECTIONS) {
    for (const progress of [45, 125, 205]) {
      const kind = random(state.vehicleStreams[direction]) < scenario.busFractions[direction] ? "bus" : "car";
      state.vehicles.push({ id: state.nextId++, direction, kind, progress, length: kind === "bus" ? 32 : 18, speed: 0, enteredAt: 0, waitTime: 0 });
      state.totals.vehiclesArrived++;
      state.arrivals[direction]++;
      if (kind === "bus") state.totals.busesArrived++;
    }
    state.pedestrianBacklog[direction].push({ id: state.nextId++, crossing: direction, enteredAt: 0 });
    state.waitingPedestrians[direction] = 1;
    state.totals.pedestriansArrived++;
  }
  return state;
}

/** Request a bounded preset. It becomes active only after the current phase safely clears. */
export function setPolicy(state: SimulationState, policyId: PolicyId): SimulationState {
  policyById(policyId);
  state.pendingPolicyId = policyId === state.policyId ? null : policyId;
  return state;
}

function addDemand(state: SimulationState): void {
  const scenario = scenarioById(state.scenarioId);
  for (const direction of DIRECTIONS) {
    const stream = state.vehicleStreams[direction];
    while (stream.nextAt <= state.time + EPSILON) {
      const kind = random(stream) < scenario.busFractions[direction] ? "bus" : "car";
      state.vehicleBacklog[direction].push({ id: state.nextId++, direction, kind, enteredAt: stream.nextAt });
      state.totals.vehiclesArrived++;
      state.arrivals[direction]++;
      if (kind === "bus") state.totals.busesArrived++;
      const burst = state.scenarioId === "event_traffic" && stream.nextAt % 90 < 25 ? 1.65 : 1;
      stream.nextAt += interval(stream, scenario.vehicleRates[direction] * burst);
    }
    const pedestrianStream = state.pedestrianStreams[direction];
    while (pedestrianStream.nextAt <= state.time + EPSILON) {
      state.pedestrianBacklog[direction].push({ id: state.nextId++, crossing: direction, enteredAt: pedestrianStream.nextAt });
      state.totals.pedestriansArrived++;
      pedestrianStream.nextAt += interval(pedestrianStream, scenario.pedestrianRates[direction]);
    }
  }
}

function vehicleInJunction(vehicle: Vehicle): boolean {
  return vehicle.progress + vehicle.length / 2 > STOP_LINE + EPSILON && vehicle.progress - vehicle.length / 2 < CLEAR_LINE - EPSILON;
}

function beginPhase(state: SimulationState, phase: Exclude<TrafficPhase, "clearance">): void {
  if (state.pendingPolicyId) {
    state.policyId = state.pendingPolicyId;
    state.pendingPolicyId = null;
  }
  const policy = policyById(state.policyId);
  state.phase = phase;
  state.signal = "green";
  state.phaseElapsed = 0;
  state.busExtensionUsed = false;
  state.phaseRemaining = phase === "north_south" ? policy.northSouthGreen : phase === "east_west" ? policy.eastWestGreen : policy.pedestrianGreen;
}

function enterClearance(state: SimulationState, nextPhase: Exclude<TrafficPhase, "clearance">): void {
  state.phase = "clearance";
  state.signal = "red";
  state.phaseElapsed = 0;
  state.phaseRemaining = MIN_CLEARANCE_SECONDS;
  state.nextPhase = nextPhase;
}

function updatePhase(state: SimulationState): void {
  state.phaseElapsed += FIXED_STEP;
  state.phaseRemaining = Math.max(0, state.phaseRemaining - FIXED_STEP);
  if (state.phase === "clearance") {
    if (state.phaseRemaining <= EPSILON && !state.vehicles.some(vehicleInJunction) && state.pedestrians.length === 0) {
      const next = state.nextPhase === "pedestrians" && !DIRECTIONS.some(direction => state.pedestrianBacklog[direction].length > 0) ? "north_south" : state.nextPhase;
      beginPhase(state, next);
    }
    return;
  }
  if (state.signal === "green" && state.phase === "east_west" && !state.busExtensionUsed && state.phaseRemaining <= 2 + EPSILON) {
    const extension = policyById(state.policyId).maxBusExtension;
    const approachingBus = state.vehicles.some(vehicle => vehicle.kind === "bus" && (vehicle.direction === "east" || vehicle.direction === "west") && vehicle.progress <= STOP_LINE);
    if (extension > 0 && approachingBus) {
      state.phaseRemaining += extension;
      state.busExtensionUsed = true;
    }
  }
  if (state.phaseRemaining > EPSILON) return;
  if (state.phase === "pedestrians") {
    enterClearance(state, "north_south");
  } else if (state.signal === "green") {
    state.signal = "amber";
    state.phaseElapsed = 0;
    state.phaseRemaining = AMBER_SECONDS;
  } else {
    enterClearance(state, state.phase === "north_south" ? "east_west" : "pedestrians");
  }
}

function canEnter(state: SimulationState, direction: Direction): boolean {
  return state.signal === "green" && (state.phase === "north_south" ? direction === "north" || direction === "south" : state.phase === "east_west" ? direction === "east" || direction === "west" : false);
}

function moveVehicles(state: SimulationState): void {
  const completed = new Set<number>();
  for (const direction of DIRECTIONS) {
    const lane = state.vehicles.filter(vehicle => vehicle.direction === direction).sort((a, b) => b.progress - a.progress);
    const backlog = state.vehicleBacklog[direction];
    // Queue time outside the drawn area is included, rather than silently dropping demand.
    state.totals.vehicleWaitSeconds += backlog.length * FIXED_STEP;
    state.totals.busWaitSeconds += backlog.filter(vehicle => vehicle.kind === "bus").length * FIXED_STEP;
    let leader: Vehicle | undefined;
    for (const vehicle of lane) {
      let limit = leader ? leader.progress - leader.length / 2 - VEHICLE_GAP - vehicle.length / 2 : Infinity;
      if (!canEnter(state, direction) && vehicle.progress + vehicle.length / 2 <= STOP_LINE + EPSILON) limit = Math.min(limit, STOP_LINE - vehicle.length / 2);
      const desiredSpeed = Math.min(VEHICLE_SPEED, vehicle.speed + 60 * FIXED_STEP);
      const distance = Math.max(0, Math.min(desiredSpeed * FIXED_STEP, limit - vehicle.progress));
      vehicle.speed = distance / FIXED_STEP;
      vehicle.progress += distance;
      if (vehicle.speed < 1 && vehicle.progress <= STOP_LINE) {
        vehicle.waitTime += FIXED_STEP;
        state.totals.vehicleWaitSeconds += FIXED_STEP;
        if (vehicle.kind === "bus") state.totals.busWaitSeconds += FIXED_STEP;
      }
      if (vehicle.progress - vehicle.length / 2 >= WORLD_SIZE) {
        completed.add(vehicle.id);
        state.totals.vehiclesCompleted++;
        state.totals.completedTravelSeconds += state.time - vehicle.enteredAt;
        if (vehicle.kind === "bus") state.totals.busesCompleted++;
      }
      leader = vehicle;
    }
    if (backlog.length) {
      const first = backlog[0];
      const length = first.kind === "bus" ? 32 : 18;
      const tail = lane.at(-1);
      if (!tail || tail.progress - tail.length / 2 >= VEHICLE_GAP + length) {
        backlog.shift();
        state.vehicles.push({ ...first, progress: length / 2, length, speed: 0, waitTime: Math.max(0, state.time - first.enteredAt) });
      }
    }
  }
  if (completed.size) state.vehicles = state.vehicles.filter(vehicle => !completed.has(vehicle.id));
}

function movePedestrians(state: SimulationState): void {
  state.pedestrians = state.pedestrians.filter(pedestrian => {
    pedestrian.progress += PEDESTRIAN_SPEED * FIXED_STEP;
    if (pedestrian.progress >= CLEAR_LINE - STOP_LINE) {
      state.totals.pedestriansCompleted++;
      return false;
    }
    return true;
  });
  for (const crossing of DIRECTIONS) {
    const backlog = state.pedestrianBacklog[crossing];
    state.totals.pedestrianWaitSeconds += backlog.length * FIXED_STEP;
    if (backlog.length && state.phase === "pedestrians" && state.signal === "green" && state.time - state.lastPedestrianEntry[crossing] >= 0.8 - EPSILON) {
      const pedestrian = backlog.shift()!;
      state.pedestrians.push({ ...pedestrian, progress: 0, waitTime: Math.max(0, state.time - pedestrian.enteredAt) });
      state.lastPedestrianEntry[crossing] = state.time;
    }
    state.waitingPedestrians[crossing] = backlog.length;
  }
}

/** Fixed 50ms physics makes frame chunking deterministic and prevents large-frame tunneling. */
export function stepSimulation(state: SimulationState, dt: number): SimulationState {
  if (!Number.isFinite(dt) || dt < 0 || dt > 60) throw new Error("Simulation steps must be between 0 and 60 seconds.");
  state.accumulator += dt;
  const ticks = Math.floor((state.accumulator + EPSILON) / FIXED_STEP);
  state.accumulator = Math.max(0, state.accumulator - ticks * FIXED_STEP);
  for (let index = 0; index < ticks; index++) {
    state.tick++;
    state.time = state.tick * FIXED_STEP;
    addDemand(state);
    updatePhase(state);
    moveVehicles(state);
    movePedestrians(state);
  }
  return state;
}

export function metrics(state: SimulationState): SimulationMetrics {
  const queues = mapDirections(direction => state.vehicleBacklog[direction].length);
  let busesWaiting = 0;
  let longestWaitSeconds = 0;
  for (const direction of DIRECTIONS) {
    const backlog = state.vehicleBacklog[direction];
    busesWaiting += backlog.filter(vehicle => vehicle.kind === "bus").length;
    if (backlog.length) longestWaitSeconds = Math.max(longestWaitSeconds, state.time - backlog[0].enteredAt);
  }
  for (const vehicle of state.vehicles) {
    longestWaitSeconds = Math.max(longestWaitSeconds, vehicle.waitTime);
    if (vehicle.speed < 1 && vehicle.progress <= STOP_LINE) {
      queues[vehicle.direction]++;
      if (vehicle.kind === "bus") busesWaiting++;
    }
  }
  const totals = state.totals;
  return {
    elapsedSeconds: state.time,
    vehiclesArrived: totals.vehiclesArrived,
    vehiclesCompleted: totals.vehiclesCompleted,
    vehiclesWaiting: DIRECTIONS.reduce((sum, direction) => sum + queues[direction], 0),
    vehiclesInNetwork: totals.vehiclesArrived - totals.vehiclesCompleted,
    meanTravelSeconds: totals.vehiclesCompleted ? totals.completedTravelSeconds / totals.vehiclesCompleted : null,
    meanQueueWaitSeconds: totals.vehiclesArrived ? totals.vehicleWaitSeconds / totals.vehiclesArrived : 0,
    longestWaitSeconds,
    busesCompleted: totals.busesCompleted,
    busesWaiting,
    meanBusWaitSeconds: totals.busesArrived ? totals.busWaitSeconds / totals.busesArrived : 0,
    pedestriansArrived: totals.pedestriansArrived,
    pedestriansCompleted: totals.pedestriansCompleted,
    pedestriansWaiting: DIRECTIONS.reduce((sum, direction) => sum + state.waitingPedestrians[direction], 0),
    meanPedestrianWaitSeconds: totals.pedestriansArrived ? totals.pedestrianWaitSeconds / totals.pedestriansArrived : 0,
    throughputPerMinute: state.time > 0 ? totals.vehiclesCompleted / state.time * 60 : 0,
    queues,
  };
}

export function createComparison(scenarioId: ScenarioId = "balanced", seed = 42): SimulationComparison {
  return { live: createSimulation(scenarioId, seed), baseline: createSimulation(scenarioId, seed) };
}

export function stepComparison(comparison: SimulationComparison, dt: number): SimulationComparison {
  stepSimulation(comparison.live, dt);
  stepSimulation(comparison.baseline, dt);
  return comparison;
}
