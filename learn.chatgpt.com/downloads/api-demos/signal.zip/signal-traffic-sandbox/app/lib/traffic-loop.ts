import { RequestCooldown } from "./request-cooldown";
import { RUN_LIMIT_SECONDS } from "./run-budget";
import type { VehicleObservation } from "./traffic-engine";
import type { TrafficReceipt } from "./traffic-contract";

export class TrafficRequestError extends Error {
  constructor(message: string, public retryAfterMs = 0, public fatal = false) { super(message); }
}

type Pending = { controller: AbortController; vehicles: VehicleObservation[]; started: number };
type Callbacks = {
  candidates: (excluded: Set<number>, count: number) => VehicleObservation[];
  submit: (vehicles: VehicleObservation[], signal: AbortSignal) => Promise<TrafficReceipt>;
  nextId: () => number;
  started: (id: number, vehicles: VehicleObservation[]) => void;
  completed: (id: number, vehicles: VehicleObservation[], receipt: TrafficReceipt, ageMs: number) => void;
  failed: (id: number, error: Error) => void;
  stopped: (ids: number[]) => void;
  backoff: (until: number, fatal: boolean) => void;
};

/** Wall-clock scheduling, independent of animation frames and simulation speed. */
export class TrafficDecisionLoop {
  private pending = new Map<number, Pending>();
  private closed = false;
  private nextAt = -Infinity;
  private failures = 0;
  private cooldown: RequestCooldown;
  constructor(private callbacks: Callbacks, private now: () => number = () => performance.now(), cooldown?: RequestCooldown) {
    this.cooldown = cooldown ?? new RequestCooldown(now);
  }

  tick(): void {
    const now = this.now();
    if (this.closed || now < this.nextAt || this.cooldown.active || this.pending.size >= 2) return;
    const excluded = new Set([...this.pending.values()].flatMap(item => item.vehicles.map(vehicle => vehicle.id)));
    const vehicles = this.callbacks.candidates(excluded, 4);
    if (!vehicles.length) return;
    const id = this.callbacks.nextId();
    const controller = new AbortController();
    this.pending.set(id, { controller, vehicles, started: now });
    this.nextAt = now + 500;
    this.callbacks.started(id, vehicles);
    void this.run(id);
  }

  private async run(id: number): Promise<void> {
    const item = this.pending.get(id)!;
    try {
      const receipt = await this.callbacks.submit(item.vehicles, item.controller.signal);
      if (this.closed || item.controller.signal.aborted) return;
      this.failures = 0;
      this.callbacks.completed(id, item.vehicles, receipt, this.now() - item.started);
    } catch (error) {
      if (this.closed || item.controller.signal.aborted) return;
      const problem = error instanceof Error ? error : new Error("The request was interrupted.");
      const fatal = problem instanceof TrafficRequestError && (problem.fatal || problem.retryAfterMs >= RUN_LIMIT_SECONDS * 1_000);
      this.failures += 1;
      const delay = Math.max(2_000 * 2 ** Math.min(this.failures - 1, 4), problem instanceof TrafficRequestError ? problem.retryAfterMs : 0);
      this.cooldown.defer(delay, problem.message);
      this.callbacks.failed(id, problem);
      this.callbacks.backoff(this.cooldown.until, fatal);
      if (fatal) this.stop();
    } finally {
      this.pending.delete(id);
    }
  }

  stop(): void {
    if (this.closed) return;
    this.closed = true;
    const ids = [...this.pending.keys()];
    for (const item of this.pending.values()) item.controller.abort();
    this.pending.clear();
    if (ids.length) this.callbacks.stopped(ids);
  }
}
