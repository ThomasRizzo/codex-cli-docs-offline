"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { applyVehicleDecision, createTraffic, decisionCandidates, stepTraffic, type TrafficScenarioId, type TrafficState, type VehicleObservation, type Maneuver } from "./traffic-engine";
import { trafficReceiptSchema, type TrafficReceipt } from "./traffic-contract";
import { TrafficDecisionLoop, TrafficRequestError } from "./traffic-loop";
import { useSoundEffects } from "./use-sound-effects";
import { RequestCooldown, retryAfterMs } from "./request-cooldown";
import { ActiveRunBudget, RUN_LIMIT_SECONDS } from "./run-budget";

type Outcome = { vehicleId: number; action: Maneuver; status: "applied" | "blocked" | "stale"; reason: string };
export type TrafficBatchLog = {
  id: number; startedAt: number; status: "pending" | "complete" | "failed" | "stopped";
  vehicleIds: number[]; receipt?: TrafficReceipt; outcomes?: Outcome[]; error?: string;
};
type Totals = { requests: number; decisions: number; applied: number; blocked: number; latencyTotal: number; completedRequests: number };
const emptyTotals = (): Totals => ({ requests: 0, decisions: 0, applied: 0, blocked: 0, latencyTotal: 0, completedRequests: 0 });
const copyWorld = (state: TrafficState): TrafficState => ({ ...state, vehicles: state.vehicles.map(vehicle => ({ ...vehicle })) });

async function requestDecisions(scenario: TrafficScenarioId, vehicles: VehicleObservation[], signal: AbortSignal): Promise<TrafficReceipt> {
  const response = await fetch("/api/traffic", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ scenario, vehicles }), signal: AbortSignal.any([signal, AbortSignal.timeout(10_000)]),
  });
  const text = await response.text();
  if (text.length > 65_536) throw new TrafficRequestError("The decision receipt was too large.");
  let value: unknown;
  try { value = JSON.parse(text); } catch { throw new TrafficRequestError("The decision receipt was interrupted. Retrying shortly."); }
  if (!response.ok) {
    const message = value && typeof value === "object" && "error" in value && typeof value.error === "string" ? value.error : "The traffic API is unavailable. Try again.";
    throw new TrafficRequestError(message, retryAfterMs(response.headers.get("Retry-After")), [401, 403, 503].includes(response.status));
  }
  const receipt = trafficReceiptSchema.parse(value);
  if (receipt.choices.length !== vehicles.length || new Set(receipt.choices.map(choice => choice.vehicleId)).size !== vehicles.length
    || receipt.choices.some(choice => !vehicles.some(vehicle => vehicle.id === choice.vehicleId && vehicle.revision === choice.revision))) {
    throw new TrafficRequestError("The returned decisions did not match these vehicles.");
  }
  return receipt;
}

export function useTrafficLab() {
  const { soundEnabled, toggleSound, playSound, cancelSounds } = useSoundEffects();
  const worldRef = useRef<TrafficState | null>(null);
  if (!worldRef.current) worldRef.current = createTraffic("market", 42);
  const [world, setWorld] = useState(() => copyWorld(worldRef.current!));
  const [scenarioId, setScenarioId] = useState<TrafficScenarioId>("market");
  const [running, setRunning] = useState(false);
  const [runComplete, setRunComplete] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [runGeneration, setRunGeneration] = useState(0);
  const [logs, setLogs] = useState<TrafficBatchLog[]>([]);
  const [pendingIds, setPendingIds] = useState<number[]>([]);
  const [selectedVehicleId, selectVehicle] = useState<number | null>(null);
  const [totals, setTotals] = useState<Totals>(emptyTotals);
  const [error, setError] = useState<string | null>(null);
  const [retrying, setRetrying] = useState(false);
  const [rates, setRates] = useState({ requestsPerSecond: 0, decisionsPerSecond: 0 });
  const loopRef = useRef<TrafficDecisionLoop | null>(null);
  const nextId = useRef(0);
  const pending = useRef(new Map<number, number[]>());
  const recent = useRef<{ at: number; requests: number; decisions: number }[]>([]);
  const cooldown = useRef(0);
  const requestCooldown = useRef(new RequestCooldown());
  const lastSound = useRef(-Infinity);
  const budgetRef = useRef<ActiveRunBudget | null>(null);
  if (!budgetRef.current) budgetRef.current = new ActiveRunBudget();

  const refreshPending = useCallback(() => setPendingIds([...pending.current.values()].flat()), []);
  const updateLog = useCallback((id: number, change: Partial<TrafficBatchLog>) => {
    setLogs(items => items.map(item => item.id === id ? { ...item, ...change } : item));
  }, []);

  useEffect(() => {
    if (!running) return;
    const activeWorld = worldRef.current!;
    const budget = budgetRef.current!;
    if (document.hidden || !budget.start()) {
      setRunning(false);
      setRunComplete(budget.expired);
      if (budget.expired) setElapsedSeconds(RUN_LIMIT_SECONDS);
      return;
    }
    let ended = false;
    const finishRun = () => {
      if (ended || worldRef.current !== activeWorld || !budget.expired) return;
      ended = true;
      budget.pause();
      loopRef.current?.stop();
      cooldown.current = 0;
      cancelSounds();
      setRetrying(false);
      setError(null);
      setElapsedSeconds(RUN_LIMIT_SECONDS);
      setRunComplete(true);
      setRunning(false);
      setWorld(copyWorld(activeWorld));
    };
    const mayContinue = () => {
      if (ended) return false;
      if (budget.expired) { finishRun(); return false; }
      return budget.running && worldRef.current === activeWorld;
    };
    const loop = new TrafficDecisionLoop({
      candidates: (excluded, count) => mayContinue() ? decisionCandidates(activeWorld, excluded, count) : [],
      submit: (vehicles, signal) => {
        if (!mayContinue()) return Promise.reject(new DOMException("This run has ended.", "AbortError"));
        return requestDecisions(activeWorld.scenarioId, vehicles, signal);
      },
      nextId: () => ++nextId.current,
      started: (id, vehicles) => {
        pending.current.set(id, vehicles.map(vehicle => vehicle.id));
        refreshPending();
        setLogs(items => [{ id, startedAt: Date.now(), status: "pending" as const, vehicleIds: vehicles.map(vehicle => vehicle.id) }, ...items].slice(0, 72));
        setTotals(previous => ({ ...previous, requests: previous.requests + 1 }));
        recent.current.push({ at: performance.now(), requests: 1, decisions: 0 });
      },
      completed: (id, observations, receipt, ageMs) => {
        if (!mayContinue()) return;
        const outcomes: Outcome[] = [];
        for (const choice of receipt.choices) {
          if (!choice.action) continue;
          const observation = observations.find(vehicle => vehicle.id === choice.vehicleId)!;
          outcomes.push(ageMs > 3_000
            ? { vehicleId: choice.vehicleId, action: choice.action, status: "stale", reason: "The traffic changed while this request was running." }
            : applyVehicleDecision(activeWorld, observation, choice.action, receipt.requestId));
        }
        const decisions = receipt.choices.filter(choice => choice.action !== null).length;
        updateLog(id, { status: "complete", receipt, outcomes });
        pending.current.delete(id); refreshPending();
        setTotals(previous => ({ ...previous, decisions: previous.decisions + decisions,
          applied: previous.applied + outcomes.filter(outcome => outcome.status === "applied").length,
          blocked: previous.blocked + outcomes.filter(outcome => outcome.status !== "applied").length,
          latencyTotal: previous.latencyTotal + receipt.durationMs, completedRequests: previous.completedRequests + 1 }));
        recent.current.push({ at: performance.now(), requests: 0, decisions });
        if (!requestCooldown.current.active) setError(null);
        if (performance.now() - lastSound.current > 2_500 && outcomes.some(outcome => outcome.status === "applied" && ["left", "right"].includes(outcome.action))) {
          playSound("phase"); lastSound.current = performance.now();
        }
      },
      failed: (id, problem) => {
        if (!mayContinue()) return;
        updateLog(id, { status: "failed", error: problem.message });
        pending.current.delete(id); refreshPending();
        setError(problem.message);
      },
      stopped: ids => {
        setLogs(items => items.map(item => ids.includes(item.id) && item.status === "pending" ? { ...item, status: "stopped" } : item));
        for (const id of ids) pending.current.delete(id);
        refreshPending();
      },
      backoff: (until, fatal) => {
        if (!mayContinue()) return;
        cooldown.current = until; setRetrying(!fatal);
        if (fatal) { budget.pause(); setRunning(false); }
      },
    }, () => performance.now(), requestCooldown.current);
    loopRef.current = loop;
    let frame = 0, previous = performance.now(), rendered = previous;
    const tick = (now: number) => {
      if (!mayContinue()) return;
      if (!document.hidden) {
        stepTraffic(activeWorld, Math.min(.12, Math.max(0, (now - previous) / 1000)));
        if (now - rendered >= 33) { setWorld(copyWorld(activeWorld)); rendered = now; }
      }
      previous = now;
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    loop.tick();
    const deadline = setTimeout(finishRun, budget.remainingMs);
    const scheduler = setInterval(() => {
      if (document.hidden || !mayContinue()) return;
      setElapsedSeconds(Math.floor(budget.elapsedMs / 1_000));
      loop.tick();
      if (cooldown.current && performance.now() >= cooldown.current) { cooldown.current = 0; setRetrying(false); }
    }, 100);
    const hide = () => {
      if (!document.hidden) return;
      budget.pause(); loop.stop();
      setElapsedSeconds(Math.floor(budget.elapsedMs / 1_000));
      setRunning(false); setRetrying(false); cooldown.current = 0;
      if (budget.expired) finishRun();
    };
    document.addEventListener("visibilitychange", hide);
    return () => {
      cancelAnimationFrame(frame); clearInterval(scheduler); clearTimeout(deadline); document.removeEventListener("visibilitychange", hide);
      budget.pause();
      loop.stop();
      if (loopRef.current === loop) loopRef.current = null;
    };
  }, [running, scenarioId, runGeneration, playSound, cancelSounds, refreshPending, updateLog]);

  useEffect(() => {
    const timer = setInterval(() => {
      const cutoff = performance.now() - 5_000;
      recent.current = recent.current.filter(event => event.at >= cutoff);
      setRates({ requestsPerSecond: recent.current.reduce((total, event) => total + event.requests, 0) / 5,
        decisionsPerSecond: recent.current.reduce((total, event) => total + event.decisions, 0) / 5 });
    }, 500);
    return () => clearInterval(timer);
  }, []);

  const resetTo = useCallback((scenario: TrafficScenarioId) => {
    budgetRef.current!.pause();
    loopRef.current?.stop(); setRunning(false);
    budgetRef.current = new ActiveRunBudget();
    setRunComplete(false); setElapsedSeconds(0);
    setRunGeneration(value => value + 1);
    cancelSounds(); playSound("tap");
    worldRef.current = createTraffic(scenario, 42);
    setWorld(copyWorld(worldRef.current)); setScenarioId(scenario);
    pending.current.clear(); setPendingIds([]);
    setLogs([]); setTotals(emptyTotals()); setError(requestCooldown.current.active ? requestCooldown.current.message : null); setRetrying(false);
    selectVehicle(null); recent.current = []; cooldown.current = 0;
    setRates({ requestsPerSecond: 0, decisionsPerSecond: 0 });
  }, [cancelSounds, playSound]);

  const toggleRunning = useCallback(() => {
    if (!running && requestCooldown.current.active) {
      setError(requestCooldown.current.message);
      return;
    }
    if (runComplete || (!running && budgetRef.current!.expired)) {
      resetTo(scenarioId);
      setRunning(true);
      return;
    }
    cancelSounds(); playSound("tap");
    if (running) {
      budgetRef.current!.pause();
      setElapsedSeconds(Math.floor(budgetRef.current!.elapsedMs / 1_000));
      if (budgetRef.current!.expired) setRunComplete(true);
      loopRef.current?.stop();
    } else setError(null);
    setRetrying(false); cooldown.current = 0;
    setRunning(!running);
  }, [running, runComplete, scenarioId, resetTo, cancelSounds, playSound]);

  return {
    world, scenarioId, setScenario: resetTo, running, toggleRunning, reset: () => resetTo(scenarioId),
    pendingIds, selectedVehicleId, selectVehicle, logs, error, retrying, soundEnabled, toggleSound,
    runComplete, elapsedSeconds, runLimitSeconds: RUN_LIMIT_SECONDS,
    stats: { requests: totals.requests, decisions: totals.decisions, applied: totals.applied, blocked: totals.blocked,
      averageLatency: totals.completedRequests ? totals.latencyTotal / totals.completedRequests : 0, ...rates },
  };
}
