/** Deterministic local physics. Only accepted API actions initiate driving or a lane change. */
export const WORLD_WIDTH = 800;
export const WORLD_HEIGHT = 500;
export const LANE_CENTERS = [170, 220, 270, 340] as const;
export const TRAFFIC_STEP = 0.05;
export const MINIMUM_GAP = 7;
export const ACTION_LEASE_SECONDS = 6;
const LANE_CHANGE_SECONDS = 1.4;
const MAX_OBSERVATION_AGE = 4;
const STOP_BUFFER = 4;
const EPSILON = 1e-8;

export type TrafficScenarioId = "market" | "rush" | "bottleneck";
export type Maneuver = "advance" | "yield" | "left" | "right";
export type Lane = 0 | 1 | 2 | 3;
export type VehicleKind = "car" | "bus" | "scooter" | "rickshaw";

export const TRAFFIC_SCENARIOS: readonly { id: TrafficScenarioId; label: string; description: string }[] = [
  { id: "market", label: "Market rush", description: "Scooters, rickshaws, cars, and buses negotiate a busy merge." },
  { id: "rush", label: "Rush hour", description: "Dense commuter traffic shares the road with slower buses." },
  { id: "bottleneck", label: "Lane squeeze", description: "A closing lane and a busy feeder compete for the same gaps." },
];

export interface TrafficVehicle {
  id: number;
  kind: VehicleKind;
  x: number;
  lane: Lane;
  targetLane: Lane | null;
  laneProgress: number;
  speed: number;
  desiredSpeed: number;
  length: number;
  width: number;
  decisionRevision: number;
  lastDecisionAt: number;
  leaseUntil: number;
  lastAction: Maneuver | null;
  lastRequestId?: string;
  highlightUntil: number;
}

export interface TrafficState {
  time: number;
  scenarioId: TrafficScenarioId;
  vehicles: TrafficVehicle[];
  completed: number;
  merges: number;
  blocked: number;
  tick: number;
  accumulator: number;
  seed: number;
  randomState: number;
  nextId: number;
  nextArrivalAt: number;
  arrivals: number;
  pendingDemand: Record<Lane, number>;
  waitingSeconds: Record<number, number>;
}

export interface AdjacentObservation { available: boolean; frontGap: number; rearGap: number }
export interface VehicleObservation {
  id: number;
  revision: number;
  observedAt: number;
  kind: VehicleKind;
  x: number;
  lane: Lane;
  speed: number;
  desiredSpeed: number;
  distanceToLaneEnd: number;
  frontGap: number;
  waitingSeconds: number;
  left: AdjacentObservation;
  right: AdjacentObservation;
}
export interface AppliedDecision {
  vehicleId: number;
  action: Maneuver;
  status: "applied" | "blocked" | "stale";
  reason: string;
}

const sizes: Record<VehicleKind, { length: number; width: number; speed: number }> = {
  car: { length: 22, width: 12, speed: 34 },
  bus: { length: 36, width: 16, speed: 23 },
  scooter: { length: 12, width: 6, speed: 40 },
  rickshaw: { length: 17, width: 10, speed: 29 },
};
const populationLimits = { market: 28, rush: 32, bottleneck: 30 };
const laneEnd = (lane: Lane) => lane === 3 ? 340 : lane === 2 ? 600 : Infinity;
const occupiedLanes = (vehicle: TrafficVehicle): Lane[] => vehicle.targetLane === null ? [vehicle.lane] : [vehicle.lane, vehicle.targetLane];
const gapValue = (gap: number) => Math.min(999, Math.max(0, Number.isFinite(gap) ? gap : 999));

function random(state: TrafficState): number {
  state.randomState = (Math.imul(state.randomState, 1664525) + 1013904223) >>> 0;
  return (state.randomState + 0.5) / 4294967296;
}

function createVehicle(state: TrafficState, lane: Lane, x: number): TrafficVehicle {
  const roll = random(state);
  const kind: VehicleKind = roll < .14 ? "bus" : roll < (state.scenarioId === "rush" ? .32 : .49) ? "scooter" : roll < .65 ? "rickshaw" : "car";
  const size = sizes[kind];
  const vehicle: TrafficVehicle = {
    id: state.nextId++, kind, x, lane, targetLane: null, laneProgress: 0,
    speed: 0, desiredSpeed: size.speed + Math.floor(random(state) * 5), length: size.length, width: size.width,
    decisionRevision: 0, lastDecisionAt: -1, leaseUntil: 0, lastAction: null, highlightUntil: 0,
  };
  state.waitingSeconds[vehicle.id] = 0;
  return vehicle;
}

export function createTraffic(scenarioId: TrafficScenarioId = "market", seed = 42): TrafficState {
  if (!TRAFFIC_SCENARIOS.some(scenario => scenario.id === scenarioId)) throw new Error("Unknown traffic scenario.");
  if (!Number.isFinite(seed)) throw new Error("A finite seed is required.");
  const state: TrafficState = {
    time: 0, scenarioId, vehicles: [], completed: 0, merges: 0, blocked: 0, tick: 0, accumulator: 0,
    seed: seed >>> 0, randomState: seed >>> 0, nextId: 1, nextArrivalAt: 1.5, arrivals: 0,
    pendingDemand: { 0: 0, 1: 0, 2: 0, 3: 0 }, waitingSeconds: {},
  };
  // Staggered poses leave real, visible gaps for merges rather than overlapping reservations.
  const positions: Record<Lane, number[]> = {
    0: [42, 122, 202, 282, 362, 442, 522, 602],
    1: [80, 160, 240, 320, 400, 480, 560, 640],
    2: [42, 117, 192, 267, 342, 417, 492],
    3: [42, 117, 192, 267],
  };
  for (const lane of [0, 1, 2, 3] as const) {
    for (const x of positions[lane]) state.vehicles.push(createVehicle(state, lane, x));
  }
  state.arrivals = state.vehicles.length;
  return state;
}

interface LaneGaps { front: number; rear: number; frontSpeed: number; rearSpeed: number }
function gapsInLane(state: TrafficState, vehicle: TrafficVehicle, lane: Lane): LaneGaps {
  let front = Infinity, rear = Infinity, frontSpeed = vehicle.desiredSpeed, rearSpeed = 0;
  for (const other of state.vehicles) {
    if (other.id === vehicle.id || !occupiedLanes(other).includes(lane)) continue;
    if (other.x >= vehicle.x) {
      const gap = other.x - other.length / 2 - vehicle.x - vehicle.length / 2;
      if (gap < front) { front = gap; frontSpeed = other.speed; }
    } else {
      const gap = vehicle.x - vehicle.length / 2 - other.x - other.length / 2;
      if (gap < rear) { rear = gap; rearSpeed = other.speed; }
    }
  }
  const endGap = laneEnd(lane) - STOP_BUFFER - vehicle.x - vehicle.length / 2;
  if (endGap < front) { front = endGap; frontSpeed = 0; }
  return { front, rear, frontSpeed, rearSpeed };
}

function adjacent(state: TrafficState, vehicle: TrafficVehicle, direction: -1 | 1): AdjacentObservation {
  const target = vehicle.lane + direction;
  // The feeder is an entry road; through traffic cannot use it as an overtaking lane.
  if (target < 0 || target > 2 || vehicle.targetLane !== null) return { available: false, frontGap: 0, rearGap: 0 };
  const gaps = gapsInLane(state, vehicle, target as Lane);
  const frontRequired = MINIMUM_GAP + vehicle.speed * .15 + Math.max(0, vehicle.speed - gaps.frontSpeed) * .5;
  const rearRequired = MINIMUM_GAP + gaps.rearSpeed * .15 + Math.max(0, gaps.rearSpeed - vehicle.speed) * .5;
  return { available: gaps.front >= frontRequired && gaps.rear >= rearRequired,
    frontGap: gapValue(gaps.front), rearGap: gapValue(gaps.rear) };
}

export function vehicleY(vehicle: TrafficVehicle): number {
  const origin = LANE_CENTERS[vehicle.lane];
  if (vehicle.targetLane === null) return origin;
  const progress = Math.min(1, Math.max(0, vehicle.laneProgress));
  const eased = progress * progress * (3 - 2 * progress);
  return origin + (LANE_CENTERS[vehicle.targetLane] - origin) * eased;
}

export function observeVehicle(state: TrafficState, id: number): VehicleObservation | null {
  const vehicle = state.vehicles.find(item => item.id === id);
  if (!vehicle) return null;
  const frontGap = Math.min(...occupiedLanes(vehicle).map(lane => gapsInLane(state, vehicle, lane).front));
  return {
    id, revision: vehicle.decisionRevision, observedAt: state.time, kind: vehicle.kind, x: vehicle.x,
    lane: vehicle.lane, speed: vehicle.speed, desiredSpeed: vehicle.desiredSpeed,
    distanceToLaneEnd: gapValue(laneEnd(vehicle.lane) - STOP_BUFFER - vehicle.x - vehicle.length / 2),
    frontGap: gapValue(frontGap), waitingSeconds: state.waitingSeconds[id] ?? 0,
    left: adjacent(state, vehicle, -1), right: adjacent(state, vehicle, 1),
  };
}

/** Oldest-first rotation prevents one blocked merge from starving the rest of the road. */
export function decisionCandidates(state: TrafficState, excludedIds: Set<number>, limit: number): VehicleObservation[] {
  if (!Number.isInteger(limit) || limit < 0 || limit > 32) throw new Error("Invalid decision batch size.");
  return state.vehicles.filter(vehicle => !excludedIds.has(vehicle.id) && vehicle.targetLane === null)
    .sort((a, b) => a.lastDecisionAt - b.lastDecisionAt ||
      (laneEnd(a.lane) - a.x) - (laneEnd(b.lane) - b.x) || a.id - b.id)
    .slice(0, limit).map(vehicle => observeVehicle(state, vehicle.id)!);
}

export function applyVehicleDecision(state: TrafficState, observation: VehicleObservation, action: Maneuver, requestId?: string): AppliedDecision {
  const receipt = (status: AppliedDecision["status"], reason: string): AppliedDecision => ({ vehicleId: observation.id, action, status, reason });
  const vehicle = state.vehicles.find(item => item.id === observation.id);
  if (!vehicle || observation.revision !== vehicle.decisionRevision || !Number.isFinite(observation.observedAt) ||
      observation.observedAt > state.time + EPSILON || state.time - observation.observedAt > MAX_OBSERVATION_AGE + EPSILON) {
    return receipt("stale", "The vehicle or its observation has changed; a fresh decision is needed.");
  }
  if (!["advance", "yield", "left", "right"].includes(action)) return receipt("stale", "The maneuver is outside the allowed actions.");
  vehicle.decisionRevision++;
  vehicle.lastDecisionAt = state.time;
  vehicle.lastAction = action;
  vehicle.lastRequestId = requestId;
  vehicle.highlightUntil = state.time + 1.2;
  const blocked = (reason: string) => {
    state.blocked++;
    // A rejected maneuver does not authorize continued driving under an old action.
    vehicle.leaseUntil = state.time;
    return receipt("blocked", reason);
  };
  if (action === "left" || action === "right") {
    const direction = action === "left" ? -1 : 1;
    if (!adjacent(state, vehicle, direction).available) return blocked("The adjacent lane no longer has a safe gap.");
    vehicle.targetLane = (vehicle.lane + direction) as Lane;
    vehicle.laneProgress = 0;
  } else if (action === "advance" && Math.min(...occupiedLanes(vehicle).map(lane => gapsInLane(state, vehicle, lane).front)) < MINIMUM_GAP) {
    return blocked("There is not enough room ahead to advance.");
  }
  vehicle.leaseUntil = state.time + ACTION_LEASE_SECONDS;
  return receipt("applied", action === "yield" ? "Slowing to leave room." : action === "advance" ? "Advancing within the available gap." : `Moving ${action} into the reserved gap.`);
}

function addDemand(state: TrafficState): void {
  while (state.nextArrivalAt <= state.time + EPSILON) {
    const roll = random(state);
    const lane: Lane = state.scenarioId === "bottleneck" ? (roll < .3 ? 3 : roll < .65 ? 2 : roll < .82 ? 1 : 0)
      : (roll < .2 ? 3 : roll < .45 ? 2 : roll < .72 ? 1 : 0);
    state.pendingDemand[lane]++;
    state.arrivals++;
    state.nextArrivalAt += state.scenarioId === "rush" ? .8 : state.scenarioId === "bottleneck" ? 1 : 1.4;
  }
  if (state.vehicles.length >= populationLimits[state.scenarioId]) return;
  for (const lane of [0, 1, 2, 3] as const) {
    if (!state.pendingDemand[lane] || state.vehicles.length >= populationLimits[state.scenarioId]) continue;
    // Reserve space for the largest entrant before consuming its deterministic kind draw.
    const entryX = 20;
    const free = state.vehicles.every(vehicle => !occupiedLanes(vehicle).includes(lane) || vehicle.x - vehicle.length / 2 >= entryX + sizes.bus.length / 2 + MINIMUM_GAP);
    if (!free) continue;
    state.vehicles.push(createVehicle(state, lane, entryX));
    state.pendingDemand[lane]--;
  }
}

function fixedStep(state: TrafficState): void {
  state.tick++;
  state.time = state.tick * TRAFFIC_STEP;
  // Reserve both lanes until the full lateral maneuver finishes.
  for (const vehicle of state.vehicles) {
    if (vehicle.targetLane === null) continue;
    vehicle.laneProgress = Math.min(1, vehicle.laneProgress + TRAFFIC_STEP / LANE_CHANGE_SECONDS);
    if (vehicle.laneProgress >= 1 - EPSILON) {
      vehicle.lane = vehicle.targetLane;
      vehicle.targetLane = null;
      vehicle.laneProgress = 0;
      state.merges++;
    }
  }
  const ordered = [...state.vehicles].sort((a, b) => b.x - a.x || a.id - b.id);
  for (const vehicle of ordered) {
    const lanes = occupiedLanes(vehicle);
    const authorized = vehicle.leaseUntil > state.time && vehicle.lastAction !== null && vehicle.lastAction !== "yield";
    const target = authorized ? vehicle.desiredSpeed : 0;
    const acceleration = target > vehicle.speed ? 9 : 24;
    const proposedSpeed = target > vehicle.speed ? Math.min(target, vehicle.speed + acceleration * TRAFFIC_STEP) : Math.max(target, vehicle.speed - acceleration * TRAFFIC_STEP);
    let maximumX = Math.min(...lanes.map(lane => laneEnd(lane) - STOP_BUFFER - vehicle.length / 2));
    for (const leader of state.vehicles) {
      if (leader.id === vehicle.id || leader.x < vehicle.x || !occupiedLanes(leader).some(lane => lanes.includes(lane))) continue;
      maximumX = Math.min(maximumX, leader.x - leader.length / 2 - vehicle.length / 2 - MINIMUM_GAP);
    }
    const nextX = Math.max(vehicle.x, Math.min(vehicle.x + proposedSpeed * TRAFFIC_STEP, maximumX));
    vehicle.speed = Math.max(0, (nextX - vehicle.x) / TRAFFIC_STEP);
    vehicle.x = nextX;
    if (vehicle.speed < 2) state.waitingSeconds[vehicle.id] = (state.waitingSeconds[vehicle.id] ?? 0) + TRAFFIC_STEP;
  }
  state.vehicles = state.vehicles.filter(vehicle => {
    if (vehicle.x - vehicle.length / 2 <= WORLD_WIDTH) return true;
    state.completed++;
    delete state.waitingSeconds[vehicle.id];
    return false;
  });
  addDemand(state);
}

/** Frames are accumulated into fixed steps; transport timing never changes physics integration. */
export function stepTraffic(state: TrafficState, dt: number): TrafficState {
  if (!Number.isFinite(dt) || dt < 0 || dt > 60) throw new Error("Traffic time delta must be between 0 and 60 seconds.");
  state.accumulator += dt;
  while (state.accumulator + EPSILON >= TRAFFIC_STEP) {
    state.accumulator -= TRAFFIC_STEP;
    if (Math.abs(state.accumulator) < EPSILON) state.accumulator = 0;
    fixedStep(state);
  }
  return state;
}
