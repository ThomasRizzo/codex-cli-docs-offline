export const RUN_LIMIT_SECONDS = 120;

/** A run spends wall-clock time only while playing, including API retry backoff. */
export class ActiveRunBudget {
  private consumedMs = 0;
  private startedAt: number | null = null;

  constructor(
    readonly limitMs = RUN_LIMIT_SECONDS * 1_000,
    private now: () => number = () => performance.now(),
  ) {}

  get elapsedMs(): number {
    const activeMs = this.startedAt === null ? 0 : Math.max(0, this.now() - this.startedAt);
    return Math.min(this.limitMs, this.consumedMs + activeMs);
  }

  get remainingMs(): number { return this.limitMs - this.elapsedMs; }
  get expired(): boolean { return this.remainingMs <= 0; }
  get running(): boolean { return this.startedAt !== null; }

  start(): boolean {
    if (this.expired) return false;
    if (this.startedAt === null) this.startedAt = this.now();
    return true;
  }

  pause(): void {
    this.consumedMs = this.elapsedMs;
    this.startedAt = null;
  }

  reset(): void {
    this.consumedMs = 0;
    this.startedAt = null;
  }
}
