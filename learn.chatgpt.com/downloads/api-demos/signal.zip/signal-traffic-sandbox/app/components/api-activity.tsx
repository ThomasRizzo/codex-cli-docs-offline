"use client";

import { memo, useEffect, useRef } from "react";
import type { ApiActivity } from "../lib/control";

export type ActivityEntry =
  | { kind: "api"; id: string; run: number; startedAt: string; data: ApiActivity; interruption?: "Stopped locally" | "Connection interrupted" }
  | { kind: "simulation"; id: string; at: string; title: string; detail: string; run?: number };

function timeLabel(at: string) {
  return new Date(at).toLocaleTimeString([], { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function ApiReceipt({ entry }: { entry: Extract<ActivityEntry, { kind: "api" }> }) {
  const { data, interruption } = entry;
  const status = interruption ?? ({ started: "Starting request", streaming: "Streaming", completed: "Complete", failed: "Failed" }[data.phase]);
  return <>
    <div className="activity-topline"><strong>{data.api === "decisions" ? "Decisions API" : "Responses API"}</strong><time dateTime={entry.startedAt} title={entry.startedAt}>{timeLabel(entry.startedAt)}</time></div>
    <div className="activity-status"><span className={`activity-dot ${interruption ? "interrupted" : data.phase}`} aria-hidden="true"/><span>{status}</span>{data.durationMs !== undefined && <span className="activity-duration">{data.durationMs.toLocaleString()} ms</span>}</div>
    {data.action && <code className="activity-action">{data.action}</code>}
    <details className="activity-details">
      <summary>Request details</summary>
      <dl>
        <div><dt>Endpoint</dt><dd><code>POST /v1/{data.api}</code></dd></div>
        <div><dt>Model</dt><dd><code>{data.model}</code></dd></div>
        {data.status !== undefined && <div><dt>HTTP status</dt><dd>{data.status}</dd></div>}
        <div><dt>Server time</dt><dd><code>{data.at}</code></dd></div>
        <div><dt>Request ID</dt><dd><code>{data.requestId ?? (data.phase === "started" && !interruption ? "Awaiting response" : "Not available")}</code></dd></div>
        <div><dt>Run</dt><dd>#{entry.run}</dd></div>
      </dl>
    </details>
  </>;
}

export const ApiActivityPanel = memo(function ApiActivityPanel({ entries, hidden }: { entries: ActivityEntry[]; hidden: boolean }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const follow = useRef(true);
  useEffect(() => {
    if (!hidden && follow.current && scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [entries, hidden]);
  return <div id="activity-panel" className="activity-panel" role="tabpanel" aria-labelledby="activity-tab" hidden={hidden} tabIndex={0} ref={scrollRef} onScroll={event => {
    const target = event.currentTarget;
    follow.current = target.scrollHeight - target.scrollTop - target.clientHeight < 70;
  }}>
    <p className="activity-note">Live API receipts. Signal changes below are applied by the local simulation.</p>
    {entries.length === 0 ? <div className="activity-empty"><p>Waiting for your first instruction.</p><span>Send a message to see the API requests arrive here.</span></div> : <ol className="activity-list" role="list">
      {entries.map(entry => <li className={`activity-entry ${entry.kind}`} key={entry.id}>
        {entry.kind === "api" ? <ApiReceipt entry={entry}/> : <>
          <div className="activity-topline"><strong>Simulation</strong><time dateTime={entry.at} title={entry.at}>{timeLabel(entry.at)}</time></div>
          <p className="activity-local-title">{entry.title}</p>
          <p className="activity-local-detail">{entry.detail}</p>
        </>}
      </li>)}
    </ol>}
  </div>;
});
