"use client";

import { memo, useRef, useState } from "react";
import Link from "next/link";
import { ArrowDownTrayIcon, ArrowPathIcon, ArrowRightIcon, Bars3Icon, CheckIcon, ChevronDownIcon, PauseIcon, PlayIcon, QuestionMarkCircleIcon, SpeakerWaveIcon, SpeakerXMarkIcon, XMarkIcon } from "@heroicons/react/16/solid";
import { TRAFFIC_SCENARIOS, type TrafficScenarioId } from "../lib/traffic-engine";
import { useTrafficLab, type TrafficBatchLog } from "../lib/use-traffic-lab";
import { TrafficCorridor, vehicleName } from "./traffic-corridor";

function actionLabel(action: string | null | undefined) {
  if (!action) return "No choice";
  const label = action === "left" ? "Merge left" : action === "right" ? "Merge right" : action.replaceAll("_", " ");
  return label.charAt(0).toUpperCase()+label.slice(1);
}
function timeLabel(time: number) {
  return new Date(time).toLocaleTimeString([], {hour12:false, hour:"2-digit",minute:"2-digit",second:"2-digit"});
}
function elapsedLabel(seconds: number) {
  return `${String(Math.floor(seconds/60)).padStart(2,"0")}:${String(Math.floor(seconds%60)).padStart(2,"0")}`;
}
function latencyLabel(ms: number) { return ms < 1000 ? `${Math.round(ms)} ms` : `${(ms/1000).toFixed(2)} s`; }

const RequestEntry = memo(function RequestEntry({ log, onSelect, selectedVehicleId }: { log: TrafficBatchLog; onSelect: (id: number | null) => void; selectedVehicleId: number | null }) {
  const complete = log.status === "complete";
  return <li className="tl-request" data-status={log.status}>
    <div className="tl-request-heading"><div className="tl-request-name"><span className="tl-request-dot"/><p>Request <span>#{String(log.id).padStart(3,"0")}</span></p></div><time dateTime={new Date(log.startedAt).toISOString()}>{timeLabel(log.startedAt)}</time></div>
    <div className="tl-request-meta"><p>{complete ? log.receipt?.model ?? "Decisions API" : log.status === "pending" ? "Awaiting Decisions API" : log.status === "stopped" ? "Request stopped" : "Request failed"}</p><p>{log.receipt ? latencyLabel(log.receipt.durationMs) : log.status === "pending" ? "In flight" : "—"}</p></div>
    <div className="tl-choices">{log.vehicleIds.map(id=>{
      const choice = log.receipt?.choices.find(item=>item.vehicleId===id);
      const outcome = log.outcomes?.find(item=>item.vehicleId===id);
      const status = outcome?.status;
      return <button type="button" key={id} className="tl-choice" data-status={status} aria-pressed={selectedVehicleId===id} onClick={()=>onSelect(selectedVehicleId===id?null:id)} title={outcome?.reason ?? `Inspect vehicle ${id}`}>
        <span className="tl-choice-id">#{id}</span><span className="tl-choice-action">{log.status === "pending" ? "Deciding…" : choice && "refused" in choice ? "No choice" : choice ? actionLabel(choice.action) : "No result"}</span>{status === "applied" ? <CheckIcon/> : status === "blocked" || status === "stale" ? <span className="tl-choice-held" aria-label={status === "blocked"?"Blocked by current road conditions":"Vehicle state changed"}>Held</span> : null}
      </button>;
    })}</div>
    <div className="tl-request-bottom">{log.receipt ? <details className="tl-receipt"><summary>API receipt</summary><dl><div><dt>Request ID</dt><dd><code>{log.receipt.requestId ?? "Not supplied by API"}</code></dd></div><div><dt>Returned</dt><dd>{log.receipt.choices.filter(choice=>choice.action!==null).length} vehicle choices{log.receipt.choices.some(choice=>choice.action===null) ? ` · ${log.receipt.choices.filter(choice=>choice.action===null).length} refused` : ""}</dd></div><div><dt>Received</dt><dd>{new Date(log.receipt.at).toLocaleTimeString([], {hour12:false})}</dd></div>{log.receipt.usage && <div><dt>Token usage</dt><dd><code>{JSON.stringify(log.receipt.usage)}</code></dd></div>}</dl></details> : <p>{log.status === "pending" ? `${log.vehicleIds.length} drivers in this batch` : log.error ?? "No new choices applied."}</p>}</div>
  </li>;
});

export function TrafficLab() {
  const lab = useTrafficLab();
  const {world, running, pendingIds, selectedVehicleId, logs, stats} = lab;
  const [menuOpen, setMenuOpen] = useState(false);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const selected = world.vehicles.find(vehicle=>vehicle.id === selectedVehicleId);
  const latestSelected = selectedVehicleId === null ? undefined : logs.find(log=>log.vehicleIds.includes(selectedVehicleId));
  const selectedOutcome = latestSelected?.outcomes?.find(outcome=>outcome.vehicleId===selectedVehicleId);
  const scenario = TRAFFIC_SCENARIOS.find(item=>item.id === lab.scenarioId);
  const openHelp = () => { setMenuOpen(false); dialogRef.current?.showModal(); };
  const status = lab.runComplete ? "Complete" : lab.retrying ? "Retrying" : running ? "Running" : stats.requests ? "Paused" : "Ready";
  return <div className="traffic-lab">
    <header className="tl-header">
      <Link href="/" className="tl-brand" aria-label="Signal homepage"><img src="/favicon.svg" alt="" width="28" height="28"/><h1>Signal</h1></Link>
      <div className="tl-scenario"><label htmlFor="traffic-scenario">Traffic</label><div className="tl-select"><select id="traffic-scenario" name="scenario" value={lab.scenarioId} onChange={event=>lab.setScenario(event.target.value as TrafficScenarioId)}>{TRAFFIC_SCENARIOS.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</select><ChevronDownIcon aria-hidden="true"/></div></div>
      <nav className="tl-header-actions" aria-label="Project"><a href="/signal-project.zip" download className="tl-button"><ArrowDownTrayIcon/>Download project</a><button type="button" className="tl-button tl-icon-button" aria-label="How Signal works" onClick={openHelp}><QuestionMarkCircleIcon/></button></nav>
      <button type="button" className="tl-button tl-icon-button tl-menu-toggle" aria-expanded={menuOpen} aria-controls="traffic-mobile-menu" aria-label={menuOpen?"Close menu":"Open menu"} onClick={()=>setMenuOpen(!menuOpen)}>{menuOpen?<XMarkIcon/>:<Bars3Icon/>}</button>
      {menuOpen && <nav id="traffic-mobile-menu" className="tl-mobile-menu" aria-label="Project"><a href="/signal-project.zip" download className="tl-button" onClick={()=>setMenuOpen(false)}><ArrowDownTrayIcon/>Download project</a><button type="button" className="tl-button" onClick={openHelp}><QuestionMarkCircleIcon/>How it works</button></nav>}
    </header>
    <main className="tl-workspace">
      <section className="tl-map-panel" aria-label="Traffic simulation">
        <div className="tl-map-heading"><div><p className="tl-eyebrow">MERIDIAN / LIVE TRAFFIC</p><h2>{scenario?.label ?? "Mixed traffic"}</h2></div><div className="tl-sim-status"><span className="tl-live-dot" data-running={running}/><p>{lab.runComplete?"Complete":running?"Live":"Paused"}</p><time title="Each run stops after two minutes of playing time.">{elapsedLabel(lab.elapsedSeconds)} / {elapsedLabel(lab.runLimitSeconds)}</time></div></div>
        <div className="tl-map-stage"><TrafficCorridor world={world} pendingIds={pendingIds} selectedVehicleId={selectedVehicleId} onSelect={lab.selectVehicle}/></div>
        <div className="tl-map-bottom"><div className="tl-controls" aria-label="Simulation controls"><button type="button" className="tl-button tl-primary tl-play" onClick={lab.toggleRunning}>{running?<PauseIcon/>:<PlayIcon/>}{lab.runComplete?"Run again":running?"Pause":"Play"}</button><button type="button" className="tl-button tl-icon-button" aria-label="Reset simulation" title="Reset simulation" onClick={lab.reset}><ArrowPathIcon/></button><span className="tl-controls-divider"/><button type="button" className="tl-button tl-icon-button" aria-label="Sound effects" aria-pressed={lab.soundEnabled} title={lab.soundEnabled?"Mute sound effects":"Enable sound effects"} onClick={lab.toggleSound}>{lab.soundEnabled?<SpeakerWaveIcon/>:<SpeakerXMarkIcon/>}</button></div><div className="tl-map-legend" aria-label="Vehicle types"><p><i className="tl-key-car"/>Cars</p><p><i className="tl-key-scooter"/>Scooters</p><p><i className="tl-key-rickshaw"/>Rickshaws</p><p><i className="tl-key-bus"/>Buses</p></div></div>
        <div className="tl-metrics">
          <div><p>On the road</p><strong>{world.vehicles.length}</strong><span>vehicles</span></div>
          <div><p>Driver choices</p><strong>{stats.decisions.toLocaleString()}</strong><span>{stats.decisionsPerSecond.toFixed(1)} per second</span></div>
          <div><p>Lane changes</p><strong>{world.merges.toLocaleString()}</strong><span>{world.completed.toLocaleString()} vehicles through</span></div>
          <div><p>API latency</p><strong>{stats.averageLatency?Math.round(stats.averageLatency).toLocaleString():"—"}<small>{stats.averageLatency?"ms":""}</small></strong><span>average round trip</span></div>
        </div>
        <div className="tl-map-caption"><p><span className="tl-outline-key"/>Cyan outline = deciding</p><p>Choose a vehicle to inspect <ArrowRightIcon/></p></div>
      </section>
      <aside className="tl-dispatch" aria-label="Live API activity">
        <div className="tl-feed-heading"><h2>Decisions</h2><div className="tl-feed-state"><span className="tl-live-dot" data-running={running&&!lab.retrying}/><p>{status}</p></div></div>
        <div className="tl-feed-stats"><p><strong>{stats.requests.toLocaleString()}</strong> requests</p><p><strong>{stats.requestsPerSecond.toFixed(1)}</strong> req/s</p></div>
        {selectedVehicleId !== null && <section className="tl-inspector" aria-label="Selected vehicle"><div className="tl-inspector-heading"><h3>{selected ? vehicleName(selected) : `Vehicle ${selectedVehicleId}`}</h3><button type="button" className="tl-button tl-icon-button" aria-label="Close vehicle details" onClick={()=>lab.selectVehicle(null)}><XMarkIcon/></button></div>{selected ? <><div className="tl-inspector-facts"><p>Lane {selected.lane+1}</p><p>{Math.round(selected.speed)} units/s</p><p>{pendingIds.includes(selected.id)?"Deciding…":selected.lastAction? actionLabel(selected.lastAction):"Awaiting choice"}</p></div><p className="tl-inspector-reason">{selectedOutcome?.reason ?? (pendingIds.includes(selected.id) ? "Checking the current gaps and nearby drivers." : "Waiting for this driver’s next decision.")}</p><p className="tl-inspector-request" title={selected.lastRequestId}>{selected.lastRequestId ?? "No API receipt yet"}</p></> : <p className="tl-inspector-reason">This vehicle has left the road. Its API receipts remain below.</p>}</section>}
        {lab.error && <div className="tl-error" role="status"><p>{lab.error}</p>{lab.retrying && <p>Retrying automatically…</p>}</div>}
        <div className="tl-request-scroll" tabIndex={0} aria-label="Decision requests">
          {logs.length===0 ? <div className="tl-feed-empty"><div className="tl-empty-mark" aria-hidden="true"><span/><span/><span/></div><h3>Every driver, a decision.</h3><p>Press Play to watch vehicles ask the Decisions API when to merge, accelerate, or yield.</p><div className="tl-empty-steps"><p><span>01</span>Observe the road</p><p><span>02</span>Choose a maneuver</p><p><span>03</span>Check the gap and move</p></div></div> : <ol role="list" className="tl-request-list">{[...logs].sort((a,b)=>b.id-a.id).map(log=><RequestEntry key={log.id} log={log} onSelect={lab.selectVehicle} selectedVehicleId={selectedVehicleId}/>)}</ol>}
        </div>
        <div className="tl-feed-footer"><p role="status">{lab.runComplete?"Two-minute run complete.":"Real requests. Returned choices."}</p><button type="button" className="tl-text-button" onClick={openHelp}>How it works <ArrowRightIcon/></button></div>
      </aside>
    </main>
    <dialog ref={dialogRef} className="tl-help" aria-labelledby="traffic-help-title" onClick={event=>{if(event.target===event.currentTarget)dialogRef.current?.close();}}><div className="tl-help-heading"><h2 id="traffic-help-title">Inside Signal</h2><button type="button" className="tl-button tl-icon-button" aria-label="Close help" onClick={()=>dialogRef.current?.close()}><XMarkIcon/></button></div><div className="tl-help-body"><p>Each vehicle has its own view of the road: nearby drivers, available gaps, and the next lane closure.</p><ol><li><strong>Decisions chooses.</strong> While playing, Signal targets two real API requests per second, with up to four drivers per request. Each driver gets an independent choice.</li><li><strong>The street responds.</strong> Returned choices control acceleration, yielding, and lane changes. Local physics checks the current gap before moving a vehicle.</li><li><strong>The feed keeps the receipt.</strong> Inspect request IDs, timings, model outputs, and whether each choice could be applied. A request can return several driver choices; the counters show both.</li></ol><p>Each run ends after two minutes of playing time. Pausing stops requests and preserves the remaining time. Traffic also pauses when this tab is hidden. This is a stylized traffic simulation; pedestrians and buildings are scenery.</p><Link className="tl-junction-link" href="/junction">Explore the original signal controller <ArrowRightIcon/></Link></div></dialog>
  </div>;
}
