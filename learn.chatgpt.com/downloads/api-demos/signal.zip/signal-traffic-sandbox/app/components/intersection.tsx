import { memo } from "react";
import type { SimulationState, Direction } from "../lib/simulation";

const directions: Direction[] = ["north", "east", "south", "west"];
const carTones = ["car-ice", "car-white", "car-steel", "car-lilac", "car-sand"];

function StreetBlock({ x, y, variant }: { x: number; y: number; variant: number }) {
  return <g transform={`translate(${x} ${y})`}>
    <rect x="0" y="0" width="246" height="246" rx="18" className="city-block" />
    {variant === 0 ? <>
      <rect x="18" y="18" width="132" height="90" rx="5" className="building" />
      <rect x="26" y="26" width="116" height="74" rx="2" className="roof" />
      <path d="M42 44h80M42 61h80M42 78h80" className="roof-detail" />
      <rect x="18" y="133" width="132" height="95" rx="5" className="building" />
      <rect x="30" y="145" width="108" height="71" rx="2" className="roof" />
      <rect x="174" y="18" width="54" height="210" rx="6" className="parking-lot" />
      {Array.from({length: 9}, (_, i) => <path key={i} d={`M178 ${32+i*21}h18m8 0h18`} className="parking-mark" />)}
      <text x="84" y="186" textAnchor="middle" className="building-label">STATION</text>
    </> : variant === 1 ? <>
      <rect x="18" y="18" width="210" height="210" rx="12" className="park" />
      <path d="M28 136h190M112 28v190" className="park-path" />
      <rect x="137" y="43" width="61" height="60" rx="30" className="park-court" />
      <circle cx="167" cy="73" r="19" className="park-court-line" />
      {[[52,51],[81,78],[55,197],[80,167],[159,170],[201,200]].map(([tx,ty],i)=><g key={i}><circle cx={tx} cy={ty} r="14" className="tree"/><circle cx={tx-3} cy={ty-3} r="8" className="tree-top"/></g>)}
      <text x="163" y="126" textAnchor="middle" className="building-label">PUBLIC GARDEN</text>
    </> : variant === 2 ? <>
      <rect x="18" y="18" width="210" height="80" rx="5" className="building" />
      <rect x="28" y="28" width="190" height="60" rx="2" className="roof" />
      <path d="M45 40v37m24-37v37m24-37v37m24-37v37m24-37v37m24-37v37m24-37v37" className="roof-detail" />
      <rect x="18" y="122" width="94" height="106" rx="5" className="building" />
      <rect x="134" y="122" width="94" height="106" rx="5" className="building" />
      <rect x="29" y="133" width="72" height="84" rx="2" className="roof" />
      <rect x="145" y="133" width="72" height="84" rx="2" className="roof" />
      <text x="123" y="67" textAnchor="middle" className="building-label">MARKET HALL</text>
    </> : <>
      <rect x="18" y="18" width="210" height="114" rx="5" className="building" />
      <rect x="30" y="30" width="186" height="90" rx="2" className="roof" />
      <rect x="44" y="47" width="40" height="24" rx="3" className="rooftop-unit" />
      <rect x="100" y="47" width="40" height="24" rx="3" className="rooftop-unit" />
      <text x="123" y="102" textAnchor="middle" className="building-label">CIVIC CENTER</text>
      <rect x="18" y="154" width="210" height="74" rx="6" className="park" />
      {[[42,191],[84,191],[126,191],[168,191],[210,191]].map(([tx,ty],i)=><g key={i}><circle cx={tx} cy={ty} r="12" className="tree"/><circle cx={tx-2} cy={ty-2} r="7" className="tree-top"/></g>)}
    </>}
  </g>;
}

const Streets = memo(function Streets() {
 return <>
   <defs><pattern id="map-grain" width="16" height="16" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="0.55" className="map-grain"/></pattern></defs>
   <rect width="800" height="800" className="map-ground" />
   <rect width="800" height="800" fill="url(#map-grain)" />
   <StreetBlock x={38} y={38} variant={0}/><StreetBlock x={516} y={38} variant={1}/>
   <StreetBlock x={38} y={516} variant={2}/><StreetBlock x={516} y={516} variant={3}/>
   <path d="M310-20h180v330h330v180H490v330H310V490H-20V310h330Z" className="sidewalk" />
   <path d="M328-20h144v348h348v144H472v348H328V472H-20V328h348Z" className="road" />
   <path d="M400 0v288m0 224v288M0 400h288m224 0h288" className="lane-center" />
   <path d="M352 0v278m96 244v278M0 448h278m244-96h278" className="lane-edge" />
   <path d="M352 289h45M403 511h45M289 403v45M511 352v45" className="stop-line" />
   {[0,1,2,3].map((turn)=><g key={turn} transform={`rotate(${turn*90} 400 400)`}>
     {Array.from({length:8},(_,i)=><rect key={i} x={337+i*16} y="303" width="9" height="19" className="crosswalk"/>)}
     <path d="M378 246v23m-5-7 5 7 5-7" className="road-arrow" />
   </g>)}
   <rect x="574" y="452" width="94" height="14" rx="3" className="bus-stop" />
   <path d="M588 458h66" className="bus-stop-line" />
   <text x="621" y="484" textAnchor="middle" className="street-label">BUS CORRIDOR</text>
   <text x="210" y="385" textAnchor="middle" className="street-label">CANAL AVENUE</text>
   <text x="590" y="385" textAnchor="middle" className="street-label">CANAL AVENUE</text>
   <text x="414" y="157" textAnchor="middle" transform="rotate(90 414 157)" className="street-label">MARKET STREET</text>
   <text x="386" y="645" textAnchor="middle" transform="rotate(-90 386 645)" className="street-label">MARKET STREET</text>
   {[[306,286],[514,306],[494,514],[286,494]].map(([x,y],i)=><g key={i}><circle cx={x} cy={y} r="8" className="tree"/><circle cx={x-2} cy={y-2} r="5" className="tree-top"/></g>)}
 </>;
});

function TrafficLight({direction, state}: {direction: Direction; state: SimulationState}) {
 const ns = direction === "north" || direction === "south";
 const matches = (ns && state.phase === "north_south") || (!ns && state.phase === "east_west");
 const active = matches ? state.signal : "red";
 const position = {north:[352,282],east:[518,352],south:[448,518],west:[282,448]}[direction];
 const turn = {north:0,east:90,south:180,west:270}[direction];
 return <g transform={`translate(${position[0]} ${position[1]}) rotate(${turn})`}>
   <rect x="-6" y="-17" width="12" height="31" rx="5" className="signal-housing"/>
   <circle cx="0" cy="-10" r="3.5" className={active === "red" ? "signal-red" : "signal-off"}/>
   <circle cx="0" cy="-1" r="3.5" className={active === "amber" ? "signal-amber" : "signal-off"}/>
   <circle cx="0" cy="8" r="3.5" className={active === "green" ? "signal-green" : "signal-off"}/>
 </g>;
}

export function Intersection({state}: {state: SimulationState}) {
 return <svg className="intersection" viewBox="0 0 800 800" preserveAspectRatio="xMidYMid slice" role="img" aria-label={`Simulated intersection. ${state.phase === "pedestrians" ? "Pedestrians are crossing" : state.phase === "clearance" ? "All lights are red for clearance" : (state.phase === "north_south" ? "North–south" : "East–west") + " traffic has the " + state.signal + " light"}.`}>
   <Streets/>
   {state.vehicles.map((vehicle)=>{
     const p = vehicle.progress;
     const positions = {north:[378,p,180],south:[422,800-p,0],west:[p,422,90],east:[800-p,378,270]};
     const [x,y,angle] = positions[vehicle.direction];
     const colorIndex = String(vehicle.id).split("").reduce((a,c)=>a+c.charCodeAt(0),0)%carTones.length;
     return <g key={vehicle.id} transform={`translate(${x} ${y}) rotate(${angle})`} className={vehicle.kind === "bus" ? "vehicle bus" : `vehicle ${carTones[colorIndex]}`}>
       <rect x="-9" y={-vehicle.length/2+3} width="18" height="4" rx="1" className="vehicle-tire" />
       <rect x="-9" y={vehicle.length/2-7} width="18" height="4" rx="1" className="vehicle-tire" />
       <rect x="-7.5" y={-vehicle.length/2} width="15" height={vehicle.length} rx={vehicle.kind === "bus" ? 3:4} className="vehicle-body"/>
       <rect x="-5.5" y={-vehicle.length/2+4} width="11" height="4" rx="1" className="vehicle-window"/>
       <rect x="-5.5" y={vehicle.length/2-8} width="11" height="3" rx="1" className="vehicle-window"/>
       {vehicle.kind === "bus" && <><path d={`M-5 ${-vehicle.length/2+12}v${vehicle.length-24}m10 0v-${vehicle.length-24}`} className="bus-window"/><rect x="-2" y="-3" width="4" height="6" rx="1" className="bus-roof"/></>}
       <path d={`M-6 ${-vehicle.length/2+1}h3m6 0h3`} className="headlights"/>
       {vehicle.speed < 2 && <path d={`M-6 ${vehicle.length/2-1}h3m6 0h3`} className="brake-lights"/>}
     </g>;
   })}
   {directions.map(direction=><TrafficLight key={direction} direction={direction} state={state}/>)}
   {directions.flatMap((direction)=>Array.from({length:Math.min(state.waitingPedestrians[direction],10)},(_,i)=>{
     const p = i*5;
     const positions = {north:[288+p,296],south:[512-p,504],west:[296,512-p],east:[504,288+p]};
     const [x,y] = positions[direction];
     return <circle key={`${direction}-${i}`} cx={x} cy={y} r="2.4" className="pedestrian waiting-pedestrian"/>;
   }))}
   {state.pedestrians.map((person)=>{
     const p=person.progress;
     const positions = {north:[288+p,312],south:[512-p,488],west:[312,512-p],east:[488,288+p]};
     const [x,y]=positions[person.crossing];
     return <g key={person.id}><circle cx={x} cy={y} r="3.2" className="pedestrian"/><circle cx={x} cy={y-0.8} r="1.3" className="pedestrian-head"/></g>;
   })}
 </svg>;
}
