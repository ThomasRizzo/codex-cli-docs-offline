"use client";

import { memo } from "react";
import { vehicleY, type TrafficState } from "../lib/traffic-engine";

type Vehicle = TrafficState["vehicles"][number];
export function vehicleName(vehicle: Vehicle) {
  const names: Record<string, string> = { car: "Car", bus: "Bus", scooter: "Scooter", rickshaw: "Rickshaw", auto_rickshaw: "Rickshaw" };
  return `${names[vehicle.kind] ?? vehicle.kind} ${vehicle.id}`;
}

const Streetscape = memo(function Streetscape() {
  return <g aria-hidden="true">
    <rect width="800" height="500" className="tl-ground" />
    <g className="tl-blocks">
      <rect x="18" y="12" width="188" height="102" rx="6" />
      <rect x="224" y="12" width="224" height="102" rx="6" />
      <rect x="466" y="12" width="166" height="102" rx="6" />
      <rect x="651" y="12" width="131" height="102" rx="6" />
      <rect x="18" y="399" width="225" height="85" rx="6" />
      <rect x="263" y="399" width="143" height="85" rx="6" />
      <rect x="425" y="336" width="357" height="148" rx="6" />
    </g>
    <g className="tl-roofs">
      <rect x="32" y="26" width="72" height="60" rx="3" /><rect x="115" y="26" width="76" height="60" rx="3" />
      <rect x="240" y="26" width="110" height="60" rx="3" /><rect x="363" y="26" width="68" height="60" rx="3" />
      <rect x="482" y="26" width="134" height="60" rx="3" /><rect x="666" y="26" width="100" height="60" rx="3" />
      <rect x="33" y="414" width="122" height="55" rx="3" /><rect x="168" y="414" width="59" height="55" rx="3" />
      <rect x="279" y="414" width="111" height="55" rx="3" />
      <rect x="445" y="355" width="139" height="110" rx="3" /><rect x="601" y="355" width="160" height="110" rx="3" />
    </g>
    <g className="tl-roof-lines">
      <path d="M43 37h50v38H43zM126 37h54v38h-54zM251 37h88v38h-88zM374 37h46v38h-46zM493 37h112v38H493zM677 37h77v38h-77zM44 426h100v31H44zM179 426h37v31h-37zM290 426h88v31h-88zM457 366h114v87H457zM614 368h134v85H614z" />
      <path d="M493 48h112M493 62h112M614 384h134M614 400h134M614 417h134M614 433h134" />
    </g>
    <g className="tl-roof-units"><rect x="65" y="48" width="18" height="13" rx="2"/><rect x="269" y="48" width="24" height="15" rx="2"/><rect x="695" y="49" width="18" height="13" rx="2"/><rect x="493" y="387" width="29" height="19" rx="3"/><rect x="538" y="426" width="17" height="13" rx="2"/></g>
    <g className="tl-awnings">
      {[36, 118, 244, 367, 487, 555, 670, 724].map((x, index) => <g key={x} className={`tl-awning-${index % 3}`}><rect x={x} y="87" width={index === 2 ? 99 : 38} height="10" rx="1"/><path d={`M${x+8} 87v10m10-10v10m10-10v10`} /></g>)}
    </g>
    <g className="tl-sidewalk"><path d="M0 120H800V137H0zM0 370H355V388H0zM393 304H800V322H393z"/></g>
    <g className="tl-sidewalk-seams"><path d="M20 120v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17m40-17v17M30 370v18m40-18v18m40-18v18m40-18v18m40-18v18m40-18v18m40-18v18m40-18v18M410 304v18m40-18v18m40-18v18m40-18v18m40-18v18m40-18v18m40-18v18m40-18v18m40-18v18m40-18v18"/></g>
    <path d="M0 140H800V298H359V367H0Z" className="tl-road" />
    <path d="M0 140H800M0 367H339L379 298H800" className="tl-curb" />
    <path d="M0 195H800M0 245H590M0 306H294" className="tl-lane-lines" />
    <path d="M0 145H800" className="tl-edge-line" />
    <path d="M605 249H800V294H585Z" className="tl-work-zone" />
    <g className="tl-work-hatch"><path d="m609 250 31 43m-7-43 31 43m-7-43 31 43m-7-43 31 43m-7-43 31 43m-7-43 31 43m-7-43 27 37"/></g>
    <g className="tl-road-arrows"><path d="M66 170h26m-9-6 9 6-9 6M468 170h26m-9-6 9 6-9 6M377 220h26m-9-6 9 6-9 6M706 220h26m-9-6 9 6-9 6M181 270h26m-9-6 9 6-9 6M481 274h18l18-20m-10 2 10-2-2 10M243 340h24l24-24m-11 2 11-2-2 11" /></g>
    <g className="tl-cones">
      {[[593,281],[598,265],[608,251],[636,249],[664,249],[692,249],[720,249],[748,249],[776,249],[342,357],[353,337],[364,316],[375,298]].map(([x,y]) => <g key={`${x}-${y}`} transform={`translate(${x} ${y})`}><rect x="-4" y="-4" width="8" height="8" rx="1" className="tl-cone-base"/><circle r="2.5" className="tl-cone"/><circle r="1" className="tl-cone-tip"/></g>)}
    </g>
    <g className="tl-map-labels"><text x="60" y="108">MARKET ROW</text><text x="501" y="108">CENTRAL BLOCK</text><text x="459" y="477">MERIDIAN MARKET</text><text x="49" y="485">FEEDER ROAD</text><text x="646" y="281">ROADWORK</text></g>
    <g className="tl-trees">{[[209,101],[450,102],[636,101],[18,104],[389,375],[409,340],[411,462],[780,345]].map(([x,y])=><g key={`${x}-${y}`} transform={`translate(${x} ${y})`}><circle r="9"/><circle cx="-2" cy="-2" r="6" className="tl-tree-top"/></g>)}</g>
    <g className="tl-street-people">{[[54,128],[59,130],[179,125],[264,130],[327,127],[438,130],[551,126],[559,127],[693,129],[735,126],[91,380],[185,378],[290,381],[464,314],[471,310],[578,313],[723,311]].map(([x,y],i)=><circle key={`${x}-${y}`} cx={x} cy={y} r={i%3===0?2.1:1.7}/>)}</g>
  </g>;
});

function VehicleBody({ vehicle }: { vehicle: Vehicle }) {
  const length = vehicle.length;
  const width = vehicle.width;
  if (vehicle.kind === "scooter") return <g className="tl-scooter-shape">
    <rect x={-length/2} y="-2.4" width="7" height="4.8" rx="2" className="tl-wheel"/><rect x={length/2-7} y="-2.4" width="7" height="4.8" rx="2" className="tl-wheel"/>
    <rect x={-length/2+4} y={-width/2} width={length-8} height={width} rx={width/2} className="tl-vehicle-body"/>
    <path d={`M${length/2-6} ${-width/2-2}v${width+4}`} className="tl-scooter-bars"/>
    <ellipse cx="-2" cy="0" rx="4.5" ry="3.8" className="tl-scooter-rider"/><circle cx="2" cy="0" r="3" className="tl-helmet"/>
  </g>;
  return <g>
    {[-1,1].map(side=><g key={side}><rect x={-length*.32} y={side<0?-width/2-1.5:width/2-1.5} width="6" height="3" rx="1" className="tl-wheel"/><rect x={length*.22} y={side<0?-width/2-1.5:width/2-1.5} width="6" height="3" rx="1" className="tl-wheel"/></g>)}
    <rect x={-length/2} y={-width/2} width={length} height={width} rx={vehicle.kind==="bus"?3:4} className="tl-vehicle-body" />
    <path d={`M${length/2-1} ${-width*.3}v${width*.18}m0 ${width*.24}v${width*.18}`} className="tl-headlights"/>
    <path d={`M${-length/2+.5} ${-width*.31}v${width*.2}m0 ${width*.22}v${width*.2}`} className="tl-taillights"/>
    <path d={`M${length*.23} ${-width*.4}l${length*.08} ${width*.1}v${width*.6}l${-length*.08} ${width*.1}Z`} className="tl-windscreen"/>
    {vehicle.kind === "bus" ? <><rect x={-length*.34} y={-width*.3} width={length*.49} height={width*.6} rx="1" className="tl-bus-roof"/><path d={`M${-length*.3} ${-width*.43}h${length*.44}M${-length*.3} ${width*.43}h${length*.44}`} className="tl-bus-windows"/></> : <rect x={-length*.23} y={-width*.33} width={length*.38} height={width*.66} rx="2" className="tl-car-roof"/>}
  </g>;
}

export function TrafficCorridor({ world, pendingIds, selectedVehicleId, onSelect }: { world: TrafficState; pendingIds: number[]; selectedVehicleId: number | null; onSelect: (id: number | null) => void }) {
  const pending = new Set(pendingIds);
  return <svg viewBox="0 0 800 500" preserveAspectRatio="xMidYMid meet" className="tl-corridor" aria-label="Mixed traffic navigating a feeder merge and a lane closure">
    <title>Traffic corridor</title><desc>Choose a vehicle to inspect its latest decision. Cyan outlines indicate a request in flight.</desc>
    <Streetscape />
    <g>{world.vehicles.map(vehicle => {
      const selected = vehicle.id === selectedVehicleId;
      const isPending = pending.has(vehicle.id);
      const changing = vehicle.targetLane !== null && vehicle.targetLane !== vehicle.lane;
      const highlight = world.time < vehicle.highlightUntil;
      const turn = changing ? (Number(vehicle.targetLane) < vehicle.lane ? -1 : 1) : 0;
      return <g key={vehicle.id} transform={`translate(${vehicle.x} ${vehicleY(vehicle)})`} className={`tl-vehicle tl-kind-${vehicle.kind} tl-color-${vehicle.id%5}`} data-selected={selected} data-pending={isPending} data-highlight={highlight} role="button" tabIndex={0} aria-label={`${vehicleName(vehicle)}, lane ${vehicle.lane+1}${isPending ? ", awaiting decision" : ""}`} aria-pressed={selected} onClick={()=>onSelect(selected?null:vehicle.id)} onKeyDown={event=>{if(event.key==="Enter"||event.key===" "){event.preventDefault();onSelect(selected?null:vehicle.id);}}}>
        <rect x={-Math.max(vehicle.length+18,40)/2} y={-Math.max(vehicle.width+18,32)/2} width={Math.max(vehicle.length+18,40)} height={Math.max(vehicle.width+18,32)} rx="6" className="tl-vehicle-hit"/>
        <rect x={-vehicle.length/2-5} y={-vehicle.width/2-5} width={vehicle.length+10} height={vehicle.width+10} rx="6" className="tl-vehicle-ring"/>
        {changing && <path d={`M${vehicle.length/2+2} 0q12 0 20 ${turn*13}m-8 ${turn*1} 8 ${-turn*1} -1 ${-turn*8}`} className="tl-maneuver-arrow"/>}
        <VehicleBody vehicle={vehicle}/>
        {(selected || isPending) && <g className="tl-vehicle-label"><rect x="-15" y={-vehicle.width/2-23} width="30" height="14" rx="4"/><text x="0" y={-vehicle.width/2-13}>#{vehicle.id}</text></g>}
      </g>;
    })}</g>
  </svg>;
}
