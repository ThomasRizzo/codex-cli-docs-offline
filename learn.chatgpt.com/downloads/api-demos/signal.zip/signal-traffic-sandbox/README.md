# Signal — Mixed-traffic sandbox

An interactive OpenAI API demo. Cars, buses, scooters, and rickshaws continuously ask the Decisions API when to advance, yield, and change lanes. Watch the traffic and inspect the actual requests beside it.

## Run locally

Requires Node.js 22.13+ and Python 3.

```sh
npm ci
cp .env.example .env.local
# Set OPENAI_API_KEY to your own project key in .env.local.
npm run package:source
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_fantastic_wolf_cub.sql
npm run dev
```

The key stays on the server. The download contains no API credentials or Sites project identity. The public demo accepts anonymous visitors without sign-in. Same-origin checks and durable network quotas protect both paid routes.

```sh
npm run typecheck
npm test
npm run build
```

## How it works

- Press Play to start continuous requests. The scheduler targets two real HTTP requests per second, with four independent vehicle questions in each batch, using `gpt-6-luna` and the [Decisions API](https://developers.openai.com/api/reference/resources/decisions/methods/create). It allows at most two in-flight requests and excludes vehicles already awaiting a response.
- Each observation includes speed, front and rear gaps, adjacent-lane availability, waiting time, and distance to a lane closure. Only available maneuvers are offered. Returned answers must match every named vehicle question before any choice is accepted.
- Local deterministic physics executes the returned choices and rechecks the current gaps. It controls acceleration and braking, reserves both lanes during a merge, and prevents overlapping vehicles. It does not independently choose lane changes. A driving choice expires after six simulation seconds; a vehicle without a fresh choice slows and stops.
- The always-visible feed separates real HTTP requests from individual driver decisions. Receipts show actual model, elapsed time, upstream request ID when supplied, and token usage. Applied, blocked, and stale choices remain distinguishable. Click a vehicle or a decision chip to inspect that driver.
- The three scenarios vary traffic mix and demand. Vehicles merge from a feeder road and around a closed lane. Arrivals that cannot enter remain queued in the simulation; demand is not silently discarded.
- Each run is limited to two minutes of active wall-clock time, including time spent awaiting or retrying API calls. At the limit, physics and requests stop, pending calls are canceled, and results remain visible. Pause/backgrounding preserve the remaining allowance; **Run again** starts a new run only after an explicit click.
- Pause, reset, scenario changes, and hiding the tab cancel pending requests. Late results are ignored. Transient failures back off, rate limits respect Retry-After, and configuration/authentication failures stop the loop. The simulation starts paused and does not spend API tokens until Play.
- Soft sound cues mark controls and occasional lane changes. The mute preference is remembered locally. Audio starts only after an interaction and stops when hidden. Visual motion respects reduced-motion preferences.
- Logs and simulation state stay in browser memory. The feed keeps the latest 72 batches; counters retain the session totals. Rates use the latest five seconds.

## Usage limits

Every paid route reserves an atomic D1 quota for the visitor's network before reading input or contacting OpenAI. `/api/traffic` allows 180 requests per minute and 1,000 per UTC day; `/api/control` allows 20 per minute and 100 per UTC day. The normal two-minute traffic run makes at most 240 requests. Same-origin validation runs before quota reservation.

Quotas are shared across Worker instances, tabs, and anonymous visitors on the same IP. Only the edge-provided `CF-Connecting-IP` is used, never `X-Forwarded-For` or a browser-provided user ID. D1 stores hashed IP/bucket identifiers and expiring counters, not raw IPs, prompts, or simulation content. Missing trusted IPs or unavailable storage fail closed with HTTP 503; quota exhaustion returns HTTP 429 and the actual `Retry-After` and reset time.

The client preserves cooldowns across pause, reset, and Run again. A wait of two minutes or longer pauses automatic requests; shorter retry waits count toward the current run's two-minute allowance. Existing results remain visible. Bind D1 as `DB` and apply the bundled Drizzle migration before local use; Sites applies bundled migrations during publishing. The download keeps the `DB` declaration while stripping the original deployment identity.

## Original signal controller

`/junction` preserves the original intersection demo. Ask it to change a timing plan and compare with a balanced baseline using the same incoming traffic. Decisions selects a bounded plan; Responses streams its explanation with `service_tier: "fast"`. Its API activity panel shows actual calls and the point at which a plan is applied. The new vehicle demo does not make a Responses call for every driver.

## Simulation scope

This is a stylized educational simulation with synthetic traffic, not a real-world driving controller. Buildings and pedestrians in the corridor are scenery. The physics and demand are deterministic for a seed; model choices and request timing can produce different traffic outcomes. Lane spacing and movement are deliberately simplified for legibility.

## Hosting with Sites

Configure `OPENAI_API_KEY` as a server secret and bind D1 as `DB`. The server sends only to `https://api.openai.com/v1/decisions` and `https://api.openai.com/v1/responses`; it rejects redirects and does not forward upstream error bodies. No private tunnel or connected app is required. Retain the starter's Sites build integration. Public sharing is configured in Sites independently of source versions. Requests and results are not saved by the demo; visible history lasts only in the current page's memory.

`npm run package:source` rebuilds `public/signal-project.zip` using Python 3. It excludes credentials, deployment identity, dependencies, build output, and local verification files. The archive contains a blank `.env.example` and a neutral hosting manifest.

Inter is distributed under the SIL Open Font License in `public/fonts/Inter-LICENSE.txt`. Dependency licenses remain with their respective packages.
