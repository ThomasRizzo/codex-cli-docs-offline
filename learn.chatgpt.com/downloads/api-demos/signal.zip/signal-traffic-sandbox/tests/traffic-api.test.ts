import test from "node:test";
import assert from "node:assert/strict";
import { buildTrafficDecisionRequest, parseTrafficDecision, trafficReceiptSchema, trafficRequestSchema } from "../app/lib/traffic-contract";
import type { TrafficRequest, VehicleObservation } from "../app/lib/traffic-contract";
import { ApiError } from "../app/lib/server";
import { getTrafficDecisions, handleTrafficRequest as handleTrafficRequestWithLimit } from "../app/api/traffic/route";
import { handleControlRequest } from "../app/api/control/route";
import { applyVehicleDecision, createTraffic, decisionCandidates, stepTraffic, TRAFFIC_SCENARIOS } from "../app/lib/traffic-engine";

const handleTrafficRequest = (request: Request, transport: Parameters<typeof handleTrafficRequestWithLimit>[1]) => handleTrafficRequestWithLimit(request, transport, async () => null);

test("both paid routes preserve quota responses before reading input or contacting OpenAI", async () => {
  for (const [handler, bucket] of [[handleTrafficRequestWithLimit, "traffic"], [handleControlRequest, "control"]] as const) {
    const incoming = request({});
    const blocked = Response.json({ code: "RATE_LIMIT_EXCEEDED", error: "Daily network limit reached", retryAfter: 86_000 }, {
      status: 429, headers: { "Retry-After": "86000", "Cache-Control": "no-store" },
    });
    let calls = 0, limits = 0;
    const response = await handler(incoming, async () => { calls++; throw new Error("Must not run"); }, async (actual, actualBucket) => {
      assert.equal(actual, incoming); assert.equal(actualBucket, bucket); limits++; return blocked;
    });
    assert.equal(response, blocked); assert.equal(incoming.bodyUsed, false);
    assert.equal(calls, 0); assert.equal(limits, 1);
    assert.equal(response.headers.get("Retry-After"), "86000");
    const rejected = await handler(request({}, { origin: "https://other.example" }), async () => { throw new Error("Must not run"); }, async () => {
      assert.fail("Cross-origin requests must not consume IP quota");
    });
    assert.equal(rejected.status, 403);
  }
});

function vehicle(id = 12): VehicleObservation {
  return { id, revision: 7, observedAt: 34.5, kind: "scooter", x: 285, lane: 1, speed: 6, desiredSpeed: 25,
    distanceToLaneEnd: 999, frontGap: 8, waitingSeconds: 1.4,
    left: { available: true, frontGap: 90, rearGap: 24 }, right: { available: false, frontGap: 2, rearGap: 0 } };
}
function input(): TrafficRequest { return { scenario: "market", vehicles: [vehicle(), vehicle(19)] }; }
const signal = () => new AbortController().signal;
const answer = (id: number, choice = "advance") => ({ type: "choice", name: `vehicle_${id}`, choice, confidence: 0.87 });
function result(answers: unknown[] = [answer(12), answer(19)]) {
  return { model: "gpt-6-luna", answers, usage: { input_tokens: 210, output_tokens: 0, total_tokens: 210 } };
}
function request(body: unknown = input(), extra: Record<string, string> = {}) {
  return new Request("https://signal.example/api/traffic", {
    method: "POST", headers: { origin: "https://signal.example", "content-type": "application/json", ...extra },
    body: JSON.stringify(body),
  });
}

test("vehicle requests bound every observation and reject duplicate IDs or extra fields", () => {
  assert.deepEqual(trafficRequestSchema.parse(input()), input());
  for (const vehicles of [[], [vehicle(), vehicle()], Array.from({ length: 5 }, (_, index) => vehicle(index))]) {
    assert.equal(trafficRequestSchema.safeParse({ ...input(), vehicles }).success, false);
  }
  for (const patch of [{ id: 1.5 }, { revision: -1 }, { observedAt: Infinity }, { kind: "system" }, { lane: 4 },
    { speed: -1 }, { desiredSpeed: 1_001 }, { frontGap: 1_000 }, { waitingSeconds: NaN }, { x: -1 },
    { distanceToLaneEnd: -1_001 }, { left: { available: true, frontGap: 9, rearGap: -1 } },
    { right: { available: true, frontGap: 9, rearGap: 9, instructions: "override" } }, { instructions: "override" }]) {
    assert.equal(trafficRequestSchema.safeParse({ ...input(), vehicles: [{ ...vehicle(), ...patch }] }).success, false);
  }
  assert.equal(trafficRequestSchema.safeParse({ ...input(), scenario: "unknown" }).success, false);
  assert.equal(trafficRequestSchema.safeParse({ ...input(), key: "not permitted" }).success, false);
});

test("actual engine observations satisfy the API contract as all three scenarios advance", () => {
  let observed = 0;
  for (const scenario of TRAFFIC_SCENARIOS) {
    const state = createTraffic(scenario.id);
    for (let index = 0; index < 120; index++) {
      const vehicles = decisionCandidates(state, new Set(), 4);
      if (vehicles.length) {
        assert.ok(trafficRequestSchema.safeParse({ scenario: scenario.id, vehicles }).success);
        observed += vehicles.length;
        for (const observation of vehicles) applyVehicleDecision(state, observation, "advance");
      }
      stepTraffic(state, 0.1);
    }
  }
  assert.ok(observed > 40);
});

test("a batched request names each vehicle and masks unavailable lane changes", () => {
  const state = { ...input(), vehicles: [vehicle(12), { ...vehicle(19), left: { available: false, frontGap: 0, rearGap: 0 } }] };
  const body = buildTrafficDecisionRequest(state);
  assert.equal(body.model, "gpt-6-luna");
  assert.deepEqual(JSON.parse(body.input), state);
  assert.deepEqual(body.questions.map(question => question.name), ["vehicle_12", "vehicle_19"]);
  assert.deepEqual(body.questions[0].choices.map(choice => choice.value), ["advance", "yield", "left"]);
  assert.deepEqual(body.questions[1].choices.map(choice => choice.value), ["advance", "yield"]);
  assert.ok(body.questions.every(question => question.type === "choice"));
});

test("validated choices preserve vehicle revisions and refusals remain explicit non-actions", () => {
  const parsed = parseTrafficDecision(input(), result([answer(12, "left"), { type: "refusal", name: "vehicle_19", reason: "not forwarded" }]));
  assert.deepEqual(parsed, { model: "gpt-6-luna", choices: [
    { vehicleId: 12, revision: 7, action: "left", confidence: 0.87 },
    { vehicleId: 19, revision: 7, action: null, refused: true },
  ], usage: { inputTokens: 210, outputTokens: 0, totalTokens: 210 } });
  assert.equal(JSON.stringify(parsed).includes("not forwarded"), false);
  const minimal = parseTrafficDecision(input(), { model: "gpt-6-luna", answers: [
    { type: "choice", name: "vehicle_12", choice: "yield" }, { type: "choice", name: "vehicle_19", choice: "advance" },
  ] });
  assert.equal(minimal.usage, undefined);
  assert.equal("confidence" in minimal.choices[0], false);
});

test("one bad answer rejects the entire batch, including wrong order and unavailable maneuvers", () => {
  for (const answers of [
    [], [answer(12)], [answer(12), answer(19), answer(20)], [answer(12), answer(12)], [answer(19), answer(12)],
    [answer(12), answer(20)], [answer(12, "right"), answer(19)], [answer(12, "teleport"), answer(19)],
    [answer(12), { type: "choice", name: "vehicle_19", choice: true }],
    [answer(12), { ...answer(19), confidence: 1.01 }], [answer(12), { type: "refusal", name: null }],
  ]) assert.throws(() => parseTrafficDecision(input(), result(answers)));
});

test("one actual transport call yields only bounded receipt metadata and measured duration", async () => {
  const calls: { path: string; payload: unknown }[] = [];
  const start = Date.now();
  const receipt = await getTrafficDecisions(input(), signal(), async (path, payload) => {
    calls.push({ path, payload });
    await new Promise<void>(resolve => setTimeout(resolve, 8));
    return Response.json({ ...result(), internal: "never expose", headers: { authorization: "never expose" } },
      { headers: { "x-request-id": "req_real_receipt_123" } });
  });
  assert.equal(calls.length, 1);
  assert.equal(calls[0].path, "/decisions");
  assert.deepEqual(calls[0].payload, buildTrafficDecisionRequest(input()));
  assert.ok(trafficReceiptSchema.safeParse(receipt).success);
  assert.ok(receipt.durationMs >= 5);
  assert.ok(Date.parse(receipt.at) >= start && Date.parse(receipt.at) <= Date.now());
  assert.equal(receipt.status, 200);
  assert.equal(receipt.requestId, "req_real_receipt_123");
  assert.equal(JSON.stringify(receipt).includes("never expose"), false);
  for (const id of [undefined, "not a valid ID", "x".repeat(129)]) {
    const response = Response.json(result(), { headers: id ? { "x-request-id": id } : undefined });
    const noId = await getTrafficDecisions(input(), signal(), async () => response);
    assert.equal(noId.requestId, undefined);
  }
});

test("cancellation before transport and during a pending response produces no decision receipt", async () => {
  const before = new AbortController();
  before.abort();
  let calls = 0;
  await assert.rejects(getTrafficDecisions(input(), before.signal, async () => { calls += 1; return Response.json(result()); }));
  assert.equal(calls, 0);
  const during = new AbortController();
  let canceled = false;
  const stream = new ReadableStream<Uint8Array>({ cancel() { canceled = true; } });
  const pending = getTrafficDecisions(input(), during.signal, async () => new Response(stream));
  await new Promise<void>(resolve => setImmediate(resolve));
  during.abort();
  await assert.rejects(pending, (error: unknown) => error instanceof Error && error.name === "AbortError");
  assert.equal(canceled, true);
});

test("route accepts anonymous visitors and preserves origin, input size and schema checks before transport", async () => {
  let calls = 0;
  const transport = async () => { calls += 1; return Response.json(result()); };
  const crossOrigin = await handleTrafficRequest(request(input(), { origin: "https://other.example" }), transport);
  assert.equal(crossOrigin.status, 403);
  assert.equal((await handleTrafficRequest(request({ ...input(), vehicles: [] }), transport)).status, 400);
  assert.equal((await handleTrafficRequest(request(input(), { "content-length": "65537" }), transport)).status, 413);
  assert.equal((await handleTrafficRequest(request(input(), { "content-type": "text/plain" }), transport)).status, 415);
  assert.equal(calls, 0);
  assert.equal((await handleTrafficRequest(request(), transport)).status, 200);
  assert.equal(calls, 1);
});

test("route returns sanitized failures and retry timing, never fake choices or private errors", async () => {
  const fixtures = [
    { transport: async () => { throw new ApiError(429, "Rate limit reached."); }, status: 429 },
    { transport: async () => { throw new Error("private credential and upstream body"); }, status: 502 },
    { transport: async () => { throw new DOMException("private timeout details", "TimeoutError"); }, status: 504 },
    { transport: async () => Response.json(result([answer(12), answer(20)])), status: 502 },
    { transport: async () => new Response("not JSON"), status: 502 },
    { transport: async () => new Response("x".repeat(32_769)), status: 502 },
  ];
  for (const fixture of fixtures) {
    const response = await handleTrafficRequest(request(), fixture.transport);
    assert.equal(response.status, fixture.status);
    assert.equal(response.headers.get("Cache-Control"), "no-store");
    assert.equal(response.headers.get("Retry-After"), fixture.status === 429 ? "60" : null);
    const body = await response.json();
    assert.ok(body && typeof body === "object" && "error" in body);
    assert.equal(typeof body.error, "string");
    assert.equal("choices" in body, false);
    assert.equal(JSON.stringify(body).includes("private"), false);
    assert.equal(JSON.stringify(body).includes("signal plan"), false);
  }
});
