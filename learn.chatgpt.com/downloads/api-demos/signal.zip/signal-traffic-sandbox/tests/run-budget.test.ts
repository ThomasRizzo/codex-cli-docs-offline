import assert from "node:assert/strict";
import test from "node:test";
import { ActiveRunBudget, RUN_LIMIT_SECONDS } from "../app/lib/run-budget";
import { TrafficDecisionLoop } from "../app/lib/traffic-loop";
import type { VehicleObservation } from "../app/lib/traffic-engine";
import type { TrafficReceipt } from "../app/lib/traffic-contract";

test("a run expires at two minutes of playing time even when the expiry timer runs late", () => {
  let now = 10_000;
  const budget = new ActiveRunBudget(undefined, () => now);
  assert.equal(RUN_LIMIT_SECONDS, 120);
  assert.equal(budget.elapsedMs, 0);
  assert.equal(budget.start(), true);
  now += 119_999;
  assert.equal(budget.expired, false);
  assert.equal(budget.remainingMs, 1);
  now += 1;
  assert.equal(budget.expired, true);
  now += 60_000;
  assert.equal(budget.elapsedMs, 120_000);
  budget.pause();
  assert.equal(budget.start(), false, "an expired run cannot silently start another allowance");
});

test("pauses and background time preserve the remaining allowance across repeated resumes", () => {
  let now = 0;
  const budget = new ActiveRunBudget(undefined, () => now);
  now = 30_000;
  assert.equal(budget.elapsedMs, 0, "initial idle time is free");
  budget.start(); now += 45_000; budget.pause();
  now += 600_000;
  assert.equal(budget.elapsedMs, 45_000);
  assert.equal(budget.remainingMs, 75_000);
  budget.start(); now += 15_000; budget.start();
  assert.equal(budget.elapsedMs, 60_000, "starting twice must not reset the clock");
  budget.pause(); now += 600_000; budget.start(); now += 60_000;
  assert.equal(budget.expired, true);
});

test("reset gives a fresh paused run without inheriting the old deadline", () => {
  let now = 0;
  const budget = new ActiveRunBudget(undefined, () => now);
  budget.start(); now = 120_000;
  assert.equal(budget.expired, true);
  budget.reset(); now = 240_000;
  assert.equal(budget.elapsedMs, 0);
  assert.equal(budget.running, false);
  assert.equal(budget.expired, false);
  assert.equal(budget.start(), true);
  now += 40_000;
  assert.equal(budget.remainingMs, 80_000);
});

test("retry backoff consumes the run allowance without needing physics or API progress", () => {
  let now = 0;
  const budget = new ActiveRunBudget(undefined, () => now);
  budget.start();
  now = 20_000;
  assert.equal(budget.remainingMs, 100_000);
  now += 100_000;
  assert.equal(budget.expired, true);
});

test("deadline guards abort pending decisions and ignore late responses before a delayed timer fires", async () => {
  let now = 0, requests = 0, applications = 0;
  const budget = new ActiveRunBudget(undefined, () => now);
  const pending: { signal: AbortSignal; resolve: (receipt: TrafficReceipt) => void }[] = [];
  const stopped: number[] = [];
  const observation = { id: 1, revision: 0 } as VehicleObservation;
  const receipt = { at: "2026-10-18T22:00:00.000Z", model: "gpt-6-luna", durationMs: 100, status: 200,
    choices: [{ vehicleId: 1, revision: 0, action: "advance" }] } as TrafficReceipt;
  const loop = new TrafficDecisionLoop({
    candidates: () => {
      if (budget.expired) { budget.pause(); loop.stop(); return []; }
      return [observation];
    },
    submit: (_vehicles, signal) => new Promise(resolve => { requests++; pending.push({ signal, resolve }); }),
    nextId: () => requests + 1,
    started: () => {},
    completed: () => {
      if (budget.expired) { budget.pause(); loop.stop(); return; }
      applications++;
    },
    failed: () => {}, backoff: () => {}, stopped: ids => stopped.push(...ids),
  }, () => now);
  budget.start(); loop.tick(); now = 500; loop.tick();
  assert.equal(requests, 2);
  now = 120_001;
  pending[0].resolve(receipt);
  await new Promise<void>(resolve => setImmediate(resolve));
  assert.equal(applications, 0);
  assert.deepEqual(stopped, [1, 2]);
  assert.ok(pending.every(request => request.signal.aborted));
  pending[1].resolve(receipt);
  await new Promise<void>(resolve => setImmediate(resolve));
  loop.tick();
  assert.equal(requests, 2);
  assert.equal(applications, 0);
});
