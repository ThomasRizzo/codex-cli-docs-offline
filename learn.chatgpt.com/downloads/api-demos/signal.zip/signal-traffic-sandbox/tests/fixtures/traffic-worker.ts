import { env } from "cloudflare:workers";
import { enforceIpRateLimitWithDb } from "../../app/lib/ip-rate-limit";
import { handleTrafficRequest } from "../../app/api/traffic/route";

let transportCalls = 0;

/** Vinext routes expose a property-forwarding Proxy, not the native Request itself. */
function trackedRequest(request: Request): Request {
  return new Proxy(request, {
    get(target, property) {
      const value = Reflect.get(target, property, target);
      return typeof value === "function" ? value.bind(target) : value;
    },
  });
}

export default {
  async fetch(incoming: Request): Promise<Response> {
    const request = trackedRequest(incoming);
    if (new URL(incoming.url).pathname === "/constructor-probe") {
      try {
        new Request(request, { signal: request.signal });
        return Response.json({ threw: false });
      } catch (error) {
        return Response.json({ threw: true, name: error instanceof Error ? error.name : "unknown" });
      }
    }
    const response = await handleTrafficRequest(request, async (path, payload, signal) => {
      transportCalls++;
      if (path !== "/decisions") throw new Error("Unexpected API path in local fixture.");
      signal.throwIfAborted();
      const questions = (payload as { questions: { name: string; choices: { value: string }[] }[] }).questions;
      return Response.json({
        model: "gpt-6-luna",
        answers: questions.map(question => ({ type: "choice", name: question.name, choice: question.choices[0].value, confidence: .9 })),
        usage: { input_tokens: 120, output_tokens: 0, total_tokens: 120 },
      }, { headers: { "x-request-id": "req_local_worker_fixture" } });
    }, (request, bucket, policy) => enforceIpRateLimitWithDb(env.DB, request, bucket, policy, Date.UTC(2026, 9, 19, 12, 0, 10)));
    response.headers.set("x-fixture-transport-calls", String(transportCalls));
    return response;
  },
};
