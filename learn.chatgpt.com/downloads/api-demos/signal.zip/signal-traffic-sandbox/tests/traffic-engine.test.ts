import assert from "node:assert/strict";
import test from "node:test";
import {
  ACTION_LEASE_SECONDS, MINIMUM_GAP, TRAFFIC_SCENARIOS, TRAFFIC_STEP,
  applyVehicleDecision, createTraffic, decisionCandidates, observeVehicle, stepTraffic, vehicleY,
  type Lane, type Maneuver, type TrafficState, type TrafficVehicle,
} from "../app/lib/traffic-engine";

function vehicle(id: number, lane: Lane, x: number, speed = 0): TrafficVehicle {
  return { id, kind: "car", x, lane, speed, desiredSpeed: 35, length: 22, width: 12,
    targetLane: null, laneProgress: 0, decisionRevision: 0, lastDecisionAt: -1,
    leaseUntil: 0, lastAction: null, highlightUntil: 0 };
}
function fixture(vehicles: TrafficVehicle[]): TrafficState {
  const state = createTraffic();
  state.vehicles = vehicles;
  state.arrivals = vehicles.length;
  state.nextId = 100;
  state.nextArrivalAt = 1_000_000;
  state.waitingSeconds = Object.fromEntries(vehicles.map(item => [item.id, 0]));
  return state;
}
function choose(state: TrafficState, id: number, action: Maneuver) {
  const observation = observeVehicle(state, id);
  assert.ok(observation);
  return applyVehicleDecision(state, observation, action, "req_test");
}
function assertSpacing(state: TrafficState): void {
  for (const lane of [0, 1, 2, 3]) {
    const occupants = state.vehicles.filter(item => item.lane === lane || item.targetLane === lane).sort((a, b) => b.x - a.x);
    for (let index = 1; index < occupants.length; index++) {
      const front = occupants[index - 1], rear = occupants[index];
      assert.ok(front.x - front.length / 2 - rear.x - rear.length / 2 >= MINIMUM_GAP - 1e-7,
        `Vehicles ${front.id}/${rear.id} overlap their lane ${lane} reservations at ${state.time}`);
    }
  }
  for (const item of state.vehicles) {
    for (const lane of [item.lane, item.targetLane]) {
      if (lane === 2) assert.ok(item.x + item.length / 2 <= 596 + 1e-7);
      if (lane === 3) assert.ok(item.x + item.length / 2 <= 336 + 1e-7);
    }
    assert.ok(Number.isFinite(item.speed) && item.speed >= 0);
  }
  const queued = Object.values(state.pendingDemand).reduce((sum, count) => sum + count, 0);
  assert.equal(state.arrivals, state.completed + state.vehicles.length + queued);
}

test("local physics cannot start cars or invent lane changes without an API decision", () => {
  const state = createTraffic("bottleneck", 7);
  const poses = state.vehicles.map(({ id, x, lane }) => ({ id, x, lane }));
  stepTraffic(state, 30);
  assert.deepEqual(state.vehicles.filter(item => poses.some(pose => pose.id === item.id)).map(({ id, x, lane }) => ({ id, x, lane })), poses);
  assert.equal(state.merges, 0);
  assert.equal(state.completed, 0);
  assert.ok(state.vehicles.every(item => item.lastAction === null && item.speed === 0));
  assertSpacing(state);
});

test("fixed physics gives identical poses for different render frame chunks", () => {
  const whole = createTraffic("rush", 18);
  const frames = createTraffic("rush", 18);
  for (const state of [whole, frames]) for (const item of state.vehicles) choose(state, item.id, "advance");
  stepTraffic(whole, 10);
  for (let frame = 0; frame < 600; frame++) stepTraffic(frames, 1 / 60);
  assert.deepEqual(whole, frames);
  assertSpacing(whole);
});

test("accepted actions move cars, then expired leases bring them to a complete stop", () => {
  const state = fixture([vehicle(1, 0, 40)]);
  assert.equal(choose(state, 1, "advance").status, "applied");
  stepTraffic(state, 3);
  assert.ok(state.vehicles[0].x > 70);
  assert.ok(state.vehicles[0].speed > 20);
  stepTraffic(state, ACTION_LEASE_SECONDS);
  assert.equal(state.vehicles[0].speed, 0);
  const stoppedX = state.vehicles[0].x;
  stepTraffic(state, 5);
  assert.equal(state.vehicles[0].x, stoppedX);
  assert.equal(state.vehicles[0].lastAction, "advance");
});

test("yield decelerates and blocked actions preserve the attempted action and fair rotation", () => {
  const state = fixture([vehicle(1, 0, 100), vehicle(2, 1, 100)]);
  choose(state, 1, "advance");
  stepTraffic(state, 1);
  assert.equal(choose(state, 1, "yield").status, "applied");
  stepTraffic(state, 1);
  assert.equal(state.vehicles[0].speed, 0);
  const beforeRevision = state.vehicles[1].decisionRevision;
  assert.equal(choose(state, 2, "left").status, "blocked");
  assert.equal(state.vehicles[1].lastDecisionAt, state.time);
  assert.equal(state.vehicles[1].lastAction, "left");
  assert.equal(state.vehicles[1].decisionRevision, beforeRevision + 1);
  assert.equal(state.blocked, 1);
});

test("lane changes reserve both lanes and actually merge feeder traffic into the corridor", () => {
  const state = fixture([vehicle(1, 3, 290), vehicle(2, 3, 230), vehicle(3, 2, 380)]);
  const beforeY = vehicleY(state.vehicles[0]);
  assert.equal(choose(state, 1, "left").status, "applied");
  choose(state, 2, "advance");
  stepTraffic(state, .6);
  assert.ok(vehicleY(state.vehicles[0]) < beforeY && vehicleY(state.vehicles[0]) > 270);
  assert.equal(state.vehicles[0].lane, 3);
  assert.equal(state.vehicles[0].targetLane, 2);
  assertSpacing(state);
  stepTraffic(state, 1);
  assert.equal(state.vehicles[0].lane, 2);
  assert.equal(state.vehicles[0].targetLane, null);
  assert.equal(vehicleY(state.vehicles[0]), 270);
  assert.equal(state.merges, 1);
  assertSpacing(state);
});

test("simultaneous merges into the same gap cannot both commit", () => {
  const state = fixture([vehicle(1, 0, 200), vehicle(2, 2, 200)]);
  const first = observeVehicle(state, 1)!;
  const second = observeVehicle(state, 2)!;
  assert.equal(first.right.available, true);
  assert.equal(second.left.available, true);
  assert.equal(applyVehicleDecision(state, first, "right").status, "applied");
  assert.equal(applyVehicleDecision(state, second, "left").status, "blocked");
  for (let i = 0; i < 60; i++) { stepTraffic(state, TRAFFIC_STEP); assertSpacing(state); }
  assert.equal(state.merges, 1);
});

test("gap safety is rechecked against current positions and closing rear traffic", () => {
  const state = fixture([vehicle(1, 1, 200), vehicle(2, 0, 150)]);
  const observation = observeVehicle(state, 1)!;
  assert.equal(observation.left.available, true);
  state.vehicles[1].speed = 60;
  assert.equal(observeVehicle(state, 1)!.left.available, false);
  assert.equal(applyVehicleDecision(state, observation, "left").status, "blocked");
  state.vehicles[1].speed = 0;
  const another = observeVehicle(state, 1)!;
  state.vehicles[1].x = 195;
  assert.equal(applyVehicleDecision(state, another, "left").status, "blocked");
  assert.equal(state.vehicles[0].targetLane, null);
});

test("old, duplicate, future, and departed-vehicle observations cannot change traffic", () => {
  const state = fixture([vehicle(1, 0, 100)]);
  const observation = observeVehicle(state, 1)!;
  assert.equal(applyVehicleDecision(state, observation, "advance").status, "applied");
  assert.equal(applyVehicleDecision(state, observation, "right").status, "stale");
  const current = observeVehicle(state, 1)!;
  assert.equal(applyVehicleDecision(state, { ...current, observedAt: state.time + 1 }, "yield").status, "stale");
  stepTraffic(state, 4.1);
  assert.equal(applyVehicleDecision(state, current, "right").status, "stale");
  state.vehicles = [];
  assert.equal(applyVehicleDecision(state, current, "right").status, "stale");
});

test("lane endpoints stop vehicles and through traffic cannot enter the feeder", () => {
  const state = fixture([vehicle(1, 3, 310), vehicle(2, 2, 570)]);
  for (const item of state.vehicles) choose(state, item.id, "advance");
  stepTraffic(state, 4);
  assert.equal(state.vehicles[0].x, 325);
  assert.equal(state.vehicles[1].x, 585);
  assert.equal(state.vehicles[0].speed, 0);
  assert.equal(state.vehicles[1].speed, 0);
  assert.equal(observeVehicle(state, 2)!.right.available, false);
  assert.equal(choose(state, 2, "right").status, "blocked");
  assertSpacing(state);
});

test("candidate rotation excludes in-flight cars, bounds batch size, and covers every vehicle", () => {
  const state = createTraffic();
  const originalIds = new Set(state.vehicles.map(item => item.id));
  const visited = new Set<number>();
  for (let round = 0; round < 8; round++) {
    for (const observation of decisionCandidates(state, new Set(), 4)) {
      visited.add(observation.id);
      applyVehicleDecision(state, observation, "yield");
    }
    stepTraffic(state, .5);
  }
  assert.deepEqual(visited, originalIds);
  const excluded = new Set([...originalIds].slice(0, 5));
  assert.ok(decisionCandidates(state, excluded, 4).every(item => !excluded.has(item.id)));
  assert.throws(() => decisionCandidates(state, new Set(), 1_000));
});

for (const scenario of TRAFFIC_SCENARIOS) {
  test(`${scenario.label}: repeated validated decisions complete trips and merges without conflicts`, () => {
    const state = createTraffic(scenario.id, 31);
    // This deterministic policy stands in for explicit API receipts in a physics test.
    // Production code never calls it or chooses substitute maneuvers locally.
    for (let tick = 0; tick < 2400; tick++) {
      if (tick % 10 === 0) {
        for (const observation of decisionCandidates(state, new Set(), 6)) {
          const needsGap = observation.distanceToLaneEnd < 120 || observation.frontGap < 40;
          const action: Maneuver = needsGap && observation.left.available ? "left"
            : needsGap && observation.right.available && observation.right.frontGap > observation.frontGap + 15 ? "right"
            : observation.frontGap > MINIMUM_GAP ? "advance" : "yield";
          applyVehicleDecision(state, observation, action);
        }
      }
      stepTraffic(state, TRAFFIC_STEP);
      assertSpacing(state);
      assert.ok(state.vehicles.length <= 32);
    }
    assert.ok(state.completed > 20, `Only ${state.completed} trips completed`);
    assert.ok(state.merges > 10, `Only ${state.merges} merges completed`);
    assert.ok(state.vehicles.some(item => item.kind === "scooter"));
  });
}

test("invalid time, scenario, and seed inputs leave valid state unchanged", () => {
  const state = createTraffic();
  const before = structuredClone(state);
  for (const dt of [-1, NaN, Infinity, 61]) assert.throws(() => stepTraffic(state, dt));
  assert.deepEqual(state, before);
  assert.throws(() => createTraffic("missing" as never));
  assert.throws(() => createTraffic("market", NaN));
});
