import assert from "node:assert/strict";
import test from "node:test";
import {
  CLEAR_LINE, DIRECTIONS, FIXED_STEP, POLICIES, SCENARIOS, STOP_LINE, VEHICLE_GAP,
  createComparison, createSimulation, metrics, setPolicy, stepComparison, stepSimulation,
  type SimulationState,
} from "../app/lib/simulation";

function advance(state: SimulationState, seconds: number): void {
  for (let time = 0; time < seconds; time += 1) stepSimulation(state, Math.min(1, seconds - time));
}

function assertSafe(state: SimulationState): void {
  const occupied = state.vehicles.filter(vehicle => vehicle.progress + vehicle.length / 2 > STOP_LINE + 1e-7 && vehicle.progress - vehicle.length / 2 < CLEAR_LINE - 1e-7);
  const northSouth = occupied.some(vehicle => vehicle.direction === "north" || vehicle.direction === "south");
  const eastWest = occupied.some(vehicle => vehicle.direction === "east" || vehicle.direction === "west");
  assert.ok(!(northSouth && eastWest), `Conflicting vehicle movements at ${state.time}`);
  assert.ok(!(occupied.length && state.pedestrians.length), `Vehicle/pedestrian conflict at ${state.time}`);
  if (state.signal === "green" && state.phase === "north_south") assert.equal(eastWest, false);
  if (state.signal === "green" && state.phase === "east_west") assert.equal(northSouth, false);
  for (const direction of DIRECTIONS) {
    const lane = state.vehicles.filter(vehicle => vehicle.direction === direction).sort((a, b) => b.progress - a.progress);
    for (let index = 1; index < lane.length; index++) {
      const leader = lane[index - 1];
      const follower = lane[index];
      assert.ok(leader.progress - leader.length / 2 - follower.progress - follower.length / 2 >= VEHICLE_GAP - 1e-7, `Rear-end overlap on ${direction} at ${state.time}`);
    }
  }
}

function assertConserved(state: SimulationState): void {
  const pendingVehicles = DIRECTIONS.reduce((sum, direction) => sum + state.vehicleBacklog[direction].length, 0);
  const pendingPedestrians = DIRECTIONS.reduce((sum, direction) => sum + state.pedestrianBacklog[direction].length, 0);
  assert.equal(state.totals.vehiclesArrived, state.totals.vehiclesCompleted + state.vehicles.length + pendingVehicles);
  assert.equal(state.totals.pedestriansArrived, state.totals.pedestriansCompleted + state.pedestrians.length + pendingPedestrians);
  assert.equal(state.totals.busesArrived, state.totals.busesCompleted + state.vehicles.filter(vehicle => vehicle.kind === "bus").length + DIRECTIONS.reduce((sum, direction) => sum + state.vehicleBacklog[direction].filter(vehicle => vehicle.kind === "bus").length, 0));
  assert.deepEqual(state.waitingPedestrians, Object.fromEntries(DIRECTIONS.map(direction => [direction, state.pedestrianBacklog[direction].length])));
}

test("fixed physics produces the same state regardless of browser frame chunks", () => {
  const large = createSimulation("event_traffic", 17);
  const small = createSimulation("event_traffic", 17);
  stepSimulation(large, 60);
  for (let frame = 0; frame < 3600; frame++) stepSimulation(small, 1 / 60);
  assert.equal(large.time, 60);
  assert.deepEqual(metrics(large), metrics(small));
  assert.deepEqual(large.vehicles, small.vehicles);
  assert.deepEqual(large.pedestrians, small.pedestrians);
  assert.deepEqual(large.vehicleStreams, small.vehicleStreams);
});

test("different seeds vary demand while repeated seeds reproduce it", () => {
  const first = createSimulation("morning_rush", 42);
  const copy = createSimulation("morning_rush", 42);
  const other = createSimulation("morning_rush", 43);
  advance(first, 120);
  advance(copy, 120);
  advance(other, 120);
  assert.deepEqual(first, copy);
  assert.notDeepEqual(first.arrivals, other.arrivals);
});

test("baseline receives identical demand even when the live policy changes repeatedly", () => {
  const pair = createComparison("bus_corridor", 113);
  for (let second = 0; second < 600; second++) {
    if (second % 37 === 0) setPolicy(pair.live, POLICIES[Math.floor(second / 37) % POLICIES.length].id);
    stepComparison(pair, 1);
    assert.equal(pair.live.time, pair.baseline.time);
    assert.deepEqual(pair.live.arrivals, pair.baseline.arrivals);
    assert.deepEqual(pair.live.vehicleStreams, pair.baseline.vehicleStreams);
    assert.deepEqual(pair.live.pedestrianStreams, pair.baseline.pedestrianStreams);
    assert.equal(pair.live.totals.busesArrived, pair.baseline.totals.busesArrived);
    assert.equal(pair.live.totals.pedestriansArrived, pair.baseline.totals.pedestriansArrived);
    assertConserved(pair.live);
    assertConserved(pair.baseline);
  }
  assert.equal(pair.baseline.policyId, "balanced");
  assert.notDeepEqual(metrics(pair.live), metrics(pair.baseline));
});

test("a requested policy waits for clearance and does not interrupt the current green", () => {
  const state = createSimulation("morning_rush");
  stepSimulation(state, 3);
  const remaining = state.phaseRemaining;
  setPolicy(state, "east_west_priority");
  assert.equal(state.policyId, "balanced");
  assert.equal(state.pendingPolicyId, "east_west_priority");
  assert.equal(state.phaseRemaining, remaining);
  while (state.pendingPolicyId) {
    stepSimulation(state, FIXED_STEP);
    assertSafe(state);
    assert.ok(state.time < 40, "Policy should take effect at the next safe boundary");
  }
  assert.equal(state.policyId, "east_west_priority");
  assert.equal(state.phase, "east_west");
  assert.equal(state.phaseRemaining, 30);
});

test("reselecting the active policy cancels an uncommitted change", () => {
  const state = createSimulation("balanced");
  setPolicy(state, "pedestrian_priority");
  setPolicy(state, "balanced");
  assert.equal(state.pendingPolicyId, null);
});

for (const scenario of SCENARIOS) {
  test(`${scenario.label}: every preset conserves demand and avoids conflicts and rear-end collisions`, () => {
    for (const policy of POLICIES) {
      const state = createSimulation(scenario.id, 987);
      setPolicy(state, policy.id);
      for (let tick = 0; tick < 12000; tick++) {
        stepSimulation(state, FIXED_STEP);
        assertSafe(state);
        if (tick % 100 === 0) assertConserved(state);
      }
      assertConserved(state);
      assert.ok(state.totals.vehiclesCompleted > 50);
      assert.ok(state.totals.pedestriansCompleted > 10);
      for (const direction of DIRECTIONS) assert.ok(state.arrivals[direction] > 10);
      // Completed trips are aggregated, never kept as an ever-growing entity array.
      assert.ok(state.vehicles.length < 120);
      assert.ok(state.pedestrians.length < 48);
      assert.ok(Object.values(metrics(state)).filter(value => typeof value === "number").every(Number.isFinite));
    }
  });
}

test("all-red lasts until an already committed vehicle clears, even beyond its minimum", () => {
  const state = createSimulation("balanced");
  state.vehicles = [{ id: 900, direction: "north", kind: "bus", progress: 300, length: 32, speed: 0, enteredAt: 0, waitTime: 0 }];
  state.phase = "clearance";
  state.signal = "red";
  state.phaseRemaining = 1;
  state.nextPhase = "east_west";
  stepSimulation(state, 1.1);
  assert.equal(state.phase, "clearance");
  while (state.phase === "clearance") {
    stepSimulation(state, FIXED_STEP);
    assertSafe(state);
    assert.ok(state.time < 10);
  }
  assert.equal(state.phase, "east_west");
  assert.ok(state.vehicles.find(vehicle => vehicle.id === 900)!.progress - 16 >= CLEAR_LINE);
});

test("offscreen backlog remains in queue and travel-time accounting", () => {
  const state = createSimulation("event_traffic");
  for (let index = 0; index < 50; index++) {
    state.vehicleBacklog.north.push({ id: 1000 + index, direction: "north", kind: "car", enteredAt: 0 });
    state.totals.vehiclesArrived++;
    state.arrivals.north++;
  }
  stepSimulation(state, 10);
  const reading = metrics(state);
  assert.ok(state.vehicleBacklog.north.length > 0);
  assert.ok(reading.queues.north >= state.vehicleBacklog.north.length);
  assert.ok(reading.meanQueueWaitSeconds > 4);
  assertConserved(state);
  advance(state, 300);
  assertConserved(state);
  assert.ok(state.totals.completedTravelSeconds > state.totals.vehiclesCompleted * 10);
});

test("bus priority extends at most once per east–west green and never past its bound", () => {
  const state = createSimulation("bus_corridor");
  state.policyId = "bus_priority";
  state.phase = "east_west";
  state.signal = "green";
  state.phaseRemaining = 2;
  state.vehicles = [{ id: 900, direction: "east", kind: "bus", progress: 20, length: 32, speed: 0, enteredAt: 0, waitTime: 0 }];
  stepSimulation(state, FIXED_STEP);
  assert.equal(state.busExtensionUsed, true);
  assert.ok(state.phaseRemaining > 9 && state.phaseRemaining <= 10);
  advance(state, 9);
  assert.ok(state.phaseRemaining < 1.1);
  stepSimulation(state, 1.1);
  assert.equal(state.signal, "amber");
});

test("invalid policies, scenarios, and time deltas cannot mutate the simulation", () => {
  const state = createSimulation("balanced");
  const before = structuredClone(state);
  assert.throws(() => setPolicy(state, "all_green" as never));
  assert.throws(() => createSimulation("nonsense" as never));
  for (const dt of [-1, Infinity, NaN, 61]) assert.throws(() => stepSimulation(state, dt));
  assert.deepEqual(state, before);
});
