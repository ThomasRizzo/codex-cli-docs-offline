import assert from 'node:assert/strict';
import test from 'node:test';
import { TrafficDecisionLoop, TrafficRequestError } from '../app/lib/traffic-loop';
import type { VehicleObservation } from '../app/lib/traffic-engine';
import type { TrafficReceipt } from '../app/lib/traffic-contract';
import { RequestCooldown, retryAfterMs } from '../app/lib/request-cooldown';
import { IP_LIMITS } from '../app/lib/rate-limit-policy';

const observation = (id: number) => ({ id, revision: 0 } as VehicleObservation);
const receipt = { at:'2026-10-18T22:00:00.000Z', model:'gpt-6-luna', durationMs:100, status:200, choices:[] } as TrafficReceipt;
const flush = () => new Promise<void>(resolve => setImmediate(resolve));
function fixture() {
  let time=0, nextId=0;
  const requests:{vehicles:VehicleObservation[];signal:AbortSignal;resolve:(value:TrafficReceipt)=>void;reject:(error:unknown)=>void}[]=[];
  const completed:{id:number;age:number}[]=[];
  const stopped:number[][]=[];
  const failures:Error[]=[];
  const backoffs:{until:number;fatal:boolean}[]=[];
  const excluded:Set<number>[]=[];
  const loop = new TrafficDecisionLoop({
    candidates:(ids,count)=>{excluded.push(new Set(ids));return Array.from({length:12},(_,index)=>observation(index+1)).filter(vehicle=>!ids.has(vehicle.id)).slice(0,count);},
    submit:(vehicles,signal)=>new Promise((resolve,reject)=>requests.push({vehicles,signal,resolve,reject})),
    nextId:()=>++nextId, started:()=>{},
    completed:(id,_observations,_receipt,age)=>completed.push({id,age}),
    failed:(_id,error)=>failures.push(error), stopped:ids=>stopped.push(ids),
    backoff:(until,fatal)=>backoffs.push({until,fatal}),
  },()=>time);
  return {loop,requests,completed,stopped,failures,backoffs,excluded,setTime:(value:number)=>{time=value;}};
}

test('continuous requests respect cadence, concurrency, and per-vehicle exclusivity',async()=>{
  const f=fixture();f.loop.tick();assert.equal(f.requests.length,1);assert.equal(f.requests[0].vehicles.length,4);
  f.setTime(499);f.loop.tick();assert.equal(f.requests.length,1);
  f.setTime(500);f.loop.tick();assert.equal(f.requests.length,2);
  assert.deepEqual(f.requests[1].vehicles.map(vehicle=>vehicle.id),[5,6,7,8]);
  f.setTime(1000);f.loop.tick();assert.equal(f.requests.length,2);
  f.requests[0].resolve(receipt);await flush();f.loop.tick();assert.equal(f.requests.length,3);
  assert.deepEqual(f.completed,[{id:1,age:1000}]);
  assert.deepEqual([...f.excluded[2]],[5,6,7,8]);f.loop.stop();
});

test('pause aborts every in-flight call and ignores late completions even if transport ignores abort',async()=>{
  const f=fixture();f.loop.tick();f.setTime(500);f.loop.tick();f.loop.stop();
  assert.ok(f.requests.every(request=>request.signal.aborted));assert.deepEqual(f.stopped,[[1,2]]);
  f.requests.forEach(request=>request.resolve(receipt));await flush();assert.equal(f.completed.length,0);
  f.setTime(10000);f.loop.tick();assert.equal(f.requests.length,2);f.loop.stop();assert.equal(f.stopped.length,1);
});

test('API failures back off and honor longer Retry-After without issuing a burst',async()=>{
  const f=fixture();f.loop.tick();f.setTime(200);f.requests[0].reject(new TrafficRequestError('Rate limited',60000));await flush();
  assert.deepEqual(f.backoffs,[{until:60200,fatal:false}]);
  f.setTime(60199);f.loop.tick();assert.equal(f.requests.length,1);
  f.setTime(60200);f.loop.tick();f.loop.tick();assert.equal(f.requests.length,2);
  f.requests[1].reject(new Error('Temporary failure'));await flush();assert.equal(f.backoffs[1].until,64200);f.loop.stop();
});

test('fatal authentication/configuration failure stops automatic spending and aborts other work',async()=>{
  const f=fixture();f.loop.tick();f.setTime(500);f.loop.tick();
  f.requests[0].reject(new TrafficRequestError('Sign in',0,true));await flush();
  assert.equal(f.backoffs[0].fatal,true);assert.ok(f.requests[1].signal.aborted);
  f.setTime(100000);f.loop.tick();assert.equal(f.requests.length,2);
});

test('empty candidate sets never produce artificial calls or completion events',()=>{
  let calls=0;
  const loop=new TrafficDecisionLoop({candidates:()=>[],submit:async()=>{calls++;return receipt;},nextId:()=>1,started:()=>{calls++;},completed:()=>{calls++;},failed:()=>{},stopped:()=>{},backoff:()=>{}},()=>0);
  loop.tick();loop.tick();assert.equal(calls,0);loop.stop();
});

test('concurrent failures cannot shorten an existing Retry-After window',async()=>{
  const f=fixture();f.loop.tick();f.setTime(500);f.loop.tick();
  f.setTime(600);f.requests[0].reject(new TrafficRequestError('Rate limited',60000));await flush();
  f.setTime(800);f.requests[1].reject(new Error('Temporary failure'));await flush();
  assert.equal(f.backoffs[1].until,60600);
  f.setTime(60599);f.loop.tick();assert.equal(f.requests.length,2);
  f.setTime(60600);f.loop.tick();assert.equal(f.requests.length,3);f.loop.stop();
});

test('a daily limit pauses automatic work and survives pause, reset, and Run again', async () => {
  let time = 0, calls = 0;
  const cooldown = new RequestCooldown(() => time);
  const backoffs: boolean[] = [];
  const makeLoop = () => new TrafficDecisionLoop({
    candidates: () => [observation(1)], nextId: () => ++calls, started() {},
    submit: async () => { throw new TrafficRequestError('Daily network limit reached', 86_400_000); },
    completed: () => assert.fail('Unexpected success'), failed() {}, stopped() {},
    backoff: (_until, fatal) => backoffs.push(fatal),
  }, () => time, cooldown);
  let loop = makeLoop(); loop.tick(); await flush();
  assert.deepEqual(backoffs, [true]); assert.equal(cooldown.until, 86_400_000);
  loop.stop(); loop = makeLoop();
  for (const now of [60_000, 120_000, 43_200_000, 86_399_999]) { time = now; loop.tick(); }
  assert.equal(calls, 1);
  time = 86_400_000; loop.tick(); await flush(); assert.equal(calls, 2); loop.stop();
});

test('Retry-After supports seconds and HTTP dates without a two-minute clamp', () => {
  assert.equal(retryAfterMs('86400', 0), 86_400_000);
  assert.equal(retryAfterMs('Thu, 01 Jan 1970 01:00:00 GMT', 0), 3_600_000);
  assert.equal(retryAfterMs(null), 0); assert.equal(retryAfterMs('invalid'), 0);
});

test('a full normal traffic run fits the IP quotas', async () => {
  let time = 0, calls = 0;
  const minutes = new Map<number, number>();
  const loop = new TrafficDecisionLoop({
    candidates: () => [observation(1)], nextId: () => ++calls, started() {},
    submit: async () => {
      const minute = Math.floor(time / 60_000);
      minutes.set(minute, (minutes.get(minute) ?? 0) + 1); return receipt;
    }, completed() {}, failed: () => assert.fail('Unexpected failure'), stopped() {}, backoff() {},
  }, () => time);
  for (; time < 120_000; time += 100) { loop.tick(); await flush(); }
  loop.stop(); assert.equal(calls, 240); assert.ok(calls <= IP_LIMITS.traffic.day);
  assert.ok([...minutes.values()].every(count => count <= IP_LIMITS.traffic.minute));
});
