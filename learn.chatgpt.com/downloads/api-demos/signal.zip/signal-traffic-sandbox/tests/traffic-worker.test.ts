import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { Log, LogLevel, Miniflare } from "miniflare";
import { createTraffic, decisionCandidates } from "../app/lib/traffic-engine";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));

test("the hosted Worker accepts a Vinext request proxy without cloning it", { timeout: 30_000 }, async t => {
  const bundled = await build({
    absWorkingDir: projectRoot,
    entryPoints: ["tests/fixtures/traffic-worker.ts"],
    bundle: true,
    format: "esm",
    platform: "neutral",
    target: "es2022",
    conditions: ["workerd", "worker", "browser"],
    external: ["cloudflare:workers", "node:net"],
    define: { "process.env.NODE_ENV": '"production"' },
    write: false,
    logLevel: "silent",
  });
  let outboundRequests = 0;
  const worker = new Miniflare({
    modules: true,
    d1Databases: ["DB"],
    script: bundled.outputFiles[0].text,
    compatibilityDate: "2026-05-15",
    compatibilityFlags: ["nodejs_compat"],
    host: "127.0.0.1",
    port: 0,
    cf: false,
    log: new Log(LogLevel.ERROR),
    outboundService: async () => {
      outboundRequests++;
      return new Response("Outbound network is disabled in this test.", { status: 503 });
    },
  });
  t.after(async () => { await worker.dispose(); });
  await worker.ready;
  const db = await worker.getD1Database("DB");
  const migration = await readFile(new URL("../drizzle/0000_fantastic_wolf_cub.sql", import.meta.url), "utf8");
  for (const statement of migration.split("--> statement-breakpoint")) await db.prepare(statement).run();

  await t.test("native Workerd reproduces the original Request constructor failure", async () => {
    const result = await worker.dispatchFetch("https://signal.test/constructor-probe", { method: "POST", body: "{}" });
    assert.deepEqual(await result.json(), { threw: true, name: "TypeError" });
  });

  const state = createTraffic("market", 42);
  const payload = { scenario: state.scenarioId, vehicles: decisionCandidates(state, new Set(), 4) };
  const headers = {
    origin: "https://signal.test",
    "cf-connecting-ip": "203.0.113.41",
    "content-type": "application/json",
  };
  await t.test("the anonymous route validates and reads a proxy body before calling the stub Decisions transport", async () => {
    const response = await worker.dispatchFetch("https://signal.test/api/traffic", { method: "POST", headers, body: JSON.stringify(payload) });
    assert.equal(response.status, 200, await response.clone().text());
    assert.equal(response.headers.get("x-fixture-transport-calls"), "1");
    const receipt = await response.json() as { requestId: string; choices: { vehicleId: number; revision: number; action: string }[] };
    assert.equal(receipt.requestId, "req_local_worker_fixture");
    assert.deepEqual(receipt.choices.map(choice => ({ id: choice.vehicleId, revision: choice.revision, action: choice.action })),
      payload.vehicles.map(vehicle => ({ id: vehicle.id, revision: vehicle.revision, action: "advance" })));
  });

  await t.test("invalid trusted IP, cross-origin, and malformed requests fail before transport", async () => {
    for (const fixture of [
      { headers: { origin: headers.origin, "content-type": "application/json", "cf-connecting-ip": "not-an-ip" }, body: payload, status: 503 },
      { headers: { ...headers, origin: "https://other.test" }, body: payload, status: 403 },
      { headers, body: { ...payload, vehicles: [] }, status: 400 },
    ]) {
      const response = await worker.dispatchFetch("https://signal.test/api/traffic", { method: "POST", headers: fixture.headers, body: JSON.stringify(fixture.body) });
      assert.equal(response.status, fixture.status);
      assert.equal(response.headers.get("x-fixture-transport-calls"), "1");
    }
  });
  await t.test("a durable IP quota blocks anonymous visitors even with a different identity header before parsing or upstream", async () => {
    const now = Date.UTC(2026, 9, 19, 12, 0, 10);
    const key = createHash("sha256").update(JSON.stringify([headers["cf-connecting-ip"], "traffic"])).digest("hex");
    await db.prepare("UPDATE demo_ip_rate_limits SET day_count = 1000 WHERE key = ?").bind(key).run();
    const response = await worker.dispatchFetch("https://signal.test/api/traffic", {
      method: "POST", headers: { ...headers, "oai-authenticated-user-id": "a-different-visitor" }, body: "not valid JSON",
    });
    assert.equal(response.status, 429);
    assert.equal(response.headers.get("x-fixture-transport-calls"), "1");
    assert.equal(response.headers.get("Retry-After"), String((Date.UTC(2026, 9, 20) - now) / 1000));
    assert.equal(response.headers.get("Cache-Control"), "no-store");
    const body = await response.json() as { code: string; retryAfter: number };
    assert.equal(body.code, "RATE_LIMIT_EXCEEDED");
    assert.ok(body.retryAfter > 120, "Daily retry time must not become a one-minute wait");
  });
  assert.equal(outboundRequests, 0, "The regression test must never call a real API.");
});
