import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { Log, LogLevel, Miniflare } from "miniflare";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));

test("the portable source adapter uses the fixed public API in production Workerd without following redirects", { timeout: 30_000 }, async t => {
  const portable = await readFile(new URL("../scripts/public-source/api-transport.ts", import.meta.url), "utf8");
  const bundle = await build({
    absWorkingDir: projectRoot,
    stdin: { contents: `import { openAIResponse, publicError } from "./app/lib/server";
      export default { async fetch(request) {
        try { return await openAIResponse(new URL(request.url).pathname, { synthetic: true }, request.signal); }
        catch (error) { const result = publicError(error); return Response.json(result, { status: result.status }); }
      }};`, resolveDir: projectRoot },
    bundle: true, format: "esm", platform: "neutral", target: "es2022",
    conditions: ["workerd", "worker", "browser"], external: ["cloudflare:workers"],
    define: { "process.env.NODE_ENV": '"production"' }, write: false, logLevel: "silent",
    plugins: [{ name: "portable-source", setup(plugin) {
      plugin.onLoad({ filter: /[/\\]app[/\\]lib[/\\]api-transport\.ts$/ }, () => ({ contents: portable, loader: "ts" }));
    } }],
  });
  let calls = 0, status = 200;
  const worker = new Miniflare({
    modules: true, script: bundle.outputFiles[0].text, compatibilityDate: "2026-05-15",
    compatibilityFlags: ["nodejs_compat"], bindings: { OPENAI_API_KEY: "fixture-only" },
    host: "127.0.0.1", port: 0, cf: false, log: new Log(LogLevel.ERROR),
    outboundService: async request => {
      calls++;
      assert.ok(["https://api.openai.com/v1/decisions", "https://api.openai.com/v1/responses"].includes(request.url));
      assert.equal(request.method, "POST");
      assert.equal(request.headers.get("authorization"), "Bearer fixture-only");
      assert.equal(request.headers.get("content-type"), "application/json");
      assert.deepEqual(await request.json(), { synthetic: true });
      return Response.json({ ok: true }, { status, headers: { location: "https://untrusted.example" } });
    },
  });
  t.after(() => worker.dispose());
  await worker.ready;
  for (const path of ["/decisions", "/responses"]) {
    const response = await worker.dispatchFetch(`https://signal.test${path}`);
    assert.equal(response.status, 200); assert.deepEqual(await response.json(), { ok: true });
  }
  status = 307;
  const redirect = await worker.dispatchFetch("https://signal.test/responses");
  assert.equal(redirect.status, 502); assert.equal(calls, 3);
  assert.equal((await worker.dispatchFetch("https://signal.test/unknown")).status, 500);
  assert.equal(calls, 3);
});
