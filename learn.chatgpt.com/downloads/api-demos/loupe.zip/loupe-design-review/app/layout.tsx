import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Loupe — Design review",
  description: "Compare your implementation with a design reference, review the differences, and refine the details.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};
export default function RootLayout({ children }: Readonly<{children:React.ReactNode}>) {
  return <html lang="en"><head><link rel="preload" href="/fonts/InterVariable.woff2" as="font" type="font/woff2" crossOrigin="anonymous"/></head><body className="antialiased">{children}</body></html>;
}
