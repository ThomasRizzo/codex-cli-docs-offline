import { MAX_IMAGE_BYTES, MAX_IMAGE_DIMENSION, type Screenshot } from "./contracts.ts";

export type PreviewViewport = { width: number; height: number };

export function validateCaptureViewport(viewport: PreviewViewport): PreviewViewport {
  const { width, height } = viewport;
  if (![width, height].every(value => Number.isInteger(value) && value >= 1 && value <= MAX_IMAGE_DIMENSION)) throw Error("Choose a preview size between 1 and 2,400 pixels.");
  return { width, height };
}

/** A blank/failed foreignObject render must never become fabricated visual evidence. */
export function hasVisualVariation(data: Uint8ClampedArray): boolean {
  if (data.length < 8) return false;
  let different = 0;
  for (let index = 4; index < data.length; index += 4) {
    if (Math.abs(data[index] - data[0]) + Math.abs(data[index + 1] - data[1]) + Math.abs(data[index + 2] - data[2]) + Math.abs(data[index + 3] - data[3]) > 16 && ++different >= 12) return true;
  }
  return false;
}

function timeout<T>(promise: Promise<T>, milliseconds: number, message: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout>;
  return Promise.race([promise, new Promise<never>((_, reject) => { timer = setTimeout(() => reject(Error(message)), milliseconds); })]).finally(() => clearTimeout(timer));
}

export async function waitForPreviewResources(doc: Document): Promise<void> {
  await timeout(Promise.all([
    doc.fonts.ready,
    ...Array.from(doc.images).map(async image => {
      if (!image.getAttribute("src")) return;
      // The static viewport must include lazy images too, without network fetches.
      image.loading = "eager";
      try { await image.decode(); } catch { throw Error("A preview image could not be rendered. Check the imported image files."); }
      if (!image.naturalWidth) throw Error("A preview image could not be rendered. Check the imported image files.");
    }),
  ]), 8_000, "The preview’s images or fonts are still loading. Try again shortly.");
  await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
}

/** Fonts are already embedded by the local importer; capture never fetches resources. */
function embeddedFontCss(doc: Document): string {
  const output: string[] = [];
  function visit(rules: CSSRuleList) {
    for (const rule of Array.from(rules)) {
      if (rule.type === 5) output.push(rule.cssText);
      else if ("cssRules" in rule) visit((rule as CSSGroupingRule).cssRules);
    }
  }
  for (const sheet of Array.from(doc.styleSheets)) {
    try { visit(sheet.cssRules); } catch { throw Error("A stylesheet is not available for capture. Import its companion files first."); }
  }
  return output.join("\n");
}

export async function capturePreview(frame: HTMLIFrameElement, viewport: PreviewViewport): Promise<Screenshot> {
  const { width, height } = validateCaptureViewport(viewport);
  const doc = frame.contentDocument;
  if (!doc?.body || !frame.contentWindow || frame.clientWidth !== width || frame.clientHeight !== height) throw Error("The page preview is not ready yet. Try again shortly.");
  frame.contentWindow.scrollTo({ top: 0, left: 0, behavior: "instant" });
  await waitForPreviewResources(doc);
  if (frame.contentDocument !== doc) throw Error("The page changed while its preview was loading. Try again.");
  const { toCanvas } = await import("html-to-image");
  const canvas = await timeout(toCanvas(doc.documentElement, {
    width, height, canvasWidth: width, canvasHeight: height, pixelRatio: 1,
    backgroundColor: "#ffffff", fontEmbedCSS: embeddedFontCss(doc), skipAutoScale: true,
    filter: node => !["SCRIPT", "META", "LINK", "VIDEO", "AUDIO", "SOURCE"].includes(node.nodeName) && !(node.nodeName === "IMG" && !node.getAttribute("src")),
    // Resource URLs in computed styles are constrained by the importer and CSP.
    fetchRequestInit: { credentials: "omit", mode: "same-origin", signal: AbortSignal.abort() },
  }), 20_000, "This page took too long to capture. Try a smaller page or viewport.");
  if (frame.contentDocument !== doc || frame.clientWidth !== width || frame.clientHeight !== height) throw Error("The page changed during capture. Try again.");
  if (canvas.width !== width || canvas.height !== height) throw Error("The preview could not be captured at the selected size.");
  const pixels = canvas.getContext("2d")?.getImageData(0, 0, width, height);
  if (!pixels || !hasVisualVariation(pixels.data)) throw Error("The captured preview is blank. Check that the page has visible content before reviewing it.");
  let dataUrl = canvas.toDataURL("image/png");
  const size = (value: string) => Math.floor(value.slice(value.indexOf(",") + 1).length * 3 / 4);
  if (size(dataUrl) > MAX_IMAGE_BYTES) {
    for (const quality of [0.92, 0.84, 0.72, 0.6]) {
      dataUrl = canvas.toDataURL("image/jpeg", quality);
      if (size(dataUrl) <= MAX_IMAGE_BYTES) break;
    }
  }
  if (size(dataUrl) > MAX_IMAGE_BYTES) throw Error("The captured image is too large. Choose a smaller preview size and try again.");
  return { dataUrl, width, height };
}
