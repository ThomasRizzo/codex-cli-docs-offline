import { MAX_RESULT_BYTES } from "./contracts.ts";

/** Read only the top-level public message; provider key order is not guaranteed. */
export function parsePartialMessage(input: string): string | null {
  if (new TextEncoder().encode(input).length > MAX_RESULT_BYTES) return null;
  let at = 0;
  const space = () => { while (/\s/.test(input[at] ?? "") && at < input.length) at++; };
  const string = (): { text: string; complete: boolean } | null => {
    if (input[at] !== '"') return null;
    const start = at++;
    while (at < input.length) {
      const char = input[at];
      if (char === '"') {
        try { return { text: JSON.parse(input.slice(start, ++at)), complete: true }; } catch { return null; }
      }
      if (char.charCodeAt(0) < 32) return null;
      if (char === "\\") {
        const escape = input[at + 1];
        if (!escape || (escape === "u" && input.length < at + 6)) break;
        if (escape === "u" ? !/^[0-9a-f]{4}$/i.test(input.slice(at + 2, at + 6)) : !'"\\/bfnrt'.includes(escape)) return null;
        at += escape === "u" ? 6 : 2;
      } else at++;
    }
    try { return { text: JSON.parse(input.slice(start, at) + '"').replace(/[\uD800-\uDBFF]$/, ""), complete: false }; } catch { return null; }
  };
  const skipEdits = (): boolean => {
    if (input[at] !== "[") return false;
    const start = at;
    let depth = 0, quoted = false, escaped = false;
    for (; at < input.length; at++) {
      const char = input[at];
      if (quoted) {
        if (escaped) escaped = false;
        else if (char === "\\") escaped = true;
        else if (char === '"') quoted = false;
      } else if (char === '"') quoted = true;
      else if (char === "[" || char === "{") depth++;
      else if (char === "]" || char === "}") {
        if (--depth === 0) {
          try { return Array.isArray(JSON.parse(input.slice(start, ++at))); } catch { return false; }
        }
      }
    }
    return false;
  };
  space(); if (input[at++] !== "{") return null;
  const keys = new Set<string>();
  while (at < input.length) {
    space(); const key = string();
    if (!key?.complete || keys.has(key.text) || !["status", "message", "findings", "edits"].includes(key.text)) return null;
    keys.add(key.text);
    space(); if (input[at++] !== ":") return null;
    space();
    if (key.text === "message") {
      const message = string();
      return message && message.text.length <= 1500 ? message.text : null;
    }
    if (key.text === "status") {
      const status = string();
      if (!status?.complete || !["review", "complete", "answer", "clarification", "off_topic"].includes(status.text)) return null;
    } else if (!skipEdits()) return null;
    space(); if (input[at++] !== ",") return null;
  }
  return null;
}
