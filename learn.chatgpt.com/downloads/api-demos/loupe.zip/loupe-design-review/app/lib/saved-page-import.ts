import postcss, { type Root, type AtRule } from "postcss";
import valueParser from "postcss-value-parser";
import { documentSchema, MAX_CSS_CHARS, MAX_IMPORT_HTML_BYTES, type PageDocument } from "./contracts.ts";
import { createPreviewAsset, isPreviewAssetReference, MAX_PREVIEW_ASSET_BYTES, MAX_PREVIEW_ASSETS, MAX_PREVIEW_ASSETS_BYTES, validatePreviewAssets, type PreviewAssets } from "./preview-assets.ts";

export type SavedPageImport = { document: PageDocument; assets: PreviewAssets; removed: number; missingStylesheets: string[]; warnings: string[] };
export type SavedStyleSource = { kind: "inline"; css: string; media?: string } | { kind: "linked"; href: string; media?: string };
type SavedFile = { path: string; file: File };
type CssImport = { href: string; media: string; supports?: string; layer?: string };

const MAX_FILES = 2_000, MAX_STYLESHEETS = 100, MAX_IMPORT_DEPTH = 12;
const MAX_CSS_SOURCE_BYTES = 4_000_000, MAX_RESOURCE_REFERENCES = 2_000;
const MIME_BY_EXTENSION: Record<string, string> = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", avif: "image/avif", woff: "font/woff", woff2: "font/woff2", ttf: "font/ttf", otf: "font/otf" };
const MIME_ALIASES: Record<string, string> = { "image/jpg": "image/jpeg", "application/font-woff": "font/woff", "application/x-font-woff": "font/woff", "application/x-font-ttf": "font/ttf", "application/x-font-opentype": "font/otf" };
const ALLOWED_MIMES = new Set(Object.values(MIME_BY_EXTENSION));
const encoder = new TextEncoder();

function label(value: string): string { return value.replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, 220); }
function note(list: string[], message: string) {
  const bounded = message.slice(0, 300);
  if (list.includes(bounded)) return;
  if (list.length < 49) list.push(bounded);
  else if (list.length === 49) list.push("Additional resources were omitted from this list.");
}
function normalizePath(value: string): string | null {
  const parts: string[] = [];
  for (const part of value.replace(/\\/g, "/").split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") { if (!parts.length) return null; parts.pop(); }
    else { if (/[\u0000-\u001f\u007f]/.test(part)) return null; parts.push(part); }
  }
  return parts.join("/");
}
function directory(path: string): string { return path.slice(0, Math.max(0, path.lastIndexOf("/") + 1)); }
function filePath(file: File): string { return normalizePath(file.webkitRelativePath || file.name) || file.name; }
function cssUnescape(value: string): string {
  return value.replace(/\\([\da-f]{1,6}[\t\n\f\r ]?|\r\n|[\s\S])/gi, (_, escaped: string) => {
    if (/^[\da-f]/i.test(escaped)) {
      const code = parseInt(escaped.trim(), 16);
      return code && code <= 0x10ffff && !(code >= 0xd800 && code <= 0xdfff) ? String.fromCodePoint(code) : "\ufffd";
    }
    return /^[\r\n\f]/.test(escaped) ? "" : escaped;
  });
}
function urlValue(node: valueParser.FunctionNode): string {
  const content = node.nodes.filter(part => part.type !== "space" && part.type !== "comment");
  return cssUnescape(content.length === 1 && content[0].type === "string" ? content[0].value : valueParser.stringify(node.nodes).trim());
}
function parseImport(rule: AtRule): CssImport | null {
  const parsed = valueParser(rule.params);
  let malformed = false;
  parsed.walk(node => { if ("unclosed" in node && node.unclosed) malformed = true; });
  const nodes = parsed.nodes.filter(node => node.type !== "space" && node.type !== "comment");
  const first = nodes.shift();
  if (malformed || !first) return null;
  const href = first.type === "string" ? cssUnescape(first.value) : first.type === "function" && first.value.toLowerCase() === "url" ? urlValue(first) : "";
  if (!href) return null;
  const result: CssImport = { href, media: "" };
  if (nodes[0]?.type === "word" && nodes[0].value.toLowerCase() === "layer") { result.layer = ""; nodes.shift(); }
  else if (nodes[0]?.type === "function" && nodes[0].value.toLowerCase() === "layer") result.layer = valueParser.stringify((nodes.shift() as valueParser.FunctionNode).nodes).trim();
  if (nodes[0]?.type === "function" && nodes[0].value.toLowerCase() === "supports") result.supports = valueParser.stringify((nodes.shift() as valueParser.FunctionNode).nodes).trim();
  // Serialize the original tail so spaces inside media queries remain significant.
  if (nodes.length) result.media = rule.params.slice(nodes[0].sourceIndex).trim();
  return result;
}
function wrap(root: Root, conditions: Omit<CssImport, "href">): Root {
  const wrappers: [string, string][] = [];
  if (conditions.media) wrappers.push(["media", conditions.media]);
  if (conditions.supports !== undefined) wrappers.push(["supports", `(${conditions.supports})`]);
  if (conditions.layer !== undefined) wrappers.push(["layer", conditions.layer]);
  for (const [name, params] of wrappers.reverse()) {
    // HTML media attributes are not CSS tokens. Validate their boundary before serializing.
    const check = postcss.parse(`@${name} ${params}{}`);
    const only = check.first;
    if (check.nodes.length !== 1 || only?.type !== "atrule" || only.name !== name || only.nodes?.length) throw new Error("A stylesheet has an invalid condition.");
    root = postcss.root({ nodes: [postcss.atRule({ name, params, nodes: root.nodes })] });
  }
  return root;
}
function decodeData(reference: string): { bytes: Uint8Array; mime: string } {
  const comma = reference.indexOf(",");
  if (comma < 0 || comma > 200) throw new Error("Invalid embedded resource.");
  const metadata = reference.slice(5, comma).split(";");
  const suppliedMime = metadata[0].toLowerCase();
  const mime = MIME_ALIASES[suppliedMime] || suppliedMime;
  const content = reference.slice(comma + 1);
  if (content.length > MAX_PREVIEW_ASSET_BYTES * 3) throw new Error("Embedded resource is too large.");
  let bytes: Uint8Array;
  if (metadata.some(part => part.toLowerCase() === "base64")) {
    const binary = atob(content.replace(/\s/g, ""));
    bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
  } else {
    const output: number[] = [];
    for (let index = 0; index < content.length; index++) {
      if (content[index] === "%") {
        const hex = content.slice(index + 1, index + 3);
        if (!/^[\da-f]{2}$/i.test(hex)) throw new Error("Invalid embedded resource.");
        output.push(parseInt(hex, 16)); index += 2;
      } else output.push(...encoder.encode(content[index]));
    }
    bytes = Uint8Array.from(output);
  }
  return { bytes, mime };
}

/** A local, bounded resolver. Only explicitly supplied File objects are ever read. */
export class SavedPageResources {
  readonly assets: PreviewAssets = {};
  readonly warnings: string[] = [];
  readonly missingStylesheets: string[] = [];
  private files: SavedFile[];
  private assetCache = new Map<string, Promise<string | null>>();
  private cssCache = new Map<string, Promise<string>>();
  private assetBytes = 0;
  private cssBytes = 0;
  private stylesheetCount = 0;
  private referenceCount = 0;
  readonly base: string;

  constructor(htmlFile: File, companionFiles: File[] = []) {
    if (companionFiles.length > MAX_FILES) throw new Error("Choose a saved-page folder with at most 2,000 files.");
    this.base = filePath(htmlFile);
    this.files = companionFiles.map(file => ({ path: filePath(file), file }));
  }
  warn(message: string) { note(this.warnings, message); }
  private missing(reference: string) { note(this.missingStylesheets, label(reference)); }

  private resolve(reference: string, base: string): SavedFile | null {
    if (reference.length > 4_000) return null;
    let pathname = reference.split(/[?#]/, 1)[0];
    let absolute = pathname.startsWith("/");
    if (/^[a-z][a-z\d+.-]*:/i.test(reference) || reference.startsWith("//")) {
      try {
        const url = new URL(reference.startsWith("//") ? `https:${reference}` : reference);
        if (!["http:", "https:", "file:"].includes(url.protocol)) return null;
        pathname = url.pathname; absolute = true;
      } catch { return null; }
    }
    try { pathname = decodeURIComponent(pathname); } catch { return null; }
    if (base.startsWith("data:") && !absolute) return null;
    const target = normalizePath((absolute ? "" : directory(base)) + pathname);
    if (!target) return null;
    const exact = this.files.filter(entry => entry.path === target);
    if (exact.length === 1) return exact[0];
    if (exact.length > 1) { this.warn(`More than one supplied file matches “${label(reference)}”.`); return null; }
    const segments = target.split("/");
    for (let index = 0; index < segments.length; index++) {
      const suffix = segments.slice(index).join("/");
      const matches = this.files.filter(entry => entry.path === suffix || entry.path.endsWith(`/${suffix}`));
      if (matches.length === 1) return matches[0];
      if (matches.length > 1) { this.warn(`More than one supplied file matches “${label(reference)}”.`); return null; }
    }
    return null;
  }

  async asset(reference: string, base = this.base): Promise<string | null> {
    reference = reference.trim();
    if (!reference) return null;
    if (++this.referenceCount > MAX_RESOURCE_REFERENCES) throw new Error("This page has too many resource references. Try a smaller saved page.");
    if (reference.startsWith("#")) return reference;
    if (isPreviewAssetReference(reference)) return this.assets[reference.slice("loupe-asset:".length)] ? reference : null;
    const embedded = /^data:/i.test(reference);
    const found = embedded ? null : this.resolve(reference, base);
    if (!embedded && !found) { this.warn(`Image or font not supplied: ${label(reference)}`); return null; }
    const cacheKey = embedded ? reference : found!.path;
    const cached = this.assetCache.get(cacheKey);
    if (cached) return cached;
    const pending = (async () => {
      const display = embedded ? "an embedded image or font" : `“${label(found!.path)}”`;
      try {
        if (Object.keys(this.assets).length >= MAX_PREVIEW_ASSETS || this.assetBytes >= MAX_PREVIEW_ASSETS_BYTES || (found && this.assetBytes + found.file.size > MAX_PREVIEW_ASSETS_BYTES)) throw new Error("The page exceeds 100 assets or 8 MB of assets.");
        let bytes: Uint8Array, mime: string;
        if (embedded) ({ bytes, mime } = decodeData(reference));
        else {
          const extension = found!.path.split(".").pop()?.toLowerCase() || "";
          const suppliedMime = found!.file.type.toLowerCase();
          mime = MIME_BY_EXTENSION[extension] || MIME_ALIASES[suppliedMime] || suppliedMime;
          if (!ALLOWED_MIMES.has(mime)) throw new Error("Unsupported image or font format.");
          if (found!.file.size > MAX_PREVIEW_ASSET_BYTES) throw new Error("Resource exceeds 2 MB.");
          bytes = new Uint8Array(await found!.file.arrayBuffer());
        }
        if (!ALLOWED_MIMES.has(mime)) throw new Error("Unsupported image or font format.");
        const asset = await createPreviewAsset(bytes, mime);
        if (!this.assets[asset.id]) {
          if (Object.keys(this.assets).length >= MAX_PREVIEW_ASSETS || this.assetBytes + bytes.byteLength > MAX_PREVIEW_ASSETS_BYTES) throw new Error("The page exceeds 100 assets or 8 MB of assets.");
          this.assets[asset.id] = asset.dataUrl; this.assetBytes += bytes.byteLength;
        }
        return asset.reference;
      } catch (error) {
        this.warn(`Skipped ${display}: ${error instanceof Error ? error.message : "Could not read resource."}`);
        return null;
      }
    })();
    this.assetCache.set(cacheKey, pending);
    return pending;
  }

  async cssValue(value: string, base = this.base): Promise<string> {
    const parsed = valueParser(value);
    const urls: valueParser.FunctionNode[] = [], imageStrings: valueParser.StringNode[] = [];
    parsed.walk(node => {
      if (node.type !== "function") return;
      if (node.value.toLowerCase() === "url") { urls.push(node); return false; }
      if (["image-set", "-webkit-image-set"].includes(node.value.toLowerCase())) for (const child of node.nodes) if (child.type === "string") imageStrings.push(child);
    });
    for (const node of urls) {
      const reference = await this.asset(urlValue(node), base);
      node.nodes = [{ type: "string", quote: '"', value: reference || "", sourceIndex: node.sourceIndex, sourceEndIndex: node.sourceEndIndex }];
    }
    for (const node of imageStrings) node.value = await this.asset(cssUnescape(node.value), base) || "";
    return valueParser.stringify(parsed.nodes);
  }

  private async linkedCss(reference: string, base: string, stack: string[]): Promise<Root> {
    if (++this.stylesheetCount > MAX_STYLESHEETS) throw new Error("This page imports more than 100 stylesheets. Try a smaller saved page.");
    let found: SavedFile | null;
    if (/^data:/i.test(reference)) {
      try {
        const { bytes, mime } = decodeData(reference);
        if (mime !== "text/css") throw new Error("An embedded stylesheet must use text/css.");
        const digest = await crypto.subtle.digest("SHA-256", new Uint8Array(bytes));
        const id = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
        found = { path: `data:${id}`, file: new File([new Uint8Array(bytes).buffer], "embedded.css", { type: "text/css" }) };
      } catch { this.missing("Embedded stylesheet"); this.warn("An embedded stylesheet could not be read."); return postcss.root(); }
    } else found = this.resolve(reference, base);
    if (!found) { this.missing(reference); return postcss.root(); }
    if (stack.includes(found.path)) { this.warn(`Circular stylesheet import skipped: ${label(found.path)}`); return postcss.root(); }
    if (stack.length >= MAX_IMPORT_DEPTH) { this.missing(found.path); this.warn("A stylesheet import exceeded the 12-level nesting limit."); return postcss.root(); }
    let source = this.cssCache.get(found.path);
    if (!source) {
      if (found.file.size > MAX_CSS_SOURCE_BYTES || this.cssBytes + found.file.size > MAX_CSS_SOURCE_BYTES) throw new Error("Keep the total stylesheet source under 4 MB.");
      this.cssBytes += found.file.size;
      source = found.file.text(); this.cssCache.set(found.path, source);
    }
    try { return await this.parseCss(await source, found.path, [...stack, found.path]); }
    catch (error) {
      if (error instanceof Error && error.name === "CssSyntaxError") { this.missing(found.path); this.warn(`Could not parse stylesheet: ${label(found.path)}`); return postcss.root(); }
      throw error;
    }
  }

  private async parseCss(css: string, base: string, stack: string[]): Promise<Root> {
    const root = postcss.parse(css);
    let importsAllowed = true;
    for (const node of [...root.nodes]) {
      if (node.type === "comment") continue;
      if (node.type === "atrule" && node.name.toLowerCase() === "charset") { node.remove(); continue; }
      if (node.type === "atrule" && node.name.toLowerCase() === "import") {
        const descriptor = parseImport(node);
        if (!importsAllowed || !descriptor || node.nodes) { this.warn("An invalid stylesheet import was skipped."); node.remove(); continue; }
        const imported = await this.linkedCss(descriptor.href, base, stack);
        try { node.replaceWith(...wrap(imported, descriptor).nodes); }
        catch { this.missing(descriptor.href); this.warn("A stylesheet import has an invalid condition."); node.remove(); }
      } else if (!(node.type === "atrule" && node.name.toLowerCase() === "layer" && !node.nodes)) importsAllowed = false;
    }
    // Nested @imports are invalid CSS and cannot be allowed to survive resolution.
    root.walkAtRules(rule => { if (rule.name.toLowerCase() === "import") { this.warn("An invalid nested stylesheet import was skipped."); rule.remove(); } });
    const declarations: postcss.Declaration[] = [];
    root.walkDecls(declaration => { declarations.push(declaration); });
    for (const declaration of declarations) declaration.value = await this.cssValue(declaration.value, base);
    if (root.toString().length > MAX_CSS_CHARS) throw new Error("Keep the resolved stylesheet under 300,000 characters.");
    return root;
  }

  async styles(sources: SavedStyleSource[]): Promise<string> {
    if (sources.length > MAX_STYLESHEETS) throw new Error("This page contains more than 100 stylesheets. Try a smaller saved page.");
    const output: string[] = [];
    let length = 0;
    for (const source of sources) {
      let root: Root;
      try { root = source.kind === "linked" ? await this.linkedCss(source.href, this.base, []) : await this.parseCss(source.css, this.base, []); }
      catch (error) {
        if (error instanceof Error && error.name === "CssSyntaxError") { this.warn("An inline stylesheet could not be parsed."); continue; }
        throw error;
      }
      try { if (source.media?.trim()) root = wrap(root, { media: source.media.trim() }); }
      catch { this.warn("A stylesheet with an invalid media condition was skipped."); continue; }
      const css = root.toString(); length += css.length + 2;
      if (length > MAX_CSS_CHARS) throw new Error("Keep the resolved stylesheet under 300,000 characters.");
      output.push(css);
    }
    return output.join("\n\n");
  }
}

/** Exposed separately so the same local CSS/resource pipeline can be tested without a DOM. */
export async function resolveSavedStyles(htmlFile: File, companionFiles: File[], sources: SavedStyleSource[]) {
  const resources = new SavedPageResources(htmlFile, companionFiles);
  const css = await resources.styles(sources);
  return { css, assets: validatePreviewAssets(resources.assets), warnings: resources.warnings, missingStylesheets: resources.missingStylesheets };
}

function responsiveCandidates(value: string): string[] {
  const result: string[] = []; let offset = 0;
  while (offset < value.length && result.length < 16) {
    while (/[\s,]/.test(value[offset] || "") && offset < value.length) offset++;
    const start = offset;
    while (offset < value.length && !/\s/.test(value[offset])) offset++;
    const raw = value.slice(start, offset);
    if (!raw) break;
    result.push(raw.replace(/,+$/, ""));
    if (!raw.endsWith(",")) { while (offset < value.length && value[offset] !== ",") offset++; offset++; }
  }
  return result;
}

export async function importSavedPage(htmlFile: File, companionFiles: File[] = []): Promise<SavedPageImport> {
  if (htmlFile.size > MAX_IMPORT_HTML_BYTES) throw new Error("Keep the HTML file under 16 MB.");
  if (typeof DOMParser === "undefined") throw new Error("Open this page in a current browser to import HTML.");
  const resources = new SavedPageResources(htmlFile, companionFiles);
  // This document stays detached. It is never inserted into the app or a live iframe.
  const parsed = new DOMParser().parseFromString(await htmlFile.text(), "text/html");
  const sources: SavedStyleSource[] = [];
  for (const node of Array.from(parsed.querySelectorAll("style,link"))) {
    if (node.tagName === "STYLE") {
      if (!node.getAttribute("type") || node.getAttribute("type")?.toLowerCase() === "text/css") sources.push({ kind: "inline", css: node.textContent || "", media: node.getAttribute("media") || undefined });
      node.remove();
    } else if (node.getAttribute("rel")?.toLowerCase().split(/\s+/).includes("stylesheet")) {
      const rel = node.getAttribute("rel")!.toLowerCase().split(/\s+/);
      if (!node.hasAttribute("disabled") && !rel.includes("alternate")) sources.push({ kind: "linked", href: node.getAttribute("href") || "", media: node.getAttribute("media") || undefined });
      node.remove();
    }
  }
  const css = await resources.styles(sources);
  for (const element of Array.from(parsed.querySelectorAll("[style]"))) element.setAttribute("style", await resources.cssValue(element.getAttribute("style") || ""));
  for (const image of Array.from(parsed.querySelectorAll("img"))) {
    const srcset = image.getAttribute("srcset");
    const pictureSources = image.parentElement?.tagName === "PICTURE" ? Array.from(image.parentElement.querySelectorAll("source[srcset]")) : [];
    const candidates = [image.getAttribute("src") || "", ...responsiveCandidates(srcset || ""), ...pictureSources.flatMap(source => responsiveCandidates(source.getAttribute("srcset") || ""))].filter(Boolean);
    let reference: string | null = null;
    for (const candidate of candidates) { reference = await resources.asset(candidate); if (reference && !reference.startsWith("#")) break; reference = null; }
    if (reference) image.setAttribute("src", reference); else image.removeAttribute("src");
    if (srcset || pictureSources.length) resources.warn("Responsive images use one supplied image in this static preview.");
  }
  // Keep CSS separate from HTML raw-text parsing, including literal </style> strings in CSS.
  const { importHtml } = await import("./document-io.ts");
  const imported = importHtml(parsed.documentElement.outerHTML);
  return { document: documentSchema.parse({ ...imported.document, css }), assets: validatePreviewAssets(resources.assets), removed: imported.removed, missingStylesheets: resources.missingStylesheets, warnings: resources.warnings };
}
