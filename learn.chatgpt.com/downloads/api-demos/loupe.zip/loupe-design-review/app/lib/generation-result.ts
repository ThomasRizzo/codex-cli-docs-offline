import type { GenerationSessionState } from "./agents.ts";
import { applyEdits, createRequestSchema, documentSchema, resultSchema, MAX_HTML_CHARS, MAX_CSS_CHARS, MAX_IMAGE_BYTES, type Screenshot, type CreateRequest, type PageDocument } from "./contracts.ts";

export type ReviewBinding = { requestHash: string; sourceHash: string };

/** Stable JSON shared with Python: object keys sort; array and patch order matter. */
export function canonicalJSON(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJSON).join(",")}]`;
  if (value && typeof value === "object") return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonicalJSON((value as Record<string, unknown>)[key])}`).join(",")}}`;
  return JSON.stringify(value);
}
export async function digest(value: unknown): Promise<string> {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalJSON(value)));
  return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, "0")).join("");
}
function imageBytes(image: Screenshot): Uint8Array {
  const encoded = image.dataUrl.slice(image.dataUrl.indexOf(",") + 1);
  let binary: string;
  try { binary = atob(encoded); } catch { throw new Error("An image could not be decoded. Upload it again."); }
  if (!binary.length || binary.length > MAX_IMAGE_BYTES || btoa(binary) !== encoded) throw new Error("An image is invalid or too large. Upload it again.");
  return Uint8Array.from(binary, character => character.charCodeAt(0));
}
const CRC32_TABLE = Uint32Array.from({length: 256}, (_, value) => {
  let crc = value;
  for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
  return crc >>> 0;
});
function pngDimensions(bytes: Uint8Array): {width: number; height: number} {
  const invalid = () => { throw new Error("An image is not a complete PNG. Upload it again."); };
  if (bytes.length < 45 || [137,80,78,71,13,10,26,10].some((value, index) => bytes[index] !== value)) return invalid();
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let at = 8, width = 0, height = 0, sawData = false, ended = false;
  while (at + 12 <= bytes.length) {
    const length = view.getUint32(at), end = at + length + 12;
    if (end > bytes.length) return invalid();
    const type = String.fromCharCode(...bytes.subarray(at + 4, at + 8));
    let crc = 0xffffffff;
    for (let i = at + 4; i < end - 4; i++) crc = (crc >>> 8) ^ CRC32_TABLE[(crc ^ bytes[i]) & 255];
    if (((crc ^ 0xffffffff) >>> 0) !== view.getUint32(end - 4)) return invalid();
    if (at === 8) {
      if (type !== "IHDR" || length !== 13) return invalid();
      width = view.getUint32(at + 8); height = view.getUint32(at + 12);
      if (!width || !height || ![1,2,4,8,16].includes(bytes[at + 16]) || ![0,2,3,4,6].includes(bytes[at + 17]) || bytes[at + 18] || bytes[at + 19] || bytes[at + 20] > 1) return invalid();
    } else if (type === "IHDR") return invalid();
    if (type === "IDAT") sawData = true;
    if (type === "IEND") { if (length || end !== bytes.length || !sawData) return invalid(); ended = true; break; }
    at = end;
  }
  if (!ended) return invalid();
  return {width, height};
}
function jpegDimensions(bytes: Uint8Array): { width: number; height: number } {
  const invalid = () => { throw new Error("An image is not a complete supported JPEG. Upload it again."); };
  const word = (at: number) => bytes[at] * 256 + bytes[at + 1];
  if (bytes.length < 20 || bytes[0] !== 255 || bytes[1] !== 216) return invalid();
  let offset = 2, width = 0, height = 0, scan = false, quantization = false, huffman = false;
  const components = new Set<number>();
  while (offset < bytes.length) {
    if (bytes[offset++] !== 255) return invalid();
    while (bytes[offset] === 255) offset++;
    const marker = bytes[offset++];
    if (marker === 217) {
      if (!scan || !width || !quantization || !huffman || offset !== bytes.length) return invalid();
      return { width, height };
    }
    if (![192, 194, 196, 218, 219, 221, 254].includes(marker) && !(marker >= 224 && marker <= 239)) return invalid();
    if (offset + 2 > bytes.length) return invalid();
    const length = word(offset), end = offset + length;
    if (length < 2 || end > bytes.length) return invalid();
    if (marker === 192 || marker === 194) {
      const count = bytes[offset + 7];
      if (width || ![1, 3].includes(count) || length !== 8 + 3 * count || bytes[offset + 2] !== 8) return invalid();
      height = word(offset + 3); width = word(offset + 5);
      if (!width || !height || width > 2400 || height > 2400) return invalid();
      for (let at = offset + 8; at < end; at += 3) {
        const id = bytes[at], sample = bytes[at + 1];
        if (components.has(id) || !(sample >> 4) || (sample >> 4) > 4 || !(sample & 15) || (sample & 15) > 4 || bytes[at + 2] > 3) return invalid();
        components.add(id);
      }
    }
    if (marker === 219) {
      let at = offset + 2;
      while (at < end) {
        const table = bytes[at++], precision = table >> 4;
        if (precision > 1 || (table & 15) > 3) return invalid();
        at += precision ? 128 : 64;
      }
      if (at !== end || length === 2) return invalid();
      quantization = true;
    }
    if (marker === 196) {
      let at = offset + 2;
      while (at < end) {
        const table = bytes[at++];
        if ((table >> 4) > 1 || (table & 15) > 3 || at + 16 > end) return invalid();
        let symbols = 0;
        for (let i = 0; i < 16; i++) symbols += bytes[at++];
        if (!symbols || symbols > 256) return invalid();
        at += symbols;
      }
      if (at !== end || length === 2) return invalid();
      huffman = true;
    }
    if (marker === 221 && length !== 4) return invalid();
    if (marker === 218) {
      const count = bytes[offset + 2], selected = new Set<number>();
      if (!width || !quantization || !huffman || !count || count > components.size || length !== 6 + 2 * count) return invalid();
      for (let at = offset + 3; at < end - 3; at += 2) {
        if (!components.has(bytes[at]) || selected.has(bytes[at]) || (bytes[at + 1] >> 4) > 3 || (bytes[at + 1] & 15) > 3) return invalid();
        selected.add(bytes[at]);
      }
      if (bytes[end - 3] > bytes[end - 2] || bytes[end - 2] > 63 || (bytes[end - 1] >> 4) > 13 || (bytes[end - 1] & 15) > 13) return invalid();
      scan = true; offset = end;
      const start = offset;
      while (offset < bytes.length) {
        if (bytes[offset] !== 255) { offset++; continue; }
        if (bytes[offset + 1] === 0 || (bytes[offset + 1] >= 208 && bytes[offset + 1] <= 215)) { offset += 2; continue; }
        break;
      }
      if (offset === start) return invalid();
    } else offset = end;
  }
  return invalid();
}

export function validateGenerationRequest(input: unknown): CreateRequest {
  const parsed = createRequestSchema.safeParse(input);
  if (!parsed.success) throw new Error("Check your reference, page, and request, then try again.");
  for (const image of [parsed.data.reference, parsed.data.screenshot]) {
    const bytes = imageBytes(image);
    const size = image.dataUrl.startsWith("data:image/png;") ? pngDimensions(bytes) : jpegDimensions(bytes);
    if (size.width !== image.width || size.height !== image.height) throw new Error("An image's dimensions do not match its contents. Upload it again.");
  }
  return parsed.data;
}
async function pixelDigest(image: Screenshot): Promise<string> {
  const bytes = await crypto.subtle.digest("SHA-256", imageBytes(image) as BufferSource);
  return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, "0")).join("");
}
function requestsCopyChanges(brief: string): boolean {
  if (/\b(?:preserve|keep)\b.{0,30}\b(?:copy|text|wording)\b|\b(?:do not|don't)\s+(?:change|edit|replace|rewrite)\b/i.test(brief)) return false;
  return /\b(?:rewrite|reword|rename|wording|copy)\b|\b(?:change|edit|replace|update|shorten)\s+(?:(?:the|this|that|all|button|hero|main|page)\s+){0,3}(?:text|title|heading|headline|caption|label|description|paragraph)\b/i.test(brief);
}
async function manifestFor(request: CreateRequest) {
  const [referenceHash, screenshotHash] = await Promise.all([pixelDigest(request.reference), pixelDigest(request.screenshot)]);
  return {
    brief: request.brief, document: request.document,
    reference: { name: request.reference.name, width: request.reference.width, height: request.reference.height, sha256: referenceHash },
    screenshot: { width: request.screenshot.width, height: request.screenshot.height, sha256: screenshotHash },
    findings: request.findings, selectedFindingKeys: request.selectedFindingKeys, history: request.history,
    allowCopyChanges: requestsCopyChanges(request.brief),
  };
}
export async function reviewBinding(input: CreateRequest): Promise<ReviewBinding> {
  const request = validateGenerationRequest(input);
  const [requestHash, sourceHash] = await Promise.all([manifestFor(request).then(digest), digest(request.document)]);
  return { requestHash, sourceHash };
}

// This validator checks patch consistency and conservative content-preservation
// rules. It does not verify visual fidelity; a fresh screenshot review does.
const VALIDATOR = String.raw`import collections, hashlib, json, pathlib, re
from html.parser import HTMLParser
root = pathlib.Path('/workspace')
manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
source = json.loads((root / 'document.json').read_text(encoding='utf-8'))
edits = json.loads((root / 'edits.json').read_text(encoding='utf-8'))
def keys(value, expected):
    assert isinstance(value, dict) and set(value) == set(expected), 'Unexpected object fields'
def text(value, maximum):
    assert isinstance(value, str) and len(value.encode('utf-16-le')) // 2 <= maximum, 'Text exceeds its limit'
def document(value):
    keys(value, ['title', 'lang', 'html', 'css'])
    for field, limit in [('title', 120), ('lang', 35), ('html', ${MAX_HTML_CHARS}), ('css', ${MAX_CSS_CHARS})]: text(value[field], limit)
def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')).hexdigest()
document(source)
assert source == manifest['document'], 'Source document no longer matches the request'
assert isinstance(edits, list) and 1 <= len(edits) <= 16, 'Return one to sixteen edits'
updated = dict(source)
seen = set()
for edit in edits:
    keys(edit, ['field', 'before', 'after'])
    field, before, after = edit['field'], edit['before'], edit['after']
    assert field in updated, 'Unknown source field'
    text(before, 18000); text(after, 18000)
    assert before != after, 'An edit must change its field'
    fingerprint = (field, before, after)
    assert fingerprint not in seen, 'Duplicate edit'
    seen.add(fingerprint)
    value = updated[field]
    if field in ['title', 'lang'] or (before == '' and value == ''):
        assert value == before, 'Metadata does not match the original value'
        updated[field] = after
    else:
        assert before and value.count(before) == 1, 'The replacement must match exactly once'
        updated[field] = value.replace(before, after, 1)
document(updated)
assert updated != source, 'The edits made no final change'

class Contents(HTMLParser):
    voids = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self, markup):
        super().__init__(convert_charrefs=True)
        self.stack = []; self.words = []; self.accessible_words = []; self.controls = 0; self.accessible_controls = 0; self.images = 0; self.styles = []
        self.feed(markup); self.close()
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        parent_ignored = any(entry[1] for entry in self.stack)
        parent_hidden = any(entry[2] for entry in self.stack)
        ignored = parent_ignored or tag in {'script','style','template','head'}
        hidden = parent_hidden or 'hidden' in attrs or 'inert' in attrs or str(attrs.get('aria-hidden','')).lower() == 'true'
        if attrs.get('style'): self.styles.append(attrs['style'])
        control = tag in {'button','select','textarea'} or (tag == 'input' and str(attrs.get('type','')).lower() != 'hidden') or (tag == 'a' and 'href' in attrs) or attrs.get('role') in {'button','link','checkbox','radio','switch','textbox','combobox','slider','spinbutton'}
        if control and not ignored:
            self.controls += 1
            if not hidden: self.accessible_controls += 1
        if tag == 'img' and not ignored: self.images += 1
        if tag not in self.voids: self.stack.append((tag, ignored, hidden))
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.voids: self.handle_endtag(tag)
    def handle_endtag(self, tag):
        for at in range(len(self.stack)-1, -1, -1):
            if self.stack[at][0] == tag:
                del self.stack[at:]; break
    def handle_data(self, data):
        if any(entry[1] for entry in self.stack): return
        words = re.findall(r'\w+', data.casefold())
        self.words.extend(words)
        if not any(entry[2] for entry in self.stack): self.accessible_words.extend(words)
old, new = Contents(source['html']), Contents(updated['html'])
if not manifest.get('allowCopyChanges', False):
    for before_words, after_words in [(old.words,new.words),(old.accessible_words,new.accessible_words)]:
        assert not (collections.Counter(before_words) - collections.Counter(after_words)), 'Preserve existing copy unless the current request explicitly asks for wording changes'
assert new.controls >= old.controls, 'Preserve the existing interactive controls'
assert new.accessible_controls >= old.accessible_controls, 'Do not hide existing interactive controls'
assert new.images >= old.images, 'Preserve the page images'
def asset_refs(value):
    return collections.Counter(re.findall(r'loupe-asset:[a-zA-Z0-9_./:-]+', value['html'] + '\n' + value['css']))
assert not (asset_refs(source) - asset_refs(updated)), 'Preserve the imported image and font references'
def hiding_declarations(css):
    css = re.sub(r'/\*.*?\*/', '', css, flags=re.S).lower()
    declarations = []
    for match in re.finditer(r'([a-z-]+)\s*:\s*([^;}]+)', css):
        prop, value = match.groups()
        value = re.sub(r'\s+|!important', '', value)
        if (prop == 'display' and value == 'none') or (prop == 'visibility' and value in {'hidden','collapse'}) or (prop == 'content-visibility' and value == 'hidden') or (prop in {'opacity','font-size'} and re.fullmatch(r'0(?:\.0+)?(?:px|em|rem|%)?', value)):
            declarations.append((prop,value))
    return collections.Counter(declarations)
assert not (hiding_declarations(updated['css'] + ';' + ';'.join(new.styles)) - hiding_declarations(source['css'] + ';' + ';'.join(old.styles))), 'Do not add rules that conceal page content'
(root / 'updated-document.json').write_text(json.dumps(updated, ensure_ascii=False), encoding='utf-8')
print(json.dumps({'loupe_validation': {'request_sha256': digest(manifest), 'source_sha256': digest(source), 'edits_sha256': digest(edits), 'result_sha256': digest(updated), 'edits': len(edits)}}))
`;

function base64(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let binary = "";
  for (let at = 0; at < bytes.length; at += 8192) binary += String.fromCharCode(...bytes.subarray(at, at + 8192));
  return btoa(binary);
}
export async function makeAgentInput(input: CreateRequest) {
  const request = validateGenerationRequest(input);
  const manifest = await manifestFor(request);
  return {
    files: [
      { type: "inline", path: "/workspace/manifest.json", data: base64(JSON.stringify(manifest)) },
      { type: "inline", path: "/workspace/document.json", data: base64(JSON.stringify(request.document)) },
      { type: "inline", path: "/workspace/apply_edits.py", data: base64(VALIDATOR) },
    ],
    input: [{ role: "user", content: [
      { type: "input_text", text: JSON.stringify(manifest) },
      { type: "input_text", text: `REFERENCE DESIGN: ${request.reference.width} × ${request.reference.height} pixels. The following image shows the intended visual appearance.` },
      { type: "input_image", image_url: request.reference.dataUrl },
      { type: "input_text", text: `CURRENT IMPLEMENTATION: ${request.screenshot.width} × ${request.screenshot.height} pixels. The following image is a fresh browser rendering of the current source.` },
      { type: "input_image", image_url: request.screenshot.dataUrl },
    ] }],
  };
}

function invokesValidator(command: string): boolean {
  let script = command.trim();
  // Agents records the actual shell invocation, including its shell wrapper.
  const wrapped = script.match(/^(?:\/(?:usr\/)?bin\/)?(?:bash|sh|zsh|dash)\s+-(?:lc|cl|c)\s+(['"])([\s\S]*)\1$/);
  if (wrapped) script = wrapped[1] === '"' ? wrapped[2].replace(/\\(["\\$`])/g, "$1") : wrapped[2];
  return /(?:^|\n|&&|;)\s*python3?\s+(?:\/workspace\/apply_edits\.py|'\/workspace\/apply_edits\.py'|"\/workspace\/apply_edits\.py")\s*(?:$|\n|&&|;)/.test(script);
}

/** Reapply against the bound original document before checking actual command evidence. */
export async function generationResult(state: Pick<GenerationSessionState, "result" | "commands">, source: PageDocument, binding: ReviewBinding) {
  const parsed = resultSchema.safeParse(state.result);
  if (!parsed.success || !documentSchema.safeParse(source).success || await digest(source) !== binding.sourceHash) return null;
  let steps = 0;
  if (parsed.data.status === "complete") {
    let updated: PageDocument;
    try { updated = applyEdits(source, parsed.data.edits); } catch { return null; }
    const identities = parsed.data.edits.map(edit => canonicalJSON(edit));
    if (new Set(identities).size !== identities.length || canonicalJSON(updated) === canonicalJSON(source)) return null;
    const [editHash, resultHash] = await Promise.all([digest(parsed.data.edits), digest(updated)]);
    steps = state.commands.filter(command => {
      if (command.status !== "completed" || command.exitCode !== 0 || !invokesValidator(command.command)) return false;
      return command.output.split("\n").some(line => {
        if (line.length > 700) return false;
        try {
          const receipt = JSON.parse(line)?.loupe_validation;
          return receipt?.request_sha256 === binding.requestHash && receipt?.source_sha256 === binding.sourceHash
            && receipt?.edits_sha256 === editHash && receipt?.result_sha256 === resultHash && receipt?.edits === parsed.data.edits.length;
        } catch { return false; }
      });
    }).length;
    if (!steps) return null;
  } else if (state.commands.length) {
    // Conversational responses do not authorize a source-editing sandbox workflow.
    return null;
  }
  return { result: parsed.data, execution: { steps, verified: parsed.data.status === "complete" && steps > 0 } };
}
