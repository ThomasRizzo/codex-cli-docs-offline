import { z } from "zod";

export const MAX_REQUEST_BYTES = 6 * 1024 * 1024;
export const MAX_RESULT_BYTES = 640 * 1024;
export const MAX_HTML_CHARS = 150_000;
export const MAX_CSS_CHARS = 300_000;
export const MAX_IMPORT_HTML_BYTES = 16_000_000;
export const MAX_IMAGE_BYTES = 1_500_000;
export const MAX_IMAGE_DIMENSION = 2400;
export const documentSchema = z.object({
  title: z.string().max(120), lang: z.string().max(35),
  html: z.string().max(MAX_HTML_CHARS), css: z.string().max(MAX_CSS_CHARS),
}).strict();
export type PageDocument = z.infer<typeof documentSchema>;
const imageShape = {
  dataUrl: z.string().max(2_000_100).regex(/^data:image\/(?:png|jpeg);base64,[A-Za-z0-9+/]+={0,2}$/),
  width: z.number().int().min(1).max(MAX_IMAGE_DIMENSION),
  height: z.number().int().min(1).max(MAX_IMAGE_DIMENSION),
};
export const screenshotSchema = z.object(imageShape).strict();
export type Screenshot = z.infer<typeof screenshotSchema>;
export const referenceSchema = z.object({ name: z.string().min(1).max(180), ...imageShape }).strict();
export type ReferenceImage = z.infer<typeof referenceSchema>;
export const findingSchema = z.object({
  key: z.string().min(1).max(100), title: z.string().min(1).max(160),
  category: z.enum(["layout", "typography", "color", "spacing", "details"]),
  severity: z.enum(["major", "minor"]),
  description: z.string().min(1).max(700), recommendation: z.string().min(1).max(700),
  selector: z.string().min(1).max(500).nullable(),
}).strict();
export type Finding = z.infer<typeof findingSchema>;
export const historyEntrySchema = z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(1500) }).strict();
export type HistoryEntry = z.infer<typeof historyEntrySchema>;
export const createRequestSchema = z.object({
  brief: z.string().trim().min(1).max(1500), document: documentSchema,
  reference: referenceSchema, screenshot: screenshotSchema,
  findings: z.array(findingSchema).max(24),
  selectedFindingKeys: z.array(z.string().min(1).max(100)).max(24),
  history: z.array(historyEntrySchema).max(12).default([]),
}).strict().superRefine((value, ctx) => {
  const keys = new Set(value.findings.map(f => f.key));
  if (keys.size !== value.findings.length || new Set(value.selectedFindingKeys).size !== value.selectedFindingKeys.length || value.selectedFindingKeys.some(key => !keys.has(key))) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["selectedFindingKeys"], message: "Select findings from the current review." });
  }
});
export type CreateRequest = z.infer<typeof createRequestSchema>;
export const editSchema = z.object({
  field: z.enum(["title", "lang", "html", "css"]),
  before: z.string().max(18_000), after: z.string().max(18_000),
}).strict();
export type SourceEdit = z.infer<typeof editSchema>;
export const resultSchema = z.object({
  status: z.enum(["review", "complete", "answer", "clarification", "off_topic"]),
  message: z.string().min(1).max(1500), findings: z.array(findingSchema).max(24),
  edits: z.array(editSchema).max(16),
}).strict().superRefine((result, ctx) => {
  if (result.status === "complete" ? !result.edits.length : result.edits.length) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["edits"], message: "Only a requested revision may contain edits." });
  if (result.status !== "review" && result.findings.length) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["findings"], message: "Only a review may return findings." });
  if (new Set(result.findings.map(f => f.key)).size !== result.findings.length) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["findings"], message: "Each finding needs its own key." });
});
export type GenerationResult = z.infer<typeof resultSchema>;
const findingJsonSchema = { type: "object", additionalProperties: false, required: ["key", "title", "category", "severity", "description", "recommendation", "selector"], properties: {
  key: { type: "string", minLength: 1, maxLength: 100 }, title: { type: "string", minLength: 1, maxLength: 160 },
  category: { type: "string", enum: ["layout", "typography", "color", "spacing", "details"] }, severity: { type: "string", enum: ["major", "minor"] },
  description: { type: "string", minLength: 1, maxLength: 700 }, recommendation: { type: "string", minLength: 1, maxLength: 700 },
  selector: { type: ["string", "null"], minLength: 1, maxLength: 500 },
} };
export const resultJsonSchema = {
  type: "object", additionalProperties: false, required: ["status", "message", "findings", "edits"], properties: {
    status: { type: "string", enum: ["review", "complete", "answer", "clarification", "off_topic"] },
    message: { type: "string", minLength: 1, maxLength: 1500 },
    findings: { type: "array", maxItems: 24, items: findingJsonSchema },
    edits: { type: "array", maxItems: 16, items: { type: "object", additionalProperties: false, required: ["field", "before", "after"], properties: { field: { type: "string", enum: ["title", "lang", "html", "css"] }, before: { type: "string", maxLength: 18000 }, after: { type: "string", maxLength: 18000 } } } },
  },
};
/** Apply exact, unique replacements in order; metadata edits replace the complete value. */
export function applyEdits(source: PageDocument, edits: SourceEdit[]): PageDocument {
  const next = { ...documentSchema.parse(source) };
  for (const edit of edits) {
    const { field, before, after } = editSchema.parse(edit), value = next[field];
    if (before === after) throw Error("An edit did not change the page.");
    if (field === "title" || field === "lang" || (!before && !value)) {
      if (value !== before) throw Error("The page changed while this edit was being prepared.");
      next[field] = after;
    } else {
      if (!before || value.split(before).length !== 2) throw Error("An edit could not be matched uniquely. The current page is preserved.");
      next[field] = value.replace(before, () => after);
    }
  }
  return documentSchema.parse(next);
}
