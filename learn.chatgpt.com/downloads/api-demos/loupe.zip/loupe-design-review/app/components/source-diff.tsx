"use client";

import { useMemo, useState, type CSSProperties } from "react";
import { MultiFileDiff } from "@pierre/diffs/react";
import type { PageDocument } from "../lib/contracts";
import { serializeDocumentSource } from "../lib/document-io";

const viewerStyle = {
  "--diffs-font-size": "12px",
  "--diffs-line-height": "20px",
} as CSSProperties;

export default function SourceDiff({ before, after }: {
  before: PageDocument;
  after: PageDocument;
}) {
  const [layout, setLayout] = useState<"unified" | "split">("unified");
  const comparison = useMemo(() => {
    try {
      return {
        ok: true as const,
        oldFile: { name: "page.html", contents: serializeDocumentSource(before) },
        newFile: { name: "page.html", contents: serializeDocumentSource(after) },
      };
    } catch (error) {
      return { ok: false as const, error: error instanceof Error ? error.message : "This source could not be displayed." };
    }
  }, [before, after]);
  const options = useMemo(() => ({
    theme: "pierre-light" as const,
    themeType: "light" as const,
    diffStyle: layout,
    diffIndicators: "classic" as const,
    overflow: "wrap" as const,
    lineDiffType: "word-alt" as const,
    hunkSeparators: "line-info" as const,
    // Highlight compact CSS without unbounded tokenization.
    maxLineDiffLength: 10_000,
    tokenizeMaxLineLength: 10_000,
  }), [layout]);

  return <>
    <div className="changes-heading">
      <div><h2>Source diff</h2><p>Original → current</p></div>
      {comparison.ok && <div className="diff-layout" role="group" aria-label="Diff layout">
        {(["unified", "split"] as const).map(value => <button key={value} type="button" aria-pressed={layout === value} onClick={() => setLayout(value)}>{value === "unified" ? "Unified" : "Split"}</button>)}
      </div>}
    </div>
    {comparison.ok ? <>
      <div className="source-diff-scroll" role="region" aria-label="Source diff" tabIndex={0}>
        <MultiFileDiff oldFile={comparison.oldFile} newFile={comparison.newFile} options={options} style={viewerStyle} />
      </div>
      {/loupe-asset:/.test(comparison.oldFile.contents + comparison.newFile.contents) && <p className="diff-asset-note">Images and fonts shown as source references.</p>}
    </> : <div className="changes-empty" role="alert"><h3>Couldn’t display this diff</h3><p>{comparison.error}</p></div>}
  </>;
}
