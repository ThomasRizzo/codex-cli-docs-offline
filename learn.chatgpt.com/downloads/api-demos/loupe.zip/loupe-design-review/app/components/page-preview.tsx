"use client";

import { forwardRef, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState, type CSSProperties } from "react";
import type { PageDocument, Screenshot } from "../lib/contracts";
import { capturePreview, validateCaptureViewport, waitForPreviewResources, type PreviewViewport } from "../lib/capture";
import { exportDocumentHtml } from "../lib/document-io";
import type { PreviewAssets } from "../lib/preview-assets";

export type PagePreviewHandle = { capture(): Promise<Screenshot>; highlight(selector: string | null): boolean };
export type PagePreviewProps = {
  document: PageDocument;
  assets: PreviewAssets;
  viewport: PreviewViewport;
  selectedSelector?: string | null;
  className?: string;
  onReady?: () => void;
  onError?: (message: string) => void;
};
type Highlight = { left: number; top: number; width: number; height: number; key: number };

export const PagePreview = forwardRef<PagePreviewHandle, PagePreviewProps>(function PagePreview({ document, assets, viewport, selectedSelector, className = "", onReady, onError }, ref) {
  const wrapper = useRef<HTMLDivElement>(null);
  const frame = useRef<HTMLIFrameElement>(null);
  const loaded = useRef(false);
  const highlightTarget = useRef<Element | null>(null);
  const captureActive = useRef(false);
  const captureRequest = useRef<{ document: Document; width: number; height: number; promise: Promise<Screenshot> } | null>(null);
  const generation = useRef(0);
  const sourceHtml = useRef<string | null>(null);
  const callbacks = useRef({ onReady, onError });
  callbacks.current = { onReady, onError };
  const [scale, setScale] = useState(1);
  const [highlightBox, setHighlightBox] = useState<Highlight | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const size = useMemo(() => validateCaptureViewport(viewport), [viewport.width, viewport.height]);
  const [source, setSource] = useState<{ html: string; revision: number }>({ html: "", revision: 0 });
  useEffect(() => {
    try {
      const html = exportDocumentHtml(document, assets);
      const doc = frame.current?.contentDocument;
      if (sourceHtml.current === html && loaded.current && doc) {
        // A no-op save/reset must re-signal readiness without waiting for an iframe load that will never fire.
        void waitForPreviewResources(doc).then(() => {
          if (frame.current?.contentDocument === doc && loaded.current) callbacks.current.onReady?.();
        }).catch(reason => callbacks.current.onError?.(reason instanceof Error ? reason.message : "The preview could not be loaded."));
        return;
      }
      sourceHtml.current = html; loaded.current = false; highlightTarget.current = null;
      setReady(false); setHighlightBox(null); setError(null);
      setSource(previous => ({ html, revision: previous.revision + 1 }));
    } catch (reason) {
      const message = reason instanceof Error ? reason.message : "This page could not be previewed.";
      sourceHtml.current = null; loaded.current = false; highlightTarget.current = null;
      setReady(false); setHighlightBox(null); setError(message);
      setSource(previous => ({ html: "", revision: previous.revision + 1 }));
      callbacks.current.onError?.(message);
    }
  }, [document, assets]);
  useEffect(() => {
    const doc = frame.current?.contentDocument;
    if (!doc || !loaded.current) return;
    void waitForPreviewResources(doc).then(() => {
      if (frame.current?.contentDocument === doc && loaded.current) callbacks.current.onReady?.();
    }).catch(reason => callbacks.current.onError?.(reason instanceof Error ? reason.message : "The preview could not be loaded."));
  }, [size]);

  const positionHighlight = useCallback(() => {
    const element = highlightTarget.current;
    if (!element || captureActive.current) return;
    const rect = element.getBoundingClientRect();
    const left = Math.max(0, rect.left), top = Math.max(0, rect.top);
    const width = Math.min(size.width, rect.right) - left, height = Math.min(size.height, rect.bottom) - top;
    setHighlightBox(width > 0 && height > 0 ? { left, top, width, height, key: generation.current } : null);
  }, [size]);

  const highlight = useCallback((selector: string | null): boolean => {
    setHighlightBox(null); highlightTarget.current = null;
    const doc = frame.current?.contentDocument;
    if (!selector || selector.length > 500 || !loaded.current || captureActive.current || !doc) return false;
    try {
      const matches = doc.querySelectorAll(selector);
      const element = matches.length === 1 ? matches[0] : null;
      if (!element || element === doc.body || element === doc.documentElement || !element.getClientRects().length) return false;
      const view = doc.defaultView!;
      for (let parent: Element | null = element; parent; parent = parent.parentElement) {
        const style = view.getComputedStyle(parent);
        if (style.visibility !== "visible" || style.display === "none" || Number(style.opacity) === 0) return false;
      }
      highlightTarget.current = element;
      generation.current++;
      element.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
      positionHighlight();
      return true;
    } catch { return false; }
  }, [positionHighlight]);

  useImperativeHandle(ref, () => ({
    highlight,
    capture() {
      const node = frame.current, doc = node?.contentDocument;
      if (!node || !doc || !loaded.current) throw Error("The page preview is still loading. Try again shortly.");
      const existing = captureRequest.current;
      if (existing && existing.document === doc && existing.width === size.width && existing.height === size.height) return existing.promise;
      captureActive.current = true;
      setHighlightBox(null); highlightTarget.current = null;
      const request = { document: doc, width: size.width, height: size.height, promise: capturePreview(node, size) };
      captureRequest.current = request;
      request.promise = request.promise.then(result => {
        if (frame.current !== node || node.contentDocument !== doc) throw Error("The page changed during capture. Try again.");
        return result;
      }).finally(() => {
        if (captureRequest.current === request) { captureRequest.current = null; captureActive.current = false; }
      });
      return request.promise;
    },
  }), [highlight, size]);

  useEffect(() => {
    const node = wrapper.current;
    if (!node) return;
    const update = () => {
      const { width, height } = node.getBoundingClientRect();
      if (width > 0 && height > 0) setScale(Math.min(1, width / size.width, height / size.height));
    };
    update(); const observer = new ResizeObserver(update); observer.observe(node);
    return () => observer.disconnect();
  }, [size]);
  useEffect(() => { if (ready) highlight(selectedSelector ?? null); }, [selectedSelector, highlight, ready]);

  const onLoad = useCallback(async () => {
    const node = frame.current, doc = node?.contentDocument;
    if (!doc || !node || !source.html) return;
    // Parent listeners keep the sanitized preview static; no script runs in the iframe.
    const preventNavigation = (event: Event) => {
      if (event.type === "submit" || (event.target as Element | null)?.closest?.("a,area")) event.preventDefault();
    };
    doc.addEventListener("click", preventNavigation, true);
    doc.addEventListener("submit", preventNavigation, true);
    doc.addEventListener("scroll", positionHighlight, { passive: true, capture: true });
    try {
      await waitForPreviewResources(doc);
      if (node.contentDocument !== doc) return;
      loaded.current = true; setReady(true); setError(null); callbacks.current.onReady?.();
    } catch (reason) {
      if (node.contentDocument !== doc) return;
      const message = reason instanceof Error ? reason.message : "The preview could not be loaded.";
      loaded.current = false; setError(message); callbacks.current.onError?.(message);
    }
  }, [source, positionHighlight]);

  const frameStyle: CSSProperties = { width: size.width, height: size.height, display: "block", border: 0, background: "white" };
  return <div className={`page-preview ${className}`} ref={wrapper} style={{ position: "relative", width: "100%", height: "100%", minWidth: 0, minHeight: 0, overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
    {source.html && <div className="page-preview-boundary" style={{ width: size.width * scale, height: size.height * scale, flex: "0 0 auto", position: "relative", overflow: "hidden", background: "white" }}>
      <div style={{ width: size.width, height: size.height, transform: `scale(${scale})`, transformOrigin: "top left" }}>
        <iframe key={`frame-${source.revision}`} ref={frame} title={`${document.title || "Page"} preview`} sandbox="allow-same-origin" referrerPolicy="no-referrer" srcDoc={source.html} onLoad={onLoad} style={frameStyle}/>
        {highlightBox && <div key={`highlight-${highlightBox.key}`} aria-hidden="true" className="page-preview-highlight" style={{ position: "absolute", pointerEvents: "none", left: highlightBox.left, top: highlightBox.top, width: highlightBox.width, height: highlightBox.height, boxSizing: "border-box", border: "3px solid var(--preview-highlight, #ff6333)", background: "color-mix(in srgb, var(--preview-highlight, #ff6333) 10%, transparent)", boxShadow: "0 0 0 1px white inset", zIndex: 1 }}/>}
      </div>
      <div aria-hidden="true" style={{ position: "absolute", inset: 0, border: "1px solid var(--preview-border, #d7dce3)", boxSizing: "border-box", pointerEvents: "none" }}/>
    </div>}
    {error && <p role="status" className="page-preview-error" style={{ position: "absolute", bottom: 12, left: 12, right: 12, padding: 12, margin: 0, border: "1px solid #e2d4cf", borderRadius: 8, color: "#6a3426", background: "#fff7f3", font: "13px/1.5 system-ui" }}>{error}</p>}
  </div>;
});
