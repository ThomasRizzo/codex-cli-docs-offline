"use client";

import { useEffect, useMemo, useRef, useState, Fragment, lazy, Suspense, type ChangeEvent, type CSSProperties, type FormEvent } from "react";
import { ArrowDownTrayIcon, ArrowPathIcon, ArrowUpIcon, Bars3Icon, CheckIcon, ChevronDownIcon, CodeBracketIcon, CursorArrowRaysIcon, DocumentIcon, QuestionMarkCircleIcon, SparklesIcon, Square2StackIcon, StopIcon, XMarkIcon } from "@heroicons/react/16/solid";
import { applyEdits, documentSchema, MAX_IMAGE_BYTES, MAX_IMAGE_DIMENSION, type Finding, type GenerationResult, type PageDocument, type ReferenceImage, type Screenshot } from "../lib/contracts";
import { exportDocumentHtml, exportDocumentPatch, normalizeDocument } from "../lib/document-io";
import { importSavedPage } from "../lib/saved-page-import";
import type { PreviewAssets } from "../lib/preview-assets";
import { REFERENCE, sampleAssets, sampleDocument } from "../lib/samples";
import { PagePreview, type PagePreviewHandle } from "./page-preview";
import { useReviewGeneration } from "./use-review-generation";

const SourceDiff = lazy(() => import("./source-diff"));

type Mode = "compare" | "overlay" | "diff";
type Message = {id:number;role:"user"|"assistant";content:string;state?:"pending"|"failed"|"stopped"};
type Reference = {name:string;width:number;height:number;url:string;dataUrl?:string};
const REVIEW_BRIEF = "Compare the current implementation with the reference image. Review the visual differences in layout, typography, spacing, colors, and details. Return specific actionable findings. Do not change the source yet.";
const FIX_BRIEF = "Fix the selected findings so the implementation more closely matches the reference. Preserve the page’s content and unrelated design decisions. If a fix needs more information, ask me first.";
function download(name:string, content:string, type:string) { const url=URL.createObjectURL(new Blob([content],{type})); const link=document.createElement("a"); link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000); }
function fileDataUrl(file:Blob):Promise<string> {return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error("This image could not be read."));reader.readAsDataURL(file);});}
async function normalizeImage(file:Blob):Promise<Screenshot> {
  if(file.size>30_000_000)throw Error("Choose an image under 30 MB.");
  if(!["image/png","image/jpeg","image/webp"].includes(file.type))throw Error("Choose a PNG, JPEG, or WebP image.");
  const source=await fileDataUrl(file); const image=new Image(); image.src=source; await image.decode().catch(()=>{throw Error("This image could not be opened. Try another PNG, JPEG, or WebP file.");});
  const ratio=Math.min(1,MAX_IMAGE_DIMENSION/Math.max(image.naturalWidth,image.naturalHeight));
  const canvas=document.createElement("canvas");canvas.width=Math.max(1,Math.round(image.naturalWidth*ratio));canvas.height=Math.max(1,Math.round(image.naturalHeight*ratio));
  const context=canvas.getContext("2d");if(!context)throw Error("Your browser could not prepare the reference image.");context.fillStyle="#ffffff";context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(image,0,0,canvas.width,canvas.height);
  let dataUrl=canvas.toDataURL("image/png");
  if(dataUrl.length*0.75>MAX_IMAGE_BYTES){for(const quality of [.9,.78,.64,.5,.35]){dataUrl=canvas.toDataURL("image/jpeg",quality);if(dataUrl.length*.75<=MAX_IMAGE_BYTES)break;}}
  if(dataUrl.length*.75>MAX_IMAGE_BYTES)throw Error("This image is too detailed to prepare. Try a smaller screenshot.");
  return {dataUrl,width:canvas.width,height:canvas.height};
}
function isElementSelector(selector:string|null){return !!selector&&!/^(?:html|body|:root|\*)$/i.test(selector.trim());}

export function LoupeApp(){
  const [page,setPage]=useState<PageDocument>(sampleDocument);
  const [original,setOriginal]=useState<PageDocument>(sampleDocument);
  const [assets,setAssets]=useState<PreviewAssets>(sampleAssets);
  const [reference,setReference]=useState<Reference>(REFERENCE);
  const [mode,setMode]=useState<Mode>("compare");
  const [mobilePanel,setMobilePanel]=useState<"canvas"|"review">("canvas");
  const [messages,setMessages]=useState<Message[]>([]);
  const [findings,setFindings]=useState<Finding[]>([]);
  const [findingsAfter,setFindingsAfter]=useState<number|null>(null);
  const [selected,setSelected]=useState<string[]>([]);
  const [expanded,setExpanded]=useState<string|null>(null);
  const [unavailable,setUnavailable]=useState<string[]>([]);
  const [reviewed,setReviewed]=useState(false);
  const [stale,setStale]=useState(false);
  const [draft,setDraft]=useState("");
  const [notice,setNotice]=useState<string|null>(null);
  const [notes,setNotes]=useState<string[]>([]);
  const [localError,setLocalError]=useState<string|null>(null);
  const [preparing,setPreparing]=useState(false);
  const [preparingText,setPreparingText]=useState("Preparing the comparison…");
  const [ready,setReady]=useState(false);
  const [opacity,setOpacity]=useState(50);
  const [overlay,setOverlay]=useState<Screenshot|null>(null);
  const [menu,setMenu]=useState(false);
  const [sourceDraft,setSourceDraft]=useState(sampleDocument);
  const [sourceTab,setSourceTab]=useState<"html"|"css">("html");
  const [sourceError,setSourceError]=useState<string|null>(null);
  const [importFile,setImportFile]=useState<File|null>(null);
  const [companion,setCompanion]=useState<File[]>([]);
  const [importing,setImporting]=useState(false);
  const [importError,setImportError]=useState<string|null>(null);
  const [undo,setUndo]=useState<PageDocument[]>([]);
  const preview=useRef<PagePreviewHandle>(null);
  const helpDialog=useRef<HTMLDialogElement>(null),sourceDialog=useRef<HTMLDialogElement>(null),importDialog=useRef<HTMLDialogElement>(null);
  const referenceInput=useRef<HTMLInputElement>(null),folderInput=useRef<HTMLInputElement>(null),transcript=useRef<HTMLDivElement>(null);
  const followTail=useRef(true);
  const sequence=useRef(0),messageId=useRef(0),operation=useRef<"reference"|"review"|null>(null);
  const generation=useReviewGeneration();
  const busy=generation.busy||preparing;
  const changed=page.html!==original.html||page.css!==original.css||page.title!==original.title||page.lang!==original.lang;
  const viewport=useMemo(()=>({width:reference.width,height:reference.height}),[reference.width,reference.height]);
  const error=localError||generation.error;
  useEffect(()=>{folderInput.current?.setAttribute("webkitdirectory","");},[]);
  useEffect(()=>{const node=transcript.current;if(node&&followTail.current)node.scrollTop=node.scrollHeight;},[messages,generation.message]);
  useEffect(()=>{if(mode!=="overlay"||!ready)return;let alive=true;preview.current?.capture().then(image=>{if(alive)setOverlay(image);}).catch(cause=>{if(alive)setLocalError(cause instanceof Error?cause.message:"The overlay could not be prepared.");});return()=>{alive=false;};},[mode,page,ready,reference.width,reference.height]);
  useEffect(()=>()=>{sequence.current++;},[]);
  function markChanged(next:PageDocument){if(JSON.stringify(next)===JSON.stringify(page))return;setUndo(items=>[...items.slice(-4),page]);setPage(next);setStale(reviewed);setSelected([]);setOverlay(null);setReady(false);}
  function stop(){sequence.current++;operation.current=null;setPreparing(false);generation.stop();setMessages(items=>items.map(item=>item.state==="pending"?{...item,state:"stopped"}:item));}
  function reset(){sequence.current++;operation.current=null;generation.stop(true);generation.clearFeedback();setPage(sampleDocument);setOriginal(sampleDocument);setAssets(sampleAssets);setReference(REFERENCE);setMessages([]);setFindings([]);setFindingsAfter(null);setSelected([]);setExpanded(null);setReviewed(false);setStale(false);setUndo([]);setOverlay(null);setNotes([]);setLocalError(null);setNotice("Sample restored.");setMode("compare");}
  async function start(brief:string,retryId?:number){
    if(operation.current||busy||!brief.trim()||!ready)return;
    operation.current="review";followTail.current=true;
    const id=++sequence.current,turnId=retryId??++messageId.current,requestPage=page,requestAssets=assets;
    setLocalError(null);setNotice(null);generation.clearFeedback();setPreparingText("Capturing the current page…");setPreparing(true);setMobilePanel("review");
    setMessages(items=>retryId?items.map(item=>item.id===retryId?{...item,state:"pending"}:item):[...items,{id:turnId,role:"user",content:brief,state:"pending"}]);setDraft("");
    const fail=(message:string)=>{setMessages(items=>items.map(item=>item.id===turnId?{...item,state:"failed"}:item));setLocalError(message);};
    try{
      const [screenshot,ref]=await Promise.all([preview.current!.capture(),(async()=>{if(reference.dataUrl)return reference as ReferenceImage;const response=await fetch(reference.url);if(!response.ok)throw Error("The reference image could not be loaded. Try uploading it again.");const image=await normalizeImage(await response.blob());return {name:reference.name,...image};})()]);
      if(sequence.current!==id)return;
      setPreparing(false);
      await generation.start({brief,document:requestPage,reference:{name:ref.name,dataUrl:ref.dataUrl!,width:ref.width,height:ref.height},screenshot,findings:stale?[]:findings,selectedFindingKeys:stale?[]:selected,history:messages.filter(item=>!item.state&&item.id!==retryId).slice(-12).map(({role,content})=>({role,content:content.slice(0,1500)}))},{
        onComplete:(result:GenerationResult)=>{
          if(sequence.current!==id)return;
          const assistantId=++messageId.current;
          if(result.status==="complete"){
            const next=normalizeDocument(applyEdits(requestPage,result.edits)).document;
            setUndo(items=>[...items.slice(-4),requestPage]);setPage(next);setAssets(requestAssets);setStale(true);setSelected([]);setOverlay(null);setReady(false);setNotice("Changes applied. Recheck to review the updated page.");
          }else if(result.status==="review"){
            setFindings(result.findings);setFindingsAfter(assistantId);setSelected([]);setExpanded(result.findings[0]?.key??null);setUnavailable([]);setReviewed(true);setStale(false);
          }
          setMessages(items=>[...items.map(item=>item.id===turnId?{...item,state:undefined}:item),{id:assistantId,role:"assistant",content:result.message}]);
        },onError:fail,onStop:()=>setMessages(items=>items.map(item=>item.id===turnId?{...item,state:"stopped"}:item)),
      });
    }catch(cause){if(sequence.current===id)fail(cause instanceof Error?cause.message:"The page could not be prepared. Please try again.");}
    finally{if(sequence.current===id){operation.current=null;setPreparing(false);}}
  }
  function submit(event:FormEvent){event.preventDefault();if(busy){stop();return;}void start(draft.trim()||(!reviewed?REVIEW_BRIEF:stale?REVIEW_BRIEF:selected.length?FIX_BRIEF:""));}
  async function uploadReference(event:ChangeEvent<HTMLInputElement>){
    const file=event.target.files?.[0];event.target.value="";if(!file||operation.current||generation.busy||importing)return;
    const id=++sequence.current;operation.current="reference";setPreparingText("Preparing your reference…");setPreparing(true);setLocalError(null);
    try{const image=await normalizeImage(file);if(sequence.current!==id)return;setReference({name:file.name,url:image.dataUrl,...image});setStale(reviewed);setSelected([]);setOverlay(null);setNotice("Reference updated. Review the implementation against this image.");}
    catch(cause){if(sequence.current===id)setLocalError(cause instanceof Error?cause.message:"The reference could not be opened.");}
    finally{if(sequence.current===id){operation.current=null;setPreparing(false);}}
  }
  async function importImplementation(){if(!importFile)return;setImporting(true);setImportError(null);try{const result=await importSavedPage(importFile,companion);sequence.current++;generation.clearFeedback();setPage(result.document);setOriginal(result.document);setAssets(result.assets);setMessages([]);setFindings([]);setFindingsAfter(null);setSelected([]);setExpanded(null);setReviewed(false);setStale(false);setUndo([]);setOverlay(null);setReady(false);setLocalError(null);setNotes(result.warnings);setNotice(`Imported ${importFile.name}.`);importDialog.current?.close();setMode("compare");}catch(cause){setImportError(cause instanceof Error?cause.message:"This page could not be imported.");}finally{setImporting(false);}}
  function saveSource(){setSourceError(null);try{const next=normalizeDocument(documentSchema.parse(sourceDraft));markChanged(next.document);sourceDialog.current?.close();setLocalError(null);setNotice(next.removed?"Source saved. Active or external content was removed from the static preview.":"Source saved.");}catch(cause){setSourceError(cause instanceof Error?cause.message:"The source could not be saved.");}}
  function reveal(finding:Finding){setMode("compare");setMobilePanel("canvas");if(!preview.current?.highlight(finding.selector))setUnavailable(items=>[...items,finding.key]);}
  function exportHtml(){try{download("page.html",exportDocumentHtml(page,assets),"text/html");}catch(cause){setLocalError(cause instanceof Error?cause.message:"The HTML could not be exported.");}}
  function exportPatch(){try{download("loupe-changes.patch",exportDocumentPatch(original,page,assets),"text/x-diff");}catch(cause){setLocalError(cause instanceof Error?cause.message:"The patch could not be exported.");}}
  const findingsContent=reviewed&&<section className="findings" aria-label="Review findings"><div className="findings-heading"><h3>{stale?"Previous findings":"Findings"}</h3>{findings.length>0&&!stale&&<button type="button" className="text-button" disabled={busy} onClick={()=>setSelected(selected.length===findings.length?[]:findings.map(item=>item.key))}>{selected.length===findings.length?"Clear":"Select all"}</button>}</div>{stale&&<p className="stale-note">The page changed. Recheck for a fresh comparison.</p>}{findings.length===0?<p className="no-findings">No specific visual differences were reported. You can ask about a detail or review again.</p>:findings.map((finding,index)=><div className="finding" key={finding.key} data-stale={stale}><div className="finding-header"><label className="finding-checkbox"><input type="checkbox" name={`finding-${finding.key}`} aria-label={`Select ${finding.title}`} checked={selected.includes(finding.key)} disabled={busy||stale} onChange={event=>setSelected(keys=>event.target.checked?[...keys,finding.key]:keys.filter(key=>key!==finding.key))}/><CheckIcon/></label><button type="button" className="finding-toggle" aria-expanded={expanded===finding.key} onClick={()=>setExpanded(expanded===finding.key?null:finding.key)}><div><p className="finding-category">{String(index+1).padStart(2,"0")} · {finding.category}<span data-severity={finding.severity}>{finding.severity}</span></p><h4>{finding.title}</h4></div><ChevronDownIcon/></button></div>{expanded===finding.key&&<div className="finding-body"><p>{finding.description}</p><div className="recommendation"><p className="recommendation-label">Suggested change</p><p>{finding.recommendation}</p></div>{isElementSelector(finding.selector)&&!unavailable.includes(finding.key)?<button type="button" className="button ghost reveal-button" disabled={stale} onClick={()=>reveal(finding)}><CursorArrowRaysIcon/>Show element</button>:<p className="page-level">{unavailable.includes(finding.key)?"Element isn’t visible in this viewport.":"Page-level observation"}</p>}</div>}</div>)}</section>;
  const primaryLabel=busy?"Stop":draft.trim()?"Send":!reviewed?"Review design":stale?"Recheck":selected.length?"Fix selected":"Send";
  const disabled=!busy&&(!ready||(!draft.trim()&&reviewed&&!stale&&!selected.length));
  return <div className="loupe-app">
    <header className="app-header"><a className="brand" href="/" aria-label="Loupe homepage"><img src="/favicon.svg" alt="" width="28" height="28"/><h1>Loupe</h1></a><div className="project-name"><span className="header-divider"/><p>Design review</p></div><nav className="header-actions" aria-label="Project"><button type="button" className="button ghost" onClick={reset} disabled={busy}>Reset sample</button><a className="button ghost" href="/loupe-project.zip" download><ArrowDownTrayIcon/>Download project</a><button type="button" className="button icon" aria-label="How Loupe works" onClick={()=>helpDialog.current?.showModal()}><QuestionMarkCircleIcon/></button></nav><button type="button" className="button icon mobile-menu-button" aria-label={menu?"Close menu":"Open menu"} aria-expanded={menu} onClick={()=>setMenu(!menu)}>{menu?<XMarkIcon/>:<Bars3Icon/>}</button>{menu&&<nav className="mobile-menu" aria-label="Project"><button type="button" className="button ghost" onClick={()=>{reset();setMenu(false);}} disabled={busy}>Reset sample</button><a className="button ghost" href="/loupe-project.zip" download>Download project</a><button type="button" className="button ghost" onClick={()=>{setMenu(false);helpDialog.current?.showModal();}}>How it works</button></nav>}</header>
    <div className="mobile-panel-tabs" role="group" aria-label="Workspace"><button type="button" aria-pressed={mobilePanel==="canvas"} onClick={()=>setMobilePanel("canvas")}>Canvas</button><button type="button" aria-pressed={mobilePanel==="review"} onClick={()=>setMobilePanel("review")}>Review {findings.length>0&&`(${findings.length})`}{busy&&<span className="activity-dot"/>}</button></div>
    <main className="workspace" data-mobile-panel={mobilePanel}>
      <section className="canvas-panel" aria-label="Design comparison">
        <div className="canvas-toolbar"><div className="view-tabs" role="group" aria-label="Comparison view">{(["compare","overlay","diff"] as Mode[]).map(view=><button key={view} type="button" aria-pressed={mode===view} disabled={preparing} onClick={()=>{setMode(view);setLocalError(null);}}>{view.charAt(0).toUpperCase()+view.slice(1)}{view==="diff"&&changed&&<span className="change-dot"/>}</button>)}</div><div className="canvas-tools"><p className="viewport-size">{reference.width} × {reference.height}</p><button type="button" className="button ghost" disabled={busy} onClick={()=>{setSourceDraft(page);setSourceTab("html");setSourceError(null);sourceDialog.current?.showModal();}}><CodeBracketIcon/><span>Source</span></button></div></div>
        <div className="canvas-area">
          <div className="compare-stage" data-active={mode==="compare"} aria-hidden={mode!=="compare"}>
            <article className="artboard"><div className="artboard-heading"><div><span className="reference-indicator"/><h2>Reference</h2></div><button type="button" className="button icon" aria-label="Upload reference image" title="Upload reference image" disabled={busy} onClick={()=>referenceInput.current?.click()}><ArrowUpIcon/></button></div><div className="artboard-space"><div className="comparison-surface" style={{"--ratio":`${reference.width}/${reference.height}`} as CSSProperties}><img className="reference-image" src={reference.dataUrl||reference.url} alt="Design reference to compare against the implementation"/></div></div><div className="artboard-footer"><p title={reference.name}>{reference.name}</p><p>Design target</p></div></article>
            <article className="artboard"><div className="artboard-heading"><div><span className="implementation-indicator"/><h2>Implementation</h2>{changed&&<p className="edited-label">Edited</p>}</div><button type="button" className="button icon" aria-label="Upload implementation HTML" title="Upload implementation HTML" disabled={busy} onClick={()=>{setImportFile(null);setCompanion([]);setImportError(null);importDialog.current?.showModal();}}><ArrowUpIcon/></button></div><div className="artboard-space"><div className="comparison-surface" style={{"--ratio":`${reference.width}/${reference.height}`} as CSSProperties}><PagePreview ref={preview} document={page} assets={assets} viewport={viewport} onReady={()=>setReady(true)} onError={message=>setLocalError(message)} className="implementation-preview"/></div></div><div className="artboard-footer"><p title={page.title}>{page.title||"Untitled page"}</p><p>Live HTML + CSS</p></div></article>
          </div>
          {mode==="overlay"&&<section className="overlay-stage" aria-label="Reference overlay"><div className="overlay-controls"><p>Reference</p><input type="range" name="overlay-opacity" aria-label="Implementation opacity" min="0" max="100" value={opacity} onChange={event=>setOpacity(Number(event.target.value))}/><p>Implementation <span>{opacity}%</span></p></div><div className="overlay-space"><div className="overlay-artboard" style={{"--ratio":`${reference.width}/${reference.height}`} as CSSProperties}><img src={reference.dataUrl||reference.url} alt="Design reference"/>{overlay?<img src={overlay.dataUrl} alt="Current implementation capture" className="overlay-implementation" style={{"--overlay-opacity":opacity/100} as CSSProperties}/>:<div className="overlay-loading" role="status">Preparing comparison…</div>}</div></div><p className="overlay-note">Both views use the same {reference.width} × {reference.height} viewport.</p></section>}
          {mode==="diff"&&<section className="changes-stage" aria-label="Source changes">{changed?<Suspense fallback={<div className="diff-loading" role="status">Loading diff…</div>}><SourceDiff before={original} after={page}/></Suspense>:<><div className="changes-heading"><div><h2>Source diff</h2><p>Your source is unchanged.</p></div></div><div className="changes-empty"><CodeBracketIcon/><h3>Every change, in view</h3><p>Choose findings to fix, or describe an edit in chat. The exact source changes will appear here.</p></div></>}</section>}
        </div>
        <div className="canvas-footer"><div><span className="canvas-status-dot"/><p>{stale?"Updated · ready to recheck":reviewed?`${findings.length} findings in this review`:"Ready for a closer look"}</p></div><div><button type="button" className="button ghost" disabled={!undo.length||busy} onClick={()=>{const previous=undo[undo.length-1];if(previous){setPage(previous);setUndo(items=>items.slice(0,-1));setStale(reviewed);setSelected([]);setOverlay(null);setReady(false);setNotice("Previous version restored.");}}}><ArrowPathIcon/><span>Undo</span></button><button type="button" className="button ghost" disabled={busy} onClick={exportHtml}><ArrowDownTrayIcon/><span>HTML</span></button><button type="button" className="button ghost" disabled={!changed||busy} onClick={exportPatch}><ArrowDownTrayIcon/><span>Patch</span></button></div></div>
      </section>
      <aside className="review-panel" aria-label="Design review and chat"><div className="review-heading"><h2>Review</h2><p>{busy?<><span className="activity-dot"/>Working</>:stale?"Needs recheck":reviewed?`${findings.length} findings`:"Ready"}</p></div>
        <div className="review-scroll" ref={transcript} onScroll={event=>{const node=event.currentTarget;followTail.current=node.scrollHeight-node.scrollTop-node.clientHeight<100;}} tabIndex={0} aria-label="Review conversation">
          {messages.length===0&&<div className="review-intro"><div className="intro-symbol" aria-hidden="true"><span/><span/><span/></div><h2>A closer look<br/>at your design.</h2><p>Compare the design with the page. Then bring them closer, one fix at a time.</p><ol role="list"><li><p>01</p><div><h3>Start with a reference</h3><p>A design screenshot, at any size.</p></div></li><li><p>02</p><div><h3>Compare the implementation</h3><p>Use the sample or upload your HTML.</p></div></li><li><p>03</p><div><h3>Review, refine, repeat</h3><p>Choose the fixes. Keep the changes.</p></div></li></ol></div>}
          {messages.map(message=><Fragment key={message.id}><article className={`chat-message ${message.role}`}><p className="message-author">{message.role==="user"?"You":"Loupe"}</p><p className="message-content">{message.content===REVIEW_BRIEF?"Review this page against the reference.":message.content===FIX_BRIEF?"Fix the selected findings.":message.content}</p>{(message.state==="failed"||message.state==="stopped")&&<button type="button" className="button ghost retry-button" disabled={busy||!ready} onClick={()=>void start(message.content,message.id)}><ArrowPathIcon/>{message.state==="stopped"?"Continue this request":"Retry request"}</button>}</article>{message.id===findingsAfter&&findingsContent}</Fragment>)}
          {busy&&generation.message&&<article className="chat-message assistant streaming"><p className="message-author">Loupe</p><p className="message-content">{generation.message}</p></article>}

        </div>
        <div className="composer-area">{selected.length>0&&!stale&&<div className="selection-summary"><p>{selected.length} {selected.length===1?"finding":"findings"} selected</p><button type="button" className="text-button" disabled={busy} onClick={()=>setSelected([])}>Clear</button></div>}{busy&&<div className="progress-line" role="status"><span className="activity-dot"/><p title={preparing?preparingText:generation.progress}>{preparing?preparingText:generation.progress||"Reviewing the details…"}</p><time>{generation.elapsed}s</time></div>}{error&&<p className="inline-error" role="alert">{error}</p>}{notice&&!busy&&!error&&<p className="inline-notice" role="status">{notice}</p>}{notes.length>0&&<details className="import-notes"><summary>{notes.length} import {notes.length===1?"note":"notes"}</summary><ul>{notes.map((note,index)=><li key={index}>{note}</li>)}</ul></details>}<form className="composer" onSubmit={submit}><textarea name="review-message" aria-label="Message Loupe" placeholder={selected.length?"Add instructions for these fixes…":"Ask about a detail or describe a change…"} maxLength={1500} value={draft} onChange={event=>setDraft(event.target.value)} onKeyDown={event=>{if(event.key==="Enter"&&!event.shiftKey&&!event.nativeEvent.isComposing){event.preventDefault();if(!busy)event.currentTarget.form?.requestSubmit();}}}/><div className="composer-footer"><p>Enter to send</p><button type={busy?"button":"submit"} className="button primary send-button" disabled={disabled} onClick={busy?event=>{event.preventDefault();stop();}:undefined}>{busy?<StopIcon/>:!reviewed&&!draft.trim()?<SparklesIcon/>:<ArrowUpIcon/>}{primaryLabel}</button></div></form><div className="composer-caption"><p>Visual review · You choose what changes</p>{reviewed&&!stale&&<button type="button" className="text-button" disabled={busy||!ready} onClick={()=>void start(REVIEW_BRIEF)}>Recheck</button>}</div></div>
      </aside>
    </main>
    <input ref={referenceInput} type="file" name="reference-file" className="visually-hidden" accept="image/png,image/jpeg,image/webp" aria-label="Upload reference image" onChange={uploadReference}/>
    <dialog ref={helpDialog} className="dialog help-dialog" onClick={event=>{if(event.target===event.currentTarget)helpDialog.current?.close();}} aria-labelledby="help-title"><div className="dialog-heading"><h2 id="help-title">A closer look with Loupe</h2><button type="button" className="button icon" aria-label="Close help" onClick={()=>helpDialog.current?.close()}><XMarkIcon/></button></div><div className="dialog-body"><p>Loupe compares a reference screenshot with your actual HTML and CSS rendered at the same viewport.</p><ol><li><strong>Review the differences.</strong> The OpenAI Agents API sees both images and the page source, then returns specific visual findings.</li><li><strong>Choose what to change.</strong> Select findings or ask for an edit. Loupe applies exact source changes and keeps the conversation going.</li><li><strong>Check the result.</strong> Use the overlay, inspect the source diff, and recheck. Export your HTML or a patch when you’re ready.</li></ol><p>Uploads are rendered as static pages. Scripts and external loads are removed; include a saved page’s companion folder for local CSS, images, and fonts. A visual review is a helpful second pair of eyes, not a verified score.</p><p>Nothing is written to GitHub or Figma. Your page and images are sent to OpenAI only when you start a review or send a message.</p></div></dialog>
    <dialog ref={importDialog} className="dialog import-dialog" aria-labelledby="import-title" onCancel={event=>{if(importing)event.preventDefault();}} onClick={event=>{if(event.target===event.currentTarget&&!importing)importDialog.current?.close();}}><div className="dialog-heading"><h2 id="import-title">Import an implementation</h2><button type="button" className="button icon" disabled={importing} aria-label="Close import" onClick={()=>importDialog.current?.close()}><XMarkIcon/></button></div><div className="dialog-body"><p>Choose the HTML file. For a browser “Save Page As” export, include its companion folder to keep local styles and images.</p><label className="upload-field"><DocumentIcon/><div><h3>{importFile?.name||"Choose an HTML file"}</h3><p>HTML · up to 16 MB</p></div><input type="file" name="implementation-html" accept=".html,.htm,text/html" disabled={importing} onChange={event=>{setImportFile(event.target.files?.[0]||null);setImportError(null);}}/></label><label className="upload-field"><Square2StackIcon/><div><h3>{companion.length?`${companion.length} companion files selected`:"Add the companion folder"}</h3><p>Optional · local CSS, images, and fonts</p></div><input ref={folderInput} type="file" name="implementation-folder" multiple disabled={importing} onChange={event=>setCompanion(Array.from(event.target.files||[]))}/></label>{importError&&<p className="inline-error" role="alert">{importError}</p>}<div className="dialog-actions"><button type="button" className="button ghost" disabled={importing} onClick={()=>importDialog.current?.close()}>Cancel</button><button type="button" className="button primary" disabled={!importFile||importing} onClick={()=>void importImplementation()}>{importing?"Importing…":"Import page"}</button></div></div></dialog>
    <dialog ref={sourceDialog} className="dialog source-dialog" aria-labelledby="source-title"><div className="dialog-heading"><h2 id="source-title">Page source</h2><button type="button" className="button icon" aria-label="Close source" onClick={()=>sourceDialog.current?.close()}><XMarkIcon/></button></div><div className="source-controls"><label>Title<input name="page-title" value={sourceDraft.title} maxLength={120} onChange={event=>setSourceDraft({...sourceDraft,title:event.target.value})}/></label><label>Language<input name="page-language" value={sourceDraft.lang} maxLength={35} onChange={event=>setSourceDraft({...sourceDraft,lang:event.target.value})}/></label></div><div className="view-tabs source-tabs" role="group" aria-label="Source language">{(["html","css"] as const).map(field=><button type="button" key={field} aria-pressed={sourceTab===field} onClick={()=>setSourceTab(field)}>{field.toUpperCase()}</button>)}</div><textarea className="source-editor" name={`source-${sourceTab}`} aria-label={`${sourceTab.toUpperCase()} source`} spellCheck={false} value={sourceDraft[sourceTab]} onChange={event=>setSourceDraft({...sourceDraft,[sourceTab]:event.target.value})}/>{sourceError&&<p className="inline-error source-error" role="alert">{sourceError}</p>}<div className="dialog-actions"><button type="button" className="button ghost" onClick={()=>sourceDialog.current?.close()}>Cancel</button><button type="button" className="button primary" onClick={saveSource}>Save source</button></div></dialog>
  </div>;
}
