import { LoupeApp } from "./components/loupe-app";
export default function Home() { return <LoupeApp/>; }
