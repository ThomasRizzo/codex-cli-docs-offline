# Loupe

A visual design reviewer built with the OpenAI Agents API. Compare a reference screenshot with an HTML implementation, inspect concrete findings, and ask for focused source changes in chat.

## Run locally

Requires Node.js 22.13+ and Python 3.

```sh
npm ci
cp .env.example .env.local
```

Set `OPENAI_API_KEY` to your own project key with Agents API access. Set `LOUPE_SESSION_SECRET` to a random secret of at least 32 characters, and `CLEANUP_PROVIDER_SCOPE` to a stable label for that provider project (1–80 letters, digits, underscores or hyphens, starting with a letter or digit). Keep `.env.local` private and untracked. Initialize a fresh local D1 database before starting the development server:

```sh
npm run build
for migration in drizzle/*.sql; do
  node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file "$migration" || exit 1
done
npm run dev
```

Run database initialization once for a fresh database. For an existing database, apply only migrations that have not already run, in filename order.

Open the printed local URL. The included sample starts ready to compare. No AI request runs until you submit a review or message.

## The workflow

- Start with the studio sample or upload a reference image and an HTML page. Saved web pages may need their companion asset folder for styles, images, and fonts.
- Loupe renders a contained, scriptless preview and captures the current viewport. The reference and fresh implementation capture are supplied directly as visual inputs to the agent.
- Review returns specific visual differences, grouped by layout, typography, spacing, color, and details. These are model observations, not a numerical fidelity certification.
- Select findings or describe a change. The hosted agent prepares exact source replacements and runs a patch validator. The server independently verifies that the replacements match the submitted source before returning them.
- Applied changes update the preview. Run another review for a fresh visual assessment. Applied edits and visually reviewed results are separate states.
- Inspect the Diff tab with Pierre’s `@pierre/diffs` viewer in unified or split view. The original source is compared with the current page, including successive edits and Undo. Images and fonts stay as compact source references in this view; HTML and patch downloads embed the complete assets. Export the page or download a unified patch. Repository writes and pull-request creation are outside this demo.

## API implementation

The server uses the Agents API with `environment.type: openai_hosted`, `gpt-6-astra`, and `service_tier: fast`. Both images are sent as labeled `input_image` content. Page source, request metadata, image hashes, and the patch validator are provided as sandbox files. Public commentary and answer text stream immediately; private reasoning and raw command output are not displayed.

Each request carries bounded conversation context and the current source/render. Loupe has no accounts or saved review history. Sources, uploads, and conversation history stay in browser memory, except for the inputs supplied to the OpenAI API for the requested review. Refreshing closes the workspace and clears its browser state.

The server requests deletion of the temporary provider session on completion, failure, timeout, and browser disconnect. Stop and page exit also request cleanup. D1 stores creation intent and deletion jobs so failures can be retried by an owner-operated maintenance task after the browser or Worker exits. A lost browser connection cannot resume a review; the user can retry with the page still in their tab. Upstream stream interruptions can be reconciled while the browser remains connected. Provider processing and retention policies still apply; API deletion confirmation does not guarantee immediate physical deletion or deletion of provider logs.

Hosted routes require same-origin requests, bounded input, and a random per-tab UUID carried in `X-Loupe-Session`. This anonymous capability is kept only in React memory, never cookies or browser storage. Signed session handles bind each temporary review to that UUID, so another tab cannot read or cancel it. ChatGPT login is not required. Secrets stay on the server. The HTML preview strips active content and blocks remote loads; this demo supports contained static HTML/CSS rather than executing arbitrary web applications.

## IP rate limits

Starting an analysis or generation is limited to **6 requests per UTC minute and 20 per UTC day, per IP address**. Both windows are reserved atomically in the Sites D1 `DB` binding and persist across Worker instances. Visitors on the same network share this allowance. Changing the anonymous UUID does not reset this quota. Status and cleanup burst limits apply only after verifying a signed session handle.

The server trusts only the edge-provided `CF-Connecting-IP`, ignores caller-supplied forwarding headers, and stores a SHA-256 hash with usage counters rather than the raw IP address. Exhausted requests receive HTTP 429 with `Retry-After` and a reset time. If the trusted IP or D1 store is unavailable, new work fails closed with HTTP 503 before contacting OpenAI.

Status and Stop/session cleanup do not consume this IP generation allowance. They require same-origin requests, the original anonymous UUID, a correctly signed session handle, and an available cleanup ledger. During a D1 outage these operations fail closed; existing durable jobs remain pending for recovery.

The Run locally commands build the Worker configuration and apply every D1 migration before starting the development server.

The source download preserves the logical `DB` binding and its migrations, without a hosted project or database ID. Hosted deployment must provision D1 and apply all migrations before serving API requests. These per-IP limits are usage safeguards, not a project-wide monetary budget.

## Durable cleanup and owner operation

The cleanup ledger stores only random run IDs, provider session IDs, logical scope, a SHA-256 fingerprint of the actual server API key and effective API origin, timestamps, leases, retry categories, sanitized incident summaries and ticket receipts. It never stores review source, prompts, uploads, model output, browser nonce values, signing capabilities or the key itself.

- A creation intent commits before the single provider creation POST. Server-generated provider metadata carries the app name, random intent ID and logical scope. The known session ID and fallback deletion job commit before a browser handle or result is exposed.
- Completion, failure, timeout and disconnect make the job eligible immediately. The fallback deadline is 210 seconds after intent creation, allowing the 180-second review deadline and a short grace period. If recording the ID fails, output stops and an emergency deletion is attempted. A confirmed emergency deletion is recorded if D1 has recovered; otherwise the intent remains unresolved.
- Each deletion attempt has an eight-second network deadline. HTTP 409 requests cancellation and leaves deletion pending. Network errors, malformed success responses, 429, 5xx and authentication failures retain the job. Retries use persisted exponential backoff from roughly 15 seconds to 15 minutes, with jitter and bounded `Retry-After`. The ledger never discards a job because of its retry count.
- Atomic 60-second leases and fenced updates prevent concurrent workers from completing each other's jobs. A maintenance call has a 20-second network budget, at most 20 deletion attempts, and one reconciliation page of up to 10 sessions. `dueJobs` and `dueReconciliations` let the owner task repeat bounded calls when work remains.
- A definitive creation HTTP 400/401/403/404/422 rejection received before any session ID closes the intent without claiming a session was deleted. Other ambiguous creation outcomes remain pending. Reconciliation lists sessions in the current provider project, matches only metadata belonging to an existing same-scope intent, and persists pagination progress. It never retries creation. Empty scans do not prove absence. Failed or empty scans back off from one to 15 minutes; invalid cursors restart the scan.
- Only an exact documented deletion confirmation (`id`, `deleted: true`, `object: agent.session.deleted`) or HTTP 404 under the recorded key/origin/scope confirms cleanup. Confirmed records and proven rejected intents are eligible for bounded pruning after 24 hours. Unconfirmed jobs and unidentified intents do not expire.

Use a separate provider project/workload and key for each demo. Before changing the key, API origin or `CLEANUP_PROVIDER_SCOPE`, stop new work and drain until both `pending` and `unknown` are zero. Even a same-project key rotation changes the fingerprint and conservatively strands old records. Restore the original credential/origin/scope to drain those records; never relabel them or accept a new project's 404 as deletion proof.

Configure these server-only bindings on a Sites deployment:

| Binding | Purpose |
| --- | --- |
| `DB` | Existing D1 storage, with all checked-in migrations applied. |
| `OPENAI_API_KEY` | That demo's provider credential. |
| `LOUPE_SESSION_SECRET` | At least 32 random characters for anonymous browser handles. |
| `CLEANUP_PROVIDER_SCOPE` | Explicit stable provider-project label. Missing scope prevents generation. |
| `CLEANUP_OWNER_EMAIL` | The verified Sites account allowed to operate maintenance. |
| `CLEANUP_IDENTITY_PROVIDER` | Set to `sites` only behind Sites' verified identity ingress. Blank disables maintenance calls. |

The manifest enables the Sites MCP capability. `POST /mcp` implements protocol `2026-07-28`: `server/discover` and `tools/list` return static public metadata; every `tools/call` requires the configured identity-provider opt-in, a Sites-verified user ID, and an exact normalized match to the configured owner email. No maintenance tool accepts arbitrary provider session IDs, provider URLs, credentials or scopes. Ticket receipt URLs are validated as Linear issue links and are never fetched by the Site. Visitors remain anonymous and need no login.

**Do not set `CLEANUP_IDENTITY_PROVIDER=sites` on a raw Worker or other public server that accepts caller-supplied `oai-authenticated-user-*` headers.** A non-Sites deployment must supply its own verified maintenance identity integration and trusted scheduler before enabling equivalent operations. The downloadable example leaves this opt-in blank.

After deploying and verifying the owner can call the Site's tools, configure an owner-linked cloud task every 15 minutes with a connected Linear account and an explicit ticket team and owner:

1. Call `cleanup_run` and read `cleanup_status`. Repeat a bounded number of batches while cleanup work is due; leave future backoff queued. A failed maintenance, authentication or storage call must itself create or reuse a P0 outage ticket assigned to the configured owner, using a stable Site-specific marker in Linear.
2. Claim pending incidents with `cleanup_claim_alert`. The claim returns an incident ID, stable ticket marker and a fenced five-minute lease. Search Linear for that exact marker before creating a ticket. Create a `[P0]` issue with the highest priority in Linear (`1`, Urgent), assign the configured owner, and include only the sanitized incident summary, timestamps and recovery context. A synthetic incident must be marked `[DRILL]`.
3. Read the issue back and verify its marker, priority and assignee. Call `cleanup_ack_alert` with the exact incident ID, current lease token and verified receipt (`issue_id`, `identifier`, canonical Linear `url`, `assignee_email`, `priority: 1`). Notification success alone cannot acknowledge an incident. Read `cleanup_status` to confirm that the receipt persisted.
4. If looking up, creating or reading back a ticket fails, call `cleanup_retry_alert` with the incident ID, lease token and sanitized category. Respect provider retry delays. Pending incidents survive process restarts and recovery; a lost call or expired lease is retried on a later run. After an ambiguous create, search and recover the marker before attempting another create. Notify the owner of escalation failures, but leave the incident pending.

Unresolved jobs or unidentified intents older than 15 minutes, stranded scopes and provider-authentication failures open a durable incident. One active failure episode per Site retains its identity as counts change. Recovery is recorded separately and does not erase a pending ticket obligation. Ticket receipts and incident history are not pruned with confirmed session metadata. Ticketed failures continue cleanup retries; the task does not automatically close real tickets.

The server validates the authenticated owner's receipt and stores it durably; it relies on that trusted task to read Linear independently. Leases and stable-marker recovery reduce duplicate creation, but Linear search-before-create is not an atomic idempotency guarantee. A crash after issue creation can require reconciliation. The task must never silently acknowledge a failed or unverified ticket.

`cleanup_test_alert({test_id})` is an owner-only, idempotent failure drill. It inserts a synthetic incident through the same escalation outbox without creating a provider session, changing credentials or processing user content. Test the real ticket path with this tool, read back the assigned P0 and persisted receipt, then explicitly resolve the drill ticket. Provider deletion failure-to-incident behavior is also covered by real-D1 tests with mocked provider responses.

Source deployment does not itself create a schedule or connect Linear. Verify the actual unattended owner task after deployment. This app provides no Worker cron, independent missed-run monitor or scheduling/ticket-service SLA. If the task stops, durable records remain but cleanup and escalation wait for another invocation. A Site/D1 outage is escalated externally by the task, since unavailable storage cannot record its own incident. Project listing can be delayed or unable to identify an ambiguous creation; those intents remain visible rather than being discarded. No provider TTL is assumed. This session cleanup does not claim to remove unrelated provider resources or logs.

The lifecycle uses the documented Agents API [creation metadata](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/create), [project session listing and pagination](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/list), and [session deletion confirmation](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/delete).

## Validation and source download

```sh
npm run typecheck
npm test
npm run package:source
npm run build
```

The project ZIP excludes credentials, site identity, dependencies, runtime state, and private QA files. Publishing on Sites requires your own project identity and server-side secrets. The downloaded project connects directly to the public Agents API at `https://api.openai.com/v1/agents/sessions`. Its hosting environment must permit outbound requests to `api.openai.com`.
