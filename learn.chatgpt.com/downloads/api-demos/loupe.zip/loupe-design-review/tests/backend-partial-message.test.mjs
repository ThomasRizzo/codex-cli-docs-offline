import assert from 'node:assert/strict';
import test from 'node:test';
import { parsePartialMessage } from '../app/lib/partial-message.ts';

test('public message streams across quotes, Unicode escapes and unfinished text without source patches',()=>{
  const message='Added “Name” and a "label".\nReady to recheck 🪷';
  const wire=JSON.stringify({status:'complete',message,edits:[{field:'html',before:'PRIVATE SOURCE',after:'UPDATED SOURCE'}]}).replace('🪷','\\ud83e\\udeb7');
  let latest='';
  for(let i=0;i<=wire.length;i++) {
    const partial=parsePartialMessage(wire.slice(0,i));
    if(partial!==null) { assert.ok(message.startsWith(partial)); assert.ok(partial.startsWith(latest)); latest=partial; }
  }
  assert.equal(latest,message);
  assert.equal(parsePartialMessage('{"status":"answer","message":"A safe partial\\u12'),'A safe partial');
});

test('nested fields, invalid JSON prefixes, unknown status and overlong messages do not become public text',()=>{
  for(const value of [
    '{"edits":[{"message":"source"}]}',
    '{"status":"unexpected","message":"source"}',
    '{"status":"answer","message":{"text":"source"}}',
    '{"status":"answer","message":"bad\\q"}',
    '{"status":"answer","message":"bad\nnewline"}',
    JSON.stringify({status:'answer',message:'x'.repeat(1501),edits:[]}),
  ]) assert.equal(parsePartialMessage(value),null);
});

test('real provider ordering streams the root message after edits and before status without leaking nested source text',()=>{
  const edits=[{field:'html',before:'<p>{"message":"PRIVATE SOURCE"}</p>',after:'<p aria-label="readable">Keep this content</p>'}];
  const wire=JSON.stringify({edits,message:'Added an accessible label.',status:'complete'});
  const messageStart=wire.indexOf(',"message":"')+',"message":"'.length;
  assert.equal(parsePartialMessage(wire.slice(0,messageStart)),'');
  assert.equal(parsePartialMessage(wire.slice(0,messageStart+8)),'Added an');
  assert.equal(parsePartialMessage(wire),'Added an accessible label.');
  for(let i=0;i<messageStart;i++)assert.equal(parsePartialMessage(wire.slice(0,i)),null);
});

test('Loupe review messages stream even when the provider puts findings first',()=>{
  assert.equal(parsePartialMessage('{"status":"review","message":"Three differences'), 'Three differences');
  assert.equal(parsePartialMessage('{"edits":[],"findings":[{"title":"Not public yet"}],"message":"Compared the two images'), 'Compared the two images');
});
