import assert from "node:assert/strict";
import test from "node:test";
import { hasVisualVariation, validateCaptureViewport } from "../app/lib/capture.ts";

test("capture refuses dimensions that could silently crop or resize the supplied viewport", () => {
  assert.deepEqual(validateCaptureViewport({ width: 1280, height: 800 }), { width: 1280, height: 800 });
  for (const width of [0, -1, 10.5, Infinity, 2401]) assert.throws(() => validateCaptureViewport({ width, height: 800 }));
});
test("blank capture detection rejects white, black and transparent failures while retaining visible content", () => {
  for (const value of [0, 255, 50]) assert.equal(hasVisualVariation(new Uint8ClampedArray(400).fill(value)), false);
  const pixels = new Uint8ClampedArray(400).fill(255);
  for (let index = 200; index < 252; index += 4) { pixels[index] = 0; pixels[index + 1] = 0; pixels[index + 2] = 0; }
  assert.equal(hasVisualVariation(pixels), true);
});
