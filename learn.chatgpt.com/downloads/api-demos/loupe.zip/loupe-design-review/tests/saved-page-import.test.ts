// @ts-nocheck
import assert from 'node:assert/strict';
import test from 'node:test';
import postcss from 'postcss';
import { SavedPageResources, resolveSavedStyles } from '../app/lib/saved-page-import.ts';
import { MAX_CSS_CHARS } from '../app/lib/contracts.ts';

const PNG = Uint8Array.from(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg==', 'base64'));
const FONT = new Uint8Array([119, 79, 70, 50, 0, 1, 0, 0]);
function file(path, content, type = '') {
  const result = new File([content], path.split('/').at(-1), { type });
  Object.defineProperty(result, 'webkitRelativePath', { value: path });
  return result;
}
const html = file('Saved page.html', '<!doctype html><title>Saved page</title>');

test('saved styles retain source order and nested import conditions while resolving relative assets', async () => {
  const files = [
    file('Saved page_files/main.css', '@import "nested/base.css?version=2" layer(components) supports(display: grid) screen and (min-width: 600px); .main { color: red }'),
    file('Saved page_files/nested/base.css', '@font-face { font-family: Local; src: url("../font.woff2#font") format("woff2") } .nested { background: url("../photo%20one.png?size=2"); color: blue }'),
    file('Saved page_files/font.woff2', FONT), file('Saved page_files/photo one.png', PNG),
  ];
  const result = await resolveSavedStyles(html, files, [
    { kind: 'inline', css: '.before { color: black }' },
    { kind: 'linked', href: './Saved%20page_files/main.css', media: 'print, screen' },
    { kind: 'inline', css: '.after { color: green }' },
  ]);
  assert.deepEqual(result.missingStylesheets, []);
  assert.deepEqual(result.warnings, []);
  assert.equal(Object.keys(result.assets).length, 2);
  assert.match(result.css, /url\("loupe-asset:[a-f0-9]{64}"\)/);
  assert.ok(!result.css.includes('@import'));
  const tree = postcss.parse(result.css);
  const selectors = []; let conditions;
  tree.walkRules(rule => {
    selectors.push(rule.selector);
    if (rule.selector === '.nested') {
      conditions = [];
      for (let parent = rule.parent; parent?.type === 'atrule'; parent = parent.parent) conditions.push([parent.name, parent.params]);
    }
  });
  assert.deepEqual(selectors, ['.before', '.nested', '.main', '.after']);
  assert.deepEqual(conditions, [['layer', 'components'], ['supports', '(display: grid)'], ['media', 'screen and (min-width: 600px)'], ['media', 'print, screen']]);
});

test('missing nested sheets are reported without discarding resolved styles', async () => {
  const result = await resolveSavedStyles(html, [file('Saved page_files/main.css', '@import "missing/nested.css"; .present { color: red }')], [
    { kind: 'inline', css: '.before { color: black }' },
    { kind: 'linked', href: 'Saved page_files/main.css' },
    { kind: 'linked', href: 'Saved page_files/not-supplied.css' },
  ]);
  assert.deepEqual(result.missingStylesheets, ['missing/nested.css', 'Saved page_files/not-supplied.css']);
  assert.match(result.css, /\.before/); assert.match(result.css, /\.present/);
  assert.ok(!result.css.includes('@import'));
});

test('absolute saved references use unique suffixes and never guess ambiguous basenames', async () => {
  const result = await resolveSavedStyles(html, [
    file('Saved page_files/hashed/main.css', '.exact { color: red }'),
    file('one/shared.css', '.wrong-one {color: red}'), file('two/shared.css', '.wrong-two {color: green}'),
  ], [
    { kind: 'linked', href: 'https://original.example/assets/hashed/main.css?v=1' },
    { kind: 'linked', href: 'https://original.example/shared.css' },
    { kind: 'linked', href: 'https://original.example/missing.css' },
  ]);
  assert.match(result.css, /\.exact/); assert.ok(!result.css.includes('.wrong'));
  assert.deepEqual(result.missingStylesheets, ['https://original.example/shared.css', 'https://original.example/missing.css']);
  assert.match(result.warnings.join('\n'), /More than one supplied file/);
});

test('relative traversal resolves inside supplied files; escaping the virtual root does not fall back by name', async () => {
  const result = await resolveSavedStyles(html, [
    file('Saved page_files/deep/main.css', '@import "../base.css"; @import "../../../outside.css";'),
    file('Saved page_files/base.css', '.base{color:red}'), file('outside.css', '.outside{color:red}'),
  ], [{ kind: 'linked', href: 'Saved page_files/deep/main.css' }]);
  assert.match(result.css, /\.base/); assert.ok(!result.css.includes('.outside'));
  assert.deepEqual(result.missingStylesheets, ['../../../outside.css']);
});

test('cyclic imports terminate and repeated imports keep their separate conditions', async () => {
  const result = await resolveSavedStyles(html, [
    file('a.css', '@import "b.css"; .a{color:red}'), file('b.css', '@import "a.css"; .b{color:blue}'),
  ], [{ kind: 'inline', css: '@import "a.css" screen; @import "a.css" print;' }]);
  assert.equal((result.css.match(/\.a\{/g) || []).length, 2);
  assert.equal((result.css.match(/\.b\{/g) || []).length, 2);
  assert.match(result.css, /@media screen/); assert.match(result.css, /@media print/);
  assert.match(result.warnings.join('\n'), /Circular/);
  assert.deepEqual(result.missingStylesheets, []);
});

test('embedded fonts and images become deduplicated opaque refs before the CSS size limit', async () => {
  const largeFont = new Uint8Array(352_000); largeFont.set(FONT);
  const fontData = `data:font/woff2;base64,${Buffer.from(largeFont).toString('base64')}`;
  const pngData = `data:image/png;base64,${Buffer.from(PNG).toString('base64')}`;
  const source = `@font-face{font-family:Local;src:url("${fontData}")} .image{background:image-set("${pngData}" 1x,url("${pngData}") 2x)}`;
  assert.ok(source.length > MAX_CSS_CHARS);
  const result = await resolveSavedStyles(html, [], [{ kind: 'inline', css: source }]);
  assert.equal(Object.keys(result.assets).length, 2);
  assert.ok(result.css.length < 600);
  assert.ok(!result.css.includes('data:'));
  assert.equal((result.css.match(/loupe-asset:/g) || []).length, 3);
  assert.deepEqual(result.warnings, []);
});

test('unsupported, unreadable, oversized and missing resources are omitted with bounded warnings', async () => {
  const oversized = file('huge.png', new Uint8Array(2_000_001), 'image/png');
  oversized.arrayBuffer = async () => { throw Error('Oversized file must not be read'); };
  const result = await resolveSavedStyles(html, [file('icon.svg', '<svg></svg>', 'image/svg+xml'), file('invalid.png', 'not a PNG'), oversized], [{
    kind: 'inline', css: '.a{background:url(icon.svg),url(invalid.png),url(huge.png),url(https://remote.example/photo.png)}',
  }]);
  assert.equal(Object.keys(result.assets).length, 0);
  assert.equal((result.css.match(/url\(""\)/g) || []).length, 4);
  assert.equal(result.warnings.length, 4);
  assert.ok(result.warnings.every(message => message.length <= 300));
  assert.match(result.warnings.join('\n'), /Unsupported/);
  assert.match(result.warnings.join('\n'), /2 MB/);
  assert.deepEqual(result.missingStylesheets, []);
});

test('CSS escaping, literal content and image-set strings do not bypass resource resolution', async () => {
  const result = await resolveSavedStyles(html, [file('photo one.png', PNG)], [{
    kind: 'inline', css: '.a{background:uRl(photo\\20 one.png);border-image:image-set("photo one.png" 1x);content:"url(https://literal.example/) </style><script>example</script>"}',
  }]);
  assert.equal(Object.keys(result.assets).length, 1);
  assert.equal((result.css.match(/loupe-asset:/g) || []).length, 2);
  // PostCSS escapes the raw-text closing tag while retaining its CSS string value.
  assert.match(result.css.replace(/\\3c /g, '<'), /content:"url\(https:\/\/literal.example\/\) <\/style><script>example<\/script>"/);
});

test('depth, output and supplied-file bounds fail predictably without external fetches', async () => {
  const files = Array.from({ length: 14 }, (_, index) => file(`${index}.css`, index < 13 ? `@import "${index + 1}.css"; .level${index}{color:red}` : '.last{color:red}'));
  const result = await resolveSavedStyles(html, files, [{ kind: 'linked', href: '0.css' }]);
  assert.deepEqual(result.missingStylesheets, ['12.css']);
  assert.match(result.warnings.join('\n'), /12-level/);
  assert.ok(!result.css.includes('.last'));
  await assert.rejects(resolveSavedStyles(html, [], [{ kind: 'inline', css: `.a{--text:"${'x'.repeat(MAX_CSS_CHARS)}"}` }]), /300,000/);
  assert.throws(() => new SavedPageResources(html, Array(2_001).fill(file('a.css', ''))), /2,000/);
  const previous = globalThis.fetch; let requests = 0;
  globalThis.fetch = async () => { requests++; throw Error('Unexpected fetch'); };
  try {
    const missing = await resolveSavedStyles(html, [], [{ kind: 'linked', href: 'https://remote.example/main.css' }, { kind: 'inline', css: '.a{background:url(https://remote.example/a.png)}' }]);
    assert.equal(missing.missingStylesheets.length, 1); assert.equal(requests, 0);
  } finally { globalThis.fetch = previous; }
});

test('media attributes cannot insert extra unprocessed CSS rules', async () => {
  const result = await resolveSavedStyles(html, [], [{ kind: 'inline', css: '.a{color:red}', media: 'screen {} @import "https://remote.example/style.css"; @media all' }]);
  assert.equal(result.css, ''); assert.match(result.warnings.join('\n'), /invalid media/);
});

test('embedded CSS imports remain local and retain conditions without inventing a base URL', async () => {
  const inline = `.embedded{color:purple;background:url("data:image/png;base64,${Buffer.from(PNG).toString('base64')}")} .relative{background:url(photo.png)}`;
  const reference = `data:text/css,${encodeURIComponent(inline)}`;
  const result = await resolveSavedStyles(html, [file('photo.png', PNG)], [{ kind: 'inline', css: `@import "${reference}" layer(local) screen;` }]);
  assert.match(result.css, /@media screen/); assert.match(result.css, /@layer local/);
  assert.match(result.css, /\.embedded/);
  assert.equal(Object.keys(result.assets).length, 1);
  assert.match(result.css, /\.relative\{background:url\(""\)}/);
  assert.match(result.warnings.join('\n'), /Image or font not supplied: photo.png/);
  assert.deepEqual(result.missingStylesheets, []);
});

test('an exhausted asset budget does not read more companion files', async () => {
  const files = Array.from({ length: 101 }, (_, index) => {
    const bytes = new Uint8Array(PNG); bytes[bytes.length - 1] = index;
    return file(`${index}.png`, bytes);
  });
  let extraReads = 0;
  files[100].arrayBuffer = async () => { extraReads++; throw Error('Do not read beyond the asset budget'); };
  const resources = new SavedPageResources(html, files);
  for (let index = 0; index < 100; index++) assert.match(await resources.asset(`${index}.png`), /^loupe-asset:/);
  assert.equal(await resources.asset('100.png'), null);
  assert.equal(extraReads, 0);
  assert.match(resources.warnings.join('\n'), /100 assets/);
  assert.match(await resources.asset('0.png'), /^loupe-asset:/, 'already cached resources remain available');
});
