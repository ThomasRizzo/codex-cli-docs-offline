import assert from 'node:assert/strict';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import { Log, LogLevel, Miniflare } from 'miniflare';
import { request as payload } from './backend-fixtures.mjs';

const root = fileURLToPath(new URL('../',import.meta.url));
test('native Worker parses framework Request proxies and binds actual image/source inputs', {timeout:30000}, async t => {
  const bundled = await build({absWorkingDir:root,stdin:{resolveDir:root,sourcefile:'fixture.ts',loader:'ts',contents:`
    import {guardRequest,parseBody,errorResponse} from './app/lib/server.ts';
    import {createRequestSchema} from './app/lib/contracts.ts';
    import {validateGenerationRequest,reviewBinding} from './app/lib/generation-result.ts';
    export default {async fetch(request:Request){
      const proxy=new Proxy(request,{get(target,key){const value=Reflect.get(target,key,target);return typeof value==='function'?value.bind(target):value;}});
      try {
        if(new URL(request.url).pathname==='/constructor') {try {new Request(proxy);return Response.json({threw:false});} catch(error){return Response.json({threw:true,name:error.name});}}
        guardRequest(proxy);
        const data=validateGenerationRequest(await parseBody(proxy,createRequestSchema,4096));
        return Response.json(await reviewBinding(data));
      }catch(error){return errorResponse(error);}
    }};`},bundle:true,format:'esm',platform:'neutral',target:'es2022',conditions:['workerd','worker','browser'],external:['cloudflare:workers'],define:{'process.env.NODE_ENV':'"production"'},write:false,logLevel:'silent'});
  let outbound=0;
  const worker=new Miniflare({modules:true,script:bundled.outputFiles[0].text,compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],host:'127.0.0.1',port:0,cf:false,log:new Log(LogLevel.ERROR),outboundService:async()=>{outbound++;return new Response(null,{status:503});}});
  t.after(()=>worker.dispose()); await worker.ready;
  const probe=await worker.dispatchFetch('https://loupe.test/constructor',{method:'POST',body:'{}'});
  assert.deepEqual(await probe.json(),{threw:true,name:'TypeError'});
  const headers={origin:'https://loupe.test','content-type':'application/json','X-Loupe-Session':crypto.randomUUID()};
  const result=await worker.dispatchFetch('https://loupe.test/parse',{method:'POST',headers,body:JSON.stringify(payload)});
  assert.equal(result.status,200,await result.clone().text());
  const bound=await result.json(); assert.match(bound.requestHash,/^[a-f0-9]{64}$/);assert.match(bound.sourceHash,/^[a-f0-9]{64}$/);
  for(const entry of [
    {headers:{origin:headers.origin,'content-type':'application/json'},body:payload,status:400},
    {headers:{...headers,origin:'https://elsewhere.test'},body:payload,status:403},
    {headers,body:{...payload,selectedFindingKeys:['missing']},status:400},
    {headers,body:{...payload,brief:'x'.repeat(5000)},status:413},
  ]){
    const response=await worker.dispatchFetch('https://loupe.test/parse',{method:'POST',headers:entry.headers,body:JSON.stringify(entry.body)});
    assert.equal(response.status,entry.status);
  }
  assert.equal(outbound,0);
});
