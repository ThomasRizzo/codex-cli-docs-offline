import assert from "node:assert/strict";
import test from "node:test";
import { readSSE } from "../app/lib/sse.ts";

const bytes = new TextEncoder();
const collect = async (iterator) => { const result = []; for await (const item of iterator) result.push(item); return result; };
function stream(text, size = 7) {
  const data = bytes.encode(text);
  return new ReadableStream({ start(controller) { for (let i = 0; i < data.length; i += size) controller.enqueue(data.slice(i, i + size)); controller.close(); } });
}

test("SSE decoding preserves split UTF-8, CRLF boundaries, multiline data, and empty data", async () => {
  const input = ": heartbeat\r\nevent: update\r\nid: ignored\r\ndata: José 👋\r\ndata: second line\r\n\r\ndata:\n\nevent: final\rdata: done\r\r";
  assert.deepEqual(await collect(readSSE(stream(input, 1))), [
    { event: "update", data: "José 👋\nsecond line" },
    { event: "message", data: "" },
    { event: "final", data: "done" },
  ]);
});

test("an unterminated frame is discarded, not presented as a final event", async () => {
  assert.deepEqual(await collect(readSSE(stream("data: saved\n\ndata: truncated\n"))), [{ event: "message", data: "saved" }]);
});

test("SSE enforces whole-stream and individual-event limits", async () => {
  await assert.rejects(() => collect(readSSE(stream("data: long payload\n\n"), { maxBytes: 10 })), /size limit/);
  await assert.rejects(() => collect(readSSE(stream("data: long payload\n\n"), { maxEventBytes: 10 })), /size limit/);
  await assert.rejects(() => collect(readSSE(stream("x".repeat(30)), { maxEventBytes: 10 })), /size limit/);
});

test("abort interrupts a pending read and early consumer return releases the stream", async () => {
  let cancelled = false;
  const controller = new AbortController();
  const pending = collect(readSSE(new ReadableStream({ cancel() { cancelled = true; } }), { signal: controller.signal }));
  controller.abort();
  await assert.rejects(() => pending, (error) => error.name === "AbortError");
  assert.equal(cancelled, true);
  cancelled = false;
  const source = new ReadableStream({
    start(controller) { controller.enqueue(bytes.encode("data: first\n\n")); },
    cancel() { cancelled = true; },
  });
  for await (const item of readSSE(source)) { assert.equal(item.data, "first"); break; }
  assert.equal(cancelled, true);
  assert.equal(source.locked, false);
});
