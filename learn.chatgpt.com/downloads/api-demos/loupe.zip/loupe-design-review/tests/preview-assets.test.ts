// @ts-nocheck
import test from "node:test";
import assert from "node:assert/strict";
import { assetReferenceRestorer, createPreviewAsset, isPreviewAssetReference, materializeAssetReferences, validatePreviewAssets, MAX_PREVIEW_ASSET_BYTES } from "../app/lib/preview-assets.ts";

const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=", "base64");

test("asset creation uses stable opaque SHA-256 references, separate from source", async () => {
  const image = await createPreviewAsset(png, "image/png");
  assert.match(image.id, /^[a-f0-9]{64}$/);
  assert.equal(image.reference, `loupe-asset:${image.id}`);
  assert.equal((await createPreviewAsset(png, "image/png")).id, image.id);
  const assets = validatePreviewAssets({ [image.id]: image.dataUrl });
  const source = `<img src="${image.reference}">`;
  assert.equal(materializeAssetReferences(source, assets), `<img src="${image.dataUrl}">`);
  assert.equal(assetReferenceRestorer(assets)(`<img src="${image.dataUrl}">`), source);
  assert.ok(!source.includes("base64"));
});

test("only raster/font data of the declared format can enter the asset map", async () => {
  const id = "a".repeat(64);
  for (const value of ["https://example.test/image.png", "data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=", "data:image/png;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==", "data:font/woff2;base64,AAAAAA=="]) {
    assert.throws(() => validatePreviewAssets({ [id]: value }));
  }
  assert.throws(() => validatePreviewAssets({ bad: `data:image/png;base64,${png.toString("base64")}` }));
  assert.throws(() => validatePreviewAssets(null));
  await assert.rejects(createPreviewAsset(png, "image/svg+xml"));
  assert.equal(isPreviewAssetReference(`loupe-asset:${id}`), true);
  assert.equal(isPreviewAssetReference(`loupe-asset:${id}more`), false);
  assert.throws(() => materializeAssetReferences(`url(loupe-asset:${id})`, {}), /missing/);
  assert.throws(() => materializeAssetReferences("url(loupe-asset:invalid)", {}), /invalid/);
});

test("asset count and decoded byte budgets apply before rendering", async () => {
  const bytes = Buffer.alloc(MAX_PREVIEW_ASSET_BYTES);
  png.copy(bytes);
  const large = await createPreviewAsset(bytes, "image/png");
  assert.deepEqual(validatePreviewAssets({ [large.id]: large.dataUrl }), { [large.id]: large.dataUrl });
  await assert.rejects(createPreviewAsset(Buffer.alloc(MAX_PREVIEW_ASSET_BYTES + 1), "image/png"), /2 MB/);
  const entry = index => [index.toString(16).padStart(64, "0"), large.dataUrl];
  assert.throws(() => validatePreviewAssets(Object.fromEntries(Array.from({ length: 5 }, (_, i) => entry(i)))), /8 MB/);
  assert.throws(() => validatePreviewAssets(Object.fromEntries(Array.from({ length: 101 }, (_, i) => entry(i)))), /100/);
  assert.throws(() => materializeAssetReferences(Array(8).fill(large.reference).join(" "), { [large.id]: large.dataUrl }), /repeats too much/);
});

test("evidence redaction does not forward unknown embedded image bytes", () => {
  assert.equal(assetReferenceRestorer({})(`<img src="data:image/png;base64,${png.toString("base64")}">`), '<img src="[embedded resource]">');
});
