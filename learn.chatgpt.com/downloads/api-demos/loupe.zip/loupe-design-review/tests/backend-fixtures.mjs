import { createHash } from 'node:crypto';
import { canonicalJSON, reviewBinding } from '../app/lib/generation-result.ts';
import { applyEdits } from '../app/lib/contracts.ts';
export const document = { title:'A studio for everyone', lang:'', html:'<main><h1>Résumé ✨</h1><p>Keep every sentence.</p><button>Book a place</button><img src="room.jpg"></main>', css:'.caption{color:#aaa;background:#fff}' };
export const finding = {key:'caption-color',title:'Caption is too pale',description:'The reference uses dark gray captions; the current caption is light gray.',recommendation:'Change the caption color to a darker gray.',category:'color',severity:'minor',selector:'.caption'};
export const screenshot = {dataUrl:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/iZk9HQAAAABJRU5ErkJggg==',width:1,height:1};
export const request = {brief:'Fix the selected color difference.',document,reference:{name:'Reference.png',...screenshot},screenshot,findings:[finding],selectedFindingKeys:[finding.key],history:[]};
export const input = {request,instructions:'Review the page carefully.',resultSchema:{type:'object'}};
export const complete = {status:'complete',message:'Darkened the caption to match the reference. Review the updated page when ready.',findings:[],edits:[{field:'css',before:'color:#aaa',after:'color:#555'}]};
export const clarification = {status:'clarification',message:'What would you like to improve about this page?',findings:[],edits:[]};
const hash=value=>createHash('sha256').update(canonicalJSON(value)).digest('hex');
export const binding = await reviewBinding(request);
export const command = {id:'command-1',command:'python3 /workspace/apply_edits.py',status:'completed',exitCode:0,output:JSON.stringify({loupe_validation:{request_sha256:binding.requestHash,source_sha256:binding.sourceHash,edits_sha256:hash(complete.edits),result_sha256:hash(applyEdits(document,complete.edits)),edits:complete.edits.length}})};

export const alternateScreenshot = {...screenshot,dataUrl:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGNgYPj/HwADAgH/5ncLrgAAAABJRU5ErkJggg=="};
