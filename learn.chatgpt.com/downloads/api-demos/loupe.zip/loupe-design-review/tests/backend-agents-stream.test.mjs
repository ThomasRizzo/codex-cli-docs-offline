import { MAX_RESULT_BYTES } from "../app/lib/contracts.ts";
import assert from "node:assert/strict";
import test from "node:test";
import { AgentsError, streamGenerationSession } from "../app/lib/agents.ts";

import { input } from "./backend-fixtures.mjs";
const root = { id: "turn_1", session_id: "sess_1", subagent_id: null, status: "in_progress" };
const event = (type, extra = {}) => ({ type, session_id: "sess_1", turn_id: "turn_1", ...extra });
const created = { type: "agent.session.created", session: { id: "sess_1" } };
const started = event("agent.session.turn.in_progress", { turn: root });
const ended = (status = "completed") => event(`agent.session.turn.${status}`, { turn: { ...root, status } });
const message = (id, phase, text = "") => ({ id, turn_id: "turn_1", type: "message", role: "assistant", phase, status: "in_progress", content: [{ type: "output_text", text }] });
const item = (value, done = false) => event(`agent.session.turn.item.${done ? "done" : "added"}`, { item: value, output_index: 0 });
const delta = (id, text, extra = {}) => event("agent.session.turn.output_text.delta", { item_id: id, content_index: 0, output_index: 0, delta: text, ...extra });
const done = (id, text, extra = {}) => event("agent.session.turn.output_text.done", { item_id: id, content_index: 0, output_index: 0, text, ...extra });
function response(events) {
  const encoded = new TextEncoder().encode(events.map((data, index) => `event: ${data.type}\r\ndata: ${JSON.stringify({ event_id: `evt_${index}`, ...data })}\r\n\r\n`).join(""));
  return new Response(new ReadableStream({ start(controller) { for (let i = 0; i < encoded.length; i += 31) controller.enqueue(encoded.slice(i, i + 31)); controller.close(); } }), { headers: { "Content-Type": "text/event-stream" } });
}
const collect = async (events, transport) => { const output = []; for await (const value of streamGenerationSession(transport ?? (async () => response(events)), input)) output.push(value); return output; };

test("stream creation uses low effort and publishes genuine public deltas before completion", async () => {
  let sent;
  const events = [
    created, started,
    item(message("comment_1", "commentary")), delta("comment_1", "I'll check José's totals."), done("comment_1", "I'll check José's totals."),
    item({ id: "cmd_1", turn_id: "turn_1", type: "command_execution", command: "private command", output: "private output", status: "in_progress" }),
    item(message("result_1", "final_answer")), delta("result_1", '{"total":'), delta("result_1", "60}"), done("result_1", '{"total":60}'), ended(),
  ];
  const output = await collect(events, async (path, init) => { sent = { path, init }; return response(events); });
  assert.equal(sent.path, "/v1/agents/sessions");
  assert.equal(sent.init.headers.Accept, "text/event-stream");
  assert.equal(sent.init.headers["OpenAI-Beta"], "agents=v1");
  const body = JSON.parse(sent.init.body);
  assert.equal(body.stream, true);
  assert.equal(body.agent.service_tier, "fast");
  assert.deepEqual(body.agent.reasoning, { effort: "low" });
  assert.equal(JSON.parse(Buffer.from(body.environment.files[0].data, "base64").toString("utf8")).brief, input.request.brief);
  assert.deepEqual(output[0], { type: "session", id: "sess_1" });
  assert.deepEqual(output.filter((value) => value.type === "text").map((value) => value.delta), ["I'll check José's totals.", '{"total":', "60}"]);
  assert.deepEqual(output.at(-1), { type: "finished", status: "completed", sessionId: "sess_1", turnId: "turn_1" });
  assert.ok(!JSON.stringify(output).includes("private"));
});

test("text is delivered while the upstream turn is still open, and observer close does not cancel agent work", { timeout: 1000 }, async () => {
  let cancelled = false;
  const calls = [];
  const unfinished = new ReadableStream({
    start(controller) {
      for (const data of [created, started, item(message("comment_1", "commentary")), delta("comment_1", "Checking your data now.")]) {
        controller.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(data)}\n\n`));
      }
      // Deliberately withhold the terminal event and leave the stream open.
    },
    cancel() { cancelled = true; },
  });
  let received = false;
  for await (const value of streamGenerationSession(async (path) => {
    calls.push(path);
    return new Response(unfinished, { headers: { "Content-Type": "text/event-stream" } });
  }, input)) {
    if (value.type === "text") { received = true; assert.equal(value.delta, "Checking your data now."); break; }
  }
  assert.equal(received, true);
  assert.equal(cancelled, true);
  assert.deepEqual(calls, ["/v1/agents/sessions"], "only caller-owned cleanup should submit cancellation");
});

test("reasoning, stdout, user messages, unknown phases, and subagent output never leave the filter", async () => {
  const output = await collect([
    created, started,
    item({ ...message("user_1", "commentary", "SECRET user"), role: "user" }),
    item(message("unknown_1", null, "SECRET unclassified")), delta("unknown_1", "SECRET delta"),
    item({ id: "reasoning_1", turn_id: "turn_1", type: "reasoning", summary: "SECRET reasoning" }),
    event("agent.session.turn.reasoning_summary_text.delta", { delta: "SECRET reasoning delta" }),
    event("agent.output.command_execution_output.delta", { delta: "SECRET stdout" }),
    event("agent.session.turn.in_progress", { turn_id: "subturn_1", turn: { ...root, id: "subturn_1", subagent_id: "subagent_1" } }),
    event("agent.session.turn.item.added", { turn_id: "subturn_1", item: { ...message("submsg_1", "final_answer", "SECRET delegated"), turn_id: "subturn_1" } }),
    event("agent.session.turn.completed", { turn_id: "subturn_1", turn: { ...root, id: "subturn_1", subagent_id: "subagent_1", status: "completed" } }),
    item(message("result_1", "final_answer", '{"public":true}'), true), ended(),
  ]);
  assert.ok(!JSON.stringify(output).includes("SECRET"));
  assert.equal(output.filter((value) => value.type === "finished").length, 1);
  assert.deepEqual(output.find((value) => value.type === "text_done"), { type: "text_done", phase: "final_answer", itemId: "result_1", text: '{"public":true}' });
});

test("authoritative text replacements handle missing deltas, multiple content parts, and duplicated events", async () => {
  const first = delta("result_1", "old", { event_id: "repeat" });
  const output = await collect([
    created, started, item(message("result_1", "final_answer")), first, first,
    done("result_1", "second", { content_index: 1 }), done("result_1", "first "), ended(),
  ]);
  assert.equal(output.filter((value) => value.type === "text" && value.delta === "old").length, 1);
  assert.deepEqual(output.filter((value) => value.type === "text_done").map((value) => value.text), ["oldsecond", "first second"]);
});

test("root outcomes stay distinct and upstream errors are sanitized", async () => {
  for (const status of ["failed", "cancelled"]) {
    const output = await collect([created, started, ended(status)]);
    assert.equal(output.at(-1).status, status);
  }
  for (const type of ["agent.session.failed", "agent.session.environment.failed", "error", "agent.session.requires_action"]) {
    const output = await collect([created, started, event(type, { error: { message: "SECRET credentials" } })]);
    assert.equal(output.at(-1).status, type === "agent.session.requires_action" ? "waiting" : "failed");
    assert.ok(!JSON.stringify(output).includes("SECRET"));
  }
  await assert.rejects(() => collect([], async () => new Response("SECRET credentials", { status: 403 })), (error) => error.status === 403 && !error.message.includes("SECRET"));
});

test("idle and premature EOF never imply completion or resubmit the task", async () => {
  const seen = []; let calls = 0;
  await assert.rejects(async () => {
    for await (const value of streamGenerationSession(async () => { calls++; return response([created, started, { type: "agent.session.idle", session: { id: "sess_1" } }]); }, input)) seen.push(value);
  }, /before the task finished/);
  assert.equal(calls, 1);
  assert.equal(seen[0].id, "sess_1");
  assert.equal(seen.some((value) => value.type === "finished"), false);
});

test("streamed output is bounded and rejects cross-session or second-root state", async () => {
  await assert.rejects(() => collect([created, started, item(message("result_1", "final_answer")), delta("result_1", "x".repeat(MAX_RESULT_BYTES + 1))]), /too large/);
  await assert.rejects(() => collect([created, started, event("agent.session.turn.in_progress", { turn_id: "turn_2", turn: { ...root, id: "turn_2" } })]), /unexpected task/);
  await assert.rejects(() => collect([created, started, event("agent.session.idle", { session_id: "sess_other" })]), /changed sessions/);
  await assert.rejects(() => collect([], async () => Response.json({ secret: "SECRET" })), AgentsError);
});
