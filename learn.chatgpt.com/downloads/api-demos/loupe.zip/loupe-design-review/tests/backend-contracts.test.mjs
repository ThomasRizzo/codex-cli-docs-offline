import assert from 'node:assert/strict';
import test from 'node:test';
import { makeAgentInput, reviewBinding, validateGenerationRequest, generationResult } from '../app/lib/generation-result.ts';
import { resultSchema, applyEdits, MAX_IMAGE_BYTES } from '../app/lib/contracts.ts';
import { request, document, screenshot, alternateScreenshot, finding, binding, complete, command } from './backend-fixtures.mjs';

test('vision inputs have distinct labels; manifest and request token inputs omit image bytes',async()=>{
  const payload=await makeAgentInput(request);
  const manifest=JSON.parse(Buffer.from(payload.files[0].data,'base64').toString());
  assert.equal(manifest.reference.dataUrl,undefined);assert.equal(manifest.screenshot.dataUrl,undefined);
  assert.match(manifest.reference.sha256,/^[a-f0-9]{64}$/);
  assert.equal(payload.input[0].content.filter(item=>item.type==='input_image').length,2);
  assert.equal(payload.input[0].content.filter(item=>item.type==='input_text').some(item=>item.text.includes('data:image/')),false);
  const changed=await reviewBinding({...request,screenshot:alternateScreenshot});
  assert.notEqual(changed.requestHash,binding.requestHash);assert.equal(changed.sourceHash,binding.sourceHash);
  assert.notEqual((await reviewBinding({...request,reference:{...request.reference,...alternateScreenshot}})).requestHash,binding.requestHash);
});
test('invalid image containers, dimensions, formats and size cannot reach the agent',()=>{
  assert.deepEqual(validateGenerationRequest(request),request);
  const bytes=Buffer.from(screenshot.dataUrl.split(',')[1],'base64');
  const corrupt=Buffer.from(bytes);corrupt[45]^=1;
  for(const image of [
    {...screenshot,width:2}, {...screenshot,height:2401},
    {...screenshot,dataUrl:'data:image/svg+xml;base64,PHN2Zz4='},
    {...screenshot,dataUrl:'data:image/png;base64,'+Buffer.from('not an image').toString('base64')},
    {...screenshot,dataUrl:'data:image/png;base64,'+bytes.subarray(0,-1).toString('base64')},
    {...screenshot,dataUrl:'data:image/png;base64,'+corrupt.toString('base64')},
    {...screenshot,dataUrl:'data:image/png;base64,'+Buffer.alloc(MAX_IMAGE_BYTES+1).toString('base64')},
    {...screenshot,dataUrl:'data:image/jpeg;base64,'+bytes.toString('base64')},
  ])assert.throws(()=>validateGenerationRequest({...request,screenshot:image}));
});
test('review and conversational outcomes cannot smuggle source edits or duplicate findings',async()=>{
  const result={status:'review',message:'The caption is lighter than the reference.',findings:[finding],edits:[]};
  assert.equal((await generationResult({result,commands:[]},document,binding)).result.status,'review');
  assert.equal(resultSchema.safeParse({...result,edits:complete.edits}).success,false);
  assert.equal(resultSchema.safeParse({...result,findings:[finding,finding]}).success,false);
  assert.equal(resultSchema.safeParse({...result,status:'answer'}).success,false);
  assert.equal(await generationResult({result:{...complete,findings:[finding]},commands:[command]},document,binding),null);
});
test('patch application rejects ambiguous source, stale edits, and unchanged fields',()=>{
  assert.throws(()=>applyEdits({...document,css:'.a{color:red}.b{color:red}'},[{field:'css',before:'color:red',after:'color:blue'}]));
  assert.throws(()=>applyEdits(document,[{field:'html',before:'missing',after:'new'}]));
  assert.throws(()=>applyEdits(document,[{field:'title',before:document.title,after:document.title}]));
});
