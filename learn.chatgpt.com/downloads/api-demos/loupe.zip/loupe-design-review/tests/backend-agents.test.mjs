import { MAX_RESULT_BYTES } from "../app/lib/contracts.ts";
import { input } from "./backend-fixtures.mjs";
import assert from "node:assert/strict";
import test from "node:test";
import {
  AgentsError,
  cancelGenerationSession,
  createGenerationSession,
  deleteGenerationSession,
  pollGenerationSession,
} from "../app/lib/agents.ts";

const page = (data) => Response.json({ data, has_more: false, last_id: data.at(-1)?.id ?? null });
const turn = { id: "turn_1", session_id: "sess_1", subagent_id: null, status: "completed" };
const message = {
  id: "msg_1", turn_id: "turn_1", type: "message", role: "assistant", phase: "final_answer", status: "completed",
  content: [{ type: "output_text", text: '{"total":60}' }],
};

function fixture({ status = "idle", turns = [turn], items = [message] } = {}) {
  return async (path) => {
    if (path.includes("/turns?")) return page(turns);
    if (path.includes("/items?")) return page(items);
    return Response.json({ id: "sess_1", status });
  };
}

test("hosted creation supplies current source, measured findings and an offline validator", async () => {
  const calls = [];
  const result = await createGenerationSession(async (path, init) => {
    calls.push({ path, init });
    return Response.json({ id: "sess_1" }, { status: 201 });
  }, input);
  assert.equal(result.id, "sess_1");
  assert.equal(calls.length, 1);
  assert.equal(calls[0].path, "/v1/agents/sessions");
  assert.equal(calls[0].init.headers["OpenAI-Beta"], "agents=v1");
  assert.equal(calls[0].init.headers.Authorization, undefined, "the injected transport owns credentials");
  const sent = JSON.parse(calls[0].init.body);
  assert.equal(sent.agent.model, "gpt-6-astra");
  assert.equal(sent.agent.service_tier, "fast");
  assert.deepEqual(sent.agent.reasoning, { effort: "low" });
  assert.deepEqual(sent.agent.text.format, { type: "json_schema", schema: { type: "object" } });
  assert.equal(sent.environment.type, "openai_hosted");
  assert.deepEqual(sent.environment.network, { access: "disabled" });
  assert.equal(sent.environment.files[0].path, "/workspace/manifest.json");
  assert.equal(JSON.parse(Buffer.from(sent.environment.files[0].data, "base64").toString("utf8")).reference.sha256.length,64);
  assert.equal(JSON.parse(sent.input[0].content[0].text).document.html,input.request.document.html);
  assert.equal(sent.input[0].content.filter(block => block.type === "input_image").length,2);
  assert.deepEqual(JSON.parse(Buffer.from(sent.environment.files[1].data, "base64").toString("utf8")),input.request.document);
  assert.equal(sent.environment.files[2].path,"/workspace/apply_edits.py");
  assert.equal(sent.stream, false);
});

test("completion reads the intended root turn's final JSON and retains actual command evidence", async () => {
  const commands = [{ id: "cmd_1", type: "command_execution", status: "completed", turn_id: "turn_1", command: "python /workspace/analyze.py", exit_code: 0, output: "60" }];
  const state = await pollGenerationSession(fixture({ items: [
    ...commands,
    { ...message, id: "msg_other", turn_id: "turn_other", content: [{ type: "output_text", text: '{"total":999}' }] },
    { ...message, id: "comment", phase: "commentary", content: [{ type: "output_text", text: "Working on it" }] },
    message,
  ] }), "sess_1");
  assert.equal(state.status, "complete");
  assert.equal(state.turnId, "turn_1");
  assert.deepEqual(state.result, { total: 60 });
  assert.deepEqual(state.commands, [{ id: "cmd_1", command: "python /workspace/analyze.py", exitCode: 0, output: "60", status: "completed" }]);
});

test("idle alone is never completion and terminal failures stay distinct from success", async () => {
  assert.equal((await pollGenerationSession(fixture({ turns: [] }), "sess_1")).status, "preparing");
  assert.equal((await pollGenerationSession(fixture({ turns: [{ ...turn, status: "queued" }] }), "sess_1")).status, "preparing");
  assert.equal((await pollGenerationSession(fixture({ turns: [{ ...turn, status: "in_progress" }] }), "sess_1")).status, "running");
  assert.equal((await pollGenerationSession(fixture({ turns: [{ ...turn, status: "failed" }] }), "sess_1")).status, "failed");
  assert.equal((await pollGenerationSession(fixture({ turns: [{ ...turn, status: "cancelled" }] }), "sess_1")).status, "cancelled");
  assert.equal((await pollGenerationSession(fixture({ status: "requires_action", turns: [{ ...turn, status: "waiting" }] }), "sess_1")).status, "waiting");
  assert.equal((await pollGenerationSession(fixture({ status: "failed" }), "sess_1")).status, "failed");
});

test("a completed turn can wait for persisted output without starting a second task", async () => {
  const calls = [];
  const transport = fixture({ items: [] });
  const state = await pollGenerationSession(async (path, init) => {
    calls.push(init.method);
    return transport(path);
  }, "sess_1");
  assert.equal(state.status, "running");
  assert.equal(state.progress, "Collecting the results");
  assert.equal(state.result, null);
  assert.ok(calls.every((method) => method === "GET"));
});

test("invalid JSON, oversized results, and multiple root turns cannot become an generation result", async () => {
  for (const text of ["not JSON", JSON.stringify({ value: "x".repeat(MAX_RESULT_BYTES) })]) {
    await assert.rejects(() => pollGenerationSession(fixture({ items: [{ ...message, content: [{ type: "output_text", text }] }] }), "sess_1"), AgentsError);
  }
  await assert.rejects(() => pollGenerationSession(fixture({ turns: [turn, { ...turn, id: "turn_2" }] }), "sess_1"), AgentsError);
  await assert.rejects(() => pollGenerationSession(fixture({ turns: [{ ...turn, session_id: "another_session" }] }), "sess_1"), AgentsError);
});

test("session paths are constrained and upstream errors never disclose response bodies", async () => {
  let called = false;
  await assert.rejects(() => pollGenerationSession(async () => { called = true; return Response.json({}); }, "../other"), AgentsError);
  assert.equal(called, false);
  await assert.rejects(() => pollGenerationSession(async () => Response.json({ secret: "not exposed" }, { status: 403 }), "sess_1"), (error) => error.status === 403 && !error.message.includes("secret"));
});

test("pagination follows cursors and rejects a repeated cursor instead of looping", async () => {
  const seen = [];
  const transport = fixture();
  const state = await pollGenerationSession(async (path) => {
    if (!path.includes("/items?")) return transport(path);
    seen.push(path);
    if (new URL(`https://example.test${path}`).searchParams.has("after")) return page([message]);
    return Response.json({ data: [{ id: "first_item", turn_id: "turn_1", type: "reasoning" }], has_more: true, last_id: "first_item" });
  }, "sess_1");
  assert.equal(state.status, "complete");
  assert.equal(seen.length, 2);
  assert.ok(seen[1].includes("after=first_item"));

  const repeated = async (path) => path.includes("?")
    ? Response.json({ data: [], has_more: true, last_id: "turn_1" })
    : Response.json({ id: "sess_1", status: "idle" });
  await assert.rejects(() => pollGenerationSession(repeated, "sess_1"), /repeated a result page/);
});

test("cancel and delete use their documented paths and preserve deletion conflicts for bounded retries", async () => {
  const calls = [];
  const transport = async (path, init) => { calls.push({ path, init }); return new Response(null, { status: 204 }); };
  await cancelGenerationSession(transport, "sess_1");
  await deleteGenerationSession(transport, "sess_1");
  assert.equal(calls[0].path, "/v1/agents/sessions/sess_1/events");
  assert.deepEqual(JSON.parse(calls[0].init.body), { events: [{ type: "agent.session.input.cancel" }] });
  assert.equal(calls[1].path, "/v1/agents/sessions/sess_1");
  assert.equal(calls[1].init.method, "DELETE");
  await assert.rejects(() => deleteGenerationSession(async () => new Response(null, { status: 409 }), "sess_1"), (error) => error.status === 409);
});
