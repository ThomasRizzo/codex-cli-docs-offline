import assert from "node:assert/strict";
import test from "node:test";
import { setTimeout as delay } from "node:timers/promises";
import { generationStream } from "../app/lib/generation-stream.ts";
import { AgentsError } from "../app/lib/agents.ts";
import { readSSE } from "../app/lib/sse.ts";

const sessionId = "session-test";
import { clarification as explanation, complete as calculation, command as python, document, binding } from "./backend-fixtures.mjs";
const state = (result = explanation, commands = []) => ({ status: "complete", sessionId, turnId: "turn-test", progress: "Ready", result, commands, error: null });
const deferred = () => Promise.withResolvers();
const tick = () => new Promise(resolve => setImmediate(resolve));

function events(deps) {
  return readSSE(generationStream({
    record: async () => {}, sign: async id => `signed-${id}`, cleanup: async () => {}, pollDelayMs: 1, deadlineMs: 1000,
    document, binding, ...deps,
  }));
}
async function next(iterator) {
  const result = await iterator.next();
  assert.equal(result.done, false);
  return { type: result.value.event, ...JSON.parse(result.value.data) };
}
async function collect(iterator) {
  const result = [];
  for await (const event of iterator) result.push({ type: event.event, ...JSON.parse(event.data) });
  return result;
}
async function* identified() {
  yield { type: "session", id: sessionId };
  yield { type: "finished", status: "completed", sessionId, turnId: "turn-test" };
}

test("public commentary and message stream before validated completion; patch data stays out of early updates", {timeout:2000}, async()=>{
  const finish=deferred(), json=JSON.stringify(calculation), split=json.indexOf(',"edits"');
  let polls=0,cleanups=0;
  const iterator=events({
    async *start(){
      yield {type:'session',id:sessionId};
      yield {type:'text',phase:'commentary',itemId:'comment',delta:'Checking the selected text contrast.'};
      yield {type:'text',phase:'final_answer',itemId:'review',delta:json.slice(0,split)};
      await finish.promise;
      yield {type:'text',phase:'final_answer',itemId:'review',delta:json.slice(split)};
      yield {type:'finished',status:'completed',sessionId,turnId:'turn-test'};
    },
    poll:async()=>{polls++;return state(calculation,[python]);},
    cleanup:async()=>{cleanups++;},
  });
  try{
    assert.equal((await next(iterator)).type,'start');
    assert.equal((await next(iterator)).type,'session');
    const progress=await next(iterator);
    assert.equal(progress.type,'progress');assert.equal(progress.progress,'Checking the selected text contrast.');
    const message=await next(iterator);
    assert.deepEqual(message,{type:'message',message:calculation.message});
    assert.equal(polls,0);
    assert.equal(JSON.stringify([progress,message]).includes('color:#aaa'),false);
    finish.resolve();
    const rest=await collect(iterator);
    assert.equal(rest.at(-1).type,'complete');
    assert.deepEqual(rest.at(-1).result,calculation);
    assert.equal(cleanups,1,'completed ephemeral sessions are deleted before the stream closes');
  }finally{finish.resolve();await iterator.return();}
});

test("final output must be persisted and edits must have matching successful validation evidence", async () => {
  for (const commands of [[], [python]]) {
    const cleaned = [];
    const output = await collect(events({ start: identified, poll: async () => state(calculation, commands), cleanup: async id => { cleaned.push(id); } }));
    const terminal = output.at(-1);
    if (commands.length) {
      assert.equal(terminal.type, "complete");
      assert.deepEqual(terminal.execution, { steps: 1, verified: true });
      assert.deepEqual(cleaned, [sessionId]);
    } else {
      assert.equal(terminal.type, "error");
      assert.match(terminal.error, /final checks/);
      assert.deepEqual(cleaned, [sessionId]);
      assert.equal(output.some(event => event.type === "complete"), false);
    }
  }
});

test("a disconnect before creation waits for the late ID and cleans up once", { timeout: 2000 }, async () => {
  const created = deferred(), cleaned = deferred(), exited = deferred();
  let signal, signs = 0, polls = 0, cleanups = 0;
  const iterator = events({
    async *start(observer) {
      signal = observer;
      try { await created.promise; yield { type: "session", id: sessionId }; }
      finally { exited.resolve(); }
    },
    sign: async () => { signs += 1; return "token"; }, poll: async () => { polls += 1; return state(); },
    cleanup: async id => { assert.equal(id, sessionId); cleanups += 1; cleaned.resolve(); },
  });
  try {
    assert.equal((await next(iterator)).type, "start");
    await iterator.return();
    assert.equal(signal.aborted, false, "creation must stay observed until its cleanup ID arrives");
    created.resolve(); await cleaned.promise; await exited.promise; await tick();
    assert.equal(signal.aborted, true);
    assert.equal(signs, 0); assert.equal(polls, 0); assert.equal(cleanups, 1);
  } finally { created.resolve(); await iterator.return(); }
});

test("a disconnect after the handle deletes once even if upstream unwinds past the deadline", { timeout: 2000 }, async () => {
  const unwind = deferred(), exited = deferred();
  let signal, polls = 0;
  const cleaned = [];
  const iterator = events({
    deadlineMs: 30,
    async *start(observer) {
      signal = observer;
      try { yield { type: "session", id: sessionId }; await unwind.promise; }
      finally { exited.resolve(); }
    },
    poll: async () => { polls += 1; return state(); }, cleanup: async id => { cleaned.push(id); },
  });
  try {
    await next(iterator); assert.equal((await next(iterator)).type, "session");
    await iterator.return();
    assert.equal(signal.aborted, true);
    await delay(60); unwind.resolve(); await exited.promise; await tick();
    assert.deepEqual(cleaned, [sessionId], "disconnected anonymous reviews do not leave a recoverable provider session");
    assert.equal(polls, 0);
  } finally { unwind.resolve(); await iterator.return(); }
});

test("reader cancellation waits for the one cleanup attempt after a handle is issued", { timeout: 2000 }, async () => {
  const unwind = deferred(), cleanupFinished = deferred(), exited = deferred();
  let signal, cleanups = 0, cancellationSettled = false;
  const reader = generationStream({
    document, binding, deadlineMs: 1000, record: async () => {},
    async *start(observer) {
      signal = observer;
      try { yield { type: "session", id: sessionId }; await unwind.promise; }
      finally { exited.resolve(); }
    },
    sign: async () => "signed-handle",
    poll: async () => assert.fail("A disconnected review must not poll."),
    cleanup: async id => { assert.equal(id, sessionId); cleanups++; await cleanupFinished.promise; },
  }).getReader();
  try {
    assert.match(new TextDecoder().decode((await reader.read()).value), /event: start/);
    assert.match(new TextDecoder().decode((await reader.read()).value), /event: session/);
    const cancellation = reader.cancel().then(() => { cancellationSettled = true; });
    await tick();
    assert.equal(signal.aborted, true);
    assert.equal(cleanups, 1);
    assert.equal(cancellationSettled, false, "Cancellation must await cleanup instead of leaving it unowned.");
    cleanupFinished.resolve(); await cancellation;
    unwind.resolve(); await exited.promise; await tick();
    assert.equal(cleanups, 1, "The stream finally block reuses the cancellation cleanup promise.");
  } finally { cleanupFinished.resolve(); unwind.resolve(); await reader.cancel(); }
});

test("stream interruption reconciles persisted output and tolerates a transient polling failure", async () => {
  let polls = 0, cleanups = 0;
  const output = await collect(events({
    async *start() { yield { type: "session", id: sessionId }; throw new Error("upstream disconnected"); },
    poll: async () => {
      polls += 1;
      if (polls === 1) throw new AgentsError("Service temporarily unavailable", 503);
      if (polls === 2) return { ...state(), status: "running", result: null, progress: "Writing the answer" };
      return state();
    },
    cleanup: async () => { cleanups += 1; },
  }));
  assert.equal(output.some(event => event.type === "progress" && /Reconnecting/.test(event.progress)), true);
  assert.equal(output.at(-1).type, "complete");
  assert.equal(output.at(-1).result.status, "clarification");
  assert.equal(polls, 3); assert.equal(cleanups, 1);
});

test("timeout aborts observation, reports the timeout, and cleans up once", { timeout: 2000 }, async () => {
  let signal;
  const cleaned = [];
  const output = await collect(events({
    deadlineMs: 15,
    async *start(observer) {
      signal = observer;
      yield { type: "session", id: sessionId };
      await new Promise((resolve, reject) => {
        if (observer.aborted) reject(observer.reason);
        else observer.addEventListener("abort", () => reject(observer.reason), { once: true });
      });
    },
    poll: async () => { throw new Error("must not poll after timeout"); }, cleanup: async id => { cleaned.push(id); },
  }));
  assert.equal(signal.aborted, true);
  assert.equal(output.at(-1).type, "error");
  assert.match(output.at(-1).error, /took too long/);
  assert.deepEqual(cleaned, [sessionId]);
});

test("a deadline wins over a persisted result that resolves during cancellation", { timeout: 2000 }, async () => {
  const cleaned = [];
  const output = await collect(events({
    deadlineMs: 15, start: identified,
    poll: async (id, signal) => new Promise(resolve => {
      if (signal.aborted) resolve(state());
      else signal.addEventListener("abort", () => resolve(state()), { once: true });
    }),
    cleanup: async id => { cleaned.push(id); },
  }));
  assert.equal(output.at(-1).type, "error");
  assert.match(output.at(-1).error, /took too long/);
  assert.equal(output.some(event => event.type === "complete"), false);
  assert.deepEqual(cleaned, [sessionId]);
});

test("unrecoverable polling errors clean up without exposing internal exception text", async () => {
  const cleaned = [];
  const output = await collect(events({
    start: identified,
    poll: async () => { throw new Error("private execution traceback with secret-data"); },
    cleanup: async id => { cleaned.push(id); },
  }));
  assert.equal(output.at(-1).type, "error");
  assert.equal(JSON.stringify(output).includes("secret-data"), false);
  assert.deepEqual(cleaned, [sessionId]);
});

test("durable attachment must finish before a handle or any result is exposed", async () => {
  const stored = deferred();
  let signs = 0, polls = 0;
  const iterator = events({
    start: identified, record: async () => { await stored.promise; },
    sign: async () => { signs++; return "signed"; },
    poll: async () => { polls++; return state(); },
  });
  await next(iterator); await tick();
  assert.equal(signs, 0); assert.equal(polls, 0);
  stored.resolve();
  const rest = await collect(iterator);
  assert.equal(rest[0].type, "session");
  assert.equal(rest.at(-1).type, "complete");
});

test("attachment failure stops output instead of entering polling recovery", async () => {
  const output = await collect(events({
    start: identified,
    record: async () => { throw new Error("private storage detail"); },
    sign: async () => assert.fail("A session without a durable job must never be signed"),
    poll: async () => assert.fail("Storage failure must not be mistaken for an SSE interruption"),
  }));
  assert.deepEqual(output.map(event => event.type), ["start", "error"]);
  assert.doesNotMatch(JSON.stringify(output), /private storage detail/);
});

test("disconnect while attachment is pending waits for its durable job before cleanup", async () => {
  const stored = deferred(), cleaned = deferred();
  let cleanups = 0;
  const iterator = events({
    start: identified, record: async () => { await stored.promise; },
    sign: async () => assert.fail("Disconnected browser must not receive a handle"),
    poll: async () => assert.fail("Disconnected browser must not poll"),
    cleanup: async () => { cleanups++; cleaned.resolve(); },
  });
  await next(iterator); await tick(); await iterator.return();
  assert.equal(cleanups, 0);
  stored.resolve(); await cleaned.promise; await tick();
  assert.equal(cleanups, 1);
});
