import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ApiError, createHandle, verifyHandle, guardRequest, limitSessionRequests, getRuntime, parseBody, errorResponse } from '../app/lib/server.ts';
import { z } from 'zod';
import {AgentsError} from '../app/lib/agents.ts';
import { binding, document } from './backend-fixtures.mjs';
const secret='test-only-signing-key-with-at-least-32-characters';

test('generation handles bind the session to its owner, expiry and signature',async()=>{
 const token=await createHandle('sess_test','alice',secret,binding,1000);
 assert.equal((await verifyHandle(token,'alice',secret,1100)).id,'sess_test');
 assert.equal((await verifyHandle(token,'alice',secret,1100)).sourceHash,binding.sourceHash);
 assert.equal(Buffer.from(token.split('.')[0],'base64url').toString().includes(document.html),false);
 for(const [t,owner,key,time] of [[token,'bob',secret,1100],[token,'alice','wrong-key',1100],[token,'alice',secret,700000],[token+'x','alice',secret,1100],['bad-token','alice',secret,1100]]) await assert.rejects(verifyHandle(t,owner,key,time),e=>e instanceof ApiError&&e.status===403);
 const payload=JSON.parse(Buffer.from(token.split('.')[0],'base64url'));payload.id='sess_other';
 await assert.rejects(verifyHandle(Buffer.from(JSON.stringify(payload)).toString('base64url')+'.'+token.split('.')[1],'alice',secret,1100));
 payload.id='sess_test';payload.sourceHash='0'.repeat(64);
 await assert.rejects(verifyHandle(Buffer.from(JSON.stringify(payload)).toString('base64url')+'.'+token.split('.')[1],'alice',secret,1100));
});
test('anonymous requests require same-origin access and a valid browser session nonce, never Sites identity',()=>{
 const owner=crypto.randomUUID(),url='https://loupe.example/api/review/start';
 const headers={origin:'https://loupe.example','X-Loupe-Session':owner};
 assert.equal(guardRequest(new Request(url,{headers})),owner);
 assert.equal(guardRequest(new Request(url,{headers:{...headers,'oai-authenticated-user-id':'unrelated-account'}})),owner);
 assert.throws(()=>guardRequest(new Request(url,{headers:{...headers,origin:'https://other.example'}})),e=>e.status===403);
 assert.throws(()=>guardRequest(new Request(url,{headers:{...headers,'sec-fetch-site':'cross-site'}})),e=>e.status===403);
 for(const nonce of ['', 'not-a-uuid', '00000000-0000-1000-8000-000000000000', '00000000-0000-4000-0000-000000000000', owner+owner]){
  assert.throws(()=>guardRequest(new Request(url,{headers:{...headers,'X-Loupe-Session':nonce}})),e=>e.status===400);
 }
 assert.throws(()=>guardRequest(new Request(url,{headers:{origin:headers.origin,'oai-authenticated-user-id':'existing-account'}})),e=>e.status===400);
});

test('unverified nonce rotation cannot populate or consume the signed-session limiter',()=>{
 const url='https://loupe.example/api/review/start';
 for(let i=0;i<2100;i++){
  const owner=crypto.randomUUID();
  assert.equal(guardRequest(new Request(url,{headers:{origin:'https://loupe.example','X-Loupe-Session':owner}})),owner);
  assert.throws(()=>guardRequest(new Request(url,{headers:{origin:'https://loupe.example','X-Loupe-Session':`invalid-${i}`}})),e=>e.status===400);
 }
 const owner=crypto.randomUUID();
 for(let i=0;i<90;i++)limitSessionRequests(owner,'status');
 assert.throws(()=>limitSessionRequests(owner,'status'),e=>e.status===429);
 for(let i=0;i<30;i++)limitSessionRequests(owner,'cancel');
 assert.throws(()=>limitSessionRequests(owner,'cancel'),e=>e.status===429);
});

test('anonymous session handles reject another browser nonce for both reading and cleanup',async()=>{
 const owner=crypto.randomUUID(),other=crypto.randomUUID();
 const token=await createHandle('sess_anonymous',owner,secret,binding,1000);
 assert.equal((await verifyHandle(token,owner,secret,1100)).id,'sess_anonymous');
 await assert.rejects(verifyHandle(token,other,secret,1100),e=>e.status===403);
 await assert.rejects(verifyHandle(token,other,secret,700000,true),e=>e.status===403);
 assert.equal((await verifyHandle(token,owner,secret,700000,true)).id,'sess_anonymous');
});
test('JSON body limits actual bytes, schema and content type',async()=>{
 const schema=z.object({question:z.string().min(1)}).strict();
 const request=(body,headers={'content-type':'application/json'})=>new Request('https://loupe.example',{method:'POST',headers,body});
 assert.deepEqual(await parseBody(request('{"question":"hello"}'),schema),{question:'hello'});
 await assert.rejects(parseBody(request('{"question":"hello"}'),schema,10),e=>e.status===413);
 await assert.rejects(parseBody(request('broken'),schema),e=>e.status===400);
 await assert.rejects(parseBody(request('{"question":"hello","extra":1}'),schema),e=>e.status===400);
 await assert.rejects(parseBody(request('{}',{'content-type':'text/plain'}),schema),e=>e.status===415);
});
test('expired handles can only authorize cleanup, and upstream 500s are retryable gateway errors',async()=>{
 const token=await createHandle('sess_cleanup','alice',secret,binding,1000);
 await assert.rejects(verifyHandle(token,'alice',secret,700000));
 assert.equal((await verifyHandle(token,'alice',secret,700000,true)).id,'sess_cleanup');
 await assert.rejects(verifyHandle(token,'bob',secret,700000,true));
 assert.equal(errorResponse(new AgentsError('upstream failure',500)).status,502);
 assert.equal(errorResponse(new Error('internal failure')).status,500);
});


test('local rate limits include a retry delay without disguising upstream quota failures', () => {
 const limited = errorResponse(new ApiError(429, 'Wait before starting again.'));
 assert.equal(limited.status, 429);
 assert.equal(limited.headers.get('Retry-After'), '60');
 assert.equal(limited.headers.get('Cache-Control'), 'no-store');
 const upstream = errorResponse(new AgentsError('The provider is busy.', 429));
 assert.equal(upstream.status, 503);
 assert.equal(upstream.headers.get('Retry-After'), null);
});
