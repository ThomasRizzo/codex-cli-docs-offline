# Folio sample imagery

These are original AI-generated sample images, created with OpenAI's built-in image generation tool on 2026-10-18. They are visual studies, not documentation of real buildings, named destinations, client projects, or journeys. The starter decks are authored examples using these images.

Files are JPEG format conversions of the generated originals, preserving their full 1536 × 1024 frames. No image content was composited, retouched, or cropped. Rendering may crop the photos to fit the chosen slide template.

## Form & light

- `architecture-1.jpg` — Curved white facade against blue sky.
- `architecture-2.jpg` — Concrete corridor with diagonal light.
- `architecture-3.jpg` — Pale concrete curves and dark glass.

## Waterline

- `coast-1.jpg` — Elevated shoreline view with cobalt water and pale sand.
- `coast-2.jpg` — Sculptural rock and turquoise surf.
- `coast-3.jpg` — Sea foam patterns above a submerged rock.

## Generation prompts

**architecture-1:** Photorealistic architectural editorial photograph for a presentation sample. A sculptural white concrete modernist art gallery with a dramatic curved cantilever and vertical fins, photographed from below against a clear pale blue sky. Invented architecture, not a famous building. Crisp late morning sunlight, strong geometric shadows, exquisite real concrete texture, subtle film grain, restrained architectural magazine composition. Landscape 3:2 photograph filling the image. No people, logos, labels, borders, or text.

**architecture-2:** Photorealistic architectural editorial photograph for a presentation sample. Interior of an invented white concrete modernist gallery: a long quiet corridor with repeated square columns, a skylight casting sharp diagonal afternoon shadows onto pale stone floor, one distant open doorway. Rich realistic material texture and dimensional light, restrained architectural magazine composition, not a render. Landscape 3:2 photograph filling the image. No furniture, people, logos, labels, borders, or text.

**architecture-3:** Photorealistic architectural editorial photograph for a presentation sample. Close abstract detail of an invented modernist building, massive pale concrete curves intersecting a vertical dark glass facade, blue sky in one corner, clear rhythm of light and shadow, architectural magazine photography, realistic stone grain. Landscape 3:2 photograph filling the image. No people, famous landmarks, logos, labels, borders, or text.

**coast-1:** Photorealistic coastal editorial photograph for a presentation sample. Aerial view of a wild Atlantic shoreline: immense deep cobalt ocean at left, white sea foam tracing a sweeping arc of pale sandy beach, dark jagged rocks and sparse green coastal grasses on the right. Beautiful real textures, bright clear daylight, natural subdued grading, premium travel magazine photography. Landscape 3:2 photograph filling the image. No buildings, people, logos, labels, borders, or text.

**coast-2:** Photorealistic coastal editorial photograph for a presentation sample. Ground-level view along a wild empty beach with one immense sculptural dark rock standing in clear turquoise water; foamy waves curling around the rock and wet pale sand reflecting the blue sky. Natural light, beautifully tactile sand and weathered rock, crisp coastal air, premium travel magazine photography. Landscape 3:2 photograph filling the image. No people, boats, logos, labels, borders, or text.

**coast-3:** Photorealistic coastal editorial photograph for a presentation sample. Close overhead view of luminous white sea foam dissolving across deep ultramarine ocean water, one dark submerged rock visible beneath turquoise water at an edge. Fine organic patterns, realistic translucent water and motion, uncluttered premium travel magazine composition. Landscape 3:2 photograph filling the image. No people, boats, logos, labels, borders, or text.

Inter Variable is licensed under the SIL Open Font License; see `/fonts/Inter-LICENSE.txt`.
