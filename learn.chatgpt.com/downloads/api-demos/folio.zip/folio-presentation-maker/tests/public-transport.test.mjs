import assert from "node:assert/strict";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { Log, LogLevel, Miniflare } from "miniflare";
import { createTransport } from "../app/lib/public-transport.ts";

const key = "test-only-provider-key";
test("public transport sends credentials only to allowlisted API paths and rejects redirects", async () => {
  const calls = [];
  const transport = createTransport({ key, fetch: async (url, init) => {
    calls.push({ url, init });
    assert.equal(new URL(url).origin, "https://api.openai.com");
    assert.equal(init.headers.get("authorization"), `Bearer ${key}`);
    assert.equal(init.headers.get("OpenAI-Beta"), "agents=v1");
    assert.equal(init.redirect, "manual");
    return Response.json({ id: "sess_test" });
  } });
  await transport("/v1/agents/sessions", { method: "POST", redirect: "follow", headers: { "OpenAI-Beta": "agents=v1", authorization: "caller-value" } });
  await transport("/v1/agents/sessions/sess_test/items?limit=100", { headers: { "OpenAI-Beta": "agents=v1" } });
  for (const path of ["https://elsewhere.test", "//elsewhere.test", "/v1/agents/sessions/../files", "/v1/agents/sessions/%2e%2e/files", "/v1/files"]) {
    await assert.rejects(transport(path, {}), error => error.status === 500);
  }
  assert.equal(calls.length, 2);
  for (const status of [301, 302, 303, 307, 308]) {
    const redirected = createTransport({ key, fetch: async () => new Response(null, { status, headers: { location: "https://elsewhere.test/private" } }) });
    await assert.rejects(redirected("/v1/agents/sessions", {}), error => error.status === 502 && !error.message.includes("private"));
  }
});

test("public transport works in the production Worker runtime with manual redirects", { timeout: 30_000 }, async t => {
  const root = fileURLToPath(new URL("../", import.meta.url));
  const bundled = await build({
    absWorkingDir: root,
    stdin: { resolveDir: root, sourcefile: "public-transport-fixture.ts", loader: "ts", contents: `
      import { createTransport } from "./app/lib/public-transport.ts";
      export default { async fetch(request, env) {
        try {
          const transport = createTransport({ key: env.OPENAI_API_KEY });
          return await transport("/v1/agents/sessions", { method: "POST", headers: { "OpenAI-Beta": "agents=v1" }, body: "{}" });
        } catch (error) { return Response.json({ error: error.message }, { status: error.status ?? 500 }); }
      } };
    ` },
    bundle: true, format: "esm", platform: "neutral", target: "es2022",
    conditions: ["workerd", "worker", "browser"], external: ["cloudflare:workers", "node:net"],
    define: { "process.env.NODE_ENV": '"production"' }, write: false, logLevel: "silent",
  });
  let calls = 0;
  const worker = new Miniflare({
    modules: true, script: bundled.outputFiles[0].text,
    compatibilityDate: "2026-05-15", compatibilityFlags: ["nodejs_compat"],
    host: "127.0.0.1", port: 0, cf: false, log: new Log(LogLevel.ERROR),
    bindings: { OPENAI_API_KEY: key },
    outboundService: async request => {
      calls++;
      assert.equal(request.url, "https://api.openai.com/v1/agents/sessions");
      assert.equal(request.headers.get("authorization"), `Bearer ${key}`);
      assert.equal(request.headers.get("OpenAI-Beta"), "agents=v1");
      return calls === 1 ? Response.json({ id: "sess_test" }) : new Response(null, { status: 302, headers: { location: "https://elsewhere.test/" } });
    },
  });
  t.after(() => worker.dispose());
  const success = await worker.dispatchFetch("https://demo.test/start");
  assert.equal(success.status, 200, await success.clone().text());
  assert.deepEqual(await success.json(), { id: "sess_test" });
  const redirect = await worker.dispatchFetch("https://demo.test/start");
  assert.equal(redirect.status, 502, await redirect.clone().text());
  assert.equal(calls, 2, "redirects never receive an additional credential-bearing fetch");
});
