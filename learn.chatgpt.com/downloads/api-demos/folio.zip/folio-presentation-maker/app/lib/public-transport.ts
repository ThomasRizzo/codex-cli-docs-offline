import { ApiError } from "./server.ts";
import type { AgentsTransport } from "./agents.ts";

export type TransportBindings = { OPENAI_API_KEY?: string };
export type TransportOptions = { key: string; bindings?: TransportBindings | null; dev?: boolean; fetch?: typeof fetch };

/** Credentials stay on the server and are sent only to the public OpenAI API. */
export function createTransport(options: TransportOptions): AgentsTransport {
  return async (path, init) => {
    if (!/^\/v1\/agents\/sessions(?:\/[A-Za-z0-9_-]+(?:\/(?:turns|items|events))?)?(?:\?[^#]*)?$/.test(path)) throw new ApiError(500, "Unsupported generation operation.");
    const headers = new Headers(init.headers);
    headers.set("Authorization", `Bearer ${options.key}`);
    try {
      const response = await (options.fetch ?? fetch)(`https://api.openai.com${path}`, { ...init, headers, redirect: "manual" });
      if (response.status >= 300 && response.status < 400) throw new Error("Unexpected API redirect");
      if (!response.ok) {
        // Never log upstream bodies: they can contain uploaded data or a credential.
        const requestId = response.headers.get("x-request-id");
        console.error(JSON.stringify({ event: "agents_request_failed", status: response.status, requestId: requestId && /^req_[A-Za-z0-9]{1,100}$/.test(requestId) ? requestId : undefined }));
      }
      return response;
    } catch {
      if (init.signal?.aborted) throw new ApiError(504, "The generation service took too long to respond. Please try again.");
      throw new ApiError(502, "Folio could not reach the generation service. Please try again.");
    }
  };
}

export function getProviderOrigin(_options?: unknown): string { return "https://api.openai.com"; }
