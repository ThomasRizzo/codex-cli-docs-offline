import type { AgentsTransport } from "./agents.ts";
import { CleanupIncidents, type TicketFailure } from "./cleanup-incidents.ts";

export type CleanupScope = { scope: string; fingerprint: string };
type Intent = { id: string; scope: string; fingerprint: string; cleanup_after: number; scan_after: string | null; scan_attempts: number; lease_token: string };
type Job = { session_id: string; intent_id: string; scope: string; fingerprint: string; due_at: number; attempts: number; lease_token: string; resolved_at: number | null };
type Counts = { pending: number; unknown: number; overdue: number; stranded: number; blocked: number; oldest: number | null };
const APP = "folio";
const OVERDUE_MS = 15 * 60_000;
const LEASE_MS = 60_000;
const RETAIN_CONFIRMED_MS = 24 * 60 * 60_000;
const resourceId = /^[A-Za-z0-9_-]{1,200}$/;
const uuid = /^[a-f0-9-]{36}$/;

export async function cleanupFingerprint(key: string, origin: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify([key, origin])));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}

async function boundedJson(response: Response): Promise<unknown> {
  if (!response.body) throw new Error("invalid_response");
  const reader = response.body.getReader(), chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      size += part.value.byteLength;
      if (size > 2_000_000) throw new Error("response_too_large");
      chunks.push(part.value);
    }
  } finally { await reader.cancel().catch(() => undefined); reader.releaseLock(); }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  return JSON.parse(new TextDecoder().decode(bytes));
}

function object(value: unknown): value is Record<string, unknown> { return !!value && typeof value === "object" && !Array.isArray(value); }
function retryAfterMs(response: Response, now: number): number {
  const header = response.headers.get("retry-after");
  const seconds = header === null ? NaN : Number(header);
  const delay = Number.isFinite(seconds) ? seconds * 1000 : header ? Date.parse(header) - now : 0;
  return Math.max(0, Math.min(900_000, delay || 0));
}
class AttemptError extends Error {
  readonly code: string;
  readonly status: number;
  readonly retryAfter: number;
  constructor(code: string, status = 0, retryAfter = 0) { super(code); this.code = code; this.status = status; this.retryAfter = retryAfter; }
}

/** Metadata only. Provider calls are never made while holding a database transaction. */
export class CleanupStore {
  readonly db: D1Database;
  readonly scope: CleanupScope;
  readonly transport: AgentsTransport;
  private readonly now: () => number;
  private readonly random: () => number;
  private readonly incidents: CleanupIncidents;
  constructor(
    db: D1Database, scope: CleanupScope, transport: AgentsTransport,
    now: () => number = Date.now, random: () => number = Math.random,
  ) {
    this.db = db; this.scope = scope; this.transport = transport; this.now = now; this.random = random;
    this.incidents = new CleanupIncidents(db, APP, now);
  }

  metadata(intent: string) { return { cleanup_app: APP, cleanup_run: intent, cleanup_scope: this.scope.scope }; }

  async begin(): Promise<string> {
    const id = crypto.randomUUID(), now = this.now();
    const saved = await this.db.prepare(`INSERT INTO cleanup_intents
      (id, scope, fingerprint, created_at, cleanup_after, next_scan_at, observed, scan_attempts)
      VALUES (?, ?, ?, ?, ?, ?, 0, 0)`)
      .bind(id, this.scope.scope, this.scope.fingerprint, now, now + 210_000, now + 210_000).run();
    if (!saved.success || saved.meta.changes !== 1) throw new Error("cleanup_intent_not_recorded");
    return id;
  }

  /** Only a definitive HTTP rejection received before any provider ID is proof. */
  async rejected(intentId: string, status: number): Promise<void> {
    if (![400, 401, 403, 404, 422].includes(status)) throw new Error("ambiguous_creation_outcome");
    await this.db.prepare(`UPDATE cleanup_intents SET observed = 1, last_error = ?, lease_token = NULL, lease_until = NULL
      WHERE id = ? AND scope = ? AND fingerprint = ? AND observed = 0
      AND NOT EXISTS (SELECT 1 FROM cleanup_jobs WHERE intent_id = cleanup_intents.id)`)
      .bind(`create_rejected_${status}`, intentId, this.scope.scope, this.scope.fingerprint).run();
  }

  /** The caller must await this before signing a browser handle or forwarding output. */
  async track(intentId: string, sessionId: string, observed = true): Promise<void> {
    if (!resourceId.test(sessionId) || !uuid.test(intentId)) throw new Error("invalid_cleanup_identity");
    const result = await this.db.batch([
      this.db.prepare(`INSERT INTO cleanup_jobs
        (session_id, intent_id, scope, fingerprint, created_at, due_at, attempts)
        SELECT ?, id, scope, fingerprint, created_at, cleanup_after, 0 FROM cleanup_intents
        WHERE id = ? AND scope = ? AND fingerprint = ?
        ON CONFLICT(session_id) DO NOTHING`).bind(sessionId, intentId, this.scope.scope, this.scope.fingerprint),
      this.db.prepare(`UPDATE cleanup_intents SET observed = MAX(observed, ?) WHERE id = ?
        AND EXISTS (SELECT 1 FROM cleanup_jobs WHERE session_id = ? AND intent_id = cleanup_intents.id
        AND scope = ? AND fingerprint = ?)`).bind(observed ? 1 : 0, intentId, sessionId, this.scope.scope, this.scope.fingerprint),
      this.db.prepare(`SELECT * FROM cleanup_jobs WHERE session_id = ?`).bind(sessionId),
    ]);
    const job = result[2].results[0] as Job | undefined;
    if (result.some(r => !r.success) || !job || job.intent_id !== intentId || !this.matches(job)) throw new Error("cleanup_identity_not_recorded");
  }

  private matches(row: CleanupScope) { return row.scope === this.scope.scope && row.fingerprint === this.scope.fingerprint; }

  async assertSession(sessionId: string): Promise<void> {
    const job = await this.db.prepare("SELECT * FROM cleanup_jobs WHERE session_id = ?").bind(sessionId).first<Job>();
    if (!job || !this.matches(job) || job.resolved_at !== null) throw new Error("cleanup_session_unavailable");
  }

  private async request(path: string, method: string, signal: AbortSignal, body?: unknown) {
    return this.transport(path, {
      method, signal, headers: { "OpenAI-Beta": "agents=v1", Accept: "application/json", ...(body ? { "Content-Type": "application/json" } : {}) },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
  }

  private async deleteOnce(id: string, signal: AbortSignal): Promise<void> {
    const response = await this.request(`/v1/agents/sessions/${id}`, "DELETE", signal);
    if (response.status === 404) { await response.body?.cancel(); return; }
    if (!response.ok) {
      const status = response.status;
      const retryAfter = retryAfterMs(response, this.now());
      await response.body?.cancel();
      if (status === 409) {
        try {
          const cancel = await this.request(`/v1/agents/sessions/${id}/events`, "POST", signal, { events: [{ type: "agent.session.input.cancel" }] });
          await cancel.body?.cancel();
        } catch { /* The durable deletion job remains responsible. */ }
      }
      throw new AttemptError(status === 401 || status === 403 ? "provider_auth" : `provider_${status}`, status, retryAfter);
    }
    const confirmation = await boundedJson(response);
    if (!object(confirmation) || confirmation.id !== id || confirmation.deleted !== true || confirmation.object !== "agent.session.deleted") {
      throw new AttemptError("invalid_delete_confirmation");
    }
  }

  /** Only for a provider ID just received by this request when its D1 attachment failed. */
  async emergencyDelete(intentId: string, sessionId: string): Promise<void> {
    if (!resourceId.test(sessionId)) throw new Error("invalid_cleanup_identity");
    await this.deleteOnce(sessionId, AbortSignal.timeout(8_000));
    // The database may have recovered since attachment failed. Retain the intent
    // if these writes also fail; an in-memory confirmation is not durable proof.
    await this.track(intentId, sessionId);
    await this.db.prepare(`UPDATE cleanup_jobs SET resolved_at = ?, lease_token = NULL, lease_until = NULL,
      last_error = NULL WHERE session_id = ? AND intent_id = ? AND scope = ? AND fingerprint = ?`)
      .bind(this.now(), sessionId, intentId, this.scope.scope, this.scope.fingerprint).run();
  }

  private async claim(sessionId?: string): Promise<Job | null> {
    const now = this.now(), token = crypto.randomUUID();
    return this.db.prepare(`UPDATE cleanup_jobs SET lease_token = ?, lease_until = ?, attempts = attempts + 1
      WHERE session_id = (SELECT session_id FROM cleanup_jobs WHERE resolved_at IS NULL
        AND scope = ? AND fingerprint = ? AND due_at <= ? AND (lease_until IS NULL OR lease_until <= ?)
        AND (? IS NULL OR session_id = ?) ORDER BY due_at, session_id LIMIT 1)
      RETURNING *`).bind(token, now + LEASE_MS, this.scope.scope, this.scope.fingerprint, now, now, sessionId ?? null, sessionId ?? null).first<Job>();
  }

  private async attempt(job: Job, parent?: AbortSignal): Promise<void> {
    if (!this.matches(job)) throw new Error("cleanup_scope_mismatch");
    const signal = AbortSignal.any([AbortSignal.timeout(8_000), ...(parent ? [parent] : [])]);
    try {
      await this.deleteOnce(job.session_id, signal);
      await this.db.prepare(`UPDATE cleanup_jobs SET resolved_at = ?, lease_token = NULL, lease_until = NULL,
        last_error = NULL WHERE session_id = ? AND lease_token = ?`)
        .bind(this.now(), job.session_id, job.lease_token).run();
    } catch (error) {
      const known = error instanceof AttemptError ? error : new AttemptError(signal.aborted ? "timeout" : "transport_or_storage");
      const delay = Math.max(known.retryAfter, Math.min(900_000, 15_000 * 2 ** Math.min(job.attempts - 1, 6) * (0.8 + this.random() * 0.4)));
      await this.db.prepare(`UPDATE cleanup_jobs SET due_at = ?, lease_token = NULL, lease_until = NULL,
        last_error = ? WHERE session_id = ? AND lease_token = ?`)
        .bind(this.now() + Math.ceil(delay), known.code, job.session_id, job.lease_token).run();
      if (known.code === "provider_auth") await this.status();
      console.error(JSON.stringify({ event: "cleanup_retry_queued", category: known.code }));
    }
  }

  async release(sessionId: string): Promise<"confirmed" | "queued"> {
    const job = await this.db.prepare("SELECT * FROM cleanup_jobs WHERE session_id = ?").bind(sessionId).first<Job>();
    if (!job || !this.matches(job)) throw new Error("cleanup_scope_or_identity_mismatch");
    if (job.resolved_at !== null) return "confirmed";
    // Repeated browser cleanup requests must not reset a failed job's backoff.
    await this.db.prepare(`UPDATE cleanup_jobs SET due_at = MIN(due_at, ?) WHERE session_id = ? AND attempts = 0`)
      .bind(this.now(), sessionId).run();
    const claimed = await this.claim(sessionId);
    if (claimed) await this.attempt(claimed);
    const current = await this.db.prepare("SELECT resolved_at FROM cleanup_jobs WHERE session_id = ?").bind(sessionId).first<{ resolved_at: number | null }>();
    return current?.resolved_at != null ? "confirmed" : "queued";
  }

  private async reconcile(signal: AbortSignal): Promise<void> {
    const now = this.now(), token = crypto.randomUUID();
    const intent = await this.db.prepare(`UPDATE cleanup_intents SET lease_token = ?, lease_until = ?, scan_attempts = scan_attempts + 1
      WHERE id = (SELECT id FROM cleanup_intents WHERE observed = 0 AND scope = ? AND fingerprint = ?
        AND next_scan_at <= ? AND (lease_until IS NULL OR lease_until <= ?) ORDER BY next_scan_at, id LIMIT 1)
      RETURNING *`).bind(token, now + LEASE_MS, this.scope.scope, this.scope.fingerprint, now, now).first<Intent>();
    if (!intent) return;
    const retryDelay = Math.min(900_000, 60_000 * 2 ** Math.min(intent.scan_attempts - 1, 4));
    try {
      const query = new URLSearchParams({ limit: "10", order: "desc", ...(intent.scan_after ? { after: intent.scan_after } : {}) });
      const response = await this.request(`/v1/agents/sessions?${query}`, "GET", AbortSignal.any([signal, AbortSignal.timeout(8_000)]));
      if (!response.ok) {
        const status = response.status, retryAfter = retryAfterMs(response, this.now());
        await response.body?.cancel();
        throw new AttemptError(`reconcile_${status}`, status, retryAfter);
      }
      const page = await boundedJson(response);
      if (!object(page) || !Array.isArray(page.data) || page.data.length > 10 || typeof page.has_more !== "boolean") throw new AttemptError("invalid_session_list");
      for (const session of page.data) {
        if (!object(session) || typeof session.id !== "string" || !resourceId.test(session.id)) throw new AttemptError("invalid_session_list");
        if (!object(session.metadata)) continue;
        const meta = session.metadata;
        if (meta.cleanup_app === APP && meta.cleanup_run === intent.id && meta.cleanup_scope === intent.scope) {
          await this.track(intent.id, session.id, false);
        }
      }
      const next = page.has_more ? page.last_id : null;
      if (next !== null && (typeof next !== "string" || !resourceId.test(next) || next === intent.scan_after)) throw new AttemptError("invalid_session_cursor");
      // A complete empty scan is not proof that an ambiguous create never happened.
      await this.db.prepare(`UPDATE cleanup_intents SET scan_after = ?, next_scan_at = ?, lease_token = NULL,
        lease_until = NULL, last_error = NULL,
        observed = CASE WHEN ? = 1 AND EXISTS (SELECT 1 FROM cleanup_jobs WHERE intent_id = cleanup_intents.id) THEN 1 ELSE observed END
        WHERE id = ? AND lease_token = ?`)
        .bind(next, this.now() + (page.has_more ? 0 : retryDelay), page.has_more ? 0 : 1, intent.id, token).run();
    } catch (error) {
      const code = error instanceof AttemptError ? error.code : "reconcile_transport_or_storage";
      // Cursors may reference a session that was deleted. Restart safely; matching is idempotent.
      await this.db.prepare(`UPDATE cleanup_intents SET scan_after = NULL, next_scan_at = ?, lease_token = NULL,
        lease_until = NULL, last_error = ? WHERE id = ? AND lease_token = ?`)
        .bind(this.now() + Math.max(retryDelay, error instanceof AttemptError ? error.retryAfter : 0), code, intent.id, token).run();
      if (code === "reconcile_401" || code === "reconcile_403") await this.status();
      console.error(JSON.stringify({ event: "cleanup_reconciliation_pending", category: code }));
    }
  }

  async run() {
    // Observe an overdue/auth/scope breach before a successful retry can erase it.
    await this.status();
    const signal = AbortSignal.timeout(20_000);
    await this.reconcile(signal);
    for (let count = 0; count < 20 && !signal.aborted; count++) {
      const job = await this.claim();
      if (!job) break;
      await this.attempt(job, signal);
    }
    await this.db.batch([
      this.db.prepare(`DELETE FROM cleanup_jobs WHERE session_id IN (SELECT j.session_id FROM cleanup_jobs j
        JOIN cleanup_intents i ON i.id = j.intent_id WHERE j.resolved_at < ? AND i.observed = 1 LIMIT 100)`).bind(this.now() - RETAIN_CONFIRMED_MS),
      this.db.prepare(`DELETE FROM cleanup_intents WHERE id IN (SELECT id FROM cleanup_intents WHERE observed = 1
        AND created_at < ? AND NOT EXISTS (SELECT 1 FROM cleanup_jobs WHERE intent_id = cleanup_intents.id) LIMIT 100)`).bind(this.now() - RETAIN_CONFIRMED_MS),
      this.db.prepare(`INSERT INTO cleanup_maintenance (id, last_run_at) VALUES ('main', ?)
        ON CONFLICT(id) DO UPDATE SET last_run_at = excluded.last_run_at`).bind(this.now()),
    ]);
    return this.status();
  }

  async status() {
    const now = this.now(), scope = this.scope;
    const rows = await this.db.batch([
      this.db.prepare(`SELECT COUNT(*) AS pending,
        COALESCE(SUM(created_at <= ?), 0) AS overdue,
        COALESCE(SUM(scope != ? OR fingerprint != ?), 0) AS stranded,
        COALESCE(SUM(last_error = 'provider_auth'), 0) AS blocked,
        MIN(created_at) AS oldest FROM cleanup_jobs WHERE resolved_at IS NULL`).bind(now - OVERDUE_MS, scope.scope, scope.fingerprint),
      this.db.prepare(`SELECT COUNT(*) AS unknown,
        COALESCE(SUM(created_at <= ?), 0) AS overdue,
        COALESCE(SUM(scope != ? OR fingerprint != ?), 0) AS stranded,
        COALESCE(SUM(last_error IN ('reconcile_401', 'reconcile_403')), 0) AS blocked,
        MIN(created_at) AS oldest FROM cleanup_intents WHERE observed = 0`).bind(now - OVERDUE_MS, scope.scope, scope.fingerprint),
      this.db.prepare(`SELECT DISTINCT last_error FROM cleanup_jobs WHERE resolved_at IS NULL
        AND (created_at <= ? OR scope != ? OR fingerprint != ? OR last_error = 'provider_auth')
        ORDER BY last_error LIMIT 30`).bind(now - OVERDUE_MS, scope.scope, scope.fingerprint),
      this.db.prepare(`SELECT DISTINCT last_error FROM cleanup_intents WHERE observed = 0
        AND (created_at <= ? OR scope != ? OR fingerprint != ? OR last_error IN ('reconcile_401', 'reconcile_403'))
        ORDER BY last_error LIMIT 30`).bind(now - OVERDUE_MS, scope.scope, scope.fingerprint),
      this.db.prepare(`SELECT COUNT(*) AS due FROM cleanup_jobs WHERE resolved_at IS NULL AND scope = ? AND fingerprint = ?
        AND due_at <= ? AND (lease_until IS NULL OR lease_until <= ?)`).bind(scope.scope, scope.fingerprint, now, now),
      this.db.prepare(`SELECT COUNT(*) AS due FROM cleanup_intents WHERE observed = 0 AND scope = ? AND fingerprint = ?
        AND next_scan_at <= ? AND (lease_until IS NULL OR lease_until <= ?)`).bind(scope.scope, scope.fingerprint, now, now),
    ]);
    const jobs = rows[0].results[0] as unknown as Counts, intents = rows[1].results[0] as unknown as Counts;
    const counts = {
      pending: jobs.pending, unknown: intents.unknown, overdue: jobs.overdue + intents.overdue,
      stranded: jobs.stranded + intents.stranded, blocked: jobs.blocked + intents.blocked,
      oldest: [jobs.oldest, intents.oldest].filter((v): v is number => v !== null).sort((a, b) => a - b)[0] ?? null,
    };
    const problem = counts.overdue > 0 || counts.stranded > 0 || counts.blocked > 0;
    const categories = [...new Set(([...rows[2].results, ...rows[3].results] as { last_error: string | null }[]).map(row => row.last_error).filter(Boolean))];
    await this.incidents.observe(problem, { ...counts, categories }, now);
    const maintenance = await this.db.prepare("SELECT last_run_at FROM cleanup_maintenance WHERE id = 'main'")
      .first<{ last_run_at: number | null }>();
    return { ...counts, dueJobs: Number((rows[4].results[0] as { due: number }).due),
      dueReconciliations: Number((rows[5].results[0] as { due: number }).due),
      lastRunAt: maintenance?.last_run_at ?? null, overdueAfterMinutes: 15, ...await this.incidents.status() };
  }

  claimAlert() { return this.incidents.claim(); }
  retryAlert(id: string, token: string, category: TicketFailure, retryAfterSeconds = 0) { return this.incidents.retry(id, token, category, retryAfterSeconds); }
  acknowledge(id: string, token: string, receipt: unknown, owner: string) { return this.incidents.acknowledge(id, token, receipt, owner); }
  testAlert(testId: string) { return this.incidents.testAlert(testId); }
}
