import { assetSchema, slideSchema, themes, MAX_IMAGES, MAX_IMAGE_BYTES, type ImageAsset, type Slide, type Theme } from "./contracts.ts";
import { SLIDE_CSS } from "./slide-styles.ts";

export { SLIDE_CSS } from "./slide-styles.ts";

export function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]!);
}

export function validateRenderAssets(assets: ImageAsset[]): ImageAsset[] {
  if (assets.length > MAX_IMAGES) throw new Error("A presentation can contain up to six images.");
  const parsed = assets.map(asset => assetSchema.parse(asset));
  if (new Set(parsed.map(asset => asset.id)).size !== parsed.length) throw new Error("Each image needs a unique ID.");
  for (const asset of parsed) {
    const base64 = asset.dataUrl.slice("data:image/jpeg;base64,".length);
    const bytes = base64.length * 3 / 4 - (base64.endsWith("==") ? 2 : base64.endsWith("=") ? 1 : 0);
    if (!base64.startsWith("/9j/") || base64.length % 4 !== 0 || bytes > MAX_IMAGE_BYTES) throw new Error("An image is not a valid prepared JPEG. Please upload it again.");
  }
  return parsed;
}

export function imageStyles(assets: ImageAsset[]): string {
  // Both the ID and data URL are strictly validated before entering CSS.
  return validateRenderAssets(assets).map(asset => `.photo[data-image="${asset.id}"]{background-image:url("${asset.dataUrl}")}`).join("\n");
}

export function validateTheme(theme: Theme): void {
  if (!themes.includes(theme)) throw new Error("Choose a supported presentation theme.");
}

export function renderSlideMarkup(slide: Slide, assets: ImageAsset[], theme: Theme, index: number, total: number, options: { animate?: boolean } = {}): string {
  const checked = slideSchema.parse(slide);
  validateTheme(theme);
  if (!Number.isInteger(index) || !Number.isInteger(total) || index < 0 || total < 1 || index >= total) throw new Error("The slide position is invalid.");
  const title = escapeHtml(checked.title);
  const eyebrow = checked.eyebrow ? `<p class="eyebrow">${escapeHtml(checked.eyebrow)}</p>` : "";
  const body = checked.body ? `<p class="copy">${escapeHtml(checked.body)}</p>` : "";
  const photo = (id: string | undefined): string => {
    const asset = assets.find(image => image.id === id);
    const safeId = id && /^image-[1-6]$/.test(id) ? id : "loading";
    return `<div class="photo-frame"><div class="photo" data-image="${safeId}" role="img" aria-label="${escapeHtml(asset?.name || "Photo")}"></div></div>`;
  };
  const heading = `<h1>${title}</h1>`;
  let content: string;
  switch (checked.layout) {
    case "cover": content = `<div class="cover-copy entrance">${eyebrow}<div class="cover-main">${heading}${body}</div></div>${photo(checked.imageIds[0])}`; break;
    case "split": content = `${photo(checked.imageIds[0])}<div class="split-copy entrance">${eyebrow}<div>${heading}${body}</div></div>`; break;
    case "statement": content = `${eyebrow}<div class="entrance">${heading}</div>${body}`; break;
    case "gallery": content = `<div class="gallery-heading entrance"><div>${eyebrow}${heading}</div>${body}</div><div class="gallery-grid" style="--photo-count:${Math.max(2, checked.imageIds.length)}">${checked.imageIds.length ? checked.imageIds.map(photo).join("") : photo(undefined) + photo(undefined)}</div>`; break;
    case "closing": content = `<div class="closing-copy entrance">${eyebrow}<div>${heading}${body}</div></div>${checked.imageIds.length ? photo(checked.imageIds[0]) : ""}`; break;
  }
  const titleSize = checked.title.length > 62 ? "title-long" : checked.title.length > 38 ? "title-medium" : "title-short";
  // Wide glyphs and long uppercase strings need more room than ordinary prose.
  // Fixed density classes keep previews script-free and preserve their full text.
  const weight = (value: string) => Array.from(value).reduce((sum, character) => sum + (/\s/.test(character) ? 0.4 : /[MWmw@%]/.test(character) ? 1.6 : character.codePointAt(0)! > 0x2e80 ? 1.8 : /[A-Z]/.test(character) ? 1.2 : 0.75), 0);
  const titleWeight = weight(checked.title);
  const titleDense = titleWeight >= 90 || (checked.title.length > 22 && titleWeight / checked.title.length > 1.3);
  const bodyDense = weight(checked.body) >= 270;
  return `<section class="slide theme-${theme} layout-${checked.layout} motion-${checked.motion} ${titleSize}${titleDense ? " title-dense" : ""}${bodyDense ? " body-dense" : ""}${checked.imageIds.length ? "" : " no-photo"}" data-duration="${checked.duration}" data-animate="${options.animate !== false}" aria-label="Slide ${index + 1} of ${total}: ${title}">${content}<span class="folio-counter" aria-hidden="true">${String(index + 1).padStart(2, "0")} / ${String(total).padStart(2, "0")}</span></section>`;
}

export function renderSlideHtml(slide: Slide, assets: ImageAsset[], theme: Theme, index: number, total: number, options: { animate?: boolean } = {}): string {
  const checked = slideSchema.parse(slide);
  const prepared = validateRenderAssets(assets);
  const css = imageStyles(prepared.filter(asset => checked.imageIds.includes(asset.id)));
  const markup = renderSlideMarkup(checked, prepared, theme, index, total, options);
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; font-src data:; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>${escapeHtml(slide.title)}</title><style>${SLIDE_CSS}${css}</style></head><body>${markup}</body></html>`;
}
