import { deckSchema, validateDeckAssets, type Deck, type ImageAsset, type Theme } from "./contracts.ts";
import { escapeHtml, imageStyles, renderSlideMarkup, validateRenderAssets, validateTheme } from "./render.ts";
import { SLIDE_CSS } from "./slide-styles.ts";

// This fixed script contains no interpolated deck content. Its CSP hash is checked in tests.
export const PLAYER_SCRIPT = String.raw`(() => {
  const slides = Array.from(document.querySelectorAll('.slide'));
  const previous = document.getElementById('previous');
  const next = document.getElementById('next');
  const play = document.getElementById('play');
  const count = document.getElementById('slide-count');
  let index = 0;
  let playing = false;
  let timer = null;
  function clearTimer() { if (timer !== null) clearTimeout(timer); timer = null; }
  function draw() {
    slides.forEach((slide, position) => { slide.hidden = position !== index; });
    previous.disabled = index === 0;
    next.disabled = index === slides.length - 1;
    play.textContent = playing ? 'Pause' : index === slides.length - 1 ? 'Replay' : 'Play';
    play.setAttribute('aria-pressed', String(playing));
    count.textContent = String(index + 1).padStart(2, '0') + ' / ' + String(slides.length).padStart(2, '0');
    document.body.classList.toggle('player-paused', !playing);
  }
  function pause() { playing = false; clearTimer(); draw(); }
  function schedule() {
    clearTimer();
    if (!playing) return;
    const seconds = Math.max(3, Math.min(12, Number(slides[index].dataset.duration) || 6));
    timer = setTimeout(() => {
      if (index === slides.length - 1) { pause(); return; }
      index += 1; draw(); schedule();
    }, seconds * 1000);
  }
  function go(position) { pause(); index = Math.max(0, Math.min(slides.length - 1, position)); draw(); }
  function toggle() {
    if (playing) { pause(); return; }
    if (index === slides.length - 1) index = 0;
    playing = true; draw(); schedule();
  }
  previous.addEventListener('click', () => go(index - 1));
  next.addEventListener('click', () => go(index + 1));
  play.addEventListener('click', toggle);
  document.addEventListener('keydown', event => {
    if (event.altKey || event.ctrlKey || event.metaKey || event.isComposing) return;
    if (event.target instanceof HTMLElement && /^(INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName)) return;
    if (['ArrowRight', 'PageDown'].includes(event.key)) { event.preventDefault(); go(index + 1); }
    else if (['ArrowLeft', 'PageUp'].includes(event.key)) { event.preventDefault(); go(index - 1); }
    else if (event.key === 'Home') { event.preventDefault(); go(0); }
    else if (event.key === 'End') { event.preventDefault(); go(slides.length - 1); }
    else if (event.key === 'Escape') pause();
    else if (event.key === ' ' && !(event.target instanceof HTMLButtonElement)) { event.preventDefault(); toggle(); }
  });
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause(); });
  window.addEventListener('pagehide', pause);
  draw();
})();`;

export const PLAYER_SCRIPT_HASH = "NtY9PR+4lqxZoz9e6U99lIy0yFwFNLp7mELkSmedtZM=";

const PLAYER_CSS = `
body.export-player{background:#ededeb;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;gap:16px;min-height:240px}
.export-stage{container-type:size;width:min(100%,calc((100dvh - 116px)*16/9));aspect-ratio:16/9;flex:none;position:relative;overflow:hidden;background:#fff;box-shadow:0 0 0 1px #0000000d}
.export-controls{display:flex;align-items:center;gap:8px;flex:none;color:#252525;max-width:100%}.export-controls button{border:1px solid #d9d9d5;border-radius:10px;background:#fff;color:#252525;min-height:48px;padding:0 18px;font:500 14px Inter,Arial,sans-serif;cursor:pointer;white-space:nowrap}.export-controls button:hover:not(:disabled){background:#f8f8f6}.export-controls button:disabled{opacity:.36;cursor:default}.export-controls button:focus-visible{outline:3px solid #2858db;outline-offset:3px}.export-controls #play{min-width:86px;background:#252525;color:#fff;border-color:#252525}.export-controls #play:hover{background:#424242}#slide-count{font-size:12px;font-variant-numeric:tabular-nums;padding:0 12px;white-space:nowrap}
@media(max-width:480px){body.export-player{padding:12px;gap:14px}.export-controls{gap:6px}.export-controls button{padding:0 12px}.export-controls #play{min-width:74px}#slide-count{padding:0 4px;font-size:11px}}
@media print{html,body{height:auto;overflow:visible}body.export-player{display:block;padding:0;background:#fff}.export-stage{width:100%;height:auto;aspect-ratio:auto;overflow:visible;box-shadow:none}.slide,.slide[hidden]{display:grid;height:auto;aspect-ratio:16/9;break-after:page}.slide.layout-statement{display:flex}.slide *{animation:none!important}.export-controls{display:none}}
`;

export function exportDeckHtml(deck: Deck, assets: ImageAsset[], theme: Theme): string {
  const checkedDeck = deckSchema.parse(deck);
  const checkedAssets = validateRenderAssets(assets);
  validateTheme(theme);
  if (!validateDeckAssets(checkedDeck, checkedAssets)) throw new Error("Some slides have missing or incompatible photos. Check their images before downloading.");
  const slides = checkedDeck.slides.map((slide, index) => {
    const markup = renderSlideMarkup(slide, checkedAssets, theme, index, checkedDeck.slides.length);
    return index ? markup.replace('<section ', '<section hidden ') : markup;
  }).join("\n");
  const csp = `default-src 'none'; img-src data:; font-src data:; style-src 'unsafe-inline'; script-src 'sha256-${PLAYER_SCRIPT_HASH}'; base-uri 'none'; form-action 'none'`;
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="${csp}"><meta name="generator" content="Folio"><title>${escapeHtml(checkedDeck.title)}</title><style>${SLIDE_CSS}${imageStyles(checkedAssets)}${PLAYER_CSS}</style></head><body class="export-player player-paused"><main class="export-stage" aria-label="${escapeHtml(checkedDeck.title)}">${slides}</main><nav class="export-controls" aria-label="Presentation controls"><button id="previous" type="button" aria-label="Previous slide" disabled>Previous</button><button id="play" type="button" aria-pressed="false">Play</button><button id="next" type="button" aria-label="Next slide">Next</button><span id="slide-count" aria-live="polite" aria-atomic="true">01 / ${String(checkedDeck.slides.length).padStart(2, "0")}</span></nav><script>${PLAYER_SCRIPT}</script></body></html>`;
}
