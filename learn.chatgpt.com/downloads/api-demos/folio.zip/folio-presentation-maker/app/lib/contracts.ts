import { z } from "zod";

export const MAX_IMAGES = 6;
export const MAX_SLIDES = 20;
// Allows a full 20-slide result even when Unicode copy is JSON-escaped.
export const MAX_RESULT_BYTES = 128 * 1024;
const slideIdPattern = `^slide-(?:${Array.from({length:MAX_SLIDES}, (_,index)=>index+1).join("|")})$`;
const slideIdSchema = z.string().regex(new RegExp(slideIdPattern));
export const MAX_IMAGE_BYTES = 320_000;
export const MAX_REQUEST_BYTES = 2_800_000;
export const themes = ["paper", "night", "cobalt"] as const;
export const layouts = ["cover", "split", "statement", "gallery", "closing"] as const;
export const motions = ["fade", "rise", "pan", "none"] as const;
export type Theme = typeof themes[number];
const text = (max: number) => z.string().max(max);
export const assetSchema = z.object({
  id: z.string().regex(/^image-[1-6]$/), name: z.string().min(1).max(100),
  dataUrl: z.string().max(430_000).regex(/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/),
  width: z.number().int().min(1).max(1800), height: z.number().int().min(1).max(1800),
}).strict();
export type ImageAsset = z.infer<typeof assetSchema>;
export const slideSchema = z.object({
  id: slideIdSchema, layout: z.enum(layouts),
  eyebrow: text(45), title: z.string().min(1).max(90), body: text(240),
  imageIds: z.array(z.string().regex(/^image-[1-6]$/)).max(3),
  notes: text(500), motion: z.enum(motions), duration: z.number().int().min(3).max(12),
}).strict();
export type Slide = z.infer<typeof slideSchema>;
export const deckSchema = z.object({title:z.string().min(1).max(80),slides:z.array(slideSchema).min(4).max(MAX_SLIDES)}).strict();
export type Deck = z.infer<typeof deckSchema>;
export const historyEntrySchema = z.object({role:z.enum(["user","assistant"]),content:z.string().min(1).max(1500)}).strict();
export type HistoryEntry = z.infer<typeof historyEntrySchema>;
export const createRequestSchema = z.object({
  brief:z.string().trim().min(3).max(1500), assets:z.array(assetSchema).min(1).max(MAX_IMAGES),
  theme:z.enum(themes), previousDeck:deckSchema.nullable().optional(),
  history:z.array(historyEntrySchema).max(12).optional(),
  selectedSlideId:slideIdSchema.nullable().optional(),
}).strict().superRefine((value,context)=>{
  if(value.selectedSlideId && !value.previousDeck?.slides.some(slide=>slide.id===value.selectedSlideId)) {
    context.addIssue({code:z.ZodIssueCode.custom,path:["selectedSlideId"],message:"Select a slide from the current presentation."});
  }
});
export type CreateRequest = z.infer<typeof createRequestSchema>;
export const resultSchema = z.object({
  status:z.enum(["complete","answer","clarification","off_topic"]), message:text(800), deck:deckSchema.nullable(),
}).strict().superRefine((v,c)=>{if((v.status==="complete")!==!!v.deck)c.addIssue({code:z.ZodIssueCode.custom,message:"A completed result requires a deck."});});
export type GenerationResult = z.infer<typeof resultSchema>;
const str=(max:number,min=0)=>({type:"string",minLength:min,maxLength:max});
export const deckJsonSchema = {
  type:"object",additionalProperties:false,required:["title","slides"],properties:{
    title:str(80,1),slides:{type:"array",minItems:4,maxItems:MAX_SLIDES,items:{
      type:"object",additionalProperties:false,
      required:["id","layout","eyebrow","title","body","imageIds","notes","motion","duration"],
      properties:{id:{type:"string",pattern:slideIdPattern},layout:{type:"string",enum:[...layouts]},eyebrow:str(45),title:str(90,1),body:str(240),imageIds:{type:"array",maxItems:3,items:{type:"string",pattern:"^image-[1-6]$"}},notes:str(500),motion:{type:"string",enum:[...motions]},duration:{type:"integer",minimum:3,maximum:12}},
    }},
  },
};
export const resultJsonSchema={type:"object",additionalProperties:false,required:["status","message","deck"],properties:{status:{type:"string",enum:["complete","answer","clarification","off_topic"]},message:str(800),deck:{anyOf:[deckJsonSchema,{type:"null"}]}}};

export function validateDeckAssets(deck:Deck,assets:ImageAsset[]): boolean {
  const ids=new Set(assets.map(a=>a.id));
  return ids.size===assets.length && new Set(deck.slides.map(s=>s.id)).size===deck.slides.length
    && deck.slides.every(s=>new Set(s.imageIds).size===s.imageIds.length && s.imageIds.every(id=>ids.has(id))
      && ((s.layout==="cover"||s.layout==="split") ? s.imageIds.length===1
        : s.layout==="gallery" ? s.imageIds.length>=2&&s.imageIds.length<=3
        : s.layout==="statement" ? s.imageIds.length===0
        : s.imageIds.length<=1));
}
