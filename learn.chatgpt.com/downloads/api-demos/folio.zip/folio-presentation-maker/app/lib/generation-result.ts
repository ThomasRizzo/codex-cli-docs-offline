import type { GenerationSessionState } from "./agents.ts";
import { createRequestSchema, resultSchema, MAX_IMAGE_BYTES, MAX_SLIDES, type CreateRequest, type Deck, type ImageAsset, type Slide } from "./contracts.ts";

/** Validate the JPEG container and dimensions; the browser re-encodes uploads before sending. */
function jpegDimensions(bytes: Uint8Array): { width: number; height: number } {
  const invalid = () => { throw new Error("An image is not a complete supported JPEG. Upload it again."); };
  const word = (at: number) => bytes[at] * 256 + bytes[at + 1];
  if (bytes.length < 20 || bytes[0] !== 255 || bytes[1] !== 216) return invalid();
  let offset = 2, width = 0, height = 0, scan = false, quantization = false, huffman = false;
  const components = new Set<number>();
  while (offset < bytes.length) {
    if (bytes[offset++] !== 255) return invalid();
    while (bytes[offset] === 255) offset++;
    const marker = bytes[offset++];
    if (marker === 217) {
      if (!scan || !width || !quantization || !huffman || offset !== bytes.length) return invalid();
      return { width, height };
    }
    if (![192, 194, 196, 218, 219, 221, 254].includes(marker) && !(marker >= 224 && marker <= 239)) return invalid();
    if (offset + 2 > bytes.length) return invalid();
    const length = word(offset), end = offset + length;
    if (length < 2 || end > bytes.length) return invalid();
    if (marker === 192 || marker === 194) {
      const count = bytes[offset + 7];
      if (width || ![1, 3].includes(count) || length !== 8 + 3 * count || bytes[offset + 2] !== 8) return invalid();
      height = word(offset + 3); width = word(offset + 5);
      if (!width || !height || width > 1800 || height > 1800) return invalid();
      for (let at = offset + 8; at < end; at += 3) {
        const id = bytes[at], sample = bytes[at + 1];
        if (components.has(id) || !(sample >> 4) || (sample >> 4) > 4 || !(sample & 15) || (sample & 15) > 4 || bytes[at + 2] > 3) return invalid();
        components.add(id);
      }
    }
    if (marker === 219) {
      let at = offset + 2;
      while (at < end) {
        const table = bytes[at++], precision = table >> 4;
        if (precision > 1 || (table & 15) > 3) return invalid();
        at += precision ? 128 : 64;
      }
      if (at !== end || length === 2) return invalid();
      quantization = true;
    }
    if (marker === 196) {
      let at = offset + 2;
      while (at < end) {
        const table = bytes[at++];
        if ((table >> 4) > 1 || (table & 15) > 3 || at + 16 > end) return invalid();
        let symbols = 0;
        for (let i = 0; i < 16; i++) symbols += bytes[at++];
        if (!symbols || symbols > 256) return invalid();
        at += symbols;
      }
      if (at !== end || length === 2) return invalid();
      huffman = true;
    }
    if (marker === 221 && length !== 4) return invalid();
    if (marker === 218) {
      const count = bytes[offset + 2], selected = new Set<number>();
      if (!width || !quantization || !huffman || !count || count > components.size || length !== 6 + 2 * count) return invalid();
      for (let at = offset + 3; at < end - 3; at += 2) {
        if (!components.has(bytes[at]) || selected.has(bytes[at]) || (bytes[at + 1] >> 4) > 3 || (bytes[at + 1] & 15) > 3) return invalid();
        selected.add(bytes[at]);
      }
      if (bytes[end - 3] > bytes[end - 2] || bytes[end - 2] > 63 || (bytes[end - 1] >> 4) > 13 || (bytes[end - 1] & 15) > 13) return invalid();
      scan = true; offset = end;
      const start = offset;
      while (offset < bytes.length) {
        if (bytes[offset] !== 255) { offset++; continue; }
        if (bytes[offset + 1] === 0 || (bytes[offset + 1] >= 208 && bytes[offset + 1] <= 215)) { offset += 2; continue; }
        break;
      }
      if (offset === start) return invalid();
    } else offset = end;
  }
  return invalid();
}

export function validateAssets(assets: ImageAsset[]): void {
  if (new Set(assets.map(asset => asset.id)).size !== assets.length) throw new Error("Each image needs a unique ID. Upload the images again.");
  for (const asset of assets) {
    const encoded = asset.dataUrl.slice("data:image/jpeg;base64,".length);
    let binary: string;
    try { binary = atob(encoded); } catch { throw new Error("An image could not be decoded. Upload it again."); }
    if (!binary.length || binary.length > MAX_IMAGE_BYTES || btoa(binary) !== encoded) throw new Error("An image is invalid or too large. Upload it again.");
    const dimensions = jpegDimensions(Uint8Array.from(binary, character => character.charCodeAt(0)));
    if (dimensions.width !== asset.width || dimensions.height !== asset.height) throw new Error("An image's dimensions do not match its contents. Upload it again.");
  }
}

export function validSlideAssets(slide: Slide, assetIds: string[]): boolean {
  return new Set(slide.imageIds).size === slide.imageIds.length
    && slide.imageIds.every(id => assetIds.includes(id))
    && (["cover", "split"].includes(slide.layout) ? slide.imageIds.length === 1
      : slide.layout === "gallery" ? slide.imageIds.length >= 2 && slide.imageIds.length <= 3
      : slide.layout === "statement" ? slide.imageIds.length === 0 : slide.imageIds.length <= 1);
}
export function validDeckAssets(deck: Deck, assetIds: string[]): boolean {
  return new Set(deck.slides.map(slide => slide.id)).size === deck.slides.length
    && deck.slides.every(slide => validSlideAssets(slide, assetIds));
}
export function validateGenerationRequest(input: unknown): CreateRequest {
  const parsed = createRequestSchema.safeParse(input);
  if (!parsed.success) throw new Error("Check your images and brief, then try again.");
  validateAssets(parsed.data.assets);
  if (parsed.data.previousDeck && !validDeckAssets(parsed.data.previousDeck, parsed.data.assets.map(asset => asset.id))) throw new Error("The previous presentation references missing images. Start a new deck with these images.");
  return parsed.data;
}

// This supplied validator checks the actual file written by the agent. A matching
// receipt demonstrates consistency, not factual accuracy of the presentation.
const VALIDATOR = `import json, hashlib, pathlib
root = pathlib.Path('/workspace')
manifest = json.loads((root / 'manifest.json').read_text())
deck = json.loads((root / 'deck.json').read_text())
def text(value, maximum, minimum=0):
    assert isinstance(value, str) and minimum <= len(value.encode('utf-16-le')) // 2 <= maximum
def keys(value, expected):
    assert isinstance(value, dict) and set(value) == set(expected)
keys(deck, ['title', 'slides'])
text(deck['title'], 80, 1)
assert isinstance(deck['slides'], list) and 4 <= len(deck['slides']) <= ${MAX_SLIDES}
asset_ids = {asset['id'] for asset in manifest['assets']}
for asset in manifest['assets']:
    image = (root / 'assets' / (asset['id'] + '.jpg')).read_bytes()
    assert image[:2] == b'\\xff\\xd8' and image[-2:] == b'\\xff\\xd9'
seen = set()
for slide in deck['slides']:
    keys(slide, ['id', 'layout', 'eyebrow', 'title', 'body', 'imageIds', 'notes', 'motion', 'duration'])
    assert slide['id'] in {'slide-' + str(n) for n in range(1, ${MAX_SLIDES + 1})} and slide['id'] not in seen
    seen.add(slide['id'])
    assert slide['layout'] in ['cover', 'split', 'statement', 'gallery', 'closing']
    for field, maximum, minimum in [('eyebrow',45,0), ('title',90,1), ('body',240,0), ('notes',500,0)]:
        text(slide[field], maximum, minimum)
    refs = slide['imageIds']
    assert isinstance(refs,list) and len(refs) <= 3 and all(isinstance(ref,str) for ref in refs)
    assert len(set(refs)) == len(refs) and set(refs) <= asset_ids
    if slide['layout'] in ['cover','split']: assert len(refs) == 1
    elif slide['layout'] == 'gallery': assert 2 <= len(refs) <= 3
    elif slide['layout'] == 'statement': assert len(refs) == 0
    else: assert len(refs) <= 1
    assert slide['motion'] in ['fade','rise','pan','none']
    assert type(slide['duration']) is int and 3 <= slide['duration'] <= 12
canonical = json.dumps(deck, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
print(json.dumps({'folio_validation': {'sha256': hashlib.sha256(canonical).hexdigest(), 'slides': len(deck['slides'])}}))
`;

function base64(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let binary = "";
  for (let at = 0; at < bytes.length; at += 8192) binary += String.fromCharCode(...bytes.subarray(at, at + 8192));
  return btoa(binary);
}

export function makeAgentInput(request: CreateRequest) {
  validateGenerationRequest(request);
  const manifest = {
    brief: request.brief, theme: request.theme,
    assets: request.assets.map(({ id, name, width, height }) => ({ id, name, width, height })),
    previousDeck: request.previousDeck ?? null, history: request.history ?? [], selectedSlideId: request.selectedSlideId ?? null,
  };
  return {
    files: [
      { type: "inline", path: "/workspace/manifest.json", data: base64(JSON.stringify(manifest)) },
      { type: "inline", path: "/workspace/validate_deck.py", data: base64(VALIDATOR) },
      ...request.assets.map(asset => ({ type: "inline", path: `/workspace/assets/${asset.id}.jpg`, data: asset.dataUrl.slice("data:image/jpeg;base64,".length) })),
    ],
    input: [{ role: "user", content: [
      { type: "input_text", text: JSON.stringify(manifest) },
      ...request.assets.flatMap(asset => [
        { type: "input_text", text: `The following supplied image has asset ID ${asset.id}.` },
        { type: "input_image", image_url: asset.dataUrl },
      ]),
    ] }],
  };
}

/** Stable JSON for the schema's string keys, strings, arrays, and integers. */
export function canonicalJSON(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJSON).join(",")}]`;
  if (value && typeof value === "object") return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonicalJSON((value as Record<string, unknown>)[key])}`).join(",")}}`;
  return JSON.stringify(value);
}

export async function generationResult(state: Pick<GenerationSessionState, "result" | "commands">, assetIds: string[]) {
  const parsed = resultSchema.safeParse(state.result);
  if (!parsed.success || (parsed.data.deck && !validDeckAssets(parsed.data.deck, assetIds))) return null;
  let steps = 0;
  if (parsed.data.status === "complete" && parsed.data.deck) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalJSON(parsed.data.deck)));
    const expected = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
    steps = state.commands.filter(command => {
      if (command.status !== "completed" || command.exitCode !== 0 || !command.command.includes("/workspace/validate_deck.py")) return false;
      return command.output.split("\n").some(line => {
        if (line.length > 500) return false;
        try {
          const receipt = JSON.parse(line)?.folio_validation;
          return receipt?.sha256 === expected && receipt?.slides === parsed.data.deck!.slides.length;
        } catch { return false; }
      });
    }).length;
    if (!steps) return null;
  }
  return { result: parsed.data, execution: { steps, verified: parsed.data.status === "complete" && steps > 0 } };
}
