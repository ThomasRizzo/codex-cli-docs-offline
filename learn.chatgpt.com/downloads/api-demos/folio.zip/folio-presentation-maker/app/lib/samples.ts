import { type Deck, type ImageAsset, type Theme } from "./contracts.ts";
import { normalizeImageFiles } from "./images.ts";

export interface SampleCollection {
  id: string;
  title: string;
  description: string;
  brief: string;
  theme: Theme;
  deck: Deck;
  images: { url: string; name: string; credit: string; sourceUrl: string }[];
}

export const SAMPLE_COLLECTIONS: SampleCollection[] = [
  {
    id: "form-and-light", title: "Form & light", description: "An architectural study. AI-generated sample photos.", theme: "paper",
    brief: "Create a short editorial presentation about form and light in architecture, using these three sample photographs. Let the images lead; use concise, thoughtful captions about geometry, repetition, material and shadow. These are AI-generated architectural studies, not a real building or a documented project. Do not invent a location, architect, or project claims.",
    images: [
      { url: "/samples/architecture-1.jpg", name: "Curved white facade against blue sky", credit: "AI-generated sample image · OpenAI", sourceUrl: "/samples/CREDITS.md" },
      { url: "/samples/architecture-2.jpg", name: "Concrete corridor with diagonal light", credit: "AI-generated sample image · OpenAI", sourceUrl: "/samples/CREDITS.md" },
      { url: "/samples/architecture-3.jpg", name: "Pale concrete curves and dark glass", credit: "AI-generated sample image · OpenAI", sourceUrl: "/samples/CREDITS.md" },
    ],
    deck: {
      title: "Form & light",
      slides: [
        { id: "slide-1", layout: "cover", eyebrow: "An architectural study", title: "Form & light.", body: "Three perspectives on the spaces we notice, and the details that stay with us.", imageIds: ["image-1"], notes: "Starter deck using AI-generated architectural sample photographs. These images do not document a real project.", motion: "pan", duration: 7 },
        { id: "slide-2", layout: "split", eyebrow: "01 — Rhythm", title: "A quiet kind of repetition.", body: "Columns set a rhythm. Light gives it a different pace.", imageIds: ["image-2"], notes: "Observe the repeated structural elements and the contrast between light and shade.", motion: "rise", duration: 7 },
        { id: "slide-3", layout: "statement", eyebrow: "A closer look", title: "Light is a material, too.", body: "It reveals edges, softens surfaces, and changes how a space feels.", imageIds: [], notes: "A visual observation rather than a claim about the building's design process.", motion: "fade", duration: 6 },
        { id: "slide-4", layout: "gallery", eyebrow: "02 — Perspectives", title: "One idea. Many angles.", body: "A curve, a corridor, a meeting of surfaces. Each frame invites a slower look.", imageIds: ["image-1", "image-2", "image-3"], notes: "Three separate generated studies in geometry, material and light.", motion: "fade", duration: 8 },
        { id: "slide-6", layout: "cover", eyebrow: "03 — Shape", title: "Start with the outline.", body: "Trace the curved edge against the sky. Notice where it gives way to straight lines.", imageIds: ["image-1"], notes: "Compare the sweeping lower edge with the straight vertical fins. Describe the visible geometry without attributing an architectural intention.", motion: "pan", duration: 8 },
        { id: "slide-7", layout: "gallery", eyebrow: "Two geometries", title: "Curves meet a grid.", body: "Compare the broad sweeps of concrete with the narrow, repeated lines of glass.", imageIds: ["image-1", "image-3"], notes: "These generated studies place curved forms beside straight divisions. Look for a similar contrast in both frames; they do not establish a shared real location.", motion: "fade", duration: 8 },
        { id: "slide-8", layout: "split", eyebrow: "04 — Depth", title: "A line that leads somewhere.", body: "Columns, floor joints, and the ceiling draw the eye toward a small opening.", imageIds: ["image-2"], notes: "Follow the converging lines toward the doorway. This is an observation about the image composition, not the function of a real building.", motion: "rise", duration: 7 },
        { id: "slide-9", layout: "statement", eyebrow: "A visual cue", title: "Depth begins with overlap.", body: "An edge in front. A surface behind. A darker interval between.", imageIds: [], notes: "Pause on the visual cues that make a flat image feel three-dimensional. Connect this idea to the overlapping surfaces in the exterior studies.", motion: "none", duration: 5 },
        { id: "slide-10", layout: "split", eyebrow: "05 — Light", title: "Shadow marks the change.", body: "Sharp diagonals cross pale surfaces, separating one plane from the next.", imageIds: ["image-1"], notes: "Point to the diagonal shadow boundaries on the concrete. Avoid making claims about time of day, orientation, or climate.", motion: "fade", duration: 7 },
        { id: "slide-11", layout: "gallery", eyebrow: "Surface & shadow", title: "Patterns, then contours.", body: "Light repeats a pattern in the corridor and traces the thickness of the curved edge.", imageIds: ["image-2", "image-3"], notes: "Compare the repeated bands of shadow in the corridor with the shaded underside of the curved form. The two frames illustrate different effects of light.", motion: "pan", duration: 8 },
        { id: "slide-12", layout: "cover", eyebrow: "06 — Material", title: "The surface comes into focus.", body: "Small marks in the concrete sit beside smooth, dark reflections.", imageIds: ["image-3"], notes: "Look at the contrast between the visibly textured pale surface and the dark glazing. Do not infer a construction method or material specification.", motion: "rise", duration: 7 },
        { id: "slide-13", layout: "split", eyebrow: "Reflected color", title: "Blue, borrowed by the glass.", body: "The sky appears twice: as open color above the curve, and as a softer reflection beside it.", imageIds: ["image-3"], notes: "Draw attention to the blue reflected in the glazing and the open sky above the concrete. Keep the comparison within what is visible in the sample image.", motion: "fade", duration: 7 },
        { id: "slide-14", layout: "gallery", eyebrow: "07 — Composition", title: "Read the frames as a sequence.", body: "An outer silhouette. A view into depth. A closer look at the surface.", imageIds: ["image-1", "image-2", "image-3"], notes: "Use the three images as a visual sequence, from overall form to spatial depth to surface detail. They are generated studies, not a documented route through a building.", motion: "fade", duration: 9 },
        { id: "slide-15", layout: "closing", eyebrow: "Three ways of looking", title: "Outline. Depth. Detail.", body: "Look for the shape, follow the light, then return to the smallest mark.", imageIds: [], notes: "A text-only synthesis before the final invitation. Recap the three ways of reading the images rather than introducing a new claim.", motion: "none", duration: 6 },
        { id: "slide-5", layout: "closing", eyebrow: "The takeaway", title: "Notice the space between.", body: "Good spaces give us something to look at, and room to look again.", imageIds: ["image-3"], notes: "End on a simple invitation to observe.", motion: "rise", duration: 7 },
      ],
    },
  },
  {
    id: "waterline", title: "Waterline", description: "A coastal visual essay. AI-generated sample photos.", theme: "cobalt",
    brief: "Build a short, image-led visual essay about the meeting of land and sea. Use clear, poetic but restrained copy, varied layouts, and gentle motion. These are AI-generated sample coast photographs, not a real trip or named location. Avoid inventing destinations, dates, distances, or personal experiences.",
    images: [
      { url: "/samples/coast-1.jpg", name: "Aerial shoreline with cobalt water and pale sand", credit: "AI-generated sample image · OpenAI", sourceUrl: "/samples/CREDITS.md" },
      { url: "/samples/coast-2.jpg", name: "Sculptural rock and turquoise surf", credit: "AI-generated sample image · OpenAI", sourceUrl: "/samples/CREDITS.md" },
      { url: "/samples/coast-3.jpg", name: "Sea foam patterns above a submerged rock", credit: "AI-generated sample image · OpenAI", sourceUrl: "/samples/CREDITS.md" },
    ],
    deck: {
      title: "Waterline",
      slides: [
        { id: "slide-1", layout: "cover", eyebrow: "A coastal study", title: "At the water’s edge.", body: "A visual essay in movement, texture, and the meeting of land and sea.", imageIds: ["image-1"], notes: "Starter deck using AI-generated coastal sample photographs. No real location or itinerary is implied.", motion: "pan", duration: 7 },
        { id: "slide-2", layout: "split", eyebrow: "01 — Contrast", title: "Stillness meets motion.", body: "Dark rock holds its shape as each wave draws a new line around it.", imageIds: ["image-2"], notes: "Point out the visual contrast between solid rock and moving water.", motion: "rise", duration: 7 },
        { id: "slide-3", layout: "statement", eyebrow: "A change of pace", title: "There is no fixed edge.", body: "The shoreline redraws itself, one wave at a time.", imageIds: [], notes: "A concise transition between the wider scene and close details.", motion: "fade", duration: 6 },
        { id: "slide-4", layout: "gallery", eyebrow: "02 — Texture", title: "From a distance. Up close.", body: "Broad curves become intricate patterns. The scale changes; the rhythm stays.", imageIds: ["image-1", "image-3"], notes: "Compare aerial composition with the close texture of foam and water.", motion: "fade", duration: 8 },
        { id: "slide-5", layout: "closing", eyebrow: "Keep looking", title: "Follow the next line.", body: "A small invitation to slow down and see what changes.", imageIds: ["image-3"], notes: "Close the visual essay with a detail of the water.", motion: "pan", duration: 7 },
      ],
    },
  },
];

export async function loadSampleCollection(id: string): Promise<{ deck: Deck; assets: ImageAsset[]; theme: Theme; brief: string }> {
  const sample = SAMPLE_COLLECTIONS.find(collection => collection.id === id);
  if (!sample) throw new Error("This sample collection could not be found.");
  const files = await Promise.all(sample.images.map(async image => {
    let response: Response;
    try { response = await fetch(image.url); }
    catch { throw new Error("The sample photos could not be loaded. Please try again."); }
    if (!response.ok) throw new Error("The sample photos could not be loaded. Please try again.");
    const blob = await response.blob();
    return new File([blob], image.name, { type: "image/jpeg" });
  }));
  return { deck: structuredClone(sample.deck), assets: await normalizeImageFiles(files), theme: sample.theme, brief: sample.brief };
}
