import { MAX_RESULT_BYTES, MAX_SLIDES, deckSchema, slideSchema, type Slide } from "./contracts.ts";
import { validSlideAssets } from "./generation-result.ts";

export type DeckDraft = { title: string; slides: Slide[] };
type Node = { value?: unknown; end: number; complete: boolean };

/** Parse a bounded JSON prefix. Only closed array elements become visible. */
export function parsePartialDeck(source: string, assetIds: string[]): DeckDraft | null {
  if (source.length > MAX_RESULT_BYTES || new TextEncoder().encode(source).length > MAX_RESULT_BYTES) return null;
  const space = (at: number) => { while (at < source.length && /[\t\n\r ]/.test(source[at])) at++; return at; };
  const bad = () => { throw new Error("Invalid JSON prefix"); };
  function parse(at: number, depth = 0): Node {
    if (depth > 10) return bad();
    at = space(at);
    if (at === source.length) return { end: at, complete: false };
    const start = at, char = source[at++];
    if (char === '"') {
      while (at < source.length) {
        if (source[at] === '"') return { value: JSON.parse(source.slice(start, ++at)), end: at, complete: true };
        if (source.charCodeAt(at) < 32) return bad();
        if (source[at++] === "\\") at++;
      }
      return { end: source.length, complete: false };
    }
    if (char === "{" || char === "[") {
      const object: Record<string, unknown> = Object.create(null), array: unknown[] = [], seen = new Set<string>();
      const isObject = char === "{", close = isObject ? "}" : "]", value = isObject ? object : array;
      at = space(at);
      if (source[at] === close) return { value, end: at + 1, complete: true };
      for (let count = 0; count < 100; count++) {
        if (at === source.length) return { value, end: at, complete: false };
        let key = "";
        if (isObject) {
          if (source[at] !== '"') return bad();
          const name = parse(at, depth + 1);
          if (!name.complete) return { value, end: name.end, complete: false };
          key = name.value as string;
          if (seen.has(key)) return bad();
          seen.add(key); at = space(name.end);
          if (at === source.length) return { value, end: at, complete: false };
          if (source[at++] !== ":") return bad();
        }
        const child = parse(at, depth + 1);
        if (isObject && child.value !== undefined) object[key] = child.value;
        else if (!isObject && child.complete) array.push(child.value);
        if (!child.complete) return { value, end: child.end, complete: false };
        at = space(child.end);
        if (at === source.length) return { value, end: at, complete: false };
        if (source[at] === close) return { value, end: at + 1, complete: true };
        if (source[at++] !== ",") return bad();
        at = space(at);
        if (source[at] === close) return bad();
      }
      return bad();
    }
    const tail = source.slice(start), token = tail.match(/^(?:true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/)?.[0];
    if (!token || start + token.length === source.length) return { end: source.length, complete: false };
    if (!/[\s,}\]]/.test(source[start + token.length])) return bad();
    return { value: JSON.parse(token), end: start + token.length, complete: true };
  }
  try {
    const parsed = parse(0);
    if (parsed.complete && space(parsed.end) !== source.length) return null;
    const root = parsed.value as Record<string, unknown> | undefined;
    if (!root || root.status !== "complete" || Object.keys(root).some(key => !["status", "message", "deck"].includes(key))) return null;
    const deck = root.deck as Record<string, unknown> | undefined;
    if (!deck || typeof deck !== "object" || Object.keys(deck).some(key => !["title", "slides"].includes(key))) return null;
    const title = deckSchema.shape.title.safeParse(deck.title);
    if (!title.success || !Array.isArray(deck.slides) || deck.slides.length > MAX_SLIDES) return null;
    const slides: Slide[] = [], seen = new Set<string>();
    for (const item of deck.slides) {
      const slide = slideSchema.safeParse(item);
      if (!slide.success || seen.has(slide.data.id) || !validSlideAssets(slide.data, assetIds)) return null;
      seen.add(slide.data.id); slides.push(slide.data);
    }
    return { title: title.data, slides };
  } catch { return null; }
}
