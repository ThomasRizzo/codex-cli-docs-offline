import { MAX_IMAGES, MAX_IMAGE_BYTES, type ImageAsset } from "./contracts.ts";

export const MAX_SOURCE_IMAGE_BYTES = 15 * 1024 * 1024;
const MAX_SIDE = 1800;

/** Read the file signature rather than trusting the browser's supplied MIME type. */
export function detectImageType(bytes: Uint8Array): "image/jpeg" | "image/png" | "image/webp" | null {
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if ([137, 80, 78, 71, 13, 10, 26, 10].every((n, i) => bytes[i] === n)) return "image/png";
  if (String.fromCharCode(...bytes.slice(0, 4)) === "RIFF" && String.fromCharCode(...bytes.slice(8, 12)) === "WEBP") return "image/webp";
  return null;
}

function toJpeg(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("This image could not be prepared. Please try another photo.")), "image/jpeg", quality));
}

function toDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("This image could not be read. Please try another photo."));
    reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("This image could not be read."));
    reader.readAsDataURL(blob);
  });
}

export async function normalizeImageFiles(files: File[] | FileList): Promise<ImageAsset[]> {
  const selected = Array.from(files);
  if (!selected.length) throw new Error("Choose at least one image.");
  if (selected.length > MAX_IMAGES) throw new Error(`Choose up to ${MAX_IMAGES} images at a time.`);
  const assets: ImageAsset[] = [];
  // Sequential decoding keeps large source images from competing for canvas memory.
  for (const [index, file] of selected.entries()) {
    const name = file.name.trim().slice(0, 100) || `Photo ${index + 1}`;
    if (!file.size) throw new Error(`${name} is empty. Choose another image.`);
    if (file.size > MAX_SOURCE_IMAGE_BYTES) throw new Error(`${name} is too large. Each image must be 15 MB or smaller.`);
    const type = detectImageType(new Uint8Array(await file.slice(0, 12).arrayBuffer()));
    if (!type) throw new Error(`${name} is not a supported photo. Choose JPEG, PNG, or WebP.`);
    let bitmap: ImageBitmap;
    try { bitmap = await createImageBitmap(new Blob([file], { type })); }
    catch { throw new Error(`${name} could not be opened. Try another JPEG, PNG, or WebP image.`); }
    const canvas = document.createElement("canvas");
    try {
      if (!bitmap.width || !bitmap.height || bitmap.width * bitmap.height > 100_000_000) throw new Error(`${name} has unsupported dimensions. Try a smaller image.`);
      let scale = Math.min(1, MAX_SIDE / Math.max(bitmap.width, bitmap.height));
      let output: Blob | null = null;
      for (let attempt = 0; attempt < 7 && !output; attempt++) {
        canvas.width = Math.max(1, Math.round(bitmap.width * scale));
        canvas.height = Math.max(1, Math.round(bitmap.height * scale));
        const context = canvas.getContext("2d");
        if (!context) throw new Error("Your browser could not prepare this image. Try a different browser.");
        context.fillStyle = "#fff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        for (const quality of [0.86, 0.74, 0.62, 0.5]) {
          const candidate = await toJpeg(canvas, quality);
          if (candidate.size <= MAX_IMAGE_BYTES) { output = candidate; break; }
        }
        scale *= 0.78;
      }
      if (!output) throw new Error(`${name} could not be reduced enough. Please try a smaller photo.`);
      assets.push({ id: `image-${index + 1}`, name, dataUrl: await toDataUrl(output), width: canvas.width, height: canvas.height });
    } finally {
      bitmap.close();
      canvas.width = 1;
      canvas.height = 1;
    }
  }
  return assets;
}
