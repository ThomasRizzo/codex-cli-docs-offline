"use client";

import { useEffect, useMemo, useRef, useState, type ChangeEvent, type CSSProperties } from "react";
import Link from "next/link";
import { ArrowDownTrayIcon, ArrowLeftIcon, ArrowRightIcon, ArrowUpIcon, ArrowUturnLeftIcon, Bars3Icon, ChevronDownIcon, PauseIcon, PhotoIcon, PlayIcon, QuestionMarkCircleIcon, Square2StackIcon, StopIcon, XMarkIcon } from "@heroicons/react/16/solid";
import { MAX_SLIDES, deckSchema, validateDeckAssets, type Deck, type ImageAsset, type Slide, type Theme } from "./lib/contracts";
import { normalizeImageFiles } from "./lib/images";
import { exportDeckHtml } from "./lib/export";
import { SAMPLE_COLLECTIONS, loadSampleCollection } from "./lib/samples";
import SlidePreview from "./components/slide-preview";
import SlideEditor from "./components/slide-editor";
import ConversationPanel, { type ChatTurn } from "./components/conversation-panel";
import { useDeckGeneration } from "./components/use-deck-generation";

const ICON = "size-4 shrink-0 fill-current";
const SAMPLE = SAMPLE_COLLECTIONS[0];
type Panel = "chat" | "images" | "edit";
const PANELS: { id: Panel; label: string }[] = [{ id: "chat", label: "Chat" }, { id: "edit", label: "Slide details" }, { id: "images", label: "Images" }];
const INSPECTOR_PANELS = PANELS.filter(item => item.id !== "chat");
type Revision = { turns: ChatTurn[]; deck: Deck; assets: ImageAsset[]; theme: Theme; selectedId: string; collectionId: string; isSample: boolean; edited: boolean };
const THEME_NAMES: Record<Theme, string> = { paper: "Paper", night: "Night", cobalt: "Cobalt" };
function TouchTarget() { return <span className="touch-target" aria-hidden="true" />; }

export default function Home() {
  const [deck, setDeck] = useState<Deck>(SAMPLE.deck);
  const [assets, setAssets] = useState<ImageAsset[]>([]);
  const [deckAssets, setDeckAssets] = useState<ImageAsset[]>([]);
  const [theme, setTheme] = useState<Theme>(SAMPLE.theme);
  const [brief, setBrief] = useState("");
  const [collectionId, setCollectionId] = useState(SAMPLE.id);
  const [deckCollectionId, setDeckCollectionId] = useState(SAMPLE.id);
  const [selectedId, setSelectedId] = useState(SAMPLE.deck.slides[0].id);
  const [panel, setPanel] = useState<Panel>("chat");
  const [inspectorPanel, setInspectorPanel] = useState<"edit" | "images">("edit");
  const [turns, setTurns] = useState<ChatTurn[]>([]);
  const [revisions, setRevisions] = useState<Revision[]>([]);
  const [previewMode, setPreviewMode] = useState<"current" | "draft">("current");
  const [isSample, setIsSample] = useState(true);
  const [edited, setEdited] = useState(false);
  const [loadingAssets, setLoadingAssets] = useState(true);
  const [localError, setLocalError] = useState<string | null>(null);
  const [notice, setNotice] = useState("");
  const [showHelp, setShowHelp] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showPlayer, setShowPlayer] = useState(false);
  const [playerReady, setPlayerReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [playerIndex, setPlayerIndex] = useState(0);
  const [reducedMotion, setReducedMotion] = useState(true);
  const input = useRef<HTMLInputElement>(null);
  const briefInput = useRef<HTMLTextAreaElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const filmstrip = useRef<HTMLDivElement>(null);
  const helpDialog = useRef<HTMLDialogElement>(null);
  const menuDialog = useRef<HTMLDialogElement>(null);
  const playerDialog = useRef<HTMLDialogElement>(null);
  const assetVersion = useRef(0);
  const turnSequence = useRef(0);
  const activeTurn = useRef<string | null>(null);
  const sidebarContent = useRef<HTMLDivElement>(null);
  const followConversation = useRef(true);
  const generation = useDeckGeneration();
  const showDraft = generation.busy && previewMode === "draft";
  const visibleDeck = showDraft ? generation.draft : deck;
  const visibleAssets = showDraft ? assets : deckAssets;
  const slides = visibleDeck?.slides ?? [];
  const index = Math.max(0, slides.findIndex(slide => slide.id === selectedId));
  const selectedSlide = slides[index];
  const validDeck = useMemo(() => deckSchema.safeParse(deck).success && validateDeckAssets(deck, deckAssets), [deck, deckAssets]);
  const canPresent = validDeck && !generation.busy && !loadingAssets;
  const compatibleAssets = assets === deckAssets;
  const acceptedIndex = Math.max(0, deck.slides.findIndex(slide => slide.id === selectedId));
  const acceptedSlide = deck.slides[acceptedIndex];
  const problem = localError;
  const feedback = notice;

  useEffect(() => {
    let disposed = false;
    const version = ++assetVersion.current;
    loadSampleCollection(SAMPLE.id).then(sample => {
      if (disposed || assetVersion.current !== version) return;
      setAssets(sample.assets); setDeckAssets(sample.assets); setDeck(sample.deck); setLoadingAssets(false);
    }).catch(() => {
      if (!disposed && assetVersion.current === version) { setLoadingAssets(false); setLocalError("The sample images could not load. Try choosing the sample again, or upload your own images."); }
    });
    return () => { disposed = true; assetVersion.current += 1; };
  }, []);
  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(media.matches);
    update(); media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  useEffect(() => {
    const selected = filmstrip.current?.querySelector<HTMLElement>(`[data-slide-index="${index}"]`);
    if (selected && filmstrip.current) filmstrip.current.scrollTo({ left: selected.offsetLeft - (filmstrip.current.clientWidth - selected.offsetWidth) / 2, behavior: reducedMotion ? "instant" : "smooth" });
  }, [index, slides.length, reducedMotion]);
  useEffect(() => {
    if (followConversation.current && sidebarContent.current?.clientHeight) sidebarContent.current.scrollTop = sidebarContent.current.scrollHeight;
  }, [turns, generation.busy, generation.progress, panel]);
  useEffect(() => {
    if (showHelp && !helpDialog.current?.open) helpDialog.current?.showModal();
    else if (!showHelp && helpDialog.current?.open) helpDialog.current.close();
  }, [showHelp]);
  useEffect(() => {
    if (showMenu && !menuDialog.current?.open) menuDialog.current?.showModal();
    else if (!showMenu && menuDialog.current?.open) menuDialog.current.close();
  }, [showMenu]);
  useEffect(() => {
    const dialog = playerDialog.current;
    if (!dialog) return;
    if (showPlayer) {
      if (!dialog.open) dialog.showModal();
      // Mount the iframe in a visible dialog so its percentage-sized document
      // does not retain the zero-size layout from the closed dialog.
      setPlayerReady(true);
    } else {
      setPlayerReady(false);
      if (dialog.open) dialog.close();
    }
  }, [showPlayer]);
  useEffect(() => {
    if (!playing || !showPlayer || !playerReady) return;
    const timer = window.setTimeout(() => {
      if (playerIndex >= deck.slides.length - 1) setPlaying(false);
      else setPlayerIndex(current => current + 1);
    }, deck.slides[playerIndex].duration * 1000);
    return () => window.clearTimeout(timer);
  }, [playing, showPlayer, playerReady, playerIndex, deck.slides]);

  async function chooseSample(id: string) {
    if (id === "uploaded" || generation.busy) return;
    const version = ++assetVersion.current;
    setLoadingAssets(true); setLocalError(null); setNotice(""); generation.clearFeedback();
    try {
      const sample = await loadSampleCollection(id);
      if (version !== assetVersion.current) return;
      setDeck(sample.deck); setAssets(sample.assets); setDeckAssets(sample.assets); setTheme(sample.theme); setPlayerIndex(0);
      setBrief(current => current === brief ? "" : current); setCollectionId(id); setDeckCollectionId(id); setIsSample(true); setEdited(false); setSelectedId(sample.deck.slides[0].id); setPreviewMode("current");
      setTurns([]); setRevisions([]); followConversation.current = true; setPanel("chat");
    } catch (cause) {
      if (version === assetVersion.current) setLocalError(cause instanceof Error ? cause.message : "Those sample images could not load. Try again.");
    } finally { if (version === assetVersion.current) setLoadingAssets(false); }
  }

  async function upload(event: ChangeEvent<HTMLInputElement>) {
    const files = event.target.files;
    if (!files?.length) return;
    const picked = Array.from(files); event.target.value = "";
    const version = ++assetVersion.current;
    setLoadingAssets(true); setLocalError(null); setNotice(""); generation.clearFeedback();
    try {
      const normalized = await normalizeImageFiles(picked);
      if (version !== assetVersion.current) return;
      setAssets(normalized); setCollectionId("uploaded");
      setBrief(current => current === brief ? "" : current);
      setTurns([]); setRevisions([]); followConversation.current = true;
      setNotice("New images ready. Describe a new deck in Chat.");
      setPanel("chat"); requestAnimationFrame(() => briefInput.current?.focus());
    } catch (cause) {
      if (version === assetVersion.current) setLocalError(cause instanceof Error ? cause.message : "Those images could not be read. Please try another file.");
    } finally { if (version === assetVersion.current) setLoadingAssets(false); }
  }

  function generate() {
    if (generation.busy || activeTurn.current || loadingAssets || !assets.length || brief.trim().length < 3) return;
    const prompt = brief.trim();
    const requestId = `turn-${++turnSequence.current}`;
    const inputAssets = assets;
    const inputTheme = theme;
    const history = turns.filter(turn => turn.status === "complete").slice(-12).map(({ role, content }) => ({ role, content }));
    const previousDeck = compatibleAssets && validDeck ? deck : null;
    const prior: Revision = { turns, deck, assets: deckAssets, theme, selectedId: acceptedSlide.id, collectionId: deckCollectionId, isSample, edited };
    activeTurn.current = requestId;
    setLocalError(null); setNotice(""); setPlaying(false); setShowPlayer(false); setPlayerIndex(0); setBrief(""); setPanel("chat"); followConversation.current = true;
    setTurns(current => [...current, { id: requestId, role: "user", content: prompt, status: "pending" }].slice(-40) as ChatTurn[]);
    const interrupted = (status: "failed" | "stopped", error?: string) => {
      if (activeTurn.current !== requestId) return;
      activeTurn.current = null;
      setTurns(current => current.map(turn => turn.id === requestId ? { ...turn, status, error } : turn));
      setBrief(current => current || prompt); setPreviewMode("current");
      setSelectedId(current => prior.deck.slides.some(slide => slide.id === current) ? current : prior.selectedId);
    };
    void generation.start({ brief: prompt, assets: inputAssets, theme: inputTheme, previousDeck, history, selectedSlideId: previousDeck ? acceptedSlide.id : null }, {
      onDraft: () => {
        setPreviewMode("draft");
      },
      onComplete: result => {
        if (activeTurn.current !== requestId) return;
        activeTurn.current = null;
        if (result.deck) {
          const nextDeck = result.deck;
          setRevisions(current => [...current, prior].slice(-5));
          setDeck(nextDeck); setDeckAssets(inputAssets); setTheme(inputTheme); setDeckCollectionId(collectionId);
          setSelectedId(current => nextDeck.slides.some(slide => slide.id === current) ? current : nextDeck.slides[Math.min(acceptedIndex, nextDeck.slides.length - 1)].id);
          setIsSample(false); setEdited(false);
        }
        setTurns(current => [...current.map(turn => turn.id === requestId ? { ...turn, status: "complete" as const } : turn), {
          id: `${requestId}-reply`, role: "assistant", content: result.message || (result.deck ? "Your deck is updated. What would you like to change next?" : "What would you like to change about the deck?"), status: "complete",
        }].slice(-40) as ChatTurn[]);
        setPreviewMode("current");
      },
      onError: message => interrupted("failed", message),
      onStop: () => interrupted("stopped"),
    });
  }
  function selectSlide(id: string) {
    setSelectedId(id);
    if (!generation.busy) {
      setInspectorPanel("edit");
      setPanel(current => current === "chat" ? "chat" : "edit");
    }
  }
  function usePrompt(message: string) {
    setBrief(message); setPanel("chat"); setLocalError(null); generation.clearFeedback(); briefInput.current?.focus();
  }
  function undoRevision() {
    const previous = revisions[revisions.length - 1];
    if (!previous || generation.busy || loadingAssets) return;
    setDeck(previous.deck); setDeckAssets(previous.assets); setAssets(previous.assets); setTheme(previous.theme); setSelectedId(previous.selectedId);
    setCollectionId(previous.collectionId); setDeckCollectionId(previous.collectionId); setIsSample(previous.isSample); setEdited(previous.edited);
    setRevisions(current => current.slice(0, -1)); setTurns(previous.turns); setPlayerIndex(0); setBrief(""); setPanel("chat"); setPreviewMode("current");
    setLocalError(null); generation.clearFeedback(); followConversation.current = true;
    setNotice("Previous version restored.");
  }
  function changeSlide(patch: Partial<Slide>) {
    if (generation.busy || !deck.slides[index]) return;
    setDeck(current => ({ ...current, slides: current.slides.map((slide, slideIndex) => slideIndex === index ? { ...slide, ...patch } : slide) }));
    setEdited(true); setNotice(""); generation.clearFeedback();
  }
  function moveSlide(direction: -1 | 1) {
    if (generation.busy || index + direction < 0 || index + direction >= deck.slides.length) return;
    setDeck(current => { const reordered = [...current.slides]; [reordered[index], reordered[index + direction]] = [reordered[index + direction], reordered[index]]; return { ...current, slides: reordered }; });
    setEdited(true);
  }
  function downloadDeck() {
    try {
      const html = exportDeckHtml(deck, deckAssets, theme);
      const url = URL.createObjectURL(new Blob([html], { type: "text/html;charset=utf-8" }));
      const anchor = document.createElement("a"); anchor.href = url; anchor.download = `${deck.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 70) || "folio-deck"}.html`;
      document.body.appendChild(anchor); anchor.click(); anchor.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 3000);
      setNotice("Your HTML deck includes the images and plays offline.");
    } catch (cause) { setLocalError(cause instanceof Error ? cause.message : "The deck could not be exported. Check the slide titles and images."); }
  }
  function present() { if (!canPresent) return; setPlayerIndex(0); setPlaying(true); setShowPlayer(true); }
  function closePlayer() { setShowPlayer(false); setPlayerReady(false); setPlaying(false); }
  function togglePlayback() { if (!playing && playerIndex === deck.slides.length - 1) setPlayerIndex(0); setPlaying(current => !current); }
  function clearFeedback() { setLocalError(null); setNotice(""); generation.clearFeedback(); }

  const projectDownload = <a className="button button-small ghost" href="/downloads/folio-presentation-maker.zip" download><ArrowDownTrayIcon className={ICON} />Download project<TouchTarget /></a>;

  return <>
    <main className="studio-shell isolate">
      <header className="document-toolbar">
        <Link href="/" aria-label="Homepage" className="brand"><Square2StackIcon className={`${ICON} fill-vermilion`} /><div className="text-xl font-medium tracking-tight text-ink">Folio</div></Link>
        <div className="document-divider" />
        <input className="document-title" name="deck-title" aria-label="Presentation title" maxLength={80} value={deck.title} disabled={generation.busy} onChange={event => { setDeck(current => ({ ...current, title: event.target.value })); setEdited(true); }} onBlur={() => { if (!deck.title.trim()) setDeck(current => ({ ...current, title: "Untitled presentation" })); }} />
        <div className="desktop-project-download">{projectDownload}</div>
        <button type="button" className="button button-small icon-button ghost mobile-menu-toggle" aria-label="Open project menu" aria-haspopup="dialog" onClick={() => setShowMenu(true)}><Bars3Icon className={ICON} /><TouchTarget /></button>
      </header>

      <div className="studio-workspace" data-panel={panel}>
        <div className="panel-tabs compact-panel-switcher" role="group" aria-label="Workspace panel">{PANELS.map(item => <button key={item.id} type="button" className="button button-small panel-tab" aria-controls={item.id === "chat" ? "conversation-sidebar" : "details-sidebar"} aria-pressed={panel === item.id} onClick={() => { setPanel(item.id); if (item.id !== "chat") setInspectorPanel(item.id); }}>{item.label}<TouchTarget /></button>)}</div>
        <aside id="conversation-sidebar" className="editor-sidebar chat-sidebar" aria-label="Chat with Folio">
          <div className="sidebar-heading"><h2 id="chat-heading" className="font-medium text-ink">Chat</h2></div>
          <div ref={sidebarContent} className="sidebar-content conversation-surface" onScroll={event => { const element = event.currentTarget; if (element.clientHeight) followConversation.current = element.scrollHeight - element.scrollTop - element.clientHeight < 56; }}>
            <ConversationPanel turns={turns} busy={generation.busy} progress={generation.progress} isNewDeck={!compatibleAssets && !loadingAssets} onSuggestion={usePrompt} onRetry={usePrompt} />
          </div>
          <form className="brief-section" onSubmit={event => { event.preventDefault(); if (!generation.busy) generate(); }}>
            <div className="composer-heading"><label htmlFor="brief" className="field-label">Message Folio</label>{revisions.length > 0 && <button type="button" className="button button-small ghost undo-revision" title="Undo last revision" aria-label="Undo last revision" disabled={generation.busy || loadingAssets} onClick={undoRevision}><ArrowUturnLeftIcon className={ICON} />Undo<TouchTarget /></button>}</div>
            <p className="composer-context" title={compatibleAssets ? acceptedSlide.title : "New images will create a new deck"}>{compatibleAssets ? <><span className="tabular-nums">Slide {String(acceptedIndex + 1).padStart(2, "0")}</span><span aria-hidden="true">·</span><span className="truncate">{acceptedSlide.title || "Untitled slide"}</span></> : `${assets.length} images · New deck`}</p>
            <div className="brief-composer"><textarea ref={briefInput} id="brief" name="brief" rows={4} maxLength={1500} value={brief} disabled={generation.busy} placeholder="Ask a question or describe a change…" onChange={event => setBrief(event.target.value)} onKeyDown={event => {
              if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing && event.keyCode !== 229) { event.preventDefault(); if (!generation.busy) generate(); }
            }} /><div className="brief-footer"><p className="keyboard-hint text-muted" title="Shift + Enter for a new line">Enter to send</p><button type={generation.busy ? "button" : "submit"} className="button primary generate-button" disabled={!generation.busy && (loadingAssets || !assets.length || brief.trim().length < 3)} onClick={event => { if (generation.busy) { event.preventDefault(); generation.stop(); setPreviewMode("current"); } }}>{generation.busy ? <StopIcon className={ICON} /> : <ArrowUpIcon className={ICON} />}{generation.busy ? "Stop" : "Send"}<TouchTarget /></button></div></div>
          </form>
          <input ref={input} className="sr-only" name="image-upload" type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={generation.busy || loadingAssets} aria-label="Upload images" onChange={upload} />
        </aside>

        <section className="preview-workspace" aria-label="Presentation preview">
          <div className="preview-toolbar"><div className="stage-status" role="status">{generation.busy ? <><span className="working-dot" aria-hidden="true" /><p className="truncate" title={generation.progress}>{generation.progress}</p><p className="tabular-nums text-muted">{generation.elapsed}s</p></> : <p className="text-muted">{isSample ? edited ? "Edited sample" : "Sample deck" : edited ? "Edited deck" : "Your deck"}</p>}{generation.busy && !!generation.draft?.slides.length && <button type="button" className="button button-small ghost version-toggle" onClick={() => { setPreviewMode(current => current === "draft" ? "current" : "draft"); }}>{showDraft ? "Previous deck" : "Live draft"}<TouchTarget /></button>}</div><div className="preview-actions"><button type="button" className="button button-small secondary" disabled={!canPresent} onClick={present}><PlayIcon className={ICON} />Play<TouchTarget /></button><button type="button" className="button button-small ghost" disabled={!canPresent} onClick={downloadDeck}><ArrowDownTrayIcon className={ICON} />Export HTML<TouchTarget /></button></div></div>
          <div ref={stage} id="slide-canvas" className="stage-area" tabIndex={-1} role="tabpanel" aria-label={selectedSlide ? `Slide ${index + 1}: ${selectedSlide.title}` : "Creating presentation"}>
            {selectedSlide ? <div className="stage-board"><SlidePreview slide={selectedSlide} assets={visibleAssets} theme={theme} index={index} total={slides.length} /></div> : <div className="stage-loading"><div className="loading-rule" aria-hidden="true" /><h1 className="text-balance text-2xl font-medium tracking-tight text-ink">Creating your slides</h1><p className="text-pretty text-muted">The first slide will appear here as it’s ready.</p></div>}
          </div>
          {problem && <div className="workspace-message error-message" role="alert"><p className="min-w-0 flex-1 text-pretty">{problem}</p><button type="button" className="button button-small icon-button ghost" aria-label="Dismiss error" onClick={clearFeedback}><XMarkIcon className={ICON} /><TouchTarget /></button></div>}
          {!problem && feedback && !generation.busy && <div className="workspace-message" role="status"><p className="min-w-0 flex-1 text-pretty">{feedback}</p><button type="button" className="button button-small icon-button ghost" aria-label="Dismiss message" onClick={clearFeedback}><XMarkIcon className={ICON} /><TouchTarget /></button></div>}
          <div className="timeline-area">
            <div ref={filmstrip} className="filmstrip" role="tablist" aria-label="Slides" onKeyDown={event => {
              if (event.altKey && ["ArrowLeft", "ArrowRight"].includes(event.key)) { event.preventDefault(); moveSlide(event.key === "ArrowLeft" ? -1 : 1); return; }
              if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key) || !slides.length) return;
              event.preventDefault();
              const next = event.key === "Home" ? 0 : event.key === "End" ? slides.length - 1 : Math.max(0, Math.min(slides.length - 1, index + (event.key === "ArrowRight" ? 1 : -1)));
              selectSlide(slides[next].id); filmstrip.current?.querySelector<HTMLButtonElement>(`[data-slide-index="${next}"]`)?.focus();
            }}>{slides.map((slide, slideIndex) => <button key={slide.id} type="button" data-slide-index={slideIndex} className="filmstrip-slide" role="tab" aria-selected={slideIndex === index} aria-controls="slide-canvas" aria-label={`Slide ${slideIndex + 1}: ${slide.title}`} tabIndex={slideIndex === index ? 0 : -1} onClick={() => selectSlide(slide.id)}><div className="thumbnail"><SlidePreview slide={slide} assets={visibleAssets} theme={theme} index={slideIndex} total={slides.length} thumbnail /></div><div className="thumbnail-caption"><p className="tabular-nums">{String(slideIndex + 1).padStart(2, "0")}</p><p className="truncate">{slide.title}</p></div></button>)}</div>
            <div className="timeline-footer"><p className="tabular-nums text-muted">{slides.length ? `${String(index + 1).padStart(2, "0")} / ${String(slides.length).padStart(2, "0")}` : "Waiting for slides"}</p><p className="reorder-hint text-muted">Select a slide · Alt + ← / → to reorder</p><button type="button" className="button button-small icon-button ghost" title="How it works" aria-label="How Folio works" onClick={() => setShowHelp(true)}><QuestionMarkCircleIcon className={ICON} /><TouchTarget /></button></div>
          </div>
        </section>
        <aside id="details-sidebar" className="editor-sidebar inspector-sidebar" aria-label="Presentation controls">
          <div className="panel-tabs inspector-tabs" role="tablist" aria-label="Slide tools" onKeyDown={event => {
            if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
            event.preventDefault();
            const next = event.key === "Home" ? "edit" : event.key === "End" ? "images" : inspectorPanel === "edit" ? "images" : "edit";
            setInspectorPanel(next); setPanel(next); document.getElementById(`${next}-tab`)?.focus();
          }}>{INSPECTOR_PANELS.map(item => <button key={item.id} type="button" className="button button-small panel-tab" id={`${item.id}-tab`} role="tab" aria-controls={`${item.id}-panel`} aria-selected={inspectorPanel === item.id} tabIndex={inspectorPanel === item.id ? 0 : -1} onClick={() => { if (item.id !== "chat") { setInspectorPanel(item.id); setPanel(item.id); } }}>{item.label}<TouchTarget /></button>)}</div>
          <div className="sidebar-content inspector-content">
            {inspectorPanel === "images" ? <div id="images-panel" role="tabpanel" aria-labelledby="images-tab" className="images-panel">
              <div className="editor-section-header"><h2 className="font-medium text-balance text-ink">Your images</h2><button type="button" className="button button-small ghost" disabled={generation.busy || loadingAssets} onClick={() => input.current?.click()}><PhotoIcon className={ICON} />Upload<TouchTarget /></button></div>
              <div className="select-wrap"><select name="sample-collection" aria-label="Choose sample images" value={collectionId} disabled={generation.busy || loadingAssets} onChange={event => void chooseSample(event.target.value)}>{SAMPLE_COLLECTIONS.map(sample => <option key={sample.id} value={sample.id}>{sample.title}</option>)}{collectionId === "uploaded" && <option value="uploaded">Your uploaded images</option>}</select><ChevronDownIcon className={ICON} /></div>
              <div className="asset-grid" aria-label="Images for your next deck">{assets.map((asset, assetIndex) => <figure key={asset.id} className="asset-tile"><img src={asset.dataUrl} alt={asset.name} /><figcaption><p className="tabular-nums">{String(assetIndex + 1).padStart(2, "0")}</p><p className="truncate" title={asset.name}>{asset.name}</p></figcaption></figure>)}{loadingAssets && !assets.length && <div className="asset-loading" role="status">Loading images…</div>}</div>
              <p className="upload-hint text-muted">Up to 6 images · JPG, PNG, or WebP</p>
              <div className="theme-section"><p className="field-label">Deck style</p><div className="theme-options" aria-label="Deck style">{(Object.keys(THEME_NAMES) as Theme[]).map(option => <button type="button" key={option} className="button button-small theme-option" aria-pressed={theme === option} disabled={generation.busy} onClick={() => { setTheme(option); setEdited(true); }}><span className={`theme-swatch theme-${option}`} aria-hidden="true" />{THEME_NAMES[option]}<TouchTarget /></button>)}</div></div>
            </div> : <div id="edit-panel" role="tabpanel" aria-labelledby="edit-tab">{selectedSlide && <SlideEditor slide={selectedSlide} index={index} total={slides.length} assets={visibleAssets} disabled={generation.busy || loadingAssets} onChange={changeSlide} onMove={moveSlide} />}{!selectedSlide && <p className="text-pretty text-muted">Your slides will appear here as they’re created.</p>}</div>}
          </div>
        </aside>
      </div>
    </main>

    <dialog ref={helpDialog} className="folio-dialog" aria-labelledby="help-title" onClose={() => setShowHelp(false)} onClick={event => { if (event.target === event.currentTarget) setShowHelp(false); }}><div className="dialog-content"><div className="dialog-heading"><h2 id="help-title" className="text-balance text-2xl font-medium tracking-tight text-ink">From images to a story</h2><button type="button" autoFocus className="button button-small icon-button ghost" aria-label="Close help" onClick={() => setShowHelp(false)}><XMarkIcon className={ICON} /><TouchTarget /></button></div><ol role="list" className="help-steps"><li><p className="help-number">01</p><div><h3 className="font-medium text-ink">Choose your material</h3><p className="text-pretty text-muted">Try a sample or upload up to six images. Describe the story, audience, and tone you have in mind. Decks contain 4–{MAX_SLIDES} slides.</p></div></li><li><p className="help-number">02</p><div><h3 className="font-medium text-ink">Watch the deck take shape</h3><p className="text-pretty text-muted">Your images are resized in your browser and sent to OpenAI when you send a message. An agent creates the sequence, captions, and slide layouts.</p></div></li><li><p className="help-number">03</p><div><h3 className="font-medium text-ink">Make it yours</h3><p className="text-pretty text-muted">Keep chatting to ask questions, revise captions, or add and remove slides. Your selected slide gives context to “this slide.” Manual edits are included in the next request. Undo restores the previous deck and conversation. Play or export an offline HTML deck.</p></div></li></ol></div></dialog>
    <dialog ref={menuDialog} className="folio-dialog menu-dialog" aria-labelledby="menu-title" onClose={() => setShowMenu(false)} onClick={event => { if (event.target === event.currentTarget) setShowMenu(false); }}><div className="dialog-content"><div className="dialog-heading"><h2 id="menu-title" className="text-balance text-xl font-medium text-ink">Folio project</h2><button type="button" autoFocus className="button button-small icon-button ghost" aria-label="Close menu" onClick={() => setShowMenu(false)}><XMarkIcon className={ICON} /><TouchTarget /></button></div><div className="mobile-project-download">{projectDownload}</div><p className="text-pretty text-muted">Includes the source and setup guide. Use your own API key to run it.</p></div></dialog>
    <dialog ref={playerDialog} className="player-dialog" aria-label="Presentation playback" onClose={closePlayer} onKeyDown={event => {
      if (event.key === "ArrowRight" || event.key === "ArrowLeft") { event.preventDefault(); setPlayerIndex(current => Math.max(0, Math.min(deck.slides.length - 1, current + (event.key === "ArrowRight" ? 1 : -1)))); }
      if (event.key === " " && event.target === event.currentTarget) { event.preventDefault(); togglePlayback(); }
    }}><div className="player-shell"><div className="player-top"><p className="min-w-0 truncate">{deck.title}</p><button type="button" autoFocus className="button button-small icon-button player-button" aria-label="Close presentation" onClick={closePlayer}><XMarkIcon className={ICON} /><TouchTarget /></button></div><div className="player-stage-area"><div className="stage-board">{showPlayer && playerReady && <SlidePreview key={playerIndex} slide={deck.slides[playerIndex]} assets={deckAssets} theme={theme} index={playerIndex} total={deck.slides.length} animate={playing && !reducedMotion} />}</div></div><div className="player-controls"><button type="button" className="button button-small icon-button player-button" aria-label="Previous slide" disabled={playerIndex === 0} onClick={() => setPlayerIndex(current => Math.max(0, current - 1))}><ArrowLeftIcon className={ICON} /><TouchTarget /></button><button type="button" className="button button-small player-button playback-toggle" aria-label={playing ? "Pause presentation" : "Play presentation"} onClick={togglePlayback}>{playing ? <PauseIcon className={ICON} /> : <PlayIcon className={ICON} />}{playing ? "Pause" : "Play"}<TouchTarget /></button><button type="button" className="button button-small icon-button player-button" aria-label="Next slide" disabled={playerIndex >= deck.slides.length - 1} onClick={() => setPlayerIndex(current => Math.min(deck.slides.length - 1, current + 1))}><ArrowRightIcon className={ICON} /><TouchTarget /></button><p className="player-count tabular-nums">{String(playerIndex + 1).padStart(2, "0")} / {String(deck.slides.length).padStart(2, "0")}</p></div>{playing && <div key={playerIndex} className="playback-progress" style={{ "--slide-duration": `${deck.slides[playerIndex].duration}s` } as CSSProperties} aria-hidden="true" />}</div></dialog>
  </>;
}
