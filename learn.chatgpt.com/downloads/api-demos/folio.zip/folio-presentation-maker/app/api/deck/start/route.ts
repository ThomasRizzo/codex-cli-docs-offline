import { createRequestSchema, resultJsonSchema, MAX_REQUEST_BYTES } from "../../../lib/contracts";
import { AgentsError, pollGenerationSession, streamGenerationSession } from "../../../lib/agents";
import { generationStream } from "../../../lib/generation-stream";
import { PRESENTATION_INSTRUCTIONS } from "../../../lib/instructions";
import { validateGenerationRequest } from "../../../lib/generation-result";
import { ApiError, createHandle, errorResponse, getRuntime, guardRequest, parseBody, privateHeaders } from "../../../lib/server";
import { enforceIpRateLimit } from "../../../lib/ip-rate-limit";
import { IP_LIMITS } from "../../../lib/rate-limit-policy";

export async function POST(request: Request) {
  try {
    const owner = guardRequest(request);
    const limited = await enforceIpRateLimit(request, "start", IP_LIMITS.start);
    if (limited) return limited;
    const parsed = await parseBody(request, createRequestSchema, MAX_REQUEST_BYTES);
    let input;
    try { input = validateGenerationRequest(parsed); }
    catch (error) { throw new ApiError(400, error instanceof Error ? error.message : "Upload valid JPEG images and try again."); }
    const runtime = await getRuntime(), assetIds = input.assets.map(asset => asset.id);
    const cleanup = await runtime.cleanup();
    const intent = await cleanup.begin();
    const stream = generationStream({
      start: async function* (signal) {
        let identified = false;
        try {
          for await (const event of streamGenerationSession(runtime.transport, { request: input, instructions: PRESENTATION_INSTRUCTIONS, resultSchema: resultJsonSchema, signal, metadata: cleanup.metadata(intent) })) {
            if (event.type === "session") identified = true;
            yield event;
          }
        } catch (error) {
          if (!identified && error instanceof AgentsError && [400, 401, 403, 404, 422].includes(error.status)) {
            await cleanup.rejected(intent, error.status);
          }
          throw error;
        }
      },
      record: async id => {
        try { await cleanup.track(intent, id); }
        catch (error) {
          try { await cleanup.emergencyDelete(intent, id); }
          catch { console.error(JSON.stringify({ event: "cleanup_tracking_failed", intentId: intent })); }
          throw error;
        }
      },
      poll: (id, signal) => pollGenerationSession(runtime.transport, id, { signal }),
      sign: id => createHandle(id, owner, runtime.secret, assetIds),
      cleanup: async id => { await cleanup.release(id); }, assetIds,
    });
    return new Response(stream, { headers: { ...privateHeaders, "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-store, no-transform", "X-Accel-Buffering": "no" } });
  } catch (error) { return errorResponse(error); }
}
