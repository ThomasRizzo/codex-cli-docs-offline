import { generationResult } from "../../../lib/generation-result";
import { pollGenerationSession } from "../../../lib/agents";
import { GENERATION_DEADLINE_MS, ApiError, errorResponse, getRuntime, guardRequest, limitSessionRequests, parseBody, privateHeaders, tokenRequestSchema, verifyHandle } from "../../../lib/server";

export async function POST(request: Request) {
  let cleanupOnError: (() => Promise<unknown>) | undefined;
  try {
    const owner = guardRequest(request);
    const { token } = await parseBody(request, tokenRequestSchema);
    const runtime = await getRuntime(), handle = await verifyHandle(token, owner, runtime.secret);
    limitSessionRequests(owner, "status");
    const queue = await runtime.cleanup();
    try { await queue.assertSession(handle.id); }
    catch { throw new ApiError(503, "This generation session is no longer available."); }
    const cleanup = () => queue.release(handle.id).catch(() => console.error(JSON.stringify({ event: "generation_cleanup_failed", sessionId: handle.id })));
    cleanupOnError = cleanup;
    if (Date.now() - handle.created > GENERATION_DEADLINE_MS) {
      await cleanup(); throw new ApiError(408, "This presentation took too long. Try a shorter brief.");
    }
    const state = await pollGenerationSession(runtime.transport, handle.id);
    if (["failed", "cancelled", "waiting"].includes(state.status)) {
      await cleanup(); return Response.json({ status: state.status, progress: state.progress, error: state.error }, { headers: privateHeaders });
    }
    if (state.status !== "complete") return Response.json({ status: state.status, progress: state.progress }, { headers: privateHeaders });
    const result = await generationResult(state, handle.assetIds);
    if (!result) {
      await cleanup();
      return Response.json({ status: "failed", progress: "Presentation incomplete", error: "The presentation did not pass its final checks. Your images are still here; try again." }, { headers: privateHeaders });
    }
    // Completed results stay in the current tab; release provider storage now.
    await cleanup();
    return Response.json({ status: "complete", progress: "Presentation ready", ...result }, { headers: privateHeaders });
  } catch (error) { await cleanupOnError?.(); return errorResponse(error); }
}
