"use client";

import { ArrowUturnLeftIcon } from "@heroicons/react/16/solid";

export type ChatTurn = {
  id: string;
  role: "user" | "assistant";
  content: string;
  status: "pending" | "complete" | "failed" | "stopped";
  error?: string;
};

export default function ConversationPanel({ turns, busy, progress, isNewDeck, onSuggestion, onRetry }: {
  turns: ChatTurn[]; busy: boolean; progress: string; isNewDeck: boolean;
  onSuggestion: (message: string) => void; onRetry: (message: string) => void;
}) {
  return <div className="chat-panel">
    {!turns.length && <div className="chat-intro"><h2 className="font-medium text-ink">{isNewDeck ? "Tell your story" : "Make it yours"}</h2><p className="text-pretty text-muted">{isNewDeck ? "Describe the story, audience, and tone for your images." : "Ask a question, change a caption, or add a slide. Keep going until it feels right."}</p><div className="chat-suggestions">{(isNewDeck ? ["Create a short visual story.", "Make a presentation with minimal text."] : ["Shorten this slide’s caption.", "Add a closing slide."]).map(suggestion => <button type="button" className="chat-suggestion" disabled={busy} key={suggestion} onClick={() => onSuggestion(suggestion)}>{suggestion}<span className="touch-target" aria-hidden="true" /></button>)}</div></div>}
    <div className="chat-transcript" role="log" aria-label="Conversation with Folio" aria-live="polite" aria-relevant="additions text">{turns.map(turn => <article key={turn.id} className="chat-turn" data-role={turn.role} data-status={turn.status}><p className="chat-speaker">{turn.role === "user" ? "You" : "Folio"}</p><p className="chat-content">{turn.content}</p>{(turn.status === "failed" || turn.status === "stopped") && <div className="chat-interruption"><p>{turn.status === "stopped" ? "Stopped. Your deck is unchanged." : turn.error || "This request didn’t finish. Your deck is unchanged."}</p><button type="button" className="button button-small ghost retry-message" disabled={busy} onClick={() => onRetry(turn.content)}><ArrowUturnLeftIcon className="size-4 shrink-0 fill-current" />Retry message<span className="touch-target" aria-hidden="true" /></button></div>}</article>)}</div>
    {busy && <div className="chat-progress" role="status"><span className="working-dot" aria-hidden="true" /><p>{progress || "Thinking about your deck…"}</p></div>}
  </div>;
}
