"use client";

import { memo, useMemo } from "react";
import type { ImageAsset, Slide, Theme } from "../lib/contracts";
import { renderSlideHtml } from "../lib/render";

const SlidePreview = memo(function SlidePreview({ slide, assets, theme, index, total, animate = false, thumbnail = false }: {
  slide: Slide; assets: ImageAsset[]; theme: Theme; index: number; total: number; animate?: boolean; thumbnail?: boolean;
}) {
  const html = useMemo(() => renderSlideHtml(slide.title.trim() ? slide : { ...slide, title: "Untitled slide" }, assets, theme, index, total, { animate }), [slide, assets, theme, index, total, animate]);
  return <iframe className="slide-frame" title={thumbnail ? `Thumbnail: ${slide.title}` : `Slide ${index + 1}: ${slide.title}`} srcDoc={html} sandbox="" referrerPolicy="no-referrer" tabIndex={-1} aria-hidden={thumbnail || undefined} loading={thumbnail ? "lazy" : "eager"} />;
});
export default SlidePreview;
