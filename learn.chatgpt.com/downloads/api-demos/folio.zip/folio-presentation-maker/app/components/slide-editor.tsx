"use client";

import { ArrowLeftIcon, ArrowRightIcon, CheckIcon, ChevronDownIcon } from "@heroicons/react/16/solid";
import { layouts, motions, type ImageAsset, type Slide } from "../lib/contracts";
import type { ReactNode } from "react";

const ICON = "size-4 shrink-0 fill-current";
const layoutNames = { cover: "Cover", split: "Image + text", statement: "Statement", gallery: "Gallery", closing: "Closing" };
const motionNames = { fade: "Soft fade", rise: "Rise in", pan: "Slow pan", none: "None" };
function Select({ children, label, name, value, disabled, onChange }: { children: ReactNode; label: string; name: string; value: string; disabled: boolean; onChange: (value: string) => void }) {
  return <div className="field"><label htmlFor={name}>{label}</label><div className="select-wrap"><select id={name} name={name} value={value} disabled={disabled} onChange={event => onChange(event.target.value)}>{children}</select><ChevronDownIcon className={ICON} /></div></div>;
}
function TouchTarget() { return <span className="touch-target" aria-hidden="true" />; }

export default function SlideEditor({ slide, index, total, assets, disabled, onChange, onMove }: {
  slide: Slide; index: number; total: number; assets: ImageAsset[]; disabled: boolean;
  onChange: (patch: Partial<Slide>) => void; onMove: (direction: -1 | 1) => void;
}) {
  function changeLayout(layout: Slide["layout"]) {
    let imageIds = slide.imageIds;
    if (layout === "statement") imageIds = [];
    else if (layout === "gallery") imageIds = [...new Set([...imageIds, ...assets.map(asset => asset.id)])].slice(0, Math.max(2, Math.min(3, imageIds.length)));
    else if (layout === "cover" || layout === "split") imageIds = imageIds.length ? imageIds.slice(0, 1) : assets.slice(0, 1).map(asset => asset.id);
    else imageIds = imageIds.slice(0, 1);
    onChange({ layout, imageIds });
  }
  const isGallery = slide.layout === "gallery";
  const maximumImages = isGallery ? 3 : 1;
  const minimumImages = isGallery ? 2 : slide.layout === "cover" || slide.layout === "split" ? 1 : 0;
  function chooseImage(id: string) {
    const selected = slide.imageIds.includes(id);
    if (isGallery) onChange({ imageIds: selected ? slide.imageIds.filter(imageId => imageId !== id) : [...slide.imageIds, id] });
    else onChange({ imageIds: selected && minimumImages === 0 ? [] : [id] });
  }
  return <div className="slide-editor">
    <div className="editor-section-header"><h2 className="font-medium text-balance text-ink">Slide {String(index + 1).padStart(2, "0")}</h2><div className="move-controls"><button type="button" className="button button-small icon-button ghost" aria-label="Move slide earlier" title="Move earlier" disabled={disabled || index === 0} onClick={() => onMove(-1)}><ArrowLeftIcon className={ICON} /><TouchTarget /></button><button type="button" className="button button-small icon-button ghost" aria-label="Move slide later" title="Move later" disabled={disabled || index === total - 1} onClick={() => onMove(1)}><ArrowRightIcon className={ICON} /><TouchTarget /></button></div></div>
    <Select label="Layout" name="slide-layout" value={slide.layout} disabled={disabled} onChange={value => changeLayout(value as Slide["layout"])}>{layouts.map(layout => <option key={layout} value={layout} disabled={layout === "gallery" && assets.length < 2}>{layoutNames[layout]}</option>)}</Select>
    <div className="field"><label htmlFor="slide-eyebrow">Eyebrow</label><input id="slide-eyebrow" name="slide-eyebrow" value={slide.eyebrow} maxLength={45} disabled={disabled} placeholder="A short introduction" onChange={event => onChange({ eyebrow: event.target.value })} /></div>
    <div className="field"><label htmlFor="slide-title">Title</label><textarea id="slide-title" name="slide-title" value={slide.title} maxLength={90} rows={2} disabled={disabled} onChange={event => onChange({ title: event.target.value })} onBlur={() => { if (!slide.title.trim()) onChange({ title: "Untitled slide" }); }} /></div>
    <div className="field"><label htmlFor="slide-body">Caption</label><textarea id="slide-body" name="slide-body" value={slide.body} maxLength={240} rows={3} disabled={disabled} placeholder="Add a little context." onChange={event => onChange({ body: event.target.value })} /></div>
    {slide.layout !== "statement" && <div className="field"><div className="flex items-center justify-between gap-3"><p className="field-label">{isGallery ? "Slide images" : "Slide image"}</p><p className="field-note tabular-nums">{slide.imageIds.length} / {maximumImages}</p></div><div className="assignment-grid">{assets.map(asset => {
      const selected = slide.imageIds.includes(asset.id);
      const unavailable = disabled || (selected && slide.imageIds.length <= minimumImages) || (isGallery && !selected && slide.imageIds.length >= maximumImages);
      return <button type="button" key={asset.id} className="assignment-image" aria-label={`${selected ? "Remove" : "Use"} ${asset.name} on this slide`} aria-pressed={selected} disabled={unavailable} title={asset.name} onClick={() => chooseImage(asset.id)}><img src={asset.dataUrl} alt="" />{selected && <span className="image-check"><CheckIcon className={ICON} /></span>}</button>;
    })}</div></div>}
    <div className="field-pair"><Select label="Motion" name="slide-motion" value={slide.motion} disabled={disabled} onChange={value => onChange({ motion: value as Slide["motion"] })}>{motions.map(motion => <option key={motion} value={motion}>{motionNames[motion]}</option>)}</Select><Select label="Duration" name="slide-duration" value={String(slide.duration)} disabled={disabled} onChange={value => onChange({ duration: Number(value) })}>{Array.from({ length: 10 }, (_, index) => index + 3).map(seconds => <option key={seconds} value={seconds}>{seconds} seconds</option>)}</Select></div>
    <details className="speaker-notes"><summary>Speaker notes</summary><div className="field"><label htmlFor="slide-notes" className="sr-only">Speaker notes</label><textarea id="slide-notes" name="slide-notes" rows={4} maxLength={500} value={slide.notes} disabled={disabled} placeholder="Notes for the presenter." onChange={event => onChange({ notes: event.target.value })} /></div></details>
  </div>;
}
