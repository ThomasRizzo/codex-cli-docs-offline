# Folio

Turn a few images and a brief into an animated presentation. Folio uses the OpenAI Agents API to inspect the supplied images, plan a visual sequence, and validate a structured deck in a hosted sandbox. A trusted renderer provides editable slides and a standalone HTML download.

## Run locally

Set `CLEANUP_PROVIDER_SCOPE` to a stable provider-project label (1–80 letters, digits, underscores or hyphens, starting with a letter or digit). Apply every D1 migration before API requests. Missing cleanup storage or scope blocks new provider work.

Requires Node.js 22.13 or later and an OpenAI API project with Agents API access.

```sh
npm ci
cp .env.example .env.local
# Set OPENAI_API_KEY and CLEANUP_PROVIDER_SCOPE in the ignored .env.local file.
npm run build
for migration in drizzle/*.sql; do
  node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file "$migration" || exit 1
done
npm run dev
```

Run database initialization once for a fresh database. For an existing database, apply only migrations that have not already run, in filename order.

Use a dedicated project API key for this app. Existing shell environment variables take precedence over local env files; unset an inherited `OPENAI_API_KEY` if you intend to use `.env.local`. Keep credentials server-side. Local development supplies an ephemeral session-signing key; set `FOLIO_SESSION_SECRET` to a random, stable secret for hosted deployment.

```sh
npm test
npm run typecheck
npm run build
```

## Experience

- Explore the 15-slide Form & light demo, choose another sample, or upload up to six JPEG, PNG, or WebP images.
- Describe the story, audience, or mood. Generation streams progress and completed slide drafts into the preview.
- Continue the conversation to refine the deck, add or remove slides, or ask about its contents. “This slide” refers to the selected slide; the current deck, including manual edits, is supplied with each follow-up.
- Edit captions, slide layouts and image assignments; reorder slides and change the visual theme.
- Play the presentation or download a standalone HTML file with embedded images and keyboard controls.
- Stop generation, retry a failed request, or refine a completed deck without losing the previous result.
- Undo a completed AI revision to recover the previous version. Decks support four to twenty slides; new decks default to about five.

Uploaded images are normalized in the browser to JPEGs of at most 320 KB and 1800 pixels per side before they are sent. Original uploads are limited to 15 MB each. Images and the brief are sent to the OpenAI API for generation. The app holds the working deck in browser memory; reloads do not restore an unsaved presentation. Download the HTML deck to keep a copy.

## API and rendering

The server creates an OpenAI-hosted Agents session using `gpt-6-astra`, image inputs, and inline sandbox files. Each request includes the current deck, selected slide, and a bounded recent conversation; sessions are cleaned up after each turn rather than kept open between edits. Questions can receive an answer without regenerating the deck. Network access in the sandbox is disabled. The agent works with a bounded deck schema; the server validates fields and asset references before accepting the result. User-visible progress excludes reasoning and raw tool output.

All generation and follow-up sessions request Fast mode with `agent.service_tier: "fast"`.

Browser clients call the app’s `/api/deck/start` and `/api/deck/cancel` endpoints. No visitor account or login is required. A random nonce held only in browser memory binds each short-lived, signed handle to its current tab. The server requests deletion after completion, failure, cancellation or browser disconnection, without waiting for browser acknowledgement. A durable metadata-only ledger retains failed cleanup for an owner-operated maintenance task. Upstream interruptions can be reconciled while the browser remains connected; a lost browser connection asks you to retry. Retries persist across Worker and browser restarts. Infrastructure or scheduling failures can delay deletion; no provider expiry is assumed.

The browser never executes model-generated HTML or JavaScript. Editor previews and downloads use the same escaped slide templates. The standalone player includes a fixed script, embedded images, keyboard navigation, and reduced-motion support; no network connection is needed for playback.

For Sites deployment, configure server-only `OPENAI_API_KEY` and a random `FOLIO_SESSION_SECRET` of at least 32 characters. The downloadable project calls `https://api.openai.com` directly from the server with a credential approved for that hosting environment. Managed hosting uses its configured server transport. Keep the starter build integration.

## IP rate limits

Starting an analysis or generation is limited to **6 requests per UTC minute and 20 per UTC day, per IP address**. Both windows are reserved atomically in the Sites D1 `DB` binding and persist across Worker instances. Visitors on the same network share this allowance. Rotating the browser nonce does not reset this allowance.

The server trusts only the edge-provided `CF-Connecting-IP`, ignores caller-supplied forwarding headers, and stores a SHA-256 hash with usage counters rather than the raw IP address. Exhausted requests receive HTTP 429 with `Retry-After` and a reset time. If the trusted IP or D1 store is unavailable, new work fails closed with HTTP 503 before contacting OpenAI.

Status and Stop/session cleanup do not consume this IP generation allowance. They require same-origin requests, the original anonymous UUID, a correctly signed session handle, and an available cleanup ledger. During a D1 outage these operations fail closed; existing durable jobs remain pending for recovery.

The Run locally commands build the Worker configuration and apply every D1 migration before starting the development server.

The source download preserves the logical `DB` binding and all migrations, without a hosted project or database ID. Hosted deployment must provision D1 and apply every migration before serving API requests. These per-IP limits are usage safeguards, not a project-wide monetary budget.

## Project download

`npm run package:source` produces `public/downloads/folio-presentation-maker.zip`. It includes runnable source, the standalone public API adapter, and blank configuration examples. It excludes credentials, Site identity, Git history, dependencies, local runtime state, and QA captures. Production builds regenerate this archive automatically.

Sample photo and font attributions are included alongside their assets in `public/`.

## Durable cleanup and owner operation

The cleanup ledger stores only random run IDs, provider session IDs, logical scope, a SHA-256 fingerprint of the actual server API key and effective API origin, timestamps, leases, retry categories, sanitized incident summaries and ticket receipts. It never stores user content, prompts, uploads, model output, browser nonce values, signing capabilities or the key itself.

- A creation intent commits before the single provider creation POST. Server-generated provider metadata carries the app name, random intent ID and logical scope. The known session ID and fallback deletion job commit before a browser handle or result is exposed.
- Completion, failure, timeout and disconnect make the job eligible immediately. The fallback deadline is 210 seconds after intent creation, allowing the 180-second generation deadline and a short grace period. If recording the ID fails, output stops and an emergency deletion is attempted. A confirmed emergency deletion is recorded if D1 has recovered; otherwise the intent remains unresolved.
- Each deletion attempt has an eight-second network deadline. HTTP 409 requests cancellation and leaves deletion pending. Network errors, malformed success responses, 429, 5xx and authentication failures retain the job. Retries use persisted exponential backoff from roughly 15 seconds to 15 minutes, with jitter and bounded `Retry-After`. The ledger never discards a job because of its retry count.
- Atomic 60-second leases and fenced updates prevent concurrent workers from completing each other's jobs. A maintenance call has a 20-second network budget, at most 20 deletion attempts, and one reconciliation page of up to 10 sessions. `dueJobs` and `dueReconciliations` let the owner task repeat bounded calls when work remains.
- A definitive creation HTTP 400/401/403/404/422 rejection received before any session ID closes the intent without claiming a session was deleted. Other ambiguous creation outcomes remain pending. Reconciliation lists sessions in the current provider project, matches only metadata belonging to an existing same-scope intent, and persists pagination progress. It never retries creation. Empty scans do not prove absence. Failed or empty scans back off from one to 15 minutes; invalid cursors restart the scan.
- Only an exact documented deletion confirmation (`id`, `deleted: true`, `object: agent.session.deleted`) or HTTP 404 under the recorded key/origin/scope confirms cleanup. Confirmed records and proven rejected intents are eligible for bounded pruning after 24 hours. Unconfirmed jobs and unidentified intents do not expire.

Use a separate provider project/workload and key for each demo. Before changing the key, API origin or `CLEANUP_PROVIDER_SCOPE`, stop new work and drain until both `pending` and `unknown` are zero. Even a same-project key rotation changes the fingerprint and conservatively strands old records. Restore the original credential/origin/scope to drain those records; never relabel them or accept a new project's 404 as deletion proof.

Configure these server-only bindings on a Sites deployment:

| Binding | Purpose |
| --- | --- |
| `DB` | Existing D1 storage, with all checked-in migrations applied. |
| `OPENAI_API_KEY` | That demo's provider credential. |
| `FOLIO_SESSION_SECRET` | At least 32 random characters for anonymous browser handles. |
| `CLEANUP_PROVIDER_SCOPE` | Explicit stable provider-project label. Missing scope prevents generation. |
| `CLEANUP_OWNER_EMAIL` | The verified Sites account allowed to operate maintenance. |
| `CLEANUP_IDENTITY_PROVIDER` | Set to `sites` only behind Sites' verified identity ingress. Blank disables maintenance calls. |

The manifest enables the Sites MCP capability. `POST /mcp` implements protocol `2026-07-28`: `server/discover` and `tools/list` return static public metadata; every `tools/call` requires the configured identity-provider opt-in, a Sites-verified user ID, and an exact normalized match to the configured owner email. No maintenance tool accepts arbitrary provider session IDs, provider URLs, credentials or scopes. Ticket receipt URLs are validated as Linear issue links and are never fetched by the Site. Visitors remain anonymous and need no login.

**Do not set `CLEANUP_IDENTITY_PROVIDER=sites` on a raw Worker or other public server that accepts caller-supplied `oai-authenticated-user-*` headers.** A non-Sites deployment must supply its own verified maintenance identity integration and trusted scheduler before enabling equivalent operations. The downloadable example leaves this opt-in blank.

After deploying and verifying the owner can call the Site's tools, configure an owner-linked cloud task every 15 minutes with a connected Linear account and an explicit ticket team and owner:

1. Call `cleanup_run` and read `cleanup_status`. Repeat a bounded number of batches while cleanup work is due; leave future backoff queued. A failed maintenance, authentication or storage call must itself create or reuse a P0 outage ticket assigned to the configured owner, using a stable Site-specific marker in Linear.
2. Claim pending incidents with `cleanup_claim_alert`. The claim returns an incident ID, stable ticket marker and a fenced five-minute lease. Search Linear for that exact marker before creating a ticket. Create a `[P0]` issue with the highest priority in Linear (`1`, Urgent), assign the configured owner, and include only the sanitized incident summary, timestamps and recovery context. A synthetic incident must be marked `[DRILL]`.
3. Read the issue back and verify its marker, priority and assignee. Call `cleanup_ack_alert` with the exact incident ID, current lease token and verified receipt (`issue_id`, `identifier`, canonical Linear `url`, `assignee_email`, `priority: 1`). Notification success alone cannot acknowledge an incident. Read `cleanup_status` to confirm that the receipt persisted.
4. If looking up, creating or reading back a ticket fails, call `cleanup_retry_alert` with the incident ID, lease token and sanitized category. Respect provider retry delays. Pending incidents survive process restarts and recovery; a lost call or expired lease is retried on a later run. After an ambiguous create, search and recover the marker before attempting another create. Notify the owner of escalation failures, but leave the incident pending.

Unresolved jobs or unidentified intents older than 15 minutes, stranded scopes and provider-authentication failures open a durable incident. One active failure episode per Site retains its identity as counts change. Recovery is recorded separately and does not erase a pending ticket obligation. Ticket receipts and incident history are not pruned with confirmed session metadata. Ticketed failures continue cleanup retries; the task does not automatically close real tickets.

The server validates the authenticated owner's receipt and stores it durably; it relies on that trusted task to read Linear independently. Leases and stable-marker recovery reduce duplicate creation, but Linear search-before-create is not an atomic idempotency guarantee. A crash after issue creation can require reconciliation. The task must never silently acknowledge a failed or unverified ticket.

`cleanup_test_alert({test_id})` is an owner-only, idempotent failure drill. It inserts a synthetic incident through the same escalation outbox without creating a provider session, changing credentials or processing user content. Test the real ticket path with this tool, read back the assigned P0 and persisted receipt, then explicitly resolve the drill ticket. Provider deletion failure-to-incident behavior is also covered by real-D1 tests with mocked provider responses.

Source deployment does not itself create a schedule or connect Linear. Verify the actual unattended owner task after deployment. This app provides no Worker cron, independent missed-run monitor or scheduling/ticket-service SLA. If the task stops, durable records remain but cleanup and escalation wait for another invocation. A Site/D1 outage is escalated externally by the task, since unavailable storage cannot record its own incident. Project listing can be delayed or unable to identify an ambiguous creation; those intents remain visible rather than being discarded. No provider TTL is assumed. This session cleanup does not claim to remove unrelated provider resources or logs.

The lifecycle uses the documented Agents API [creation metadata](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/create), [project session listing and pagination](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/list), and [session deletion confirmation](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/delete).
