import { constants, closeSync, existsSync, fstatSync, lstatSync, mkdirSync, openSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { zipSync } from "fflate";

const archiveRoot = "folio-presentation-maker";
const sourceDirectories = ["app", "public", "components", "hooks", "lib", "scripts", "tests", "vendor", "db", "drizzle", "public-source"];
const sourceFiles = [
  ".gitignore", ".npmrc", "README.md", "LICENSE", "LICENSE.md", "package.json", "package-lock.json",
  "components.json", "cloudflare-env.d.ts", "drizzle.config.ts", "eslint.config.mjs", "next.config.ts",
  "postcss.config.mjs", "tsconfig.json", "vite.config.ts",
  "build/connector-preview-plugin.mjs", "build/connector-preview-worker.mjs", "build/sites-vite-plugin.LICENSE",
  "build/sites-vite-plugin.ts", "build/sites-worker.ts",
];
const excludedDirectories = new Set(["node_modules", "dist", "coverage", "output", "outputs", "work"]);
const secretPattern = /\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}|-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----/;

function assertSafeName(name) {
  if (/[\\\x00-\x1f\x7f]/.test(name)) throw new Error("Source contains an unsafe archive filename.");
}

function readSourceFile(filename, relativePath, secretValues) {
  const descriptor = openSync(filename, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    if (!fstatSync(descriptor).isFile()) throw new Error(`Not a regular source file: ${relativePath}`);
    const bytes = readFileSync(descriptor);
    if (secretPattern.test(bytes.toString("utf8")) || secretValues.some(value => bytes.includes(Buffer.from(value)))) {
      throw new Error(`Potential credential found in source file: ${relativePath}`);
    }
    if (relativePath === ".npmrc" && /(?:_authToken|_auth|password)\s*=\s*[^\s#]+/i.test(bytes.toString("utf8"))) {
      throw new Error("Authenticated npm configuration must not be included in the source download.");
    }
    return bytes;
  } finally {
    closeSync(descriptor);
  }
}

export function buildSourceArchive(projectRoot, { secretValues = [] } = {}) {
  const root = path.resolve(projectRoot);
  const entries = new Map();
  const knownSecrets = secretValues.filter(value => typeof value === "string" && value.length >= 12);
  const addFile = relativePath => {
    const absolute = path.join(root, relativePath);
    let parent = root;
    for (const part of relativePath.split("/").slice(0, -1)) {
      parent = path.join(parent, part);
      if (lstatSync(parent).isSymbolicLink()) throw new Error(`Symlinks are not allowed in source downloads: ${relativePath}`);
    }
    const metadata = lstatSync(absolute);
    if (metadata.isSymbolicLink()) throw new Error(`Symlinks are not allowed in source downloads: ${relativePath}`);
    // The download is a standalone project with the public API adapter.
    if (relativePath === "app/lib/transport.ts" && lstatSync(path.join(root, "public-source")).isSymbolicLink()) {
      throw new Error("Source templates must not be symlinks.");
    }
    const source = relativePath === "app/lib/transport.ts"
      ? path.join(root, "public-source", "transport.ts.txt") : absolute;
    entries.set(relativePath, readSourceFile(source, relativePath, knownSecrets));
  };
  const walk = relativePath => {
    const absolute = path.join(root, relativePath);
    const metadata = lstatSync(absolute);
    if (metadata.isSymbolicLink()) throw new Error(`Symlinks are not allowed in source downloads: ${relativePath}`);
    if (!metadata.isDirectory()) throw new Error(`Expected a source directory: ${relativePath}`);
    for (const name of readdirSync(absolute).sort()) {
      assertSafeName(name);
      const next = `${relativePath}/${name}`;
      // Never read local secrets, runtime state, or the previous generated ZIP.
      if (name.startsWith(".") || name.endsWith(".hosting.test.mjs") || excludedDirectories.has(name) || next === "public/downloads"
        || /\.env(?:\.|$)|^(?:credentials|secrets)(?:[.-]|$)/i.test(name)
        || /\.(?:pem|key|p12|pfx|log|tsbuildinfo)$/i.test(name)) continue;
      const child = lstatSync(path.join(root, next));
      if (child.isSymbolicLink()) throw new Error(`Symlinks are not allowed in source downloads: ${next}`);
      if (child.isDirectory()) walk(next);
      else addFile(next);
    }
  };
  for (const directory of sourceDirectories) {
    if (existsSync(path.join(root, directory))) walk(directory);
  }
  for (const filename of sourceFiles) {
    if (existsSync(path.join(root, filename))) addFile(filename);
  }
  entries.set(".openai/hosting.json", Buffer.from(`${JSON.stringify({ d1: "DB", r2: null, capabilities: ["mcp"] }, null, 2)}\n`));
  entries.set(".env.example", Buffer.from("OPENAI_API_KEY=\n# Required for hosted deployment; local development creates an ephemeral signing key.\nFOLIO_SESSION_SECRET=\nCLEANUP_PROVIDER_SCOPE=\nCLEANUP_OWNER_EMAIL=\nCLEANUP_IDENTITY_PROVIDER=\n"));

  if (entries.has("package-lock.json")) {
    // Normalize registry tarballs while preserving pinned versions and integrity hashes.
    const lock = JSON.parse(entries.get("package-lock.json").toString("utf8"));
    for (const entry of Object.values(lock.packages)) {
      if (!entry.resolved) continue;
      const resolved = new URL(entry.resolved);
      const pathname = resolved.pathname.replace(/^\/npm(?=\/)/, "");
      if (resolved.protocol !== "https:" || resolved.search || resolved.hash
        || !/^\/(?:@[^/]+\/)?[^/]+\/-\/[^/]+\.tgz$/.test(pathname)) {
        throw new Error("Expected an HTTPS npm registry tarball in package-lock.json");
      }
      entry.resolved = `https://registry.npmjs.org${pathname}`;
    }
    entries.set("package-lock.json", Buffer.from(`${JSON.stringify(lock, null, 2)}\n`));
  }

  const files = [...entries.keys()].sort();
  const zipEntries = Object.create(null);
  for (const filename of files) {
    zipEntries[`${archiveRoot}/${filename}`] = [entries.get(filename), {
      // ZIP stores local wall-clock fields: construct the same fields in every TZ.
      mtime: new Date(2000, 0, 1, 0, 0, 0),
      os: 3,
      attrs: (filename.endsWith(".sh") ? 0o100755 : 0o100644) << 16,
      level: /\.(?:woff2?|png|jpe?g|webp|avif|gif|mp[34]|zip)$/i.test(filename) ? 0 : 9,
    }];
  }
  return { bytes: zipSync(zipEntries), files };
}

export function packageSource(projectRoot) {
  const root = path.resolve(projectRoot);
  const result = buildSourceArchive(root, { secretValues: [process.env.OPENAI_API_KEY, process.env.FOLIO_SESSION_SECRET] });
  const directory = path.join(root, "public", "downloads");
  if (existsSync(directory) && lstatSync(directory).isSymbolicLink()) throw new Error("The download directory must not be a symlink.");
  mkdirSync(directory, { recursive: true });
  const destination = path.join(directory, `${archiveRoot}.zip`);
  const descriptor = openSync(destination, constants.O_WRONLY | constants.O_CREAT | constants.O_TRUNC | constants.O_NOFOLLOW, 0o644);
  try { writeFileSync(descriptor, result.bytes); } finally { closeSync(descriptor); }
  return { destination, fileCount: result.files.length, byteCount: result.bytes.length };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const result = packageSource(fileURLToPath(new URL("../", import.meta.url)));
  console.log(`Packaged ${result.fileCount} source files (${result.byteCount} bytes) into public/downloads/${archiveRoot}.zip`);
}
