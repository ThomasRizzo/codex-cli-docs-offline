'use client';
import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { XMarkIcon } from '@heroicons/react/16/solid';
import type { ScheduleAvailability, ScheduleTravelLeg } from '@/lib/schedule-travel';
import { calendarTime, snapCalendarMinute, type ScheduleItem } from '@/lib/scheduling';

type Point={x:number;y:number};
type SwapTarget={id:string;name:string;time:string};
function swapTargetAt(item:ScheduleItem,point:Point):SwapTarget|null {
 if(!item.stopId||!('time' in item.place)||!item.place.time)return null;
 const target=document.elementFromPoint(point.x,point.y)?.closest<HTMLElement>('[data-calendar-swap-id]');
 const id=target?.dataset.calendarSwapId,time=target?.dataset.swapTime,name=target?.dataset.swapName;
 return id&&id!==item.stopId&&time&&name?{id,time,name}:null;
}
type PointerInput={button:number;pointerType:string;clientX:number;clientY:number;preventDefault:()=>void;stopPropagation:()=>void};
type ScheduleContextValue={
 availability:ScheduleAvailability|null;swapTarget:SwapTarget|null;choosingTime:boolean;enabled:boolean;canDrag:boolean;item:ScheduleItem|null;dragging:boolean;point:Point|null;busy:boolean;time:string;setTime:(time:string)=>void;
 begin:(item:ScheduleItem)=>void;cancel:()=>void;pointerDown:(event:PointerInput,item:ScheduleItem)=>void;commit:(time:string)=>Promise<void>;
};
const ScheduleContext=createContext<ScheduleContextValue|null>(null);
export const useScheduling=()=>useContext(ScheduleContext);

export function SchedulingProvider({enabled,busy,onBegin,onSave,onDayChange,getAvailability,prepareRoutes,children}:{enabled:boolean;busy:boolean;onBegin:()=>void;onSave:(item:ScheduleItem,time:string,swapId?:string)=>Promise<void>;onDayChange:(date:string)=>void;getAvailability:(item:ScheduleItem,time:string,swapId?:string)=>ScheduleAvailability;prepareRoutes:(legs:ScheduleTravelLeg[])=>Promise<void>;children:ReactNode}){
 const [item,setItem]=useState<ScheduleItem|null>(null),[dragging,setDragging]=useState(false),[point,setPoint]=useState<Point|null>(null),[desktop,setDesktop]=useState(false),[error,setError]=useState(''),[time,setTime]=useState('09:00'),[submitting,setSubmitting]=useState(false),[choosingTime,setChoosingTime]=useState(false),[swapTarget,setSwapTarget]=useState<SwapTarget|null>(null);
 const saving=useRef(false),gesture=useRef<{item:ScheduleItem;start:Point;active:boolean}|null>(null),dayHover=useRef<{day:string;timer:ReturnType<typeof setTimeout>}|null>(null);
 const callbacks=useRef({onSave,onDayChange,prepareRoutes});callbacks.current={onSave,onDayChange,prepareRoutes};
 const availability=item?getAvailability(item,swapTarget?.time||time,swapTarget?.id):null;
 const routeLoadKey=availability?.status==='checking'?availability.missing.map(leg=>leg.key).sort().join('|'):'';
 useEffect(()=>{
  if(!routeLoadKey||!availability)return;
  const timer=setTimeout(()=>{void callbacks.current.prepareRoutes(availability.missing).catch(()=>{});},180);
  return()=>clearTimeout(timer);
 },[routeLoadKey]);
 const clearHover=()=>{if(dayHover.current)clearTimeout(dayHover.current.timer);dayHover.current=null;};
 const cancel=()=>{gesture.current=null;clearHover();setItem(null);setSwapTarget(null);setChoosingTime(false);setDragging(false);setPoint(null);setError('');};
 const save=async(next:ScheduleItem,time:string,fromDrag=false,swapId?:string)=>{if(saving.current)return;saving.current=true;setSubmitting(true);setTime(time);setError('');setDragging(false);setPoint(null);setSwapTarget(null);try{await callbacks.current.onSave(next,time,swapId);setItem(null);}catch(e){setItem(fromDrag?null:next);setError((e as Error).message);}finally{saving.current=false;setSubmitting(false);}};
 useEffect(()=>{const media=matchMedia('(min-width:1100px) and (pointer:fine)');const change=()=>setDesktop(media.matches);change();media.addEventListener('change',change);return()=>media.removeEventListener('change',change);},[]);
 useEffect(()=>{
  let hoverPoint:Point|null=null,frame=0;
  // Re-hit-test while scrolling too, so the highlighted card is the drop target.
  const hover=()=>{
   const current=gesture.current,next=current?.active&&hoverPoint?swapTargetAt(current.item,hoverPoint):null;
   setSwapTarget(old=>old?.id===next?.id&&old?.time===next?.time?old:next);
   frame=current?.active?requestAnimationFrame(hover):0;
  };
  const move=(event:PointerEvent)=>{
   const current=gesture.current;if(!current)return;
   if(!current.active&&Math.hypot(event.clientX-current.start.x,event.clientY-current.start.y)<6)return;
   event.preventDefault();current.active=true;hoverPoint={x:event.clientX,y:event.clientY};if(!frame)frame=requestAnimationFrame(hover);setChoosingTime(false);setItem(current.item);setDragging(true);setPoint({x:event.clientX,y:event.clientY});
   const target=document.elementFromPoint(event.clientX,event.clientY)?.closest<HTMLElement>('[data-schedule-day]');
   const date=target?.dataset.scheduleDay;
   if(date&&date!==dayHover.current?.day){clearHover();dayHover.current={day:date,timer:setTimeout(()=>callbacks.current.onDayChange(date),600)};}else if(!date)clearHover();
  };
  const up=(event:PointerEvent)=>{
   const current=gesture.current;gesture.current=null;clearHover();if(!current?.active)return;
   event.preventDefault();event.stopPropagation();setDragging(false);setPoint(null);setSwapTarget(null);
   // A drag must not also activate the source card or a calendar event.
   const suppress=(e:MouseEvent)=>{e.preventDefault();e.stopPropagation();};
   document.addEventListener('click',suppress,true);setTimeout(()=>document.removeEventListener('click',suppress,true),0);
   const grid=document.elementFromPoint(event.clientX,event.clientY)?.closest<HTMLElement>('[data-calendar-drop]');
   if(!grid){setItem(null);return;}
   const minute=snapCalendarMinute(event.clientY-grid.getBoundingClientRect().top,Number(grid.dataset.firstMinute),Number(grid.dataset.lastMinute));
   const swap=swapTargetAt(current.item,{x:event.clientX,y:event.clientY});
   void save(current.item,swap?.time||calendarTime(minute),true,swap?.id);
  };
  const key=(e:KeyboardEvent)=>{if(e.key==='Escape'&&!saving.current){gesture.current=null;clearHover();setItem(null);setSwapTarget(null);setChoosingTime(false);setDragging(false);setPoint(null);setError('');}};
  const abort=()=>cancel();
  window.addEventListener('pointermove',move,{capture:true,passive:false});window.addEventListener('pointerup',up,true);window.addEventListener('pointercancel',abort,true);window.addEventListener('keydown',key);window.addEventListener('blur',abort);
  return()=>{cancelAnimationFrame(frame);clearHover();window.removeEventListener('pointermove',move,true);window.removeEventListener('pointerup',up,true);window.removeEventListener('pointercancel',abort,true);window.removeEventListener('keydown',key);window.removeEventListener('blur',abort);};
 },[]);
 const working=busy||submitting;
 const value:ScheduleContextValue={availability,swapTarget,choosingTime,enabled:enabled&&!working,canDrag:enabled&&!working&&desktop,item,dragging,point,busy:working,time,setTime,
  begin:next=>{if(!enabled||working)return;setItem(next);setSwapTarget(null);setChoosingTime(true);setDragging(false);setTime('09:00');setError('');onBegin();requestAnimationFrame(()=>document.getElementById('schedule-time')?.focus({preventScroll:true}));},cancel,
  pointerDown:(event,next)=>{if(!enabled||working||!desktop||event.pointerType==='touch'||event.button!==0)return;event.preventDefault();event.stopPropagation();gesture.current={item:next,start:{x:event.clientX,y:event.clientY},active:false};setSwapTarget(null);setError('');},
  commit:async time=>{if(item&&!working)await save(item,time);},
 };
 return <ScheduleContext.Provider value={value}>{children}{dragging&&point&&item&&<div className={'schedule-drag-ghost'+(availability?.status==='blocked'||availability?.status==='unavailable'?' is-blocked':'')} style={{'--drag-x':`${point.x+16}px`,'--drag-y':`${point.y+16}px`} as React.CSSProperties} aria-hidden="true"><p>{item.place.name}</p>{swapTarget&&<p className="schedule-swap-label">Swap with {swapTarget.name}</p>}{availability?.label&&<p className="schedule-drag-detail">{availability.label}</p>}</div>}{error&&<div className="schedule-error" role="alert"><span>{error}</span><button type="button" className="icon" aria-label="Dismiss scheduling error" onClick={()=>setError('')}><XMarkIcon/></button></div>}</ScheduleContext.Provider>;
}

export function SchedulePrompt(){
 const schedule=useScheduling();
 // Only an explicit Schedule action opens the picker, including while a drop saves.
 if(!schedule?.item||!schedule.choosingTime)return null;
 return <div className="schedule-prompt">
  <div className="schedule-prompt-heading"><p>{schedule.item.place.name}</p><button type="button" className="icon" aria-label="Cancel scheduling" disabled={schedule.busy} onClick={schedule.cancel}><XMarkIcon/><span className="touch-target" aria-hidden="true"/></button></div>
  <p className={'schedule-instruction'+(schedule.availability?.status==='blocked'||schedule.availability?.status==='unavailable'?' is-conflict':'')} role="status">{schedule.availability?.message||'Choose a time on the calendar.'}</p><form className="schedule-time-form" onSubmit={e=>{e.preventDefault();schedule.commit(schedule.time);}}><input id="schedule-time" name="schedule-time" aria-label="Schedule time" type="time" value={schedule.time} required disabled={schedule.busy} onInput={e=>schedule.setTime(e.currentTarget.value)}/><button type="submit" className="secondary" disabled={schedule.busy||schedule.availability?.status==='blocked'}>{schedule.busy?'Checking…':schedule.availability?.status==='unavailable'?'Retry':'Schedule'}</button></form>
 </div>;
}
