'use client';
import { hasLocation } from '@/lib/trips';
import { useState } from 'react';
import { Car, MapPin, Check, ArrowLeft } from 'lucide-react';
import type { DeparturePlan, Flight, Place, Trip } from '@/lib/trips';
import { duration, departurePlanSchema } from '@/lib/trips';
import { Modal, PlaceSearch, api } from './controls';
import { hotelDayBounds } from '@/lib/hotels';
import { departureSchedule, wallDate, wallTime } from '@/lib/departures';

export default function DepartureForm({ trip, flight, onSave, onClose }: {trip: Trip; flight: Flight; onSave: (f: Flight) => Promise<void>; onClose: () => void}) {
  const old = flight.departurePlan;
  const hotels = hotelDayBounds(trip.hotels, flight.date);
  const [airport, setAirport] = useState<Place | null>(old?.airport || null);
  const [originPlace, setOriginPlace] = useState<Place | null>(old?.originPlace || (!old ? hotels.start : null) || null);
  const [originStopId, setOriginStopId] = useState(old?.originStopId || '');
  const [kind, setKind] = useState<'domestic'|'international'>(old?.kind || 'domestic');
  const [arrivalMinutes, setArrivalMinutes] = useState(old?.arrivalMinutes ?? 120);
  const [extraMinutes, setExtraMinutes] = useState(old?.extraMinutes ?? 10);
  const [override, setOverride] = useState(old?.driveOverrideMinutes?.toString() || '');
  const [departure, setDeparture] = useState(flight.scheduledDeparture || flight.departure);
  const [picker, setPicker] = useState<'airport'|'origin'|null>(null);
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  const [preview, setPreview] = useState<ReturnType<typeof departureSchedule> | null>(null);
  const origin = originStopId ? trip.stops.filter(hasLocation).find(s => s.id === originStopId) : originPlace;
  function changed() { setPreview(null); setError(''); }
  function plan(): DeparturePlan | null { if(!airport || !origin) return null; const parsed=departurePlanSchema.safeParse({airport, originStopId: originStopId || null, originPlace: originStopId ? null : originPlace, kind, arrivalMinutes, extraMinutes, driveOverrideMinutes: override ? Number(override) : null});return parsed.success?parsed.data:null; }
  async function calculate() {
    const p = plan(); if (!p || !departure) return;
    setBusy(true); setError('');
    try {
      const candidate = {...flight, scheduledDeparture: departure, departurePlan: p};
      const { routeKey } = await import('@/lib/trips');
      const route = p.driveOverrideMinutes ? null : await api<import('@/lib/trips').Route>('/api/route', {method:'POST', body:JSON.stringify({a:origin,b:airport,mode:'uber'})});
      setPreview(departureSchedule(candidate, trip.stops, route ? {[routeKey(origin!,airport!,'uber')]:route} : {}));
    } catch { setError('Could not estimate this drive. Try again or enter your own travel estimate below.'); }
    finally {setBusy(false);}
  }
  async function save(e: React.FormEvent) {
    e.preventDefault(); const p=plan(); if(!p) return;
    setBusy(true); setError('');
    try {await onSave({...flight, departure, scheduledDeparture:departure, departurePlan:p,flightaware:departure===(flight.scheduledDeparture||flight.departure)?flight.flightaware:undefined});onClose();}
    catch(e){setError((e as Error).message);setBusy(false);}
  }
  return <Modal title={picker ? (picker==='airport'?'Departure airport':'Where will you leave from?') : `Airport timing · ${flight.number}`} onClose={onClose}>
    {picker ? <><button className="back picker-back" onClick={()=>setPicker(null)}><ArrowLeft size={14}/>Back to timing</button><PlaceSearch center={picker==='origin' ? airport || trip.destination : undefined} placeholder={picker==='airport'?`Search ${flight.from || 'departure airport'}`:'Search your hotel or starting place'} onPick={p=>{if(picker==='airport')setAirport(p);else{setOriginPlace(p);setOriginStopId('');}changed();setPicker(null);}}/></> :
    <form className="form" onSubmit={save}>
      <p className="field-note">We’ll reserve your Uber and airport time before the scheduled flight.</p>
      <label>Scheduled departure · {flight.date}<input type="time" required value={departure} onInput={e=>{setDeparture(e.currentTarget.value);changed();}}/></label>
      <div className="location-pick"><span className="field-label">Departure airport</span><button type="button" className="location-choice" onClick={()=>setPicker('airport')}><MapPin size={16}/><span>{airport?.name || `Choose ${flight.from || 'your airport'}`}</span><span className="muted">{airport?'Change':'Choose'}</span></button></div>
      <div className="location-pick"><span className="field-label">Leave from</span>{trip.stops.length>0&&<select aria-label="Starting place" value={originStopId || 'custom'} onChange={e=>{setOriginStopId(e.currentTarget.value==='custom'?'':e.currentTarget.value);changed();}}><option value="custom">Hotel or another address</option>{trip.stops.filter(hasLocation).map(s=><option key={s.id} value={s.id}>{s.name} · {s.date}{s.time?' · '+s.time:''}</option>)}</select>}{!originStopId&&<button type="button" className="location-choice" onClick={()=>setPicker('origin')}><MapPin size={16}/><span>{originPlace?.name || 'Choose a starting place'}</span><span className="muted">{originPlace?'Change':'Choose'}</span></button>}</div>
      <div className="two-col"><label>Flight type<select value={kind} onChange={e=>{const k=e.currentTarget.value as typeof kind;setKind(k);setArrivalMinutes(k==='international'?180:120);changed();}}><option value="domestic">Domestic</option><option value="international">International</option></select></label><label>Arrive before departure<input type="number" required min={30} max={480} step={5} value={arrivalMinutes} onChange={e=>{setArrivalMinutes(Number(e.currentTarget.value));changed();}}/><span className="field-note">Minutes · {duration(arrivalMinutes)}</span></label></div>
      <p className="field-note">Start with <a className="text-link" href="https://www.phl.org/flights/security-information/screening" target="_blank" rel="noreferrer">2 hours for domestic or 3 hours for international flights</a>. Adjust to your airline’s guidance.</p>
      <div className="two-col"><label>Pickup + traffic allowance<input type="number" required min={0} max={180} step={5} value={extraMinutes} onChange={e=>{setExtraMinutes(Number(e.currentTarget.value));changed();}}/><span className="field-note">Extra minutes beyond the drive</span></label><label>Drive time override<input type="number" min={1} max={1440} placeholder="Use route estimate" value={override} onChange={e=>{setOverride(e.currentTarget.value);changed();}}/><span className="field-note">Optional · minutes</span></label></div>
      <button type="button" className="secondary" disabled={busy||!plan()||!departure} onClick={calculate}><Car size={15}/>{busy?'Calculating…':'Preview timing'}</button>
      {preview?.leave!=null&&<div className="timing-preview"><strong>Leave by {wallTime(preview.leave)}{wallDate(preview.leave)!==flight.date?' on '+wallDate(preview.leave):''}</strong><span>{duration(preview.driveMinutes!)} drive + {extraMinutes} min allowance</span><span>Arrive {wallTime(preview.arrive!)} · depart {wallTime(preview.depart!)}</span></div>}
      <p className="field-note">Times use the departure airport’s local clock. Delays won’t move your airport arrival later automatically. Drive estimates don’t include live traffic.</p>
      {error&&<p className="error" role="alert">{error}</p>}
      <div className="form-actions"><button type="button" onClick={onClose}>Cancel</button><button className="primary" disabled={busy||!plan()||!departure}>Save airport timing<Check size={16}/></button></div>
    </form>}
  </Modal>;
}
