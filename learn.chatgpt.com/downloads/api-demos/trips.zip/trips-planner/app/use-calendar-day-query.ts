'use client';
import { useEffect } from 'react';
import { calendarDayURL, selectedCalendarDay } from '@/lib/day-query';
import type { Trip } from '@/lib/trips';

// Replace the URL without navigation, preserving scroll, the router's history
// state, and any other query parameters. All ways of changing days use this.
export function useCalendarDayQuery(trip:Trip|null|undefined,day:string,setDay:(day:string)=>void,dates:string[],tripKey?:string) {
 const datesKey=dates.join(',');
 useEffect(()=>{
  if(!trip||!day)return;
  const selected=selectedCalendarDay(day,trip,dates);
  if(selected!==day){setDay(selected);return;}
  const url=calendarDayURL(location.href,selected);
  if(url!==location.href)history.replaceState(history.state,'',url);
 },[trip?.id,trip?.start,day,datesKey,setDay]);
 useEffect(()=>{
  if(!trip)return;
  const read=()=>{
   const url=new URL(location.href);
   if(tripKey&&url.searchParams.get('trip')!==tripKey)return;
   setDay(selectedCalendarDay(url.searchParams.get('day'),trip,dates));
  };
  window.addEventListener('popstate',read);
  return()=>window.removeEventListener('popstate',read);
 },[trip?.id,trip?.start,datesKey,tripKey,setDay]);
}
