'use client';
const zones = Intl.supportedValuesOf('timeZone');
export default function TimeZoneSelect({ label, value, onChange, placeholder = 'Choose a time zone' }: { label: string; value?: string; onChange: (v: string) => void; placeholder?: string }) {
  const options = value && !zones.includes(value) ? [value, ...zones] : zones;
  return <label>{label}<select value={value || ''} onChange={e => onChange(e.currentTarget.value)}><option value="">{placeholder}</option>{options.map(z => <option key={z} value={z}>{z.replace(/_/g, ' ')}</option>)}</select></label>;
}
