'use client';
import { useEffect, useId, useRef, useState, type CSSProperties } from 'react';
import { ChevronDownIcon, ArrowTopRightOnSquareIcon, ArrowPathIcon, ExclamationTriangleIcon } from '@heroicons/react/16/solid';
import { duration, type Route, type Stop, type LocatedStop } from '@/lib/trips';
import type { DayPoint } from '@/lib/hotels';
import { stopDuration } from '@/lib/event-duration';
import { wallMinutes } from '@/lib/departures';
import { useScheduling } from './scheduling';

export type TravelActions={
  onTravelMode:(stop:DayPoint,mode:Stop['mode'])=>Promise<void>;
  onRetryRoute:(from:Stop,to:Stop)=>Promise<void>;
};
export default function CalendarTravel({from,to,route,routeError,disabled,onTravelMode,onRetryRoute,compact=false}:{
  from:LocatedStop;to:LocatedStop;route?:Route;routeError?:string;disabled:boolean;compact?:boolean;
}&TravelActions){
  const id=useId(),popover=useRef<HTMLDivElement>(null),trigger=useRef<HTMLButtonElement>(null),schedule=useScheduling();
  const [open,setOpen]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(''),[position,setPosition]=useState({x:0,y:0});
  const mode=to.mode==='walk'?'Walk':'Uber';
  const gap=from.time&&to.time?wallMinutes(to.date,to.time)!-wallMinutes(from.date,from.time)!-stopDuration(from):null;
  const tight=!!route&&gap!==null&&route.minutes>gap;
  useEffect(()=>{const element=popover.current;if(!element)return;const toggle=(e:Event)=>setOpen((e as ToggleEvent).newState==='open');element.addEventListener('toggle',toggle);return()=>element.removeEventListener('toggle',toggle);},[]);
  useEffect(()=>{if(schedule?.item)popover.current?.hidePopover();},[schedule?.item]);
  useEffect(()=>{if(!open)return;const close=()=>popover.current?.hidePopover();window.addEventListener('resize',close);const pane=trigger.current?.closest('.calendar-pane');pane?.addEventListener('scroll',close);return()=>{window.removeEventListener('resize',close);pane?.removeEventListener('scroll',close);};},[open]);
  async function change(next:Stop['mode']){if(next===to.mode)return;setBusy(true);setError('');try{await onTravelMode(to,next);}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
  async function retry(){setBusy(true);setError('');try{await onRetryRoute(from,to);}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
  const label=`Travel from ${from.name} to ${to.name}: ${mode}, ${route?duration(route.minutes):routeError?'route unavailable':'finding route'}`;
  return <div className={'calendar-travel-control'+(compact?' travel-compact':'')+(tight?' travel-tight':'')}>
    <button ref={trigger} type="button" className="calendar-travel-trigger" popoverTarget={id} aria-haspopup="dialog" aria-expanded={open} aria-label={label} title={label} disabled={!!schedule?.item} onClick={()=>{const rect=trigger.current!.getBoundingClientRect();setPosition({x:Math.max(12,Math.min(rect.left,innerWidth-272)),y:Math.max(12,Math.min(rect.bottom+6,innerHeight-280))});}}>
      {tight&&<ExclamationTriangleIcon/>}<span className="travel-mode-label">{mode}<span aria-hidden="true"> · </span></span><span className="travel-duration">{route?duration(route.minutes):routeError?'Unavailable':'…'}</span><ChevronDownIcon/><span className="touch-target" aria-hidden="true"/>
    </button>
    <div id={id} ref={popover} popover="auto" role="dialog" aria-label={`Travel to ${to.name}`} className="calendar-travel-popover" style={{'--travel-x':`${position.x}px`,'--travel-y':`${position.y}px`} as CSSProperties}>
      <p className="travel-endpoints">{from.name}<span aria-hidden="true"> → </span>{to.name}</p>
      <div className="calendar-travel-modes" aria-label="Travel mode">{(['walk','uber'] as const).map(value=><button type="button" key={value} aria-pressed={to.mode===value} disabled={disabled||busy} onClick={()=>change(value)}>{value==='walk'?'Walk':'Uber'}<span className="touch-target" aria-hidden="true"/></button>)}</div>
      <div className="calendar-travel-estimate" role="status">{route?<p>{duration(route.minutes)}<span> · {route.km.toFixed(1)} km</span></p>:routeError?<button type="button" className="text-button" disabled={busy} onClick={retry}><ArrowPathIcon/>{busy?'Retrying…':'Route unavailable · Retry'}</button>:<p>Finding route…</p>}</div>
      {tight&&<p className="travel-conflict">{gap!<0?'These visits overlap.':`Only ${duration(gap!)} ${'arrivalFlightId' in from?'after leaving the airport':'after the visit ends'}.`}</p>}
      {to.mode==='uber'&&<><p className="travel-caveat">Excludes traffic and pickup waits.</p><a className="calendar-uber-link" href={`https://m.uber.com/ul/?action=setPickup&pickup[latitude]=${from.lat}&pickup[longitude]=${from.lng}&dropoff[latitude]=${to.lat}&dropoff[longitude]=${to.lng}`} target="_blank" rel="noopener noreferrer">Open Uber<ArrowTopRightOnSquareIcon/><span className="touch-target" aria-hidden="true"/></a></>}
      {error&&<p className="travel-conflict" role="alert">{error}</p>}
    </div>
  </div>;
}
