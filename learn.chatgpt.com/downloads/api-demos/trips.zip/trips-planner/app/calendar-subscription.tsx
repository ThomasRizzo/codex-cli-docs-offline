'use client';
import { useEffect, useState } from 'react';
import { Check, Copy, CalendarPlus, Link2 } from 'lucide-react';
import { api, Modal } from './controls';
import type { Trip } from '@/lib/trips';

type Subscription = { available: boolean; url: string | null };
export default function CalendarSubscription({ trips, onClose }: { trips: Trip[]; onClose: () => void }) {
  const [data, setData] = useState<Subscription | null>(null), [busy, setBusy] = useState(false), [error, setError] = useState(''), [copied, setCopied] = useState(false), [confirmRevoke, setConfirmRevoke] = useState(false);
  const needsZone = trips.flatMap(t => t.flights.filter(f => !f.departureTimeZone && !f.departurePlan));
  useEffect(() => { api<Subscription>('/api/calendar').then(setData).catch(e => setError(e.message)); }, []);
  async function create() { setBusy(true); setError(''); try { setData(await api<Subscription>('/api/calendar', { method: 'POST' })); } catch (e) { setError((e as Error).message); } finally { setBusy(false); } }
  async function revoke() { setBusy(true); setError(''); try { await api('/api/calendar', { method: 'DELETE' }); setData({ available: true, url: null }); setConfirmRevoke(false); setCopied(false); } catch (e) { setError((e as Error).message); } finally { setBusy(false); } }
  async function copy() { if (!data?.url) return; try { await navigator.clipboard.writeText(data.url); setCopied(true); } catch { setError('Select and copy the link below.'); } }
  return <Modal title="Calendar subscription" onClose={onClose}><div className="calendar-subscription">
    <p>Read-only calendar for all trips. Updates when Apple Calendar refreshes.</p>
    {needsZone.length > 0 && <p className="calendar-warning">{needsZone.length === 1 ? 'One flight needs' : `${needsZone.length} flights need`} a departure time zone. Edit the flight or set up airport timing. Until then, it appears as an all-day reminder.</p>}
    {!data && !error && <p className="muted">Loading subscription…</p>}
    {data && !data.available && <p className="connection-note">Calendar subscriptions are not connected.</p>}
    {data?.available && !data.url && <><p className="field-note">Anyone with this link can view your calendar. You can revoke it here.</p><button className="primary" disabled={busy} onClick={create}><Link2 size={15}/>{busy ? 'Creating…' : 'Create calendar link'}</button></>}
    {data?.url && <><label className="calendar-url-label">Your secret calendar link<input aria-label="Your secret calendar link" readOnly value={data.url} onFocus={e => e.currentTarget.select()} spellCheck={false}/></label><div className="subscription-actions"><a className="primary" href={data.url.replace(/^https?:/, 'webcal:')}><CalendarPlus size={15}/>Open Apple Calendar</a><button className="secondary" onClick={copy}>{copied ? <Check size={14}/> : <Copy size={14}/>} {copied ? 'Copied' : 'Copy link'}</button></div><p className="field-note">Anyone with this link can view your calendar.</p><details className="subscription-help"><summary>Setup and event details</summary><p>On Mac, choose File → New Calendar Subscription and paste the link. Set Auto-refresh to your preferred interval; choose iCloud to see it on your other devices.</p><p>Untimed places appear all day. Timed events include their scheduled duration. Airport transfers appear after their route has been calculated.</p></details>{confirmRevoke ? <div className="revoke-confirm"><p>This stops future refreshes for the current link. Calendar may keep events it has already downloaded. A new link will need a new subscription.</p><div className="form-actions"><button disabled={busy} onClick={() => setConfirmRevoke(false)}>Keep link</button><button className="secondary danger" disabled={busy} onClick={revoke}>{busy ? 'Revoking…' : 'Revoke link'}</button></div></div> : <button className="text-button revoke-link" onClick={() => setConfirmRevoke(true)}>Revoke calendar link</button>}</>}
    {error && <p className="error" role="alert">{error}</p>}
  </div></Modal>;
}
