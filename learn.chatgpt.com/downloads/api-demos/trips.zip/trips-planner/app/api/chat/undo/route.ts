import { z } from 'zod';
import { db, failure, json, user, requirePersistentWorkspace } from '@/lib/server';
import { getTurn, loadChatTrip, publicTurn } from '@/lib/chat-store';
import { tripSchema } from '@/lib/trips';
export async function POST(request:Request){try{requirePersistentWorkspace();const owner=await user(request);const parsed=z.object({id:z.string().uuid(),tripId:z.string().uuid()}).strict().safeParse(await request.json());if(!parsed.success)return json({error:'Invalid update.'},400);const {id,tripId}=parsed.data;const turn=await getTurn(owner,id);if(!turn||turn.trip_id!==tripId||!turn.before_data||turn.status!=='complete'||!turn.after_version)return json({error:'This update can no longer be undone.'},409);const before=tripSchema.parse(JSON.parse(turn.before_data));const results=await db().batch([
 db().prepare('UPDATE trips SET data=?,version=version+1,updated_at=? WHERE id=? AND owner=? AND version=? AND deleted_at IS NULL').bind(JSON.stringify(before),Date.now(),tripId,owner,turn.after_version),
 db().prepare("UPDATE chat_turns SET status='undone' WHERE id=? AND owner=? AND changes()=1").bind(id,owner)
]);if(!results[0].meta.changes)return json({error:'This trip changed after that update. Undo would overwrite newer edits.'},409);return json({trip:await loadChatTrip(owner,tripId),turn:publicTurn((await getTurn(owner,id))!)});}catch(e){return failure(e);}}
