import { requirePersistentWorkspace } from '@/lib/server';
import { loadTrip } from '@/lib/load-trip';
import { env } from 'cloudflare:workers';
import { z } from 'zod';
import { db, failure, json, user } from '@/lib/server';
import { flightQuery } from '@/lib/flightaware-cache';
import { lookupFlight, matchingFlight, FlightError } from '@/lib/flightaware';
import { tripSchema, type Trip } from '@/lib/trips';

const input=z.union([z.object({number:z.string().max(20),date:z.string().max(10)}).strict(),z.object({tripId:z.string().uuid(),flightId:z.string().max(100)}).strict()]);
export async function POST(request:Request){
 try {
  requirePersistentWorkspace();
  const owner=await user(request),body=input.safeParse(await request.json());
  if(!body.success)return json({error:'Enter a flight number and departure date.'},400);
  if(!env.FLIGHTAWARE_API_KEY)return json({error:'Flight lookup is not connected yet.'},503);
  const database=db(),query=flightQuery(database,env.FLIGHTAWARE_API_KEY);
  if('number' in body.data)return json(await lookupFlight(body.data.number,body.data.date,query));
  const {tripId,flightId}=body.data;
  const row=await database.prepare('SELECT data,version FROM trips WHERE id = ? AND owner = ? AND deleted_at IS NULL').bind(tripId,owner).first<{data:string;version:number}>();
  if(!row)return json({error:'Trip not found.'},404);
  const trip=await loadTrip(row.data,row.version),flight=trip.flights.find(f=>f.id===flightId);
  if(!flight?.flightaware)return json({error:'Look up this flight before refreshing it.'},400);
  if(flight.flightaware.complete||Date.parse(flight.flightaware.nextCheckAt)>Date.now())return json(trip);
  const result=await lookupFlight(flight.flightaware.ident,flight.date,query);
  const found=matchingFlight(flight,result.flights);
  if(!found)return json({error:'FlightAware has no unambiguous update for this flight. Your saved details are unchanged.'},422);
  const data=tripSchema.parse({...trip,flights:trip.flights.map(f=>f.id===flightId?{...f,flightaware:found.flightaware,arrivalAirport:found.arrivalAirport||f.arrivalAirport}:f)});
  const saved=await database.prepare('UPDATE trips SET data = ?, version = version + 1, updated_at = ? WHERE id = ? AND owner = ? AND version = ? AND deleted_at IS NULL').bind(JSON.stringify(data),Date.now(),tripId,owner,row.version).run();
  if(!saved.meta.changes)return json({error:'The trip changed during refresh. Try again.'},409);
  return json({...data,version:row.version+1});
 }catch(e){if(e instanceof FlightError)return json({error:e.message},e.status);return failure(e);}
}
