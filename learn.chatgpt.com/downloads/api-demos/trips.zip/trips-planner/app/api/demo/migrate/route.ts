import { env } from 'cloudflare:workers';
import { db, failure, json } from '@/lib/server';
import { cleanupDemoSessions, clearDemoContent, findDemoSession, requireDemoOrigin } from '@/lib/demo-session';
import { publicTurn, type TurnRow } from '@/lib/chat-store';
import { tripSchema } from '@/lib/trips';

// Transitional, cookie-scoped export of the old 24-hour workspace. Never accepts content writes.
export async function GET(request: Request) {
  try {
    if (env.TRIPS_DEMO_MODE !== 'true') return json({ error: 'Not found.' }, 404);
    const database = db();
    await cleanupDemoSessions(database);
    const session = await findDemoSession(database, request.headers);
    if (!session) return json(null);
    const running = await database.prepare("SELECT id FROM chat_turns WHERE owner=? AND status='running' AND created_at>?").bind(session.id, Date.now() - 240000).first();
    if (running) return json({ error: 'A previous reply is finishing. Reload in a moment to move your workspace into this browser.' }, 409);
    const { results: rows } = await database.prepare('SELECT data,version FROM trips WHERE owner=? AND deleted_at IS NULL').bind(session.id).all<{ data: string; version: number }>();
    const trips = rows.map(row => ({ ...tripSchema.parse(JSON.parse(row.data)), version: row.version }));
    const { results: turns } = await database.prepare('SELECT * FROM chat_turns WHERE owner=? AND archived_at IS NULL ORDER BY created_at').bind(session.id).all<TurnRow>();
    return json({ migrationId: session.id, trips, turns: turns.filter(turn => turn.trip_id === 'general' || trips.some(trip => trip.id === turn.trip_id)).map(row => ({
      ...publicTurn(row), tripId: row.trip_id, before: row.before_data ? JSON.parse(row.before_data) : null,
      ...(row.status === 'running' ? { status: 'error', assistant: 'The reply was interrupted. No itinerary changes were saved.' } : {}),
    })) });
  } catch (error) { return failure(error); }
}

export async function DELETE(request: Request) {
  try {
    if (env.TRIPS_DEMO_MODE !== 'true') return json({ error: 'Not found.' }, 404);
    requireDemoOrigin(request);
    const database = db(), session = await findDemoSession(database, request.headers);
    if (session) await clearDemoContent(database, session.id);
    return json({ migrated: true });
  } catch (error) { return failure(error); }
}
