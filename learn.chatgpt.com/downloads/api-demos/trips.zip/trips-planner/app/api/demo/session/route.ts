import { env } from 'cloudflare:workers';
import { db, failure, json } from '@/lib/server';
import { cleanupDemoSessions, createDemoSession, demoCookie, findDemoSession, requireDemoOrigin, resetDemoSession } from '@/lib/demo-session';
import { enforceDemoRateLimit } from '@/lib/demo-rate-limit';

export async function POST(request: Request) {
  try {
    if (env.TRIPS_DEMO_MODE !== 'true') return json({ error: 'Not found.' }, 404);
    requireDemoOrigin(request);
    const database = db();
    await cleanupDemoSessions(database);
    const existing = await findDemoSession(database, request.headers);
    if (existing) return json({ expiresAt: existing.expires_at });
    const limited = await enforceDemoRateLimit(database, request, 'new-session', { minute: 5, day: 20 });
    if (limited) return limited;
    const { session, cookie } = await createDemoSession(database);
    const response = json({ expiresAt: session.expires_at });
    response.headers.set('Set-Cookie', cookie);
    return response;
  } catch (error) { return failure(error); }
}

export async function DELETE(request: Request) {
  try {
    if (env.TRIPS_DEMO_MODE !== 'true') return json({ error: 'Not found.' }, 404);
    requireDemoOrigin(request);
    const database = db(), session = await findDemoSession(database, request.headers);
    if (session) await resetDemoSession(database, session);
    await cleanupDemoSessions(database);
    const response = json({ reset: true });
    response.headers.set('Set-Cookie', demoCookie('', 0));
    return response;
  } catch (error) { return failure(error); }
}
