import { requirePersistentWorkspace } from '@/lib/server';
import { getChatGPTUser } from '@/app/chatgpt-auth';
import { json } from '@/lib/server';

export const dynamic = 'force-dynamic';

// Shows only the signed-in visitor's Site-scoped identity for account setup.
export async function GET() {
  try {requirePersistentWorkspace();} catch(error) {if(error instanceof Response)return error;throw error;}
  const visitor = await getChatGPTUser();
  if (!visitor) return json({ error: 'Please sign in.' }, 401);
  return json({ userId: visitor.userId });
}
