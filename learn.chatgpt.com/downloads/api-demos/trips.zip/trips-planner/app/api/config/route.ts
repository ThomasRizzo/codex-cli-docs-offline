import { env } from 'cloudflare:workers';
import { user,json,failure } from '@/lib/server';
export async function GET(){try{await user();return json({googleMapsKey:env.TRIPS_DEMO_MODE==='true'?null:env.GOOGLE_MAPS_BROWSER_KEY||null,flightLookup:env.TRIPS_DEMO_MODE!=='true'&&!!env.FLIGHTAWARE_API_KEY});}catch(e){return failure(e);}}
