import { requirePersistentWorkspace } from '@/lib/server';
import { enrichArrivalAirports,cachedAirportQuery } from '@/lib/arrival-airports';
import { db } from '@/lib/server';
import { calendar } from '@/lib/calendar';
import { validCalendarToken, tokenHash } from '@/lib/calendar-token';
import type { Route, Trip } from '@/lib/trips';

export async function GET(_request: Request, context: { params: Promise<{ token: string }> }) {
  const headers = { 'Cache-Control': 'private, no-store', 'X-Robots-Tag': 'noindex, nofollow', 'Referrer-Policy': 'no-referrer' };
  try {
    requirePersistentWorkspace();
    const { token } = await context.params;
    if (!validCalendarToken(token)) return new Response('Not found', { status: 404, headers });
    // A revocable calendar token authorizes this read-only, public endpoint.
    const subscription = await db().prepare('SELECT owner FROM calendar_subscriptions WHERE token_hash = ?').bind(await tokenHash(token)).first<{ owner: string }>();
    if (!subscription) return new Response('Not found', { status: 404, headers });
    const { results } = await db().prepare('SELECT data,version,updated_at FROM trips WHERE owner = ? AND deleted_at IS NULL ORDER BY id').bind(subscription.owner).all<{ data: string; version: number; updated_at: number }>();
    const airportQuery=cachedAirportQuery(db());
    const rows = await Promise.all(results.map(async r => ({ trip:await enrichArrivalAirports({ ...JSON.parse(r.data), version: r.version } as Trip,airportQuery), updatedAt: r.updated_at })));
    const { results: cached } = await db().prepare("SELECT key,data FROM service_cache WHERE key LIKE 'route:%'").all<{ key: string; data: string }>();
    const routes: Record<string, Route> = Object.fromEntries(cached.map(r => [r.key.slice(6), JSON.parse(r.data)]));
    const body = calendar(rows, routes, 'https://trips.haydenbleasel.chatgpt.site');
    return new Response(body, { headers: { ...headers, 'Content-Type': 'text/calendar; charset=utf-8', 'Content-Disposition': 'inline; filename="trips.ics"', 'X-Content-Type-Options': 'nosniff' } });
  } catch (error) {
    if(error instanceof Response)return error;
    // Never return an empty calendar on failure: clients could delete events.
    return new Response('Calendar temporarily unavailable. Try again later.', { status: 503, headers: { ...headers, 'Retry-After': '300' } });
  }
}
