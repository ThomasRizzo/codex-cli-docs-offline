import { requirePersistentWorkspace } from '@/lib/server';
import { calendarURL } from '@/lib/sharing';
import { db, failure, json, user } from '@/lib/server';
import { newCalendarToken, tokenHash } from '@/lib/calendar-token';

export async function GET(request:Request) {
  try {
    requirePersistentWorkspace();
    const owner = await user();
    const row = await db().prepare('SELECT token FROM calendar_subscriptions WHERE owner = ?').bind(owner).first<{ token: string }>();
    return json({available:true,url:row?calendarURL(new URL(request.url).origin,row.token):null});
  } catch (e) { return failure(e); }
}
export async function POST(request: Request) {
  try {
    requirePersistentWorkspace();
    const owner = await user(request);
    const token = newCalendarToken();
    // Create is idempotent: re-opening the dialog never breaks a subscription.
    await db().prepare('INSERT INTO calendar_subscriptions (owner,token,token_hash,created_at) VALUES (?,?,?,?) ON CONFLICT(owner) DO NOTHING').bind(owner, token, await tokenHash(token), Date.now()).run();
    return GET(request);
  } catch (e) { return failure(e); }
}
export async function DELETE(request: Request) {
  try {
    requirePersistentWorkspace();
    const owner = await user(request);
    await db().prepare('DELETE FROM calendar_subscriptions WHERE owner = ?').bind(owner).run();
    return json({ revoked: true });
  } catch (e) { return failure(e); }
}
