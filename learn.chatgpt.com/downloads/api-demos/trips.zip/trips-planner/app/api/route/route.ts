import { json,user } from '@/lib/server';
import { loadRoute } from '@/lib/route-service';
import { z } from 'zod';
const point=z.object({lat:z.number().min(-85).max(85),lng:z.number().min(-180).max(180)});
export async function POST(request:Request){try{await user(request);const parsed=z.object({a:point,b:point,mode:z.enum(['walk','uber'])}).safeParse(await request.json());if(!parsed.success)return json({error:'Invalid route.'},400);const {a,b,mode}=parsed.data;return json(await loadRoute(a,b,mode));}catch(e){if(e instanceof Response)return e;return json({error:'No route available. Try the other travel option.'},503);}}
