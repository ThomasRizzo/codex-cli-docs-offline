import { placeTimeZone } from '@/lib/calendar';
import { failure, json, user } from '@/lib/server';
export async function GET(request: Request) { try { await user(); const p = new URL(request.url).searchParams; const lat = Number(p.get('lat')), lng = Number(p.get('lng')); if (!p.has('lat') || !p.has('lng') || !Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 85 || Math.abs(lng) > 180) return json({ error: 'Invalid location.' }, 400); return json({ timeZone: placeTimeZone({ lat, lng }) }); } catch (e) { return failure(e); } }
