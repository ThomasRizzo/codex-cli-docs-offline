import { requirePersistentWorkspace } from '@/lib/server';
import { db, failure, json } from '@/lib/server';
import { readSharedTrip } from '@/lib/sharing';
import { calendarRoutePairs } from '@/lib/chat-calendar';
import { planningDays, departureSchedule } from '@/lib/departures';
import { routeKey, type Route } from '@/lib/trips';
import { loadRoute } from '@/lib/route-service';
export async function GET(request:Request,context:{params:Promise<{token:string}>}){try{
  requirePersistentWorkspace();
  const {token}=await context.params,trip=await readSharedTrip(db(),token);
  if(!trip)return json({error:'This shared trip is unavailable.'},404);
  const day=new URL(request.url).searchParams.get('day')||trip.start;
  if(!planningDays(trip,trip.flights.map(f=>departureSchedule(f,trip.stops,{}))).includes(day))return json({error:'Choose a day in this trip.'},400);
  // Visitors can only resolve the saved itinerary's routes, never arbitrary
  // locations or paid flight/chat lookups. Existing route caching is reused.
  const pairs=calendarRoutePairs(trip,day),routes:Record<string,Route>={},routeErrors:Record<string,string>={};let next=0;
  await Promise.all(Array.from({length:Math.min(3,pairs.length)},async()=>{while(next<pairs.length){const {from,to,mode}=pairs[next++],key=routeKey(from,to,mode);try{routes[key]=await loadRoute(from,to,mode);}catch{routeErrors[key]='Route unavailable';}}}));
  // Recheck revocation after upstream work, before returning any itinerary.
  if(!await readSharedTrip(db(),token))return json({error:'This shared trip is unavailable.'},404);
  return json({trip,routes,routeErrors});
}catch(e){return failure(e);}}
