import { requirePersistentWorkspace } from '@/lib/server';
import { db, failure, json, user } from '@/lib/server';
import { newCalendarToken, tokenHash } from '@/lib/calendar-token';
import { shareURL } from '@/lib/sharing';
import { z } from 'zod';
async function owned(request:Request) {
  requirePersistentWorkspace();
  const owner=await user(request),id=z.string().uuid().safeParse(new URL(request.url).searchParams.get('trip'));
  if(!id.success)throw new Response('Not found',{status:404});
  const row=await db().prepare('SELECT id FROM trips WHERE id=? AND owner=? AND deleted_at IS NULL').bind(id.data,owner).first();
  if(!row)throw new Response('Not found',{status:404});
  return {owner,id:id.data};
}
async function link(request:Request,id:string,owner:string) {
  const row=await db().prepare('SELECT token FROM trip_shares WHERE trip_id=? AND owner=?').bind(id,owner).first<{token:string}>();
  return json({url:row?shareURL(new URL(request.url).origin,row.token):null});
}
export async function GET(request:Request){try{const {id,owner}=await owned(request);return link(request,id,owner);}catch(e){return failure(e);}}
export async function POST(request:Request){try{
  const {id,owner}=await owned(request),token=newCalendarToken();
  await db().prepare('INSERT INTO trip_shares (trip_id,owner,token,token_hash,created_at) VALUES (?,?,?,?,?) ON CONFLICT(trip_id) DO NOTHING').bind(id,owner,token,await tokenHash(token),Date.now()).run();
  return link(request,id,owner);
}catch(e){return failure(e);}}
export async function DELETE(request:Request){try{const {id,owner}=await owned(request);await db().prepare('DELETE FROM trip_shares WHERE trip_id=? AND owner=?').bind(id,owner).run();return json({revoked:true});}catch(e){return failure(e);}}
