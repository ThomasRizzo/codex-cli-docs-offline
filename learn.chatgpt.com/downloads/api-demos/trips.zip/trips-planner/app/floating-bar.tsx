'use client';
import { useEffect, useRef, useState } from 'react';
import { ShareIcon, MapPinIcon, PlusIcon, CalendarDaysIcon, AdjustmentsHorizontalIcon, MapIcon, Bars3Icon, ChevronUpDownIcon, CheckIcon, ChatBubbleLeftRightIcon, BuildingOffice2Icon, PaperAirplaneIcon } from '@heroicons/react/16/solid';
import type { Trip } from '@/lib/trips';
import { formatDate } from '@/lib/trips';

export type AddKind = 'event' | 'place' | 'hotel' | 'flight';
export type WorkspaceView = 'calendar' | 'map' | 'chat';
function DockButton({ label, children, onClick, active, className = '' }: { label: string; children: React.ReactNode; onClick: () => void; active?: boolean; className?: string }) {
  return <button type="button" className={`dock-button ${className}`} aria-label={label} aria-pressed={active} onClick={onClick}>{children}<span className="touch-target" aria-hidden="true"/><span className="dock-tooltip" aria-hidden="true">{label}</span></button>;
}
export default function FloatingBar({ assistantEnabled=true, trips, trip, demo, loading, view, onSelect, onExample, onNew, onSubscribe, onMenu, onView, onAdd, addingDisabled, onShare }: {
  assistantEnabled?:boolean; onShare?:()=>void; onAdd:(kind:AddKind)=>void; addingDisabled:boolean;
  trips: Trip[]; trip?: Trip; demo: boolean; loading: boolean; view: WorkspaceView;
  onSelect: (trip: Trip) => void; onExample: () => void; onNew: () => void; onSubscribe?: () => void; onMenu: () => void; onView: (view: WorkspaceView) => void;
}) {
  const addPopover=useRef<HTMLDivElement>(null),addTrigger=useRef<HTMLButtonElement>(null);
  const [adding,setAdding]=useState(false);
  useEffect(()=>{const p=addPopover.current;if(!p)return;const toggle=(e:Event)=>setAdding((e as ToggleEvent).newState==='open');p.addEventListener('toggle',toggle);return()=>p.removeEventListener('toggle',toggle);},[]);
  function add(kind:AddKind){addPopover.current?.hidePopover();addTrigger.current?.focus();onAdd(kind);}
  const popover = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const [expanded, setExpanded] = useState(false);
  useEffect(() => { const element=popover.current; if(!element)return; const toggle=(event:Event)=>setExpanded((event as ToggleEvent).newState==='open'); element.addEventListener('toggle',toggle); return()=>element.removeEventListener('toggle',toggle); },[]);
  function closeThen(action:()=>void) { popover.current?.hidePopover(); trigger.current?.focus(); action(); }
  return <nav className="floating-bar workspace-dock" aria-label="Planner actions">
    <button type="button" ref={trigger} className="trip-switcher-trigger" popoverTarget="trip-switcher" aria-haspopup="dialog" aria-expanded={expanded} aria-label={`Switch trip${trip?': '+trip.name:''}`} disabled={loading}><MapPinIcon/><span>{loading?'Loading…':trip?.name||'Select trip'}</span><ChevronUpDownIcon/><span className="touch-target" aria-hidden="true"/></button>
    <div id="trip-switcher" ref={popover} popover="auto" role="dialog" aria-labelledby="trip-switcher-title" className="trip-switcher-popover">
      <h2 id="trip-switcher-title">Trips</h2>
      <div className="trip-switcher-list">{[...trips].sort((a,b)=>a.start.localeCompare(b.start)).map(t=><button type="button" className="trip-option" key={t.id} aria-pressed={!demo&&trip?.id===t.id} onClick={()=>closeThen(()=>onSelect(t))}><span><strong>{t.name}</strong><small>{formatDate(t.start)} – {formatDate(t.end,{month:'short',day:'numeric',year:'numeric'})}</small></span>{!demo&&trip?.id===t.id&&<CheckIcon/>}</button>)}{!trips.length&&<p className="no-trips">No trips yet.</p>}</div>
      <div className="trip-switcher-footer"><button type="button" onClick={()=>closeThen(onNew)}><PlusIcon/>Add trip</button>{!trips.length&&<button type="button" className="example-option" onClick={()=>closeThen(onExample)}>View example</button>}</div>
    </div>
    <button type="button" ref={addTrigger} className="dock-button" popoverTarget="add-to-trip" aria-label="Add to trip" aria-haspopup="dialog" aria-expanded={adding} disabled={addingDisabled}><PlusIcon/><span className="touch-target" aria-hidden="true"/><span className="dock-tooltip" aria-hidden="true">Add</span></button>
    <div ref={addPopover} id="add-to-trip" popover="auto" role="dialog" aria-label="Add to trip" className="trip-switcher-popover dock-add-popover">
      <button type="button" onClick={()=>add('event')}><CalendarDaysIcon/>Event</button>
      <button type="button" onClick={()=>add('place')}><MapPinIcon/>Place</button>
      <button type="button" onClick={()=>add('hotel')}><BuildingOffice2Icon/>Hotel</button>
      <button type="button" onClick={()=>add('flight')}><PaperAirplaneIcon/>Flight</button>
    </div>
    <span className="dock-divider" aria-hidden="true"/>
    {assistantEnabled&&<DockButton label="Show assistant" onClick={()=>onView('chat')} active={view==='chat'} className="dock-compact"><ChatBubbleLeftRightIcon/></DockButton>}
    <DockButton label="Show map" onClick={()=>onView('map')} active={view==='map'} className="dock-mobile"><MapIcon/></DockButton>
    <DockButton label="Show calendar" onClick={()=>onView('calendar')} active={view==='calendar'} className="dock-compact"><CalendarDaysIcon/></DockButton>
    {onShare&&<DockButton label="Share trip" onClick={onShare}><ShareIcon/></DockButton>}
    {onSubscribe&&<DockButton label="Calendar subscription" onClick={onSubscribe} className="dock-desktop"><CalendarDaysIcon/></DockButton>}
    <DockButton label={trip?'Trip options':'Options'} onClick={onMenu}><AdjustmentsHorizontalIcon className="dock-desktop"/><Bars3Icon className="dock-mobile"/></DockButton>
  </nav>;
}
