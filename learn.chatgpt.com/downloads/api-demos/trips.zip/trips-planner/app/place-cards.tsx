'use client';
import { useRef } from 'react';
import { MapPinIcon, PlusIcon, CheckIcon, StarIcon, ArrowUpRightIcon } from '@heroicons/react/16/solid';
import { useScheduling } from './scheduling';
import { useGooglePlaceDetails } from './google-place-details';
import type { RecommendedPlace } from '@/lib/recommendations';

type Props={places:RecommendedPlace[];googleMapsKey?:string;active:string|null;selected:string|null;added:Set<string>;onHighlight:(id:string|null)=>void;onSelect:(id:string)=>void;onAdd?:(place:RecommendedPlace)=>void};

function PlaceCard({place:p,index,googleMapsKey,active,selected,added,onHighlight,onSelect,onAdd}:Omit<Props,'places'|'added'> & {place:RecommendedPlace;index:number;added:boolean}){
 const schedule=useScheduling(),element=useRef<HTMLLIElement>(null);
 const {details,hidePhoto}=useGooglePlaceDetails(p,googleMapsKey,element);
 const mapInteraction={
  'data-schedulable':schedule?.canDrag||undefined,draggable:false,
  onPointerDown:(e:React.PointerEvent<HTMLButtonElement>)=>schedule?.pointerDown(e,{place:p}),
  title:schedule?.canDrag?'Drag onto the calendar to schedule':undefined,
  onClick:()=>onSelect(p.id),'aria-label':'Show '+p.name+' on map','aria-pressed':selected===p.id,
 };
 return <li ref={element} className={'place-card'+(active===p.id?' is-highlighted':'')+(selected===p.id?' is-selected':'')} data-recommendation-id={p.id} onMouseEnter={()=>onHighlight(p.id)} onMouseLeave={()=>onHighlight(null)} onFocus={()=>onHighlight(p.id)} onBlur={e=>{if(!e.currentTarget.contains(e.relatedTarget))onHighlight(null);}}>
  {details?.photo&&<figure className="place-card-media">
   <button type="button" className="place-card-photo" {...mapInteraction} tabIndex={-1}><img src={details.photo} alt="" loading="lazy" width={720} height={480} draggable={false} onError={hidePhoto}/></button>
   {(details.authors.length>0||details.photoUrl)&&<figcaption className="place-photo-credit"><div>{details.authors.map((a,i)=><span key={i}>{i>0?', ':''}{a.url?<a href={a.url} target="_blank" rel="noopener noreferrer">{a.name}</a>:a.name}</span>)}</div>{details.photoUrl&&<a className="place-photo-original" href={details.photoUrl} target="_blank" rel="noopener noreferrer" aria-label={'View original photo of '+p.name}><ArrowUpRightIcon/><span className="touch-target" aria-hidden="true"/></a>}</figcaption>}
  </figure>}
  <button type="button" className="place-card-main" {...mapInteraction}>
   <div className="place-card-heading"><span className="place-card-number">{String.fromCharCode(65+index)}</span><h3>{p.name}</h3><MapPinIcon/></div>
   <p className="place-card-address" title={p.address}>{p.address.split(',')[0]}</p>
   <p className="place-card-reason">{p.reason}</p>
  </button>
  {(details?.rating!=null||onAdd)&&<div className="place-card-actions">
   {details?.rating!=null&&<div className="place-card-rating" aria-label={`${details.rating.toFixed(1)} out of 5${details.count!=null?`, ${details.count.toLocaleString()} reviews`:''}`}><StarIcon/><p>{details.rating.toFixed(1)}{details.count!=null&&<span> ({details.count.toLocaleString()})</span>}</p></div>}
   {onAdd&&<button type="button" onClick={()=>onAdd(p)} disabled={added||!schedule?.enabled}>{added?<><CheckIcon/>Scheduled</>:<><PlusIcon/>Schedule</>}<span className="touch-target" aria-hidden="true"/></button>}
  </div>}
 </li>;
}

export default function PlaceCards(props:Props){
 return <div className="place-results"><ol className="place-cards" role="list" aria-label="Recommended places">{props.places.map((place,index)=><PlaceCard {...props} key={place.id} place={place} index={index} added={props.added.has(place.id)}/>)}</ol>{props.googleMapsKey&&<div className="place-results-attribution"><img src="/google-maps-attribution.svg" alt="Google Maps" width={80} height={16}/></div>}</div>;
}
