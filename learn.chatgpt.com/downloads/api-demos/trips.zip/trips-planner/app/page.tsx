import { env } from 'cloudflare:workers';
import { getChatGPTUser } from './chatgpt-auth';
import { isTripOwner } from '@/lib/access';
import { assistantEnabled } from '@/lib/assistant-config';
import AccessScreen from './access-screen';
import Planner from './planner';
import { tripPath } from '@/lib/day-query';
export const dynamic='force-dynamic';
export default async function Home({searchParams}:{searchParams:Promise<{trip?:string;day?:string}>}){if(env.TRIPS_DEMO_MODE==='true')return <Planner anonymousDemo assistantEnabled={assistantEnabled(env)}/>;const visitor=await getChatGPTUser(),{trip,day}=await searchParams;if(!isTripOwner(visitor?.userId,env.TRIPS_OWNER_ID))return <AccessScreen signedIn={!!visitor} returnTo={tripPath(trip,day)}/>;return <Planner assistantEnabled={assistantEnabled(env)}/>;}
