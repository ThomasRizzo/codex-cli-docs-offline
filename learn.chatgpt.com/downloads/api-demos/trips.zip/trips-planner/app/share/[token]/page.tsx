import { notFound } from 'next/navigation';
import { env } from 'cloudflare:workers';
import { db } from '@/lib/server';
import { readSharedTrip } from '@/lib/sharing';
import { selectedCalendarDay } from '@/lib/day-query';
import SharedTrip from '../../shared-trip';
export const dynamic='force-dynamic';
export default async function SharePage({params,searchParams}:{params:Promise<{token:string}>;searchParams:Promise<{day?:string}>}) {
  if(env.TRIPS_DEMO_MODE==='true')notFound();
  const {token}=await params,{day}=await searchParams,trip=await readSharedTrip(db(),token);
  if(!trip)notFound();
  return <SharedTrip initialTrip={trip} initialDay={selectedCalendarDay(day,trip)} token={token} googleMapsKey={env.GOOGLE_MAPS_BROWSER_KEY}/>;
}
