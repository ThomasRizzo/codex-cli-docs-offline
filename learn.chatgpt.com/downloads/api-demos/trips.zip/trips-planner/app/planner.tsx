'use client';
import { hasLocation, sameLocation, withHotelCheckIns, hotelCheckInIssue } from '@/lib/trips';
import { changedArrivalTravelLegs, arrivalTimeIssue } from '@/lib/arrivals';
import { chooseTravelModes, previewTravelModes } from '@/lib/auto-travel';
import { initializeBrowserDemo } from '@/lib/demo-client';
import { listLocalTrips, saveLocalTrip, deleteLocalTrip, resetLocalWorkspace, subscribeLocalWorkspace } from '@/lib/local-workspace';
import { OptimisticTrips } from '@/lib/optimistic-trips';
import { selectedCalendarDay } from '@/lib/day-query';
import { useCalendarDayQuery } from './use-calendar-day-query';
import EventForm from './event-form';
import { stopDuration, stopMinute } from '@/lib/event-duration';
import { useState,useEffect,useRef,useCallback } from 'react';
import { Plus,ArrowRight,MapPin,Check,X } from 'lucide-react';
import type { Place,Stop,Trip,Flight,Route,Hotel } from '@/lib/trips';
import { days,formatDate,routeKey } from '@/lib/trips';
import { orderedDayStops } from '@/lib/calendar-travel';
import { example } from '@/lib/example';
import TripMap from './map';
import FloatingBar, { type WorkspaceView } from './floating-bar';
import AssistantPane from './assistant-pane';
import type { RecommendedPlace, RecommendationSet } from '@/lib/recommendations';
import { PlusIcon, XMarkIcon, PencilSquareIcon, TrashIcon, ArrowDownTrayIcon } from '@heroicons/react/16/solid';
import TripSharing from './trip-sharing';
import CalendarSubscription from './calendar-subscription';
import TimeZoneSelect from './time-zone-select';
import { api,Modal,PlaceSearch } from './controls';
import DepartureForm from './departure-form';
import { SchedulingProvider, SchedulePrompt } from './scheduling';
import { placeOnCalendar, resizeCalendarStop, fitCalendarSwap, type CalendarChange, type ScheduleItem } from '@/lib/scheduling';
import { changedTravelLegs, scheduleTravelAvailability, type ScheduleAvailability, type ScheduleTravelLeg } from '@/lib/schedule-travel';
import DayCalendar,{DepartureSummary} from './day-calendar';
import HotelForm from './hotel-form';
import FlightForm from './flight-form';
import { dayRoute, hotelDayBounds, type DayPoint } from '@/lib/hotels';
import { departureSchedule,departureOrigin,planningDays,clashesWithDeparture } from '@/lib/departures';

function uid(){return crypto.randomUUID();}
function localToday(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function timeLabel(time:string){if(!time)return '';const [h,m]=time.split(':').map(Number);return `${h%12||12}:${String(m).padStart(2,'0')} ${h<12?'am':'pm'}`;}

function TripForm({trip,onSave,onClose}:{trip?:Trip;onSave:(trip:Trip)=>Promise<void>;onClose:()=>void}){const [place,setPlace]=useState<Place|null>(trip?.destination||null),[zone,setZone]=useState(trip?.timeZone||''),[name,setName]=useState(trip?.name||''),[start,setStart]=useState(trip?.start||localToday()),[end,setEnd]=useState(trip?.end||localToday()),[busy,setBusy]=useState(false),[error,setError]=useState('');useEffect(()=>{if(!place||zone)return;let stale=false;api<{timeZone:string}>('/api/timezone?'+new URLSearchParams({lat:String(place.lat),lng:String(place.lng)})).then(r=>{if(!stale)setZone(r.timeZone);}).catch(()=>{});return()=>{stale=true;};},[place]);async function submit(e:React.FormEvent){e.preventDefault();if(!place)return;setBusy(true);setError('');try{await onSave({...trip,id:trip?.id||uid(),name:name.trim()||place.name,destination:place,timeZone:zone||undefined,start,end,stops:trip?.stops||[],flights:trip?.flights||[],version:trip?.version||0});onClose();}catch(e){setError((e as Error).message);setBusy(false);}}return <Modal title={trip?'Edit trip':'New trip'} onClose={onClose}>{!place?<><PlaceSearch placeholder="Search a city or destination" onPick={p=>{setPlace(p);setZone('');if(!name)setName(p.name);}}/></>:<form onSubmit={submit} className="form"><div className="chosen-place"><MapPin size={18}/><div><strong>{place.name}</strong><small>{place.address}</small></div><button type="button" className="text-button" onClick={()=>setPlace(null)}>Change</button></div><label>Trip name<input autoFocus value={name} onChange={e=>setName(e.currentTarget.value)} maxLength={100} placeholder={place.name} required/></label><div className="two-col"><label>First day<input type="date" value={start} onInput={e=>{setStart(e.currentTarget.value);if(end<e.currentTarget.value)setEnd(e.currentTarget.value);}} required/></label><label>Last day<input type="date" min={start} value={end} onInput={e=>setEnd(e.currentTarget.value)} required/></label></div><TimeZoneSelect label="Trip time zone" value={zone} onChange={setZone} placeholder="Use each place’s time zone"/><p className="field-note">Suggested from your destination. Used for local event times.</p>{trip&&<p className="field-note">Stops keep their dates. Move or remove any stops outside your new dates first.</p>}{error&&<p className="error" role="alert">{error}</p>}<div className="form-actions"><button type="button" onClick={onClose}>Cancel</button><button className="primary" disabled={busy}>{busy?'Saving…':trip?'Save changes':'Create trip'}<ArrowRight size={16}/></button></div></form>}</Modal>;}
function StopForm({trip,day,stop,initialPlace,initialTime='',onSave,onClose,onRemove}:{trip:Trip;day:string;stop?:Stop;initialPlace?:Place;initialTime?:string;onSave:(s:Stop)=>Promise<void>;onClose:()=>void;onRemove?:()=>Promise<void>}){const [place,setPlace]=useState<Place|null>(stop&&hasLocation(stop)?stop:initialPlace||null),[date,setDate]=useState(stop?.date||day),[time,setTime]=useState(stop?.time??initialTime),[zone,setZone]=useState(stop?.timeZone||''),[note,setNote]=useState(stop?.note||''),[booked,setBooked]=useState(stop?.booked??false),[minutes,setMinutes]=useState(stopDuration(stop||{time:initialTime})),[busy,setBusy]=useState(false),[error,setError]=useState('');async function remove(){if(!onRemove)return;setBusy(true);setError('');try{await onRemove();onClose();}catch(e){setError((e as Error).message);setBusy(false);}}async function submit(e:React.FormEvent){e.preventDefault();if(!place)return;setBusy(true);try{await onSave({...place,id:stop?.id||uid(),date,time,durationMinutes:minutes,timeZone:zone||undefined,note,booked,mode:stop?.mode||'walk'});onClose();}catch(e){setError((e as Error).message);setBusy(false);}}return <Modal title={stop?'Edit place':'Add a place'} onClose={onClose}>{!place?<PlaceSearch center={trip.destination} onPick={setPlace}/>:<form className="form" onSubmit={submit}><div className="chosen-place"><MapPin size={18}/><div><strong>{place.name}</strong><small>{place.address}</small></div><button type="button" className="text-button" onClick={()=>setPlace(null)}>Change</button></div><div className="two-col"><label>Day<select value={date} onChange={e=>setDate(e.currentTarget.value)}>{days(trip.start,trip.end).map(d=><option key={d} value={d}>{formatDate(d,{weekday:'short',month:'short',day:'numeric'})}</option>)}</select></label><label>Time <span className="muted">(optional)</span><input type="time" value={time} onInput={e=>setTime(e.currentTarget.value)}/></label></div>{time&&<label>Duration <span className="muted">(minutes)</span><input type="number" min={1} max={1440-(stopMinute({time})||0)} step={1} required value={minutes} onInput={e=>setMinutes(Number(e.currentTarget.value))}/></label>}<TimeZoneSelect label="Place time zone" value={zone} onChange={setZone} placeholder={trip.timeZone?`Use ${trip.timeZone.replace(/_/g,' ')}`:"Use this place’s time zone"}/><label>A note <span className="muted">(optional)</span><textarea value={note} onChange={e=>setNote(e.currentTarget.value)} placeholder="Reservation, a reminder, or something to try…" maxLength={1500} rows={3}/></label><label className="booked-field" htmlFor="place-booked"><input id="place-booked" name="booked" type="checkbox" checked={booked} onChange={e=>setBooked(e.currentTarget.checked)}/>Booked</label>{error&&<p className="error" role="alert">{error}</p>}<div className="form-actions">{onRemove&&<button type="button" className="flight-delete danger" disabled={busy} onClick={remove}>Remove place</button>}<button type="button" onClick={onClose}>Cancel</button><button className="primary" disabled={busy}>{busy?'Saving…':stop?'Save changes':'Add to day'}<Plus size={16}/></button></div></form>}</Modal>;}

function MapDataCredit(){
 const [visible,setVisible]=useState(true),element=useRef<HTMLDivElement>(null);
 useEffect(()=>{let timer:ReturnType<typeof setTimeout>|undefined;const observer=new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting)){if(!timer)timer=setTimeout(()=>setVisible(false),6000);}else{clearTimeout(timer);timer=undefined;}});if(element.current)observer.observe(element.current);return()=>{clearTimeout(timer);observer.disconnect();};},[]);
 return visible?<div ref={element} className="workspace-map-credit">Route &amp; place data © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a></div>:null;
}

export default function Planner({assistantEnabled=false,anonymousDemo=false}:{assistantEnabled?:boolean;anonymousDemo?:boolean}){
 const [resetting,setResetting]=useState(false),[resetDialog,setResetDialog]=useState(false);
 async function resetDemo(){setResetting(true);try{await resetLocalWorkspace();await api('/api/demo/session',{method:'DELETE',signal:AbortSignal.timeout(5000)}).catch(()=>{});try{localStorage.removeItem('trips.active');}catch{}location.replace('/');}catch(e){setError((e as Error).message);setResetting(false);}}
 const [recommendationSet,setRecommendationSet]=useState<RecommendationSet|null>(null),[highlightedRecommendation,setHighlightedRecommendation]=useState<string|null>(null),[selectedRecommendation,setSelectedRecommendation]=useState<string|null>(null),[suggestedPlace,setSuggestedPlace]=useState<Place|undefined>(),[googleMapsKey,setGoogleMapsKey]=useState<string|undefined>(),[flightLookup,setFlightLookup]=useState(false);
 const receiveRecommendations=useCallback((set:RecommendationSet|null)=>{setRecommendationSet(set);setHighlightedRecommendation(null);setSelectedRecommendation(null);},[]);

 const [trips,setTrips]=useState<Trip[]>([]),[active,setActive]=useState<string|null>(null),[demo,setDemo]=useState(false),[day,setDay]=useState(''),[loading,setLoading]=useState(true),[saving,setSaving]=useState(false),[calendarSaving,setCalendarSaving]=useState(false),[error,setError]=useState(''),[toast,setToast]=useState(''),[modal,setModal]=useState<'trip'|'edit-trip'|'stop'|'event'|'flight'|'hotel'|'departure'|'subscribe'|'share'|null>(null),[editStop,setEditStop]=useState<Stop|undefined>(),[editFlight,setEditFlight]=useState<Flight|undefined>(),[editHotel,setEditHotel]=useState<Hotel|undefined>(),[selected,setSelected]=useState<string|null>(null),[routes,setRoutes]=useState<Record<string,Route>>({}),[routeErrors,setRouteErrors]=useState<Record<string,string>>({}),[menu,setMenu]=useState(false),[deleteTrip,setDeleteTrip]=useState(false),[workspaceView,setWorkspaceView]=useState<WorkspaceView>(assistantEnabled?'chat':'calendar'),[draftTime,setDraftTime]=useState(''),[routeRevision,setRouteRevision]=useState(0);
 const [scheduleNotice,setScheduleNotice]=useState<{tripId:string;version:number;before:Stop[];beforeHotels:Hotel[]|undefined;message:string}|null>(null);
 const routesRef=useRef(routes);routesRef.current=routes;
 const routeRequests=useRef(new Map<string,Promise<Route>>());
 const mutation=useRef(false),tripRef=useRef<Trip|undefined>(undefined);const trip=demo?example:trips.find(t=>t.id===active);tripRef.current=trip;const stops=trip?orderedDayStops(trip.stops,day):[];const hotelRoute=trip?dayRoute(trip,day):{start:null,end:null,points:[],hotels:{start:undefined,end:undefined},arrival:null};const routePoints=hotelRoute.points;const airportPairs=(trip?.flights||[]).flatMap(f=>{const a=trip?departureOrigin(f,trip.stops):null;return a&&f.departurePlan&&!f.departurePlan.driveOverrideMinutes?[{a,b:f.departurePlan.airport,mode:'uber' as const}]:[];});const routePairs=[...airportPairs,...routePoints.slice(1).flatMap((s,i)=>sameLocation(routePoints[i],s)?[]:[{a:routePoints[i],b:s,mode:s.mode}])];const key=routePairs.map(p=>routeKey(p.a,p.b,p.mode)).join('|');const schedules=trip?trip.flights.map(f=>departureSchedule(f,trip.stops,routes,routeErrors)):[];const visibleDays=trip?planningDays(trip,schedules):[];
 const applyTrip=(updated:Trip)=>{if(tripRef.current?.id===updated.id&&updated.version>=tripRef.current.version)tripRef.current=updated;setTrips(ts=>ts.map(t=>t.id===updated.id&&updated.version>=t.version?updated:t));};
 useCalendarDayQuery(loading?undefined:trip,day,setDay,visibleDays,demo?'example':trip?.id);
 const optimisticRef=useRef<OptimisticTrips|null>(null);
 if(!optimisticRef.current)optimisticRef.current=new OptimisticTrips({
  save:next=>anonymousDemo?saveLocalTrip(next):api<Trip>('/api/trips',{method:'PATCH',body:JSON.stringify(next)}),
  reload:async id=>(await (anonymousDemo?listLocalTrips():api<Trip[]>('/api/trips'))).find(t=>t.id===id),
  onChange:applyTrip,onPending:setCalendarSaving,
  onError:(error,id)=>{setError(error.message);if(tripRef.current?.id===id)setScheduleNotice(null);},
 });
 const optimistic=optimisticRef.current;
 useEffect(()=>{if(!calendarSaving)return;const warn=(event:BeforeUnloadEvent)=>{event.preventDefault();event.returnValue='';};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);},[calendarSaving]);
 useEffect(()=>{(anonymousDemo?initializeBrowserDemo():Promise.resolve()).then(()=>Promise.all([anonymousDemo?listLocalTrips():api<Trip[]>('/api/trips'),anonymousDemo?Promise.resolve({googleMapsKey:null,flightLookup:false}):api<{googleMapsKey:string|null;flightLookup:boolean}>('/api/config')])).then(([data,config])=>{setTrips(data);setGoogleMapsKey(config.googleMapsKey||undefined);setFlightLookup(config.flightLookup);const id=new URL(location.href).searchParams.get('trip');let remembered:string|null=null;try{remembered=localStorage.getItem('trips.active');}catch{}if(id==='example'&&!anonymousDemo){open(example,true);return;}const sorted=[...data].sort((a,b)=>a.start.localeCompare(b.start));const found=data.find(t=>t.id===id)||data.find(t=>t.id===remembered)||sorted.find(t=>t.end>=localToday())||sorted.at(-1);if(found)open(found);}).catch(e=>setError(e.message)).finally(()=>setLoading(false));},[]);
 useEffect(()=>{if(!anonymousDemo||loading)return;return subscribeLocalWorkspace(()=>{if(mutation.current||optimistic.busy)return;void listLocalTrips().then(data=>{setTrips(data);for(const saved of data)optimistic.receive(saved);if(tripRef.current&&!data.some(t=>t.id===tripRef.current?.id)){if(data.length)open(data[0]);else clearTrip();}}).catch(e=>setError(e.message));});},[anonymousDemo,loading]);
 useEffect(()=>{if(!toast)return;const timer=setTimeout(()=>setToast(''),3500);return()=>clearTimeout(timer);},[toast]);
 useEffect(()=>{
  if(!flightLookup||demo||modal||!active)return;
  let stopped=false,running=false;const retryAt=new Map<string,number>();
  async function refresh(){
   if(stopped||running||mutation.current||optimistic.busy||document.visibilityState!=='visible')return;
   const current=tripRef.current;if(!current||current.id!==active)return;
   const flight=current.flights.find(f=>f.flightaware&&!f.flightaware.complete&&Date.parse(f.flightaware.nextCheckAt)<=Date.now()&&(retryAt.get(f.id)||0)<=Date.now()&&Date.parse(f.date)>Date.now()-7*86400000);
   if(!flight)return;running=true;mutation.current=true;setSaving(true);
   try{const saved=await api<Trip>('/api/flights',{method:'POST',body:JSON.stringify({tripId:current.id,flightId:flight.id})});optimistic.receive(saved);}
   catch{retryAt.set(flight.id,Date.now()+15*60000);}
   finally{running=false;mutation.current=false;setSaving(false);}
  }
  const timer=setInterval(refresh,60000);const initial=setTimeout(refresh,2000);document.addEventListener('visibilitychange',refresh);
  return()=>{stopped=true;clearInterval(timer);clearTimeout(initial);document.removeEventListener('visibilitychange',refresh);};
 },[active,demo,flightLookup,modal]);
 useEffect(()=>{if(!trip)return;let cancelled=false;async function load(){for(const {a,b,mode} of routePairs){const k=routeKey(a,b,mode);if(routes[k]||routeErrors[k])continue;try{await ensureRoute(a,b,mode);}catch{}if(cancelled)break;await new Promise(r=>setTimeout(r,1100));}}load();return()=>{cancelled=true;};},[key,routeRevision]);
 function open(t:Trip,isDemo=false){const url=new URL(location.href),key=isDemo?'example':t.id,requested=!url.searchParams.has('trip')||url.searchParams.get('trip')===key?url.searchParams.get('day'):null;const date=selectedCalendarDay(requested,t);setScheduleNotice(null);receiveRecommendations(null);setDemo(isDemo);setActive(t.id);setDay(date);setSelected(null);setMenu(false);setWorkspaceView(assistantEnabled?'chat':'calendar');setError('');url.searchParams.set('trip',key);url.searchParams.set('day',date);history.replaceState(history.state,'',url);if(!isDemo){try{localStorage.setItem('trips.active',t.id);}catch{}}}
 function clearTrip(){setScheduleNotice(null);receiveRecommendations(null);setActive(null);setDay('');setDemo(false);setMenu(false);setDeleteTrip(false);setSelected(null);setWorkspaceView(assistantEnabled?'chat':'calendar');history.replaceState(null,'','/');try{localStorage.removeItem('trips.active');}catch{}}
 async function persist(t:Trip,isNew=false,automaticTravel=true){if(demo&&!isNew)throw new Error('This is an example. Create a trip to make it your own.');if(mutation.current||optimistic.busy)throw new Error('Please wait for the current change to save.');mutation.current=true;setSaving(true);try{t=withHotelCheckIns(t);if(automaticTravel)t=await chooseTravelModes(!isNew&&tripRef.current?.id===t.id?tripRef.current:undefined,t,ensureRoute);const saved=await (anonymousDemo?saveLocalTrip(t,isNew):api<Trip>('/api/trips',{method:isNew?'POST':'PATCH',body:JSON.stringify(t)}));if(isNew)setTrips(old=>[saved,...old]);else optimistic.receive(saved);if(isNew)open(saved);return saved;}finally{mutation.current=false;setSaving(false);}}
 async function update(t:Trip){try{await persist(t);}catch(e){setError((e as Error).message);}}
 async function changeTravelMode(stop:DayPoint,mode:Stop['mode']){const current=tripRef.current;if(!current)return;if(stop.arrivalTransferFlightId){await persist({...current,flights:current.flights.map(f=>f.id===stop.arrivalTransferFlightId?{...f,arrivalMode:mode}:f)});}else if(stop.hotelId){await persist({...current,hotels:(current.hotels||[]).map(h=>h.id===stop.hotelId?{...h,returnModes:{...h.returnModes,[stop.date]:mode}}:h)});}else await persist({...current,stops:current.stops.map(s=>s.id===stop.id?{...s,mode}:s)});}
 async function ensureRoute(a:Place,b:Place,mode:Stop['mode']):Promise<Route>{
  const key=routeKey(a,b,mode),cached=routesRef.current[key];if(cached)return cached;
  const pending=routeRequests.current.get(key);if(pending)return pending;
  const request=api<Route>('/api/route',{method:'POST',body:JSON.stringify({a,b,mode})}).then(result=>{
   routesRef.current={...routesRef.current,[key]:result};setRoutes(routesRef.current);
   setRouteErrors(old=>{const next={...old};delete next[key];return next;});return result;
  }).catch(error=>{setRouteErrors(old=>({...old,[key]:(error as Error).message}));throw error;}).finally(()=>routeRequests.current.delete(key));
  routeRequests.current.set(key,request);return request;
 }
 async function prepareScheduleRoutes(legs:ScheduleTravelLeg[]){await Promise.all(legs.filter(leg=>hasLocation(leg.from)&&hasLocation(leg.to)).map(leg=>ensureRoute(leg.from as Place,leg.to as Place,leg.to.mode)));}
 async function retryRoute(from:Stop,to:Stop){if(hasLocation(from)&&hasLocation(to))await ensureRoute(from,to,to.mode);}
 function scheduleAvailability(item:ScheduleItem,time:string,swapId?:string):ScheduleAvailability{
  const current=tripRef.current;
  try{
   if(!current)throw new Error('Select a trip first.');
   const change=placeOnCalendar(current,item,day,time,'schedule-preview',swapId);
   const planned=previewStopChange(current,change,routeErrors);
   return scheduleTravelAvailability([...changedTravelLegs(current.stops,planned.stops),...changedArrivalTravelLegs(current,planned)],routes,routeErrors);
  }catch(error){return {status:'blocked',label:'Choose another time',message:(error as Error).message,missing:[]};}
 }

 async function removeTrip(){if(!trip||optimistic.busy||mutation.current)return;setSaving(true);try{await (anonymousDemo?deleteLocalTrip(trip.id):api('/api/trips?id='+trip.id,{method:'DELETE'}));const remaining=trips.filter(t=>t.id!==trip.id);setTrips(remaining);setDeleteTrip(false);if(remaining.length)open([...remaining].sort((a,b)=>a.start.localeCompare(b.start))[0]);else clearTrip();setToast('Trip deleted.');}catch(e){setError((e as Error).message);}finally{setSaving(false);}}
 function addPlace(time=''){setEditStop(undefined);setSuggestedPlace(undefined);setDraftTime(time);setModal('stop');}
 function addEvent(time='09:00'){setEditStop(undefined);setDraftTime(time);setModal('event');}
 function editPlace(stop:Stop){setEditStop(stop);setSelected(stop.id);setModal(stop.kind==='event'?'event':'stop');}
 function editHotelStay(hotel:Hotel){setEditHotel(hotel);setModal('hotel');}
 function editDeparture(flight:Flight){setEditFlight(flight);setModal('departure');}
 function newTrip(){setMenu(false);setModal('trip');}
 function chooseDay(date:string){setDay(date);setSelected(null);}
 function showPlace(id:string){setSelected(id);const stop=trip?.stops.find(s=>s.id===id);setWorkspaceView(stop&&!hasLocation(stop)?'calendar':'map');setModal(null);}
 function selectFromMap(id:string){setSelected(id);setWorkspaceView('calendar');requestAnimationFrame(()=>document.querySelector(`[data-stop-id="${CSS.escape(id)}"]`)?.scrollIntoView({block:'center',behavior:'instant'}));}
 function checkStopTiming(current:Trip,next:Trip,stop:Stop){
  const old=current.stops.find(s=>s.id===stop.id);
  if(old&&old.date===stop.date&&old.time===stop.time&&stopDuration(old)===stopDuration(stop)&&old.lat===stop.lat&&old.lng===stop.lng)return;
  const arrivalIssue=arrivalTimeIssue(stop,next);if(arrivalIssue)throw new Error(arrivalIssue);
  const checkInIssue=hotelCheckInIssue(stop,next);if(checkInIssue)throw new Error(checkInIssue);
  const plans=current.flights.map(f=>departureSchedule(f,current.stops,routesRef.current,routeErrors));
  if(clashesWithDeparture(stop,plans))throw new Error('That time is reserved for the airport. Choose another time.');
 }
 function checkedStopChange(current:Trip,edit:(base:Trip)=>CalendarChange){
  if(mutation.current)throw new Error('Please wait for the current change to save.');
  const change=edit(current);
  const preview=previewStopChange(current,change);
  const availability=scheduleTravelAvailability([...changedTravelLegs(current.stops,preview.stops),...changedArrivalTravelLegs(current,preview)],routesRef.current);
  if(availability.status==='blocked')throw new Error(availability.message);
  const result=optimistic.enqueue(current,base=>previewStopChange(base,edit(base)),async(before,next)=>{
   const changed=edit(before);
   next=await chooseTravelModes(before,next,ensureRoute);
   for(;;){
    next=fitCalendarSwap(before,{...changed,trip:next},routesRef.current).trip;
    for(const stop of next.stops)checkStopTiming(before,next,stop);
    const legs=[...changedTravelLegs(before.stops,next.stops),...changedArrivalTravelLegs(before,next)];
    const available=scheduleTravelAvailability(legs,routesRef.current);
    if(available.status==='blocked')throw new Error(available.message);
    if(!available.missing.length){if(available.status!=='ready')throw new Error(available.message);return next;}
    try{await prepareScheduleRoutes(available.missing);}catch{throw new Error('Travel time could not be checked. Try again.');}
   }
  });
  // Failures are reported centrally even if the dialog or active trip changes.
  void result.settled.catch(()=>{});
  return result;
 }
 function previewStopChange(before:Trip,change:CalendarChange,errors:Record<string,string>={}){
  const modes=previewTravelModes(before,withHotelCheckIns(change.trip),routesRef.current,errors);
  const planned=fitCalendarSwap(before,{...change,trip:modes},routesRef.current).trip;
  for(const stop of planned.stops)checkStopTiming(before,planned,stop);
  return planned;
 }
 function scheduleConfirmation(result:ReturnType<typeof checkedStopChange>,message:string){
  setScheduleNotice(null);
  void result.settled.then(({before,saved})=>{
   if(tripRef.current?.id!==saved.id||optimistic.pending(saved.id)||tripRef.current.version!==saved.version)return;
   setScheduleNotice({tripId:saved.id,version:saved.version,before:before.stops,beforeHotels:before.hotels,message});
  }).catch(()=>{});
 }
 function resizeAvailability(id:string,minutes:number):ScheduleAvailability{
  const current=tripRef.current;
  try{
   if(!current)throw new Error('Select a trip first.');
   const change=resizeCalendarStop(current,id,minutes);
   const arrivalIssue=arrivalTimeIssue(change.stop,change.trip);if(arrivalIssue)throw new Error(arrivalIssue);
   const plans=current.flights.map(f=>departureSchedule(f,current.stops,routes,routeErrors));
   if(clashesWithDeparture(change.stop,plans))return {status:'blocked',label:'Airport time',message:'This visit would run into reserved airport time.',missing:[]};
   const planned=previewTravelModes(current,change.trip,routes,routeErrors);
   return scheduleTravelAvailability([...changedTravelLegs(current.stops,planned.stops),...changedArrivalTravelLegs(current,planned)],routes,routeErrors);
  }catch(error){return {status:'blocked',label:'Cannot resize',message:(error as Error).message,missing:[]};}
 }
 async function resizePlace(id:string,minutes:number){
  const current=tripRef.current;if(!current||demo)throw new Error('Select a trip first.');
  const change=resizeCalendarStop(current,id,minutes);
  if(stopDuration(change.previous)===minutes)return;
  const result=checkedStopChange(current,base=>resizeCalendarStop(base,id,minutes));
  scheduleConfirmation(result,`${change.stop.name} · ${minutes} min`);
  setSelected(id);setToast('');
 }
 async function savePlace(stop:Stop){
  const current=tripRef.current;if(!current)throw new Error('Select a trip first.');
  const old=current.stops.find(s=>s.id===stop.id);
  const changes=Object.fromEntries(Object.entries(stop).filter(([key,value])=>!old||value!==old[key as keyof Stop]));
  checkedStopChange(current,base=>{
   const existing=base.stops.find(s=>s.id===stop.id);
   if(old&&!existing)throw new Error('This event was removed. Refresh your trip.');
   const updated=existing?{...existing,...changes}:stop;
   return {trip:{...base,stops:existing?base.stops.map(s=>s.id===stop.id?updated:s):[...base.stops,updated]},stop:updated};
  });
  setScheduleNotice(null);setDay(stop.date);setSelected(stop.id);setWorkspaceView('calendar');
 }
 async function schedulePlace(item:ScheduleItem,time:string,swapId?:string){
  const current=tripRef.current;if(!current||demo)throw new Error('Select a trip first.');
  const id=uid(),date=day,change=placeOnCalendar(current,item,date,time,id,swapId);
  const result=checkedStopChange(current,base=>placeOnCalendar(base,item,date,time,id,swapId));
  scheduleConfirmation(result,change.swapped?`Swapped ${change.stop.name} and ${change.swapped.name}`:`${change.stop.name} · ${formatDate(date)} at ${timeLabel(time)}`);
  setToast('');setSelected(change.stop.id);setWorkspaceView('calendar');
  requestAnimationFrame(()=>document.querySelector(`[data-stop-id="${CSS.escape(change.stop.id)}"]`)?.scrollIntoView({block:'nearest',behavior:'instant'}));
 }
 async function undoSchedule(){
  const current=tripRef.current;if(!current||!scheduleNotice||current.id!==scheduleNotice.tripId||current.version!==scheduleNotice.version)return;
  try{await persist({...current,stops:scheduleNotice.before,hotels:scheduleNotice.beforeHotels},false,false);setScheduleNotice(null);setSelected(null);setToast('Schedule change undone.');}catch(e){setError((e as Error).message);}
 }
 const dayFlights=trip?.flights.filter(f=>f.date===day&&!f.departure)||[];
 return <SchedulingProvider key={demo?'example':trip?.id||'empty'} enabled={!!trip&&!demo} busy={saving} onBegin={()=>setWorkspaceView('calendar')} onSave={schedulePlace} getAvailability={scheduleAvailability} prepareRoutes={prepareScheduleRoutes} onDayChange={chooseDay}><div className={"planner-app planner-trip"+(anonymousDemo?" planner-demo":"")}>
 {anonymousDemo&&<div className="demo-banner"><span><strong>Demo</strong><span className="demo-detail">Saved in this browser</span></span><nav className="demo-actions" aria-label="Demo actions"><a href="/trips-project.zip" download><ArrowDownTrayIcon aria-hidden="true"/><span>Download project</span></a><button type="button" onClick={()=>setResetDialog(true)} disabled={resetting}>Reset demo</button></nav></div>}
 {error&&<div role="alert" className="workspace-error"><span>{error}</span><button type="button" className="icon" aria-label="Dismiss error" onClick={()=>setError('')}><XMarkIcon/><span className="touch-target" aria-hidden="true"/></button></div>}
 <main className={'trip-workspace workspace-three '+(assistantEnabled?'':'workspace-without-assistant ')+'workspace-view-'+workspaceView}>
  {assistantEnabled&&<AssistantPane localWorkspace={anonymousDemo} assistantEnabled={assistantEnabled} beforeSend={()=>trip&&!demo?optimistic.waitForIdle(trip.id):Promise.resolve()} key={demo?'example':trip?.id||'general'} trip={trip} demo={demo} day={day} googleMapsKey={googleMapsKey} recommendationSet={recommendationSet} highlightedRecommendation={highlightedRecommendation} selectedRecommendation={selectedRecommendation} onRecommendations={receiveRecommendations} onHighlight={setHighlightedRecommendation} onSelectRecommendation={id=>{setSelectedRecommendation(id);setWorkspaceView('map');}} onTripChange={updated=>{optimistic.receive(updated);setRouteErrors({});setRouteRevision(n=>n+1);}} onClose={()=>setWorkspaceView('calendar')}/>}
  <aside className="workspace-map" aria-label="Trip map" data-testid="map-pane">{(trip||recommendationSet)&&<div className="workspace-map-label">{recommendationSet?<><strong>{recommendationSet.places.length} recommendations</strong><button type="button" className="icon" aria-label="Show itinerary on map" title="Show itinerary" onClick={()=>receiveRecommendations(null)}><XMarkIcon/><span className="touch-target" aria-hidden="true"/></button></>:<><strong>{formatDate(day,{weekday:'short',month:'short',day:'numeric'})}</strong><span>{stops.length} {stops.length===1?'event':'events'}</span></>}</div>}<TripMap googleMapsKey={googleMapsKey} recommendations={recommendationSet?.places} highlightedRecommendation={highlightedRecommendation} selectedRecommendation={selectedRecommendation} onRecommendationHighlight={setHighlightedRecommendation} onRecommendationSelect={id=>{setSelectedRecommendation(id);setWorkspaceView(assistantEnabled?'chat':'calendar');}} center={trip?.destination} stops={routePoints} routes={routes} selected={selected} onSelect={selectFromMap}/>{trip&&<MapDataCredit/>}</aside>
  <section className="calendar-column" aria-label="Trip calendar">
   <div className="calendar-pane" data-testid="calendar-pane" tabIndex={0}>
   {trip?<>
   <div className="calendar-days" role="tablist" aria-label="Trip days">{visibleDays.map(d=><button type="button" key={d} data-schedule-day={d} role="tab" aria-selected={day===d} aria-controls="calendar-day" id={'day-'+d} tabIndex={day===d?0:-1} onKeyDown={e=>{const index=visibleDays.indexOf(d);const next=e.key==='ArrowRight'?visibleDays[(index+1)%visibleDays.length]:e.key==='ArrowLeft'?visibleDays[(index+visibleDays.length-1)%visibleDays.length]:e.key==='Home'?visibleDays[0]:e.key==='End'?visibleDays.at(-1):undefined;if(next){e.preventDefault();chooseDay(next);document.getElementById('day-'+next)?.focus();}}} onClick={()=>chooseDay(d)}><span>{formatDate(d,{weekday:'short'})}</span><strong>{formatDate(d,{month:'short',day:'numeric'})}</strong><i className={(trip.stops.some(s=>s.date===d)||trip.flights.some(f=>f.date===d)||Object.values(hotelDayBounds(trip.hotels,d)).some(Boolean))?'has-stops':''}/></button>)}</div>
   <div className="calendar-day-content" id="calendar-day" role="tabpanel" aria-labelledby={'day-'+day}>
    {dayFlights.length>0&&<section className="day-flights" aria-label="Flights"><div className="section-heading"><h2>Flights</h2></div>{dayFlights.length?<div className="flight-list">{dayFlights.map(f=><div className="flight-row" key={f.id}><div className="flight-date">{formatDate(f.date)}<small>{f.number}</small></div><button type="button" className="flight-main" onClick={()=>{setEditFlight(f);setModal('flight');}} disabled={demo}><span>{f.from}<small>{timeLabel(f.departure)||'Time not set'}</small></span><ArrowRight size={16}/><span>{f.to}<small>{timeLabel(f.arrival)||'Time not set'}{f.arrivalDate!==f.date?' · '+formatDate(f.arrivalDate):''}</small></span></button><div className="flight-status"><button type="button" className="text-button airport-plan-link" disabled={demo} onClick={()=>{setEditFlight(f);setModal('departure');}}>{f.departurePlan?'Airport timing':'Plan airport timing'}</button></div><button type="button" className="icon subtle" disabled={demo||saving} aria-label={'Remove flight '+f.number} onClick={()=>update({...trip,flights:trip.flights.filter(x=>x.id!==f.id)})}><X size={15}/></button></div>)}</div>:null}</section>}
    <DepartureSummary schedules={schedules.filter(s=>!!s.issue)} day={day} disabled={demo} onEdit={editDeparture}/>
    <DayCalendar timeZone={trip.timeZone} onResize={resizePlace} resizeAvailability={resizeAvailability} hotelRoute={hotelRoute} onEditHotel={editHotelStay} routes={routes} routeErrors={routeErrors} onTravelMode={changeTravelMode} onRetryRoute={retryRoute} stops={stops} schedules={schedules} day={day} selected={selected} onSelect={showPlace} onEdit={editPlace} onEditDeparture={editDeparture} onEditFlight={f=>{setEditFlight(f);setModal('flight');}} onAdd={demo?undefined:addEvent} disabled={demo||saving}/>
   </div></>:<div className="calendar-empty"><header><h1>Calendar</h1></header>{loading?<p className="muted">Loading your trips…</p>:<div className="calendar-empty-content"><p>No trip selected.</p><button type="button" className="primary" onClick={newTrip}><PlusIcon/>Add trip</button></div>}</div>}
   </div>
   {trip&&<div className="calendar-scheduling"><SchedulePrompt/></div>}
  </section>
 </main>
 <FloatingBar assistantEnabled={assistantEnabled} onShare={!anonymousDemo&&trip&&!demo?()=>setModal('share'):undefined} trips={trips} trip={trip} demo={demo} loading={loading} view={workspaceView} onSelect={t=>open(t)} onExample={()=>open(example,true)} onNew={newTrip} onSubscribe={anonymousDemo?undefined:()=>setModal('subscribe')} onMenu={()=>setMenu(true)} onView={setWorkspaceView} addingDisabled={demo||saving||calendarSaving||!trip} onAdd={kind=>{if(kind==='event')addEvent();else if(kind==='place')addPlace();else if(kind==='hotel'){setEditHotel(undefined);setModal('hotel');}else{setEditFlight(undefined);setModal('flight');}}}/>
 {menu&&<Modal title={trip?'Trip options':'Options'} onClose={()=>setMenu(false)}><div className="workspace-menu">{!anonymousDemo&&<div className="mobile-navigation"><button type="button" onClick={()=>{setMenu(false);setModal('subscribe');}}>Calendar subscription</button></div>}{trip&&<><button type="button" disabled={demo} onClick={()=>{setMenu(false);setModal('edit-trip');}}><PencilSquareIcon/>Edit trip</button><button type="button" className="danger" disabled={demo} onClick={()=>{setMenu(false);setDeleteTrip(true);}}><TrashIcon/>Delete trip</button></>}{!anonymousDemo&&!trip&&<button type="button" className="dock-desktop" onClick={()=>{setMenu(false);setModal('subscribe');}}>Calendar subscription</button>}{!anonymousDemo&&<a className="workspace-signout text-button" href="/signout-with-chatgpt?return_to=%2F" target="_top">Sign out</a>}<div className="map-data-credits"><p>Route and place data © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>.</p><p>Routing by <a href="https://www.fossgis.de/" target="_blank" rel="noopener noreferrer">FOSSGIS</a> / <a href="https://valhalla.github.io/valhalla/" target="_blank" rel="noopener noreferrer">Valhalla</a>. <a href="https://www.openstreetmap.org/fixthemap" target="_blank" rel="noopener noreferrer">Fix the map</a></p></div></div></Modal>}
 {modal==='trip'&&<TripForm onClose={()=>setModal(null)} onSave={async t=>{await persist(t,true);}}/>}{modal==='edit-trip'&&trip&&<TripForm trip={trip} onClose={()=>setModal(null)} onSave={async t=>{await persist(t);}}/>}{modal==='stop'&&trip&&<StopForm trip={trip} day={day} stop={editStop} onRemove={editStop?async()=>{await persist({...trip,stops:trip.stops.filter(s=>s.id!==editStop.id)});setSelected(null);}:undefined} initialPlace={suggestedPlace} initialTime={draftTime} onClose={()=>setModal(null)} onSave={savePlace}/>}{modal==='flight'&&trip&&<FlightForm lookupEnabled={flightLookup} day={day} flight={editFlight} onRemove={editFlight?async()=>{await persist({...trip,flights:trip.flights.filter(f=>f.id!==editFlight.id)});}:undefined} onClose={()=>setModal(null)} onSave={async f=>{await persist({...trip,flights:editFlight?trip.flights.map(x=>x.id===f.id?f:x):[...trip.flights,f]});}}/>}
 {modal==='event'&&trip&&<EventForm onEditHotel={editHotelStay} trip={trip} day={day} event={editStop} initialTime={draftTime} onClose={()=>setModal(null)} onSave={savePlace} onRemove={editStop&&!editStop.hotelCheckInId?async()=>{await persist({...trip,stops:trip.stops.filter(s=>s.id!==editStop.id)});setSelected(null);}:undefined}/>}
 {modal==='hotel'&&trip&&<HotelForm trip={trip} day={day} hotel={editHotel} onClose={()=>setModal(null)} onRemove={editHotel?async()=>{await persist({...trip,hotels:(trip.hotels||[]).filter(h=>h.id!==editHotel.id)});setSelected(null);}:undefined} onSave={async hotel=>{await persist({...trip,stops:trip.stops.map(s=>s.hotelCheckInId===hotel.id&&s.time<(hotel.checkInFrom||'15:00')?{...s,time:hotel.checkInFrom||'15:00'}:s),hotels:editHotel?(trip.hotels||[]).map(h=>h.id===hotel.id?hotel:h):[...(trip.hotels||[]),hotel]});receiveRecommendations(null);setWorkspaceView('calendar');}}/>}
 {modal==='departure'&&trip&&editFlight&&<DepartureForm trip={trip} flight={editFlight} onClose={()=>setModal(null)} onSave={async f=>{await persist({...trip,flights:trip.flights.map(x=>x.id===f.id?f:x)});setRouteErrors({});setRouteRevision(n=>n+1);setDay(f.date);setWorkspaceView('calendar');}}/>}
 {!anonymousDemo&&modal==='share'&&trip&&<TripSharing trip={trip} day={day} beforeShare={()=>optimistic.waitForIdle(trip.id)} onClose={()=>setModal(null)}/>}
 {!anonymousDemo&&modal==='subscribe'&&<CalendarSubscription trips={trips} onClose={()=>setModal(null)}/>}
 {resetDialog&&<Modal title="Reset this demo?" onClose={()=>setResetDialog(false)}><p className="dialog-intro">Trips and chat saved in this browser will be removed. Start fresh with the Seattle itinerary.</p><div className="form-actions"><button onClick={()=>setResetDialog(false)} disabled={resetting}>Keep exploring</button><button className="primary" onClick={resetDemo} disabled={resetting}>{resetting?'Resetting…':'Start fresh'}</button></div></Modal>}
 {deleteTrip&&trip&&<Modal title="Delete this trip?" onClose={()=>setDeleteTrip(false)}><p className="dialog-intro">{trip.name} will be removed from your trips.</p><div className="form-actions"><button onClick={()=>setDeleteTrip(false)}>Keep trip</button><button className="primary danger-button" disabled={saving||calendarSaving} onClick={removeTrip}>Delete trip</button></div></Modal>}
 {scheduleNotice&&scheduleNotice.tripId===trip?.id&&scheduleNotice.version===trip.version&&<div className="schedule-notice" role="status"><Check size={16}/><span>{scheduleNotice.message}</span><button type="button" disabled={saving||calendarSaving} onClick={undoSchedule}>Undo</button><button type="button" className="icon" aria-label="Dismiss schedule confirmation" onClick={()=>setScheduleNotice(null)}><XMarkIcon/></button></div>}
 {toast&&<div className="toast" role="status"><Check size={15}/>{toast}</div>}
 </div></SchedulingProvider>;
}
