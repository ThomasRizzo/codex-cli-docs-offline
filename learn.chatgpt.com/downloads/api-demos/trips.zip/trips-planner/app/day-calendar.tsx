'use client';
import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties } from 'react';
import CalendarHotel from './calendar-hotel';
import { useEventResize } from './event-resize';
import { stopDuration, maxEventDuration } from '@/lib/event-duration';
import type { ScheduleAvailability } from '@/lib/schedule-travel';
import type { dayRoute } from '@/lib/hotels';
import CalendarTravel, { type TravelActions } from './calendar-travel';
import { calendarTravelLayout, calendarHotelAnchors, stopMinute } from '@/lib/calendar-travel';
import { eventTone } from '@/lib/event-colors';
import { useScheduling } from './scheduling';
import { snapCalendarMinute, calendarTime } from '@/lib/scheduling';
import { BuildingOffice2Icon, TruckIcon, PaperAirplaneIcon, PlusIcon, XMarkIcon, CheckCircleIcon } from '@heroicons/react/16/solid';
import { flightStatus } from '@/lib/flightaware';
import { flightCalendarRange, flightDayBlock, calendarMinuteInZone } from '@/lib/calendar-flights';
import type { Flight, Stop, Route, Hotel } from '@/lib/trips';
import { duration, formatDate, routeKey, hasLocation, sameLocation } from '@/lib/trips';
import { type DepartureSchedule, wallMinutes, wallDate, wallTime, onDay, clashesWithDeparture } from '@/lib/departures';

function stamp(min: number, day: string) { return `${wallTime(min)}${wallDate(min)!==day?' · '+formatDate(wallDate(min)):''}`; }
export function DepartureSummary({schedules,day,disabled,onEdit}:{schedules:DepartureSchedule[];day:string;disabled:boolean;onEdit:(f:Flight)=>void}) {
 return <div className="departure-summaries">{schedules.filter(s=>onDay(s,day)).map(s=><div className="departure-summary" key={s.flight.id}>
  <div className="departure-summary-heading"><div>{s.flight.number} · {s.flight.from} → {s.flight.to}</div><button type="button" disabled={disabled} onClick={()=>onEdit(s.flight)}>{s.flight.departurePlan?'Edit timing':'Plan airport timing'}</button></div>
  {s.depart!==null&&s.arrive!==null&&<><strong>{s.leave!==null?'Leave by '+stamp(s.leave,day):'Arrive by '+stamp(s.arrive,day)}</strong><p>{s.driveMinutes!==null?`${duration(s.driveMinutes)} Uber + ${s.extraMinutes} min allowance · `:''}{duration(s.bufferMinutes)} at the airport</p></>}
  {s.issue&&<p className="timing-issue">{s.issue}</p>}
 </div>)}</div>;
}

function BookedIndicator(){return <span className="event-booked" title="Booked" aria-label="Booked"><CheckCircleIcon aria-hidden="true"/><span aria-hidden="true">Booked</span></span>;}

type Props = TravelActions & { timeZone?:string; onResize:(id:string,minutes:number)=>Promise<void>;resizeAvailability:(id:string,minutes:number)=>ScheduleAvailability; hotelRoute:ReturnType<typeof dayRoute>; onEditHotel:(hotel:Hotel)=>void; routes:Record<string,Route>;routeErrors:Record<string,string>;stops:Stop[]; schedules:DepartureSchedule[]; day:string; selected:string|null; onSelect:(id:string)=>void; onEdit:(s:Stop)=>void; onEditDeparture:(f:Flight)=>void; onEditFlight:(f:Flight)=>void; onAdd?: (time:string)=>void; disabled:boolean };
export default function DayCalendar({timeZone,onResize,resizeAvailability,hotelRoute,onEditHotel,routes,routeErrors,onTravelMode,onRetryRoute,stops,schedules,day,selected,onSelect,onEdit,onEditDeparture,onEditFlight,onAdd,disabled}:Props) {
 const openStop=(stop:Stop)=>{onSelect(stop.id);if(!disabled)onEdit(stop);};
 const schedule=useScheduling(),grid=useRef<HTMLDivElement>(null),[preview,setPreviewState]=useState<number|null>(null);
 const setPreview=(minute:number|null)=>{setPreviewState(minute);if(minute!==null)schedule?.setTime(calendarTime(minute));};
 useEffect(()=>{if(preview!==null&&schedule?.time&&!schedule.dragging){const [h,m]=schedule.time.split(':').map(Number);setPreviewState(h*60+m);}},[schedule?.time]);
 const scale=1.5;
 const resize=useEventResize({day,grid,scale,disabled:disabled||!!schedule?.item,onSave:onResize,getAvailability:resizeAvailability});
 const displayedStops=stops.map(s=>s.id===resize.preview?.id?{...s,durationMinutes:resize.preview.minutes}:s);
 const start=wallMinutes(day,'00:00')!;
 const calendarZone=timeZone||hotelRoute.arrival?.flight.arrivalTimeZone||schedules[0]?.flight.arrivalTimeZone||schedules[0]?.flight.departureTimeZone;
 const inZone=(minute:number,flight:Flight)=>calendarMinuteInZone(minute,flight.departureTimeZone,calendarZone);
 const plans=schedules.filter(s=>s.depart!==null&&s.arrive!==null&&inZone(s.leave??s.arrive,s.flight)<start+1440&&inZone(s.depart,s.flight)>=start);
 const timed=displayedStops.filter(s=>s.time).sort((a,b)=>a.time.localeCompare(b.time));
 const points=timed.map(s=>wallMinutes(s.date,s.time)!-start);
 const ranges=plans.map(s=>({s,from:Math.max(0,inZone(s.leave??s.arrive!,s.flight)-start),to:Math.min(1440,inZone(s.depart!,s.flight)-start)}));
 const min=0,max=24*60;
 const arrival=hotelRoute.arrival;
 const flightRanges=schedules.flatMap(s=>{const range=flightCalendarRange(s.flight,calendarZone);return range?[range]:[];});
 const flightBlocks=flightRanges.flatMap(range=>{const block=flightDayBlock(range,day);return block?[block]:[];});
 const flightVisuals:Stop[]=flightBlocks.map(block=>({id:block.id,name:block.flight.number,address:'',kind:'event',date:day,time:calendarTime(block.from),durationMinutes:block.to-block.from,note:'',mode:'uber'}));
 const travelLayout=calendarTravelLayout(timed,scale);
 const layout=calendarTravelLayout([...timed,...flightVisuals].sort((a,b)=>a.time.localeCompare(b.time)),scale).lanes;
 const legs=[...travelLayout.legs];
 const arrivalTo=arrival&&timed.find(s=>s.id===arrival.to.id);
 if(arrival&&arrivalTo){
  const ready=flightRanges.find(r=>r.flight.id===arrival.flight.id)?.ready??arrival.ready;
  const top=Math.max(0,ready-start)*scale+1,bottom=stopMinute(arrivalTo)!*scale-1;
  const above=bottom-top<20;
  legs.push({from:arrival.from,to:arrival.to,top:above?bottom-20:top,bottom,above,compact:above||bottom-top<36});
 }
 const anchors=calendarHotelAnchors(displayedStops,{...travelLayout,lanes:layout},scale);
 const hotelStart=hotelRoute.start&&anchors.start&&!sameLocation(hotelRoute.start,anchors.start.stop)?anchors.start:null,hotelEnd=hotelRoute.end&&anchors.end&&!sameLocation(hotelRoute.end,anchors.end.stop)?anchors.end:null;
 const hotelAnchors=[hotelStart,hotelEnd].filter(a=>a!==null);
 const gridTopPadding=Math.max(0,-(hotelStart?.top??0),...legs.map(leg=>-leg.top));
 const gridHeight=Math.max((max-min)*scale+60,hotelEnd?hotelEnd.top+hotelEnd.travelHeight+hotelEnd.cardHeight+24:0);
 const initialMinute=Math.max(0,Math.floor(Math.min(8*60,...points,...flightBlocks.map(b=>b.from),...ranges.map(r=>r.from),hotelStart?hotelStart.top/scale:8*60)/60)*60);
 useLayoutEffect(()=>{
  const pane=grid.current?.closest<HTMLElement>('.calendar-pane'),tabs=pane?.querySelector<HTMLElement>('.calendar-days');
  if(!pane||!tabs)return;
  let positioned=false;
  const position=()=>{
   if(!pane.clientHeight)return;
   pane.style.setProperty('--calendar-tabs-height',`${tabs.offsetHeight}px`);
   if(!positioned){pane.scrollTop=initialMinute*scale;positioned=true;}
  };
  const observer=new ResizeObserver(position);observer.observe(pane);observer.observe(tabs);position();
  return()=>observer.disconnect();
  // Set the starting view only on day changes, not when events move or routes load.
 },[day]);
 useEffect(()=>{setPreview(null);},[day,schedule?.item]);
 const point=useRef(schedule?.point);point.current=schedule?.point;
 useEffect(()=>{if(!schedule?.dragging||!schedule.point||!grid.current)return;const rect=grid.current.getBoundingClientRect(),p=schedule.point;setPreview(p.x>=rect.left&&p.x<=rect.right&&p.y>=rect.top&&p.y<=rect.bottom?snapCalendarMinute(p.y-rect.top,min,max,scale):null);},[schedule?.point,day,min,max]);
 useEffect(()=>{
  if(!schedule?.dragging)return;
  let frame:number;
  const tick=()=>{const current=point.current,element=grid.current,pane=element?.closest('.calendar-pane');if(current&&element&&pane){const bounds=pane.getBoundingClientRect();const delta=current.x<bounds.left||current.x>bounds.right?0:current.y<bounds.top+125?-10:current.y>bounds.bottom-70?10:0;if(delta){pane.scrollTop+=delta;setPreview(snapCalendarMinute(current.y-element.getBoundingClientRect().top,min,max,scale));}}frame=requestAnimationFrame(tick);};
  frame=requestAnimationFrame(tick);return()=>cancelAnimationFrame(frame);
 },[schedule?.dragging,min,max]);
 const minuteAt=(y:number)=>snapCalendarMinute(y-(grid.current?.getBoundingClientRect().top||0),min,max,scale);
 const airportBlocked=preview!==null&&ranges.some(r=>preview>=r.from&&preview<r.to);
 const availability=schedule?.swapTarget?schedule.availability:preview!==null&&schedule?.time===calendarTime(preview)?schedule.availability:null;
 const blocked=airportBlocked||availability?.status==='blocked'||availability?.status==='unavailable';
 const previewLabel=airportBlocked?'Airport time':availability&&availability.status!=='ready'?availability.label:schedule?.item?.place.name;
 const commit=(minute:number)=>{schedule?.commit(calendarTime(minute));};
 const conflict=timed.filter(s=>clashesWithDeparture(s,schedules));
 const travel=(from:Stop,to:Stop,compact=false)=>hasLocation(from)&&hasLocation(to)?<CalendarTravel from={from} to={to} route={routes[routeKey(from,to,to.mode)]} routeError={routeErrors[routeKey(from,to,to.mode)]} disabled={disabled} onTravelMode={onTravelMode} onRetryRoute={onRetryRoute} compact={compact}/>:null;
 const hotel=(role:'start'|'end')=>{
  const point=hotelRoute[role],stay=hotelRoute.hotels[role];
  if(!point||!stay)return null;
  return <CalendarHotel hotel={stay} point={point} to={role==='start'?stops.filter(hasLocation)[0]:undefined} from={role==='end'?(stops.filter(hasLocation).at(-1)||(hotelRoute.start&&hotelRoute.start.hotelId!==point.hotelId?hotelRoute.start:undefined)):undefined} routes={routes} routeErrors={routeErrors} disabled={disabled} selected={selected} onSelect={onSelect} onEdit={onEditHotel} onTravelMode={onTravelMode} onRetryRoute={onRetryRoute}/>;
 };
 const hotelAnchor=(role:'start'|'end',anchor:NonNullable<typeof hotelStart>)=>{
  const lane=layout.get(anchor.stop.id)!;
  const overlapsAirport=ranges.some(r=>anchor.top+anchor.cardHeight+anchor.travelHeight>r.from*scale&&anchor.top<r.to*scale);
  const eventMinute=stopMinute(anchor.stop)!;
  const width=overlapsAirport||ranges.some(r=>eventMinute+lane.height/scale>r.from&&eventMinute<r.to)?50:100;
  return <div className="calendar-hotel-anchor" style={{'--hotel-top':`${anchor.top}px`,'--hotel-card-height':`${anchor.cardHeight}px`,'--hotel-travel-height':`${anchor.travelHeight}px`,'--event-left':`${lane.column*width/lane.columns}%`,'--event-width':`${width/lane.columns}%`} as CSSProperties}>{hotel(role)}</div>;
 };
 return <div className="calendar-view">
  {resize.error&&<div className="schedule-error" role="alert"><span>{resize.error}</span><button type="button" className="icon" aria-label="Dismiss resize error" onClick={resize.clearError}><XMarkIcon/></button></div>}
  {!stops.some(hasLocation)&&<div className="calendar-hotel-empty">{hotel('start')}{hotel('end')}</div>}
  {conflict.length>0&&<p className="calendar-conflict" role="status">{conflict.map(s=>s.name).join(', ')} {conflict.length===1?'is':'are'} scheduled during airport time.</p>}
  <div className="calendar-scroll" style={{paddingTop:10+gridTopPadding}}><div ref={grid} data-calendar-drop={schedule?.item&&!disabled?true:undefined} data-first-minute={min} data-last-minute={max} className={'calendar-grid'+(schedule?.item?' is-scheduling':'')} tabIndex={schedule?.item?0:undefined} role="group" aria-description={schedule?.item?'Choose a start time. Arrow keys adjust by 15 minutes; Enter schedules; Escape cancels.':undefined}
   onMouseMove={e=>{if(schedule?.item&&!schedule.dragging)setPreview(minuteAt(e.clientY));}}
   onMouseLeave={()=>{if(!schedule?.dragging)setPreview(null);}}
   onClickCapture={e=>{if(!schedule?.item||schedule.dragging||schedule.busy)return;e.preventDefault();e.stopPropagation();commit(minuteAt(e.clientY));}}
   onFocus={e=>{if(e.target===e.currentTarget&&schedule?.item)setPreview(Math.max(min,Number(schedule.time.slice(0,2))*60+Number(schedule.time.slice(3))));}}
   onKeyDown={e=>{if(!schedule?.item||e.target!==e.currentTarget)return;const at=preview??Math.max(min,540);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();setPreview(Math.max(min,Math.min(max,1425,at+(e.key==='ArrowDown'?15:-15))));}else if(e.key==='Enter'||e.key===' '){e.preventDefault();commit(at);}}}
   style={{'--calendar-height':`${gridHeight}px`} as CSSProperties} aria-label="Day calendar">
   {Array.from({length:(max-min)/60+1},(_,i)=>min+i*60).map(t=><div className="hour-line" key={t} style={{'--hour-top':`${(t-min)*scale}px`} as CSSProperties}><time>{t===1440?'12 am':wallTime(start+t).replace(':00','')}</time>{onAdd&&t<1440&&<button type="button" className="hour-add" onClick={()=>onAdd(`${String(Math.floor(t/60)).padStart(2,'0')}:00`)} aria-label={'Add event at '+wallTime(start+t)}><PlusIcon/><span className="touch-target" aria-hidden="true"/></button>}</div>)}
   <div className="calendar-travel-lane">{legs.map(leg=>{
    const lane=layout.get(leg.to.id)!;
    const overlapsAirport=ranges.some(r=>leg.bottom/scale>r.from&&leg.top/scale<r.to);
    const eventOverlapsAirport=ranges.some(r=>stopMinute(leg.to)!+lane.height/scale>r.from&&stopMinute(leg.to)!<r.to);
    const width=(leg.above?eventOverlapsAirport:overlapsAirport)?50:100;
    return <div key={leg.to.id} className={'calendar-travel-link'+(leg.above?' travel-above':'')} style={{'--travel-top':`${leg.top-min*scale}px`,'--travel-height':`${leg.bottom-leg.top}px`,'--travel-left':`${leg.above?lane.column*width/lane.columns:0}%`,'--travel-width':`${leg.above?width/lane.columns:width}%`} as CSSProperties}>{travel(leg.from,leg.to,leg.compact)}</div>;
   })}</div>
   <div className={'calendar-stops-lane '+(!plans.length?'full-stops-lane':'')}>{hotelStart&&hotelAnchor('start',hotelStart)}{hotelEnd&&hotelAnchor('end',hotelEnd)}{flightBlocks.map(block=>{
    const lane=layout.get(block.id)!,width=ranges.some(r=>block.to>r.from&&block.from<r.to)?50:100;
    return <button key={block.id} type="button" className={'calendar-flight'+(block.flightMinutes<45?' calendar-flight-compact':'')+(block.continuesBefore?' flight-continues-before':'')+(block.continuesAfter?' flight-continues-after':'')} disabled={disabled} aria-label={'Edit flight '+block.flight.number+', '+block.flight.from+' to '+block.flight.to+', '+stamp(block.departure,day)+' to '+stamp(block.arrival,day)} onClick={()=>onEditFlight(block.flight)} style={{'--event-top':`${block.from*scale}px`,'--event-height':`${(block.to-block.from)*scale}px`,'--event-left':`${lane.column*width/lane.columns}%`,'--event-width':`${width/lane.columns}%`,'--flight-body-height':`${block.flightMinutes*scale}px`,'--flight-exit-height':`${block.exitMinutes*scale}px`} as CSSProperties}>
      {block.flightMinutes>0&&<div className="calendar-flight-body"><div className="calendar-flight-title"><PaperAirplaneIcon/><strong>{block.flight.number}</strong><span>{block.flight.from} → {block.flight.to}</span></div><div className="calendar-flight-times">{stamp(block.departure,day)} – {stamp(block.arrival,day)}</div>{block.continuesBefore&&<div className="calendar-flight-continuation">Continued from {formatDate(wallDate(block.departure))}</div>}{block.flight.flightaware&&<div className="calendar-flight-status">{flightStatus(block.flight)}</div>}</div>}
      {block.exitMinutes>0&&<div className="calendar-flight-exit" title={`${block.flight.arrivalExitMinutes??30} minutes to leave the airport`}>{block.flight.arrivalExitMinutes??30} min to leave airport</div>}
    </button>;
   })}{timed.map(s=>{const minute=wallMinutes(s.date,s.time)!-start;const lane=layout.get(s.id)!;const width=ranges.some(r=>minute+lane.height/scale>r.from&&minute<r.to)?50:100;return <div key={s.id} data-stop-id={s.id} data-calendar-swap-id={!disabled?s.id:undefined} data-swap-name={s.name} data-swap-time={s.time} data-swap-state={schedule?.swapTarget?.id===s.id?schedule.availability?.status:undefined} data-calendar-tone={s.hotelCheckInId?'sand':eventTone(stops.findIndex(stop=>stop.id===s.id))} className={'calendar-place '+(s.kind!=='event'&&s.booked?'is-booked ':'')+(stopDuration(s)<30?'calendar-place-short ':stopDuration(s)<45?'calendar-place-medium ':'')+(resize.preview?.id===s.id?'is-resizing ':'')+(clashesWithDeparture(stops.find(stop=>stop.id===s.id)!,schedules)?'calendar-place-conflict ':'')+(selected===s.id?'is-selected':'')} style={{'--event-top':`${(minute-min)*scale}px`,'--event-height':`${lane.height}px`,'--event-left':`${lane.column*width/lane.columns}%`,'--event-width':`${width/lane.columns}%`} as CSSProperties}><button type="button" className="calendar-place-main" data-schedulable={schedule?.canDrag||undefined} draggable={false} onPointerDown={e=>{if(!resize.preview)schedule?.pointerDown(e,{place:s,stopId:s.id});}} title={s.name+(s.kind!=='event'&&s.booked?' · Booked':'')+(schedule?.canDrag?' · Drag to change time':'')} onClick={()=>openStop(s)} aria-label={(disabled?'Show '+s.name+' on map':'Edit '+s.name)+(s.kind!=='event'&&s.booked?', booked':'')}><div className="event-time">{s.hotelCheckInId?<BuildingOffice2Icon className="check-in-icon"/>:<span className="event-number">{stops.findIndex(stop=>stop.id===s.id)+1}</span>}<time>{wallTime(start+minute)}<span className="event-end-time"> – {wallTime(start+minute+stopDuration(s))}</span></time></div><p>{s.name}</p>{s.kind!=='event'&&s.booked&&<BookedIndicator/>}</button>{<button type="button" role="slider" className="calendar-resize-handle" aria-label={'Resize '+s.name} aria-orientation="vertical" aria-valuemin={Math.min(15,maxEventDuration(s))} aria-valuemax={maxEventDuration(s)} aria-valuenow={stopDuration(s)} aria-valuetext={`${duration(stopDuration(s))}, ends ${wallTime(start+minute+stopDuration(s))}`} title="Drag to resize · Arrow keys adjust by 15 minutes" disabled={disabled||resize.busy||!!schedule?.item} onPointerDown={e=>resize.start(e,s)} onKeyDown={e=>{if(['ArrowUp','ArrowDown','Home','End'].includes(e.key)){e.preventDefault();e.stopPropagation();resize.keyboard(s,e.key,e.currentTarget);}}} onClick={e=>{e.preventDefault();e.stopPropagation();}}><span aria-hidden="true"/></button>}{resize.preview?.id===s.id&&<div className={'calendar-resize-status'+(resize.availability?.status==='blocked'?' is-blocked':'')} role="status">{resize.availability?.status==='blocked'?resize.availability.label:`${wallTime(start+minute)} – ${wallTime(start+minute+stopDuration(s))} · ${duration(stopDuration(s))}`}</div>}</div>;})}</div>
   <div className={'calendar-airport-lane '+(!timed.length?'full-lane':'')}>{ranges.map(({s,from,to},i)=>{const overlap=timed.some(stop=>{const p=stopMinute(stop)!;return p+layout.get(stop.id)!.height/scale>from&&p<to;})||hotelAnchors.some(a=>a.top+a.cardHeight+a.travelHeight>from*scale&&a.top<to*scale);const base=overlap?50:0;const width=overlap?50:100;return <div key={s.flight.id} className="calendar-flight-group" style={{'--flight-left':`${base+i*(width/ranges.length)}%`,'--flight-width':`${width/ranges.length}%`} as CSSProperties}>
    {to>from&&<button type="button" className="calendar-reserved" disabled={disabled} aria-label={'Edit airport timing '+s.flight.number} onClick={()=>onEditDeparture(s.flight)} style={{'--block-top':`${(from-min)*scale}px`,'--block-height':`${Math.max(12,(to-from)*scale)}px`} as CSSProperties} title={`${s.flight.number}: ${stamp(s.leave??s.arrive!,day)} – ${stamp(s.depart!,day)}`}>
      <div className="reserved-heading"><strong>Airport · {s.flight.number}</strong></div>
      <div className="reserved-time">{stamp(s.leave??s.arrive!,day)} – {stamp(s.depart!,day)}</div>
      {s.leave!==null&&<div className="reserved-detail"><TruckIcon/><div>Uber · {duration(s.driveMinutes!)}<small>+ {s.extraMinutes} min allowance</small></div></div>}
      <div className="reserved-detail"><PaperAirplaneIcon/><div>At airport · {duration(s.bufferMinutes)}<small>Arrive {stamp(s.arrive!,day)}</small></div></div>
      {s.leave===null&&<small>Airport buffer only</small>}
      {(s.leave??s.arrive!)<start&&<small>Continues from {formatDate(wallDate(s.leave??s.arrive!))}</small>}
    </button>}
    {!flightRanges.some(r=>r.flight.id===s.flight.id)&&s.depart!>=start&&s.depart!<start+1440&&<button type="button" className="calendar-departure" disabled={disabled} style={{'--departure-top':`${(s.depart!-start-min)*scale}px`} as CSSProperties} onClick={()=>onEditFlight(s.flight)}><PaperAirplaneIcon/><span>{wallTime(s.depart!)} · {s.flight.number} departs{s.flight.flightaware&&<small className="calendar-flight-status">{flightStatus(s.flight)}</small>}</span></button>}
   </div>;})}</div>
   {schedule?.item&&!schedule.swapTarget&&preview!==null&&preview>=min&&preview<=max&&<div className={'calendar-drop-preview'+(blocked?' is-blocked':'')} style={{'--preview-top':`${(preview-min)*scale}px`} as CSSProperties} aria-hidden="true"><div><time>{wallTime(start+preview)}</time><span>{previewLabel}</span></div></div>}
  </div></div>
  {stops.some(s=>!s.time)&&<div className="calendar-unscheduled"><p>No time set</p><div className="calendar-unscheduled-stops">{!timed.length&&hotel('start')}<ul role="list">{stops.filter(s=>!s.time).map(s=><li key={s.id} data-stop-id={s.id} data-calendar-tone={s.hotelCheckInId?'sand':eventTone(stops.findIndex(stop=>stop.id===s.id))} className={selected===s.id?'is-selected':''}><button type="button" data-schedulable={schedule?.canDrag||undefined} draggable={false} onPointerDown={e=>schedule?.pointerDown(e,{place:s,stopId:s.id})} title={schedule?.canDrag?'Drag onto a time to schedule':undefined} onClick={()=>openStop(s)} aria-label={(disabled?'Show '+s.name+' on map':'Edit '+s.name)+(s.kind!=='event'&&s.booked?', booked':'')}><span className="event-number">{stops.indexOf(s)+1}</span><span className="unscheduled-place-name">{s.name}</span>{s.kind!=='event'&&s.booked&&<BookedIndicator/>}</button>{stops.indexOf(s)>0&&hasLocation(s)&&hasLocation(stops[stops.indexOf(s)-1])&&<div className="calendar-unscheduled-travel"><p>From {stops[stops.indexOf(s)-1].name}</p>{travel(stops[stops.indexOf(s)-1],s)}</div>}</li>)}</ul>{hotel('end')}</div></div>}
 </div>;
}
