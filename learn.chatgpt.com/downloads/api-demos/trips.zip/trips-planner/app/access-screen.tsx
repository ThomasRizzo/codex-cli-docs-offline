import { chatGPTSignInPath, chatGPTSignOutPath } from './chatgpt-auth';
export default function AccessScreen({signedIn=false,returnTo='/'}:{signedIn?:boolean;returnTo?:string}) {
  return <main className="planner-app access-screen"><div><h1>Trips</h1><p>{signedIn?'Editing is only available to the trip owner.':'Sign in to plan your trips.'}</p><a className="primary" href={signedIn?chatGPTSignOutPath(returnTo):chatGPTSignInPath(returnTo)} target="_top">{signedIn?'Use another account':'Sign in with ChatGPT'}</a><p className="field-note">Have a shared trip? Open its link to view it.</p></div></main>;
}
