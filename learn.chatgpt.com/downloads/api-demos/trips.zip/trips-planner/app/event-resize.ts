'use client';
import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent, type RefObject } from 'react';
import { maxEventDuration, snapEventDuration, stopDuration } from '@/lib/event-duration';
import type { Stop } from '@/lib/trips';
import type { ScheduleAvailability } from '@/lib/schedule-travel';

type Preview={id:string;minutes:number};
type Gesture={stop:Stop;pointerId:number;y:number;startY:number;moved:boolean;minutes:number};
export function useEventResize({day,grid,disabled,onSave,getAvailability,scale=1.5}:{day:string;grid:RefObject<HTMLDivElement|null>;disabled:boolean;onSave:(id:string,minutes:number)=>Promise<void>;getAvailability:(id:string,minutes:number)=>ScheduleAvailability;scale?:number}) {
 const [preview,setPreview]=useState<Preview|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const gesture=useRef<Gesture|null>(null),saving=useRef(false),callbacks=useRef({onSave});callbacks.current={onSave};
 const cancel=()=>{if(saving.current)return;gesture.current=null;setPreview(null);};
 async function save(id:string,minutes:number){
  if(saving.current)return;saving.current=true;setBusy(true);setError('');setPreview({id,minutes});
  try{await callbacks.current.onSave(id,minutes);}catch(e){setError((e as Error).message);}finally{saving.current=false;setBusy(false);setPreview(null);}
 }
 useEffect(()=>{cancel();setError('');},[day]);
 useEffect(()=>{
  if(!preview||busy)return;
  const update=()=>{const current=gesture.current,element=grid.current;if(!current||!element)return;current.minutes=snapEventDuration(current.stop,(current.y-element.getBoundingClientRect().top)/scale);setPreview({id:current.stop.id,minutes:current.minutes});};
  const move=(e:PointerEvent)=>{const current=gesture.current;if(!current||current.pointerId!==e.pointerId)return;e.preventDefault();current.y=e.clientY;if(Math.abs(e.clientY-current.startY)>2)current.moved=true;if(current.moved)update();};
  const up=(e:PointerEvent)=>{const current=gesture.current;if(!current||current.pointerId!==e.pointerId)return;e.preventDefault();e.stopPropagation();gesture.current=null;if(current.moved)void save(current.stop.id,current.minutes);else setPreview(null);};
  const abort=()=>cancel();
  const key=(e:KeyboardEvent)=>{if(e.key==='Escape'&&gesture.current){e.preventDefault();cancel();}};
  let frame:number;
  const scroll=()=>{const current=gesture.current,pane=grid.current?.closest('.calendar-pane');if(current?.moved&&pane){const bounds=pane.getBoundingClientRect(),tabs=pane.querySelector('.calendar-days')?.getBoundingClientRect().height||82;const delta=current.y<bounds.top+tabs+16?-8:current.y>bounds.bottom-24?8:0;if(delta){pane.scrollTop+=delta;update();}}frame=requestAnimationFrame(scroll);};
  frame=requestAnimationFrame(scroll);
  window.addEventListener('pointermove',move,{capture:true,passive:false});window.addEventListener('pointerup',up,true);window.addEventListener('pointercancel',abort,true);window.addEventListener('blur',abort);window.addEventListener('keydown',key);
  return()=>{cancelAnimationFrame(frame);window.removeEventListener('pointermove',move,true);window.removeEventListener('pointerup',up,true);window.removeEventListener('pointercancel',abort,true);window.removeEventListener('blur',abort);window.removeEventListener('keydown',key);};
 },[grid,scale,!!preview,busy]);
 return {preview,busy,error,clearError:()=>setError(''),availability:preview?getAvailability(preview.id,preview.minutes):null,
  start:(e:ReactPointerEvent<HTMLButtonElement>,stop:Stop)=>{if(disabled||saving.current||e.button!==0)return;e.preventDefault();e.stopPropagation();setError('');gesture.current={stop,pointerId:e.pointerId,y:e.clientY,startY:e.clientY,moved:false,minutes:stopDuration(stop)};setPreview({id:stop.id,minutes:stopDuration(stop)});},
  keyboard:(stop:Stop,key:string,element:HTMLButtonElement)=>{if(disabled||saving.current)return;const max=maxEventDuration(stop),min=Math.min(15,max);const minutes=key==='Home'?min:key==='End'?max:Math.max(min,Math.min(max,stopDuration(stop)+(key==='ArrowUp'?-15:15)));void save(stop.id,minutes).finally(()=>requestAnimationFrame(()=>{if(element.isConnected)element.focus({preventScroll:true});}));},
 };
}
