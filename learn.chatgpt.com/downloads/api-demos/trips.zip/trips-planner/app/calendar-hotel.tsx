'use client';
import { BuildingOffice2Icon } from '@heroicons/react/16/solid';
import type { Hotel, Route } from '@/lib/trips';
import { routeKey, sameLocation } from '@/lib/trips';
import type { DayPoint } from '@/lib/hotels';
import CalendarTravel, { type TravelActions } from './calendar-travel';

type Props=TravelActions & {hotel:Hotel;point:DayPoint;from?:DayPoint;to?:DayPoint;routes:Record<string,Route>;routeErrors:Record<string,string>;disabled:boolean;selected:string|null;onSelect:(id:string)=>void;onEdit:(hotel:Hotel)=>void};
export default function CalendarHotel({hotel,point,from,to,routes,routeErrors,disabled,selected,onSelect,onEdit,...travelActions}:Props){
 const end=point.hotelRole==='end';
 const a=end?from:point,b=end?point:to;
 const leg=a&&b&&!sameLocation(a,b)&&<div className="hotel-travel"><CalendarTravel {...travelActions} from={a} to={b} route={routes[routeKey(a,b,b.mode)]} routeError={routeErrors[routeKey(a,b,b.mode)]} disabled={disabled}/></div>;
 const label=end?'Return to hotel':(hotel.checkOut===point.date?'Start · Check out':'Start at hotel');
 return <section className={'calendar-hotel '+(end?'hotel-end':'hotel-start')} data-stop-id={point.id} aria-label={label}>
  {end&&leg}
  <button type="button" className={'hotel-calendar-card'+(selected===point.id?' is-selected':'')} aria-label={(disabled?'Show hotel ':'Edit hotel ')+hotel.name} onClick={()=>{onSelect(point.id);if(!disabled)onEdit(hotel);}}>
   <BuildingOffice2Icon className="hotel-icon"/><div><p className="hotel-day-label">{label}</p><p className="hotel-day-name">{hotel.name}</p></div>
  </button>
  {!end&&leg}
 </section>;
}
