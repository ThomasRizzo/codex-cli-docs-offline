'use client';
import { useState } from 'react';
import { Plus, MapPin, ArrowLeft } from 'lucide-react';
import { Modal, PlaceSearch } from './controls';
import { days, formatDate, hasLocation, type Place, type Stop, type Trip } from '@/lib/trips';
import { stopDuration, stopMinute } from '@/lib/event-duration';

export default function EventForm({trip,day,event,initialTime='09:00',onSave,onRemove,onEditHotel,onClose}:{trip:Trip;day:string;event?:Stop;initialTime?:string;onSave:(event:Stop)=>Promise<void>;onRemove?:()=>Promise<void>;onEditHotel?:(hotel:NonNullable<Trip['hotels']>[number])=>void;onClose:()=>void}){
 const checkInHotel=event?.hotelCheckInId?trip.hotels?.find(h=>h.id===event.hotelCheckInId):undefined;
 const [name,setName]=useState(event?.name||''),[date,setDate]=useState(event?.date||day),[time,setTime]=useState(event?.time??initialTime),[minutes,setMinutes]=useState(stopDuration(event||{time:initialTime})),[note,setNote]=useState(event?.note||'');
 const [location,setLocation]=useState<Place|null>(event&&hasLocation(event)?{id:event.id,name:event.locationName||event.name,address:event.address,lat:event.lat,lng:event.lng}:null),[picking,setPicking]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');try{await onSave({id:event?.id||crypto.randomUUID(),kind:'event',hotelCheckInId:event?.hotelCheckInId,name:name.trim(),date,time,durationMinutes:minutes,note,mode:event?.mode||'walk',timeZone:event?.timeZone,locationName:location?.name,address:location?.address||'',lat:location?.lat,lng:location?.lng});onClose();}catch(e){setError((e as Error).message);setBusy(false);}}
 async function remove(){if(!onRemove)return;setBusy(true);setError('');try{await onRemove();onClose();}catch(e){setError((e as Error).message);setBusy(false);}}
 function pick(place:Place){setLocation(place);setPicking(false);}
 const hotels=(trip.hotels||[]).filter(h=>h.checkIn<=date&&h.checkOut>=date);
 return <Modal title={checkInHotel?'Hotel check-in':event?'Edit event':'Add an event'} onClose={onClose}>{picking?<>
  <button type="button" className="back picker-back" onClick={()=>setPicking(false)}><ArrowLeft size={14}/>Back to event</button>
  {!!hotels.length&&<div className="event-hotel-options"><p className="field-label">Your hotel</p>{hotels.map(h=><button type="button" className="location-choice" key={h.id} onClick={()=>pick(h)}><MapPin size={16}/><span>{h.name}</span></button>)}</div>}
  <PlaceSearch center={trip.destination} onPick={pick}/>
 </>:<form className="form" onSubmit={submit}>
  <label>Title<input readOnly={!!checkInHotel} autoFocus={!checkInHotel} required maxLength={160} value={name} onChange={e=>setName(e.currentTarget.value)} placeholder="Check in to hotel, meet with Alex…"/></label>
  <div className="two-col"><label>Day<select disabled={!!checkInHotel} value={date} onChange={e=>setDate(e.currentTarget.value)}>{days(trip.start,trip.end).map(d=><option key={d} value={d}>{formatDate(d,{weekday:'short',month:'short',day:'numeric'})}</option>)}</select></label><label>Time {!checkInHotel&&<span className="muted">(optional)</span>}<input type="time" required={!!checkInHotel} min={checkInHotel?.checkInFrom|| (checkInHotel?'15:00':undefined)} value={time} onInput={e=>setTime(e.currentTarget.value)}/></label></div>
  {time&&<label>Duration <span className="muted">(minutes)</span><input type="number" required min={1} max={1440-(stopMinute({time})||0)} value={minutes} onChange={e=>setMinutes(Number(e.currentTarget.value))}/></label>}
  {checkInHotel?<div className="chosen-place"><MapPin size={16}/><div><strong>{checkInHotel.name}</strong><small>{checkInHotel.address}</small></div></div>:<div className="event-location"><span className="field-label">Location <span className="muted">(optional)</span></span><button type="button" className="location-choice" onClick={()=>setPicking(true)}><MapPin size={16}/><span>{location?.name||'Add a location'}</span>{location&&<span className="muted">Change</span>}</button>{location?<button type="button" className="text-button" onClick={()=>setLocation(null)}>Remove location</button>:<p className="field-note">Add a location to include it on the map and in travel estimates.</p>}</div>}
  <label>Notes <span className="muted">(optional)</span><textarea value={note} onChange={e=>setNote(e.currentTarget.value)} maxLength={1500} rows={3}/></label>
  {error&&<p className="error" role="alert">{error}</p>}
  <div className="form-actions">{checkInHotel&&onEditHotel&&<button type="button" className="flight-delete" disabled={busy} onClick={()=>onEditHotel(checkInHotel)}>Edit hotel stay</button>}{onRemove&&<button type="button" className="flight-delete danger" disabled={busy} onClick={remove}>Remove event</button>}<button type="button" onClick={onClose}>Cancel</button><button className="primary" disabled={busy}>{busy?'Saving…':event?'Save changes':'Add event'}<Plus size={16}/></button></div>
 </form>}</Modal>;
}
