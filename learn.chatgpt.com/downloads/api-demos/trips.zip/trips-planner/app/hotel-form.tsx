'use client';
import { useState } from 'react';
import { BuildingOffice2Icon, CheckIcon } from '@heroicons/react/16/solid';
import { hotelSchema, type Hotel, type Place, type Trip } from '@/lib/trips';
import { Modal, PlaceSearch } from './controls';

export default function HotelForm({trip,day,hotel,onSave,onRemove,onClose}:{trip:Trip;day:string;hotel?:Hotel;onSave:(h:Hotel)=>Promise<void>;onRemove?:()=>Promise<void>;onClose:()=>void}) {
 const [place,setPlace]=useState<Place|null>(hotel||null),[checkIn,setCheckIn]=useState(hotel?.checkIn||day);
 const nextDay=(date:string)=>{const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+1);return d.toISOString().slice(0,10);};
 const [checkOut,setCheckOut]=useState(hotel?.checkOut||(trip.end>day?trip.end:nextDay(day)));
 const [checkInFrom,setCheckInFrom]=useState(hotel?.checkInFrom||'15:00');
 const [note,setNote]=useState(hotel?.note||''),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function save(e:React.FormEvent){e.preventDefault();if(!place)return;setError('');const parsed=hotelSchema.safeParse({...place,id:hotel?.id||crypto.randomUUID(),checkIn,checkOut,checkInFrom,note,returnModes:hotel?.returnModes});if(!parsed.success){setError(parsed.error.issues[0].message);return;}setBusy(true);try{await onSave(parsed.data);onClose();}catch(e){setError((e as Error).message);setBusy(false);}}
 async function remove(){if(!onRemove)return;setBusy(true);setError('');try{await onRemove();onClose();}catch(e){setError((e as Error).message);setBusy(false);}}
 return <Modal title={hotel?'Edit hotel':'Add a hotel'} onClose={onClose}>{!place?<PlaceSearch center={trip.destination} placeholder="Search your hotel or its address" onPick={setPlace}/>:<form className="form" onSubmit={save}>
  <div className="chosen-place"><BuildingOffice2Icon className="hotel-icon"/><div><strong>{place.name}</strong><small>{place.address}</small></div><button type="button" className="text-button" onClick={()=>setPlace(null)}>Change</button></div>
  <div className="two-col"><label>Check-in<input type="date" required value={checkIn} onInput={e=>{const value=e.currentTarget.value;setCheckIn(value);if(value&&checkOut<=value)setCheckOut(nextDay(value));}}/></label><label>Check-out<input type="date" required min={checkIn?nextDay(checkIn):undefined} value={checkOut} onInput={e=>setCheckOut(e.currentTarget.value)}/></label></div>
  <label>Check-in opens<input type="time" required value={checkInFrom} onInput={e=>setCheckInFrom(e.currentTarget.value)}/></label>
  <p className="field-note">Check-in starts as a 30-minute event. Drag it later or resize it in the calendar.</p>
  <p className="field-note">Your day starts where you stayed the night before and ends where you’re staying that night.</p>
  <label>A note <span className="muted">(optional)</span><textarea rows={3} maxLength={1500} value={note} onChange={e=>setNote(e.currentTarget.value)} placeholder="Booking details or a reminder…"/></label>
  {error&&<p className="error" role="alert">{error}</p>}
  <div className="form-actions">{onRemove&&<button type="button" className="flight-delete danger" disabled={busy} onClick={remove}>Remove hotel</button>}<button type="button" onClick={onClose}>Cancel</button><button type="submit" className="primary" disabled={busy}>{busy?'Saving…':'Save hotel'}<CheckIcon className="hotel-icon"/></button></div>
 </form>}</Modal>;
}
