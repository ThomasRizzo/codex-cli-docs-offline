import type { Metadata } from 'next';
import './globals.css';
import './workspace.css';
export const metadata:Metadata={title:'Trips',description:'Trips, flights, and daily itineraries.',icons:{icon:'/favicon.svg'},robots:{index:false,follow:false,noarchive:true,nosnippet:true,noimageindex:true},referrer:'no-referrer'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>;}
