'use client';
import { useEffect, useState } from 'react';
import { CheckIcon, LinkIcon, ClipboardIcon } from '@heroicons/react/16/solid';
import { api, Modal } from './controls';
import type { Trip } from '@/lib/trips';
import { calendarDayURL } from '@/lib/day-query';
export default function TripSharing({trip,day,beforeShare,onClose}:{trip:Trip;day:string;beforeShare:()=>Promise<void>;onClose:()=>void}) {
  const [url,setURL]=useState<string|null>(null),[loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState(''),[copied,setCopied]=useState(false),[confirm,setConfirm]=useState(false);
  const endpoint='/api/share?trip='+encodeURIComponent(trip.id);
  const selectedURL=url?calendarDayURL(url,day):null;
  useEffect(()=>{let cancelled=false;api<{url:string|null}>(endpoint).then(data=>{if(!cancelled)setURL(data.url);}).catch(e=>{if(!cancelled)setError(e.message);}).finally(()=>{if(!cancelled)setLoading(false);});return()=>{cancelled=true;};},[endpoint]);
  async function create(){setBusy(true);setError('');try{await beforeShare();const data=await api<{url:string}>(endpoint,{method:'POST'});setURL(data.url);}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
  async function revoke(){setBusy(true);setError('');try{await api(endpoint,{method:'DELETE'});setURL(null);setConfirm(false);setCopied(false);}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
  async function copy(){if(!selectedURL)return;try{await navigator.clipboard.writeText(selectedURL);setCopied(true);}catch{setError('Select and copy the link below.');}}
  return <Modal title="Share trip" onClose={onClose}><div className="calendar-subscription trip-sharing"><p>Anyone with the link can view {trip.name}. Only you can edit it.</p><p className="field-note">Includes the itinerary, map, flights, and hotels. Notes and AI chat stay private. Changes appear at the same link.</p>{loading?<p className="muted">Loading link…</p>:selectedURL?<><label className="calendar-url-label">Trip link<input name="trip-share-url" aria-label="Trip link" readOnly value={selectedURL} onFocus={e=>e.currentTarget.select()} spellCheck={false}/></label><div className="subscription-actions"><button type="button" className="primary" onClick={copy}>{copied?<CheckIcon/>:<ClipboardIcon/>}{copied?'Copied':'Copy link'}</button><a className="secondary" href={selectedURL} target="_blank" rel="noopener noreferrer">Preview</a></div>{confirm?<div className="revoke-confirm"><p>This link will stop working for everyone you shared it with.</p><div className="form-actions"><button type="button" disabled={busy} onClick={()=>setConfirm(false)}>Keep sharing</button><button type="button" className="secondary danger" disabled={busy} onClick={revoke}>{busy?'Stopping…':'Stop sharing'}</button></div></div>:<button type="button" className="text-button revoke-link" onClick={()=>setConfirm(true)}>Stop sharing</button>}</>:<button type="button" className="primary" disabled={busy} onClick={create}><LinkIcon/>{busy?'Creating…':'Create share link'}</button>}{error&&<p className="error" role="alert">{error}</p>}</div></Modal>;
}
