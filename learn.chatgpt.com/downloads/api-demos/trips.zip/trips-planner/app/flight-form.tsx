'use client';
import { useState } from 'react';
import { ArrowRight,Check,RefreshCw } from 'lucide-react';
import type { Flight } from '@/lib/trips';
import { formatDate } from '@/lib/trips';
import { flightStatus, type FlightLookup, type FlightMatch } from '@/lib/flightaware';
import { api,Modal } from './controls';
function uid(){return crypto.randomUUID();}
function timeLabel(value:string){if(!value)return 'Time not set';const [hours,minutes]=value.split(':').map(Number);return `${hours%12||12}:${String(minutes).padStart(2,'0')} ${hours<12?'am':'pm'}`;}

export default function FlightForm({day,flight,lookupEnabled,onSave,onClose,onRemove}:{lookupEnabled:boolean;day:string;flight?:Flight;onRemove?:()=>Promise<void>;onSave:(f:Flight)=>Promise<void>;onClose:()=>void}){
 const [f,setF]=useState<Flight>(flight||{id:uid(),number:'',date:day,arrivalDate:day,from:'',to:'',departure:'',arrival:''}),[busy,setBusy]=useState(false),[error,setError]=useState(''),[matches,setMatches]=useState<FlightMatch[]>([]),[notice,setNotice]=useState(''),[resolved,setResolved]=useState(!!flight);
 function field(k:'number'|'date',v:string){setMatches([]);setNotice('');setError('');setResolved(false);setF(old=>({...old,[k]:v,flightaware:undefined,arrivalAirport:undefined}));}
 async function remove(){if(!onRemove)return;setBusy(true);setError('');try{await onRemove();onClose();}catch(e){setError((e as Error).message);setBusy(false);}}
 async function save(e:React.FormEvent){e.preventDefault();if(!resolved||busy)return;setBusy(true);setError('');try{await onSave({...f,number:f.number.replace(/\s/g,'').toUpperCase()});onClose();}catch(e){setError((e as Error).message);setBusy(false);}}
 function applyMatch(match:FlightMatch){setF(old=>({...old,...match,scheduledDeparture:match.departure,departurePlan:old.from===match.from?old.departurePlan:undefined,arrivalAirport:match.arrivalAirport,arrivalExitMinutes:old.arrivalExitMinutes,arrivalMode:old.arrivalMode,arrivalTransfer:old.to===match.to?old.arrivalTransfer:undefined}));setMatches([]);setNotice('');setResolved(true);}
 async function lookup(){setBusy(true);setError('');setMatches([]);setNotice('');setResolved(false);try{const result=await api<FlightLookup>('/api/flights',{method:'POST',body:JSON.stringify({number:f.number,date:f.date})});if(result.flights.length===1&&!result.partial)applyMatch(result.flights[0]);else if(result.flights.length){setMatches(result.flights);setNotice(result.partial?'Choose your flight. More matches may exist; check the route against your booking.':'Choose your flight.');}else setError('FlightAware has no published details for this flight on this date. Check the number and date, or try again later.');}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
 return <Modal title={flight?'Edit flight':'Add a flight'} onClose={onClose}><form className="form" onSubmit={save}>
  <div className="two-col"><label>Flight number<input disabled={busy} autoFocus required maxLength={12} placeholder="e.g. AS 331" value={f.number} onInput={e=>field('number',e.currentTarget.value)}/></label><label>Departure date<input disabled={busy} type="date" required value={f.date} onInput={e=>field('date',e.currentTarget.value)}/></label></div>
  {lookupEnabled&&<button type="button" className="flight-lookup" disabled={busy||!f.number.trim()||!f.date} onClick={lookup}><RefreshCw size={16} className={busy?'spin':''}/>{busy?'Looking up flight…':'Look up flight'}</button>}
  {!lookupEnabled&&<p className="field-note" role="status">Flight lookup is temporarily unavailable.</p>}
  {notice&&<p className="field-note" role="status">{notice}</p>}
  {!!matches.length&&<div className="flight-matches">{matches.map(match=><button type="button" key={match.flightaware.origin+match.flightaware.scheduledOut+match.to} onClick={()=>applyMatch(match)}><strong>{match.from} → {match.to}</strong><span>{match.departure} – {match.arrival}{match.arrivalDate!==match.date?' · '+formatDate(match.arrivalDate):''}</span></button>)}</div>}
  {resolved&&<div className="flight-summary" role="status" aria-label="Flight details"><div><small>Departure</small><strong>{f.from}</strong><time>{timeLabel(f.departure)}</time></div><ArrowRight size={18} aria-hidden="true"/><div><small>Arrival</small><strong>{f.to}</strong><time>{timeLabel(f.arrival)}</time>{f.arrivalDate!==f.date&&<small>{formatDate(f.arrivalDate)}</small>}</div></div>}
  {resolved&&<label>Time to leave the arrival airport<input type="number" min={0} max={240} step={5} value={f.arrivalExitMinutes??30} onChange={e=>setF(old=>({...old,arrivalExitMinutes:Number(e.currentTarget.value)}))}/><span className="field-note">Minutes after arrival for bags and getting outside. Travel to your first stop is added separately.</span></label>}
  {resolved&&<label className="arrival-transfer-toggle"><input type="checkbox" checked={f.arrivalTransfer!==false} onChange={e=>setF(old=>({...old,arrivalTransfer:e.currentTarget.checked?undefined:false}))}/>Connect arrival to the first nearby event</label>}
  {resolved&&f.flightaware&&<div className="flight-provider"><p>{flightStatus(f)}</p><small><a href="https://www.flightaware.com/" target="_blank" rel="noreferrer">FlightAware</a> · Checked {new Date(f.flightaware.checkedAt).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}</small></div>}
  {error&&<p className="error" role="alert">{error}</p>}
  <div className="form-actions">{onRemove&&<button type="button" className="flight-delete danger" disabled={busy} onClick={remove}>Remove flight</button>}<button type="button" onClick={onClose}>Cancel</button><button type="submit" className="primary" disabled={busy||!resolved}>Save flight<Check size={16}/></button></div>
 </form></Modal>;
}
