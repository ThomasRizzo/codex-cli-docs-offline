'use client';
import { useEffect,useState, type RefObject } from 'react';
import { loadGoogleMaps } from '@/lib/google-maps';
import type { Place } from '@/lib/trips';
import { safeSource } from '@/lib/chat-model';
export type PlaceDetails={rating?:number;count?:number;photo?:string;photoUrl?:string|null;authors:{name:string;url:string|null}[];url:string|null};
const sessionResults=new Map<string,Promise<PlaceDetails|null>>();
async function detailsFor(place:Place,key:string){
 const cacheKey=`${place.id}:${place.lat}:${place.lng}`;if(sessionResults.has(cacheKey))return sessionResults.get(cacheKey)!;
 const pending=(async()=>{const g=await loadGoogleMaps(key);const {Place:GooglePlace}=await g.importLibrary('places');const r=await GooglePlace.searchByText({textQuery:place.name+' '+place.address,fields:['id','displayName','location','rating','userRatingCount','photos','googleMapsURI'],locationBias:{center:{lat:place.lat,lng:place.lng},radius:200},maxResultCount:3});
  const normalize=(s:string)=>s.toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();const name=normalize(place.name);
  const match=r.places?.find((p:any)=>{if(!p.location)return false;const distance=Math.hypot((p.location.lat()-place.lat)*111000,(p.location.lng()-place.lng)*111000*Math.cos(place.lat*Math.PI/180));const candidate=normalize(p.displayName||'');return distance<250&&(candidate.includes(name)||name.includes(candidate));});if(!match)return null;
  const photo=match.photos?.[0];return {rating:match.rating,count:match.userRatingCount,url:match.googleMapsURI?safeSource(match.googleMapsURI):null,photo:photo?.getURI({maxWidth:720,maxHeight:480}),photoUrl:photo?.googleMapsURI?safeSource(photo.googleMapsURI):null,authors:(photo?.authorAttributions||[]).map((a:any)=>({name:a.displayName,url:a.uri?safeSource(a.uri):null}))} as PlaceDetails;
 })().catch(error=>{console.warn('Google place details unavailable:',String(error?.message||error).replace(/AIza[\w-]+/g,'[key hidden]'));return null;});sessionResults.set(cacheKey,pending);return pending;
}
export function useGooglePlaceDetails(place:Place,apiKey:string|undefined,element:RefObject<HTMLElement|null>){
 const [details,setDetails]=useState<PlaceDetails|null>(null);
 useEffect(()=>{
  setDetails(null);if(!apiKey)return;
  let active=true;
  const observer=new IntersectionObserver(entries=>{if(!entries.some(e=>e.isIntersecting))return;observer.disconnect();detailsFor(place,apiKey).then(d=>{if(active)setDetails(d);});},{rootMargin:'160px'});
  if(element.current)observer.observe(element.current);
  return()=>{active=false;observer.disconnect();};
 },[place.id,place.lat,place.lng,apiKey,element]);
 return {details,hidePhoto:()=>setDetails(d=>d?{...d,photo:undefined}:d)};
}
