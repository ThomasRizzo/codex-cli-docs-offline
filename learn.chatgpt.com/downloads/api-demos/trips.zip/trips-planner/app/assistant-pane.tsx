'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import Markdown from 'react-markdown';
import { ArrowUpIcon, XMarkIcon, StopIcon, PencilSquareIcon, ArrowUturnLeftIcon, ArrowPathIcon } from '@heroicons/react/16/solid';
import { useScheduling } from './scheduling';
import PlaceCards from './place-cards';
import type { RecommendationSet } from '@/lib/recommendations';
import { hasLocation, type Trip } from '@/lib/trips';
import type { ChatEvent, ChatTurn } from '@/lib/chat-types';
import { api } from './controls';
import { workspaceFetch } from '@/lib/demo-client';
import { beginLocalTurn, finishLocalTurn, failLocalTurn, readLocalChat, undoLocalTurn, clearLocalChat, subscribeLocalWorkspace } from '@/lib/local-workspace';

function MessageMarkdown({text}:{text:string}) {
 return <Markdown skipHtml components={{img:()=>null,a:({href,children})=>href&&/^https?:\/\//i.test(href)?<a href={href} target="_blank" rel="noopener noreferrer">{children}</a>:<span>{children}</span>}}>{text}</Markdown>;
}

export default function AssistantPane({localWorkspace=false,assistantEnabled=false,beforeSend,trip,demo,day,googleMapsKey,recommendationSet,highlightedRecommendation,selectedRecommendation,onRecommendations,onHighlight,onSelectRecommendation,onTripChange,onClose}:{localWorkspace?:boolean;assistantEnabled?:boolean;beforeSend:()=>Promise<void>;trip?:Trip;demo:boolean;day:string;googleMapsKey?:string;recommendationSet:RecommendationSet|null;highlightedRecommendation:string|null;selectedRecommendation:string|null;onRecommendations:(set:RecommendationSet|null)=>void;onHighlight:(id:string|null)=>void;onSelectRecommendation:(id:string)=>void;onTripChange:(trip:Trip)=>void;onClose:()=>void}) {
 const scheduling=useScheduling();
 const placeCallbacks=useRef({onRecommendations,onHighlight});placeCallbacks.current={onRecommendations,onHighlight};
 const placeVersion=useRef('');
 const context=demo?'example':trip?.id||'general';
 const [turns,setTurns]=useState<ChatTurn[]>([]),[draft,setDraft]=useState(''),[loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[connected,setConnected]=useState(false),[status,setStatus]=useState(''),[error,setError]=useState('');
 const list=useRef<HTMLDivElement>(null),input=useRef<HTMLTextAreaElement>(null),abort=useRef<AbortController|null>(null),alive=useRef(true),follow=useRef(true),callback=useRef(onTripChange);callback.current=onTripChange;
 const load=useCallback(async()=>{const r=localWorkspace?{...await readLocalChat(context),connected:assistantEnabled}:await api<{turns:ChatTurn[];trip:Trip|null;connected:boolean}>('/api/chat?trip='+context);if(!alive.current)return;setTurns(r.turns);setConnected(r.connected);setBusy(r.turns.some(t=>t.status==='running'));if(r.trip&&!demo)callback.current(r.trip);return r;},[context,demo,localWorkspace,assistantEnabled]);
 useEffect(()=>{alive.current=true;load().catch(e=>{if(alive.current)setError(e.message);}).finally(()=>{if(alive.current)setLoading(false);});return()=>{alive.current=false;abort.current?.abort();};},[load]);
 useEffect(()=>{if(!localWorkspace)return;return subscribeLocalWorkspace(()=>{if(!abort.current)void load().catch(e=>{if(alive.current)setError(e.message);});});},[load,localWorkspace]);
 useEffect(()=>{if(!busy)return;const timer=setInterval(()=>{if(!abort.current)load().catch(()=>{});},4000);return()=>clearInterval(timer);},[busy,load]);
 useEffect(()=>{const last=[...turns].reverse().find(t=>t.places?.length);const key=last?last.id+JSON.stringify(last.places):'';if(key!==placeVersion.current){placeVersion.current=key;placeCallbacks.current.onRecommendations(last?{turnId:last.id,places:last.places}:null);}},[turns]);
 useEffect(()=>{if(!selectedRecommendation||!recommendationSet)return;const card=list.current?.querySelector(`[data-turn-id="${CSS.escape(recommendationSet.turnId)}"] [data-recommendation-id="${CSS.escape(selectedRecommendation)}"]`);if(card){follow.current=false;card.scrollIntoView({block:'nearest',behavior:'instant'});}},[selectedRecommendation,recommendationSet?.turnId]);
 useEffect(()=>{if(follow.current&&list.current)list.current.scrollTop=list.current.scrollHeight;},[turns,status,loading]);
 async function send(e?:React.FormEvent){
  e?.preventDefault();const message=draft.trim();if(!message||busy||!connected||loading)return;
  setError('');setDraft('');setBusy(true);setStatus('Checking your calendar…');follow.current=true;
  const id=crypto.randomUUID(),pending:ChatTurn={id,user:message,assistant:'',sources:[],places:[],changes:[],status:'running',afterVersion:null,createdAt:Date.now()};
  setTurns(t=>[...t,pending]);const controller=new AbortController();abort.current=controller;
  let finished=false,claimed=false,pendingAfterStop=false;
  try{
   await beforeSend();controller.signal.throwIfAborted();
   const body=localWorkspace?await beginLocalTurn(pending,context,day):{id,tripId:context,message,day};claimed=localWorkspace;
   controller.signal.throwIfAborted();setStatus('Thinking…');
   const r=await workspaceFetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:controller.signal});
   if(!r.ok){const data=await r.json() as {error?:string};throw new Error(data.error||'Could not send this message.');}
   if(!r.body)throw new Error('The reply was interrupted.');
   const reader=r.body.getReader(),decoder=new TextDecoder();let buffer='';
   const apply=async(line:string)=>{
    if(!line.trim())return;controller.signal.throwIfAborted();
    const event=JSON.parse(line) as ChatEvent;
    if(event.type==='status'&&alive.current)setStatus(event.text);
    if(event.type==='delta'&&alive.current)setTurns(ts=>ts.map(t=>t.id===id?{...t,assistant:t.assistant+event.text}:t));
    if(event.type==='done'){
     const saved=localWorkspace?await finishLocalTurn(id,event.turn,event.trip):event;
     finished=true;
     if(alive.current){setTurns(ts=>ts.map(t=>t.id===id?saved.turn:t));if(saved.trip&&!demo)callback.current(saved.trip);}
    }
    if(event.type==='error'){
     if(localWorkspace)await failLocalTurn(id,event.message);finished=true;
     if(alive.current)setTurns(ts=>ts.map(t=>t.id===id?{...t,status:'error',assistant:event.message}:t));
    }
   };
   try{for(;;){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});let at;while((at=buffer.indexOf('\n'))>=0){await apply(buffer.slice(0,at));buffer=buffer.slice(at+1);}}if(buffer.trim())await apply(buffer);}
   finally{reader.releaseLock();}
   if(!finished)throw new Error('The connection was interrupted. No itinerary changes were saved.');
  }catch(e){
   let message=controller.signal.aborted?'Reply stopped. No itinerary changes were saved.':(e as Error).message;
   if(localWorkspace&&claimed&&!finished)try{await failLocalTurn(id,message);}catch(storageError){message=(storageError as Error).message;}
   if(alive.current){
    if(!localWorkspace&&controller.signal.aborted){const recovered=await load().catch(()=>undefined);pendingAfterStop=!!recovered?.turns.some(t=>t.status==='running');}
    else{if(!controller.signal.aborted)setError(message);setTurns(ts=>ts.map(t=>t.id===id?{...t,status:'error',assistant:message}:t));}
   }
  }finally{abort.current=null;if(alive.current){setBusy(pendingAfterStop);setStatus('');input.current?.focus();}}
 }
 async function undo(turn:ChatTurn){if(!trip||demo)return;setError('');setBusy(true);try{const result=localWorkspace?await undoLocalTurn(turn.id,trip.id):await api<{trip:Trip;turn:ChatTurn}>('/api/chat/undo',{method:'POST',body:JSON.stringify({id:turn.id,tripId:trip.id})});if(alive.current){setTurns(ts=>ts.map(t=>t.id===turn.id?result.turn:t));callback.current(result.trip);}}catch(e){if(alive.current)setError((e as Error).message);}finally{if(alive.current)setBusy(false);}}
 async function clear(){setError('');try{if(localWorkspace)await clearLocalChat(context);else await api('/api/chat?trip='+context,{method:'DELETE'});if(alive.current){setTurns([]);input.current?.focus();}}catch(e){if(alive.current)setError((e as Error).message);}}
 const latest=turns.at(-1);
 return <aside className="assistant-pane" aria-label="Trip assistant" data-testid="assistant-pane">
  <header className="assistant-header"><div><h2>Assistant</h2><span className="assistant-model">GPT-6 Astra</span></div><div className="assistant-header-actions">{turns.length>0&&<button type="button" className="icon" onClick={clear} disabled={busy} aria-label="New chat" title="New chat"><PencilSquareIcon/></button>}<button type="button" className="icon assistant-close" onClick={onClose} aria-label="Close assistant"><XMarkIcon/><span className="touch-target" aria-hidden="true"/></button></div></header>
  <div ref={list} className="assistant-conversation" onScroll={()=>{const e=list.current;if(e)follow.current=e.scrollHeight-e.scrollTop-e.clientHeight<80;}} role="log" aria-label="Chat messages" aria-live="polite" aria-relevant="additions text">
   {loading?<p className="chat-empty">Loading chat…</p>:!turns.length&&<p className="chat-empty">{demo?'Research this example, or add your own trip to edit its itinerary.':trip?'Find places or change your itinerary.':'Ask about a destination, or add a trip to start planning.'}</p>}
   {turns.map(t=><div className="chat-turn" key={t.id} data-turn-id={t.id}><div className="chat-user chat-markdown"><MessageMarkdown text={t.user}/></div>{t.assistant&&<div className={'chat-answer chat-markdown '+(['error','conflict'].includes(t.status)?'chat-answer-error':'')}><MessageMarkdown text={t.assistant.replace(/[^]*/g,'')}/></div>}{t.places?.length>0&&<PlaceCards googleMapsKey={googleMapsKey} places={t.places} active={recommendationSet?.turnId===t.id?highlightedRecommendation:null} selected={recommendationSet?.turnId===t.id?selectedRecommendation:null} added={new Set(t.places.filter(p=>trip?.stops.some(s=>s.kind!=='event'&&hasLocation(s)&&s.date===day&&Math.abs(s.lat-p.lat)<.0001&&Math.abs(s.lng-p.lng)<.0001)).map(p=>p.id))} onHighlight={id=>{if(id&&recommendationSet?.turnId!==t.id)onRecommendations({turnId:t.id,places:t.places});onHighlight(id);}} onSelect={id=>{if(recommendationSet?.turnId!==t.id)onRecommendations({turnId:t.id,places:t.places});onSelectRecommendation(id);}} onAdd={trip&&!demo?p=>scheduling?.begin({place:p}):undefined}/>}{t.sources.length>0&&<details className="chat-sources"><summary>{t.sources.length} {t.sources.length===1?'source':'sources'}</summary><ul role="list">{t.sources.map(s=><li key={s.url}><a href={s.url} target="_blank" rel="noopener noreferrer">{s.title}</a></li>)}</ul></details>}{t.changes.length>0&&<div className="chat-changes"><span>{t.status==='undone'?'Changes undone':`${t.changes.length} ${t.changes.length===1?'change':'changes'} saved`}</span>{t.status==='complete'&&t.afterVersion===trip?.version&&<button type="button" onClick={()=>undo(t)} disabled={busy} aria-label="Undo itinerary changes"><ArrowUturnLeftIcon/>Undo</button>}</div>}</div>)}
   {busy&&<p className="chat-progress" role="status">{status|| (latest?.status==='running'?'Working…':'Saving…')}</p>}
  </div>
  <form className="assistant-composer" onSubmit={send}>{error&&<div className="chat-error" role="alert"><p>{error}</p><button type="button" className="text-button" onClick={()=>{setError('');load().catch(e=>setError(e.message));}}><ArrowPathIcon/>Refresh chat</button></div>}<div className="assistant-input"><textarea ref={input} name="message" aria-label="Message the trip assistant" placeholder="Ask about your trip…" rows={3} value={draft} maxLength={4000} onChange={e=>setDraft(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.nativeEvent.isComposing){e.preventDefault();send();}}} disabled={!connected||loading||busy}/>{busy&&abort.current?<button type="button" className="assistant-send" aria-label="Stop reply" onClick={()=>abort.current?.abort()}><StopIcon/></button>:<button type="submit" className="assistant-send" aria-label="Send message" disabled={!connected||loading||busy||!draft.trim()}><ArrowUpIcon/></button>}</div>{!connected&&!loading&&<p>AI isn’t connected yet.</p>}</form>
 </aside>;
}
