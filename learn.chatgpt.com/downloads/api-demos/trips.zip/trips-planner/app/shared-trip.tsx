'use client';
import { useEffect, useState } from 'react';
import { MapIcon, CalendarDaysIcon, ArrowRightEndOnRectangleIcon } from '@heroicons/react/16/solid';
import type { Trip,Route } from '@/lib/trips';
import { formatDate } from '@/lib/trips';
import { dayRoute } from '@/lib/hotels';
import { orderedDayStops } from '@/lib/calendar-travel';
import { departureSchedule,planningDays } from '@/lib/departures';
import TripMap from './map';
import DayCalendar from './day-calendar';
import { tripPath } from '@/lib/day-query';
import { useCalendarDayQuery } from './use-calendar-day-query';

const noop=()=>{};
const readonly=async()=>{};
export default function SharedTrip({initialTrip,initialDay,token,googleMapsKey}:{initialTrip:Trip;initialDay:string;token:string;googleMapsKey?:string}) {
  const [trip,setTrip]=useState<Trip|null>(initialTrip),[day,setDay]=useState(initialDay),[selected,setSelected]=useState<string|null>(null),[view,setView]=useState<'map'|'calendar'>('calendar'),[routes,setRoutes]=useState<Record<string,Route>>({}),[routeErrors,setRouteErrors]=useState<Record<string,string>>({}),[error,setError]=useState('');
  const schedules=trip?trip.flights.map(f=>departureSchedule(f,trip.stops,routes,routeErrors)):[],dates=trip?planningDays(trip,schedules):[];
  useCalendarDayQuery(trip,day,setDay,dates);
  useEffect(()=>{let cancelled=false,running=false;const controller=new AbortController();async function refresh(){if(running||document.visibilityState==='hidden')return;running=true;try{const r=await fetch('/api/shared/'+token+'?day='+day,{signal:controller.signal});if(r.status===404){if(!cancelled)setTrip(null);return;}if(!r.ok)throw new Error('Could not refresh this trip.');const data=await r.json() as {trip:Trip;routes:Record<string,Route>;routeErrors:Record<string,string>};if(!cancelled){setTrip(data.trip);setRoutes(old=>({...old,...data.routes}));setRouteErrors(data.routeErrors);setError('');}}catch(e){if(!cancelled)setError((e as Error).message);}finally{running=false;}}void refresh();const timer=setInterval(refresh,60000);document.addEventListener('visibilitychange',refresh);return()=>{cancelled=true;controller.abort();clearInterval(timer);document.removeEventListener('visibilitychange',refresh);};},[token,day]);
  if(!trip)return <main className="planner-app access-screen"><div><h1>Trip unavailable</h1><p>This link is no longer shared.</p><a className="secondary" href="/">Trips</a></div></main>;
  const stops=orderedDayStops(trip.stops,day),hotelRoute=dayRoute(trip,day);
  function chooseDay(date:string){setDay(date);setSelected(null);}
  function select(id:string){setSelected(id);}
  function selectFromMap(id:string){select(id);setView('calendar');requestAnimationFrame(()=>document.querySelector(`[data-stop-id="${CSS.escape(id)}"]`)?.scrollIntoView({block:'nearest',behavior:'instant'}));}
  return <div className={'planner-app planner-trip shared-workspace shared-view-'+view}>
    {error&&<p className="shared-error" role="status">{error} Trying again shortly.</p>}
    <main className="trip-workspace">
      <aside className="workspace-map" aria-label="Trip map"><div className="workspace-map-label"><strong>{formatDate(day,{weekday:'short',month:'short',day:'numeric'})}</strong></div><TripMap center={trip.destination} googleMapsKey={googleMapsKey} stops={hotelRoute.points} routes={routes} selected={selected} onSelect={selectFromMap}/></aside>
      <section className="calendar-column" aria-label="Shared trip calendar"><div className="calendar-pane" tabIndex={0}>
        <div className="calendar-days" role="tablist" aria-label="Trip days">{dates.map((date,index)=><button type="button" key={date} role="tab" aria-selected={date===day} aria-controls="shared-calendar-day" id={'shared-day-'+date} tabIndex={date===day?0:-1} onClick={()=>chooseDay(date)} onKeyDown={e=>{const next=e.key==='ArrowRight'?dates[(index+1)%dates.length]:e.key==='ArrowLeft'?dates[(index+dates.length-1)%dates.length]:e.key==='Home'?dates[0]:e.key==='End'?dates.at(-1):null;if(next){e.preventDefault();chooseDay(next);document.getElementById('shared-day-'+next)?.focus();}}}><span>{formatDate(date,{weekday:'short'})}</span><strong>{formatDate(date)}</strong><i className={trip.stops.some(s=>s.date===date)?'has-stops':''}/></button>)}</div>
        <div className="calendar-day-content" id="shared-calendar-day" role="tabpanel" aria-labelledby={'shared-day-'+day}><DayCalendar timeZone={trip.timeZone} onResize={readonly} resizeAvailability={()=>({status:'blocked',label:'View only',message:'Only the owner can edit this trip.',missing:[]})} hotelRoute={hotelRoute} onEditHotel={noop} routes={routes} routeErrors={routeErrors} onTravelMode={readonly} onRetryRoute={readonly} stops={stops} schedules={schedules} day={day} selected={selected} onSelect={select} onEdit={noop} onEditDeparture={noop} onEditFlight={noop} disabled/></div>
      </div></section>
    </main>
    <nav className="floating-bar shared-dock" aria-label="Shared trip"><div className="shared-trip-name"><strong>{trip.name}</strong><span>View only</span></div><span className="dock-divider" aria-hidden="true"/><button type="button" className="dock-button shared-mobile" aria-label="Show map" aria-pressed={view==='map'} onClick={()=>setView('map')}><MapIcon/><span className="touch-target" aria-hidden="true"/></button><button type="button" className="dock-button shared-mobile" aria-label="Show calendar" aria-pressed={view==='calendar'} onClick={()=>setView('calendar')}><CalendarDaysIcon/><span className="touch-target" aria-hidden="true"/></button><a className="dock-button" href={tripPath(trip.id,day)} aria-label="Sign in to edit" title="Sign in to edit"><ArrowRightEndOnRectangleIcon/><span className="touch-target" aria-hidden="true"/></a></nav>
  </div>;
}
