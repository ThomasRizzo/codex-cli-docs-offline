CREATE TABLE `trip_shares` (
	`trip_id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`token` text NOT NULL,
	`token_hash` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `trip_shares_token_hash_unique` ON `trip_shares` (`token_hash`);