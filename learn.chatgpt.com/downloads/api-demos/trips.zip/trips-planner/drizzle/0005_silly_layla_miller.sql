CREATE TABLE `demo_rate_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`minute_window` integer NOT NULL,
	`minute_count` integer NOT NULL,
	`day_window` integer NOT NULL,
	`day_count` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `demo_rate_limits_expiry` ON `demo_rate_limits` (`expires_at`);--> statement-breakpoint
CREATE TABLE `demo_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `demo_sessions_expiry` ON `demo_sessions` (`expires_at`);