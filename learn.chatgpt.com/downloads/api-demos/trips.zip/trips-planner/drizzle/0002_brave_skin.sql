CREATE TABLE `chat_turns` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`trip_id` text NOT NULL,
	`user_text` text NOT NULL,
	`assistant_text` text DEFAULT '' NOT NULL,
	`sources` text DEFAULT '[]' NOT NULL,
	`changes` text DEFAULT '[]' NOT NULL,
	`status` text DEFAULT 'running' NOT NULL,
	`before_data` text,
	`after_version` integer,
	`created_at` integer NOT NULL,
	`archived_at` integer
);
--> statement-breakpoint
CREATE INDEX `chat_turns_owner_trip` ON `chat_turns` (`owner`,`trip_id`,`created_at`);