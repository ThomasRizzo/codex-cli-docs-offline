CREATE TABLE `calendar_subscriptions` (
	`owner` text PRIMARY KEY NOT NULL,
	`token` text NOT NULL,
	`token_hash` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `calendar_subscriptions_token_hash_unique` ON `calendar_subscriptions` (`token_hash`);