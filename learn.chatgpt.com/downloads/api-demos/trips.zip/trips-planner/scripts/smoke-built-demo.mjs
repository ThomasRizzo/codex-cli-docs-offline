import assert from 'node:assert/strict';
import { readdir, readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { Miniflare, Log, LogLevel, createFetchMock } from 'miniflare';

// Exercise the exact production modules in workerd, without real credentials or external calls.
const root = resolve('dist/server'), files = await readdir(root, { recursive: true });
const modules = ['index.js', ...files.filter(name => /\.m?js$/.test(name) && name !== 'index.js')]
  .map(name => ({ type: 'ESModule', path: resolve(root, name) }));
const mock = createFetchMock(); mock.disableNetConnect();
let modelCalls = 0, phase = 'edit', placeCalls = 0;
const cafes = ['Anchorhead Coffee', 'Monorail Espresso', 'Moore Coffee'];
mock.get('https://photon.komoot.io').intercept({ path: /^\/api\/\?/, method: 'GET' }).reply(503, () => { placeCalls++; return 'Temporarily unavailable'; });
mock.get('https://photon.komoot.io').intercept({ path: /^\/api\/\?/, method: 'GET' }).reply(200, options => {
  placeCalls++; const name = new URL(options.path, 'https://photon.komoot.io').searchParams.get('q');
  const index = cafes.indexOf(name); assert.ok(index >= 0);
  return JSON.stringify({ features: [{ properties: { osm_type: 'N', osm_id: index + 1, name, city: 'Seattle' }, geometry: { coordinates: [-122.3321 + index * .001, 47.6062 + index * .001] } }] });
}, { headers: { 'Content-Type': 'application/json' } }).persist();
mock.get('https://api.openai.com').intercept({ path: '/v1/responses', method: 'POST' }).reply(200, async options => {
  const body = await new Response(options.body).json();
  assert.equal(body.store, false); assert.equal(body.model, 'gpt-6-astra');
  assert.equal(body.max_output_tokens, 4000); assert.equal(body.max_tool_calls, 3);
  const call = modelCalls++;
  let output = call === 0
    ? [{ type: 'function_call', call_id: 'synthetic-call', name: 'edit_trip', arguments: JSON.stringify({ name: 'Browser-only verification', start: null, end: null }) }]
    : [{ type: 'message', content: [{ type: 'output_text', text: 'Renamed your trip.' }] }];
  if (phase === 'recommendations') {
    const results = body.input.filter(item => item.type === 'function_call_output').map(item => JSON.parse(item.output));
    assert.ok(results.every(result => !result.error), 'transient place failure should recover before returning to the model');
    if (call < 3) output = [{ type: 'function_call', call_id: 'place-' + call, name: 'search_places', arguments: JSON.stringify({ query: cafes[call] }) }];
    else if (call === 3) {
      assert.deepEqual(results.map(result => result[0].id), ['N-1', 'N-2', 'N-3']);
      output = [{ type: 'function_call', call_id: 'cards', name: 'show_places', arguments: JSON.stringify({ places: cafes.map((name, i) => ({ place_id: 'N-' + (i + 1), reason: 'A researched café for this visit.', source_url: 'https://example.com/cafes/' + i })) }) }];
    } else output = [{ type: 'message', content: [{ type: 'output_text', text: 'Here are three researched cafés.' }] }];
    if (call === 0) output.unshift({ type: 'web_search_call', status: 'completed', action: { type: 'search', sources: [{ type: 'url', url: 'https://example.com/cafes' }] } });
  }
  return 'data: ' + JSON.stringify({ type: 'response.completed', response: { status: 'completed', output } }) + '\n\n';
}, { headers: { 'Content-Type': 'text/event-stream' } }).persist();
const worker = new Miniflare({ modules, compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
  bindings: { TRIPS_DEMO_MODE: 'true', TRIPS_ASSISTANT_ENABLED: 'true', OPENAI_API_KEY: 'synthetic-test-only' },
  d1Databases: { DB: 'trips-built-smoke' }, fetchMock: mock, cf: false, log: new Log(LogLevel.ERROR) });
const origin = 'https://demo.test';
const send = (path, cookie = '', options = {}) => worker.dispatchFetch(origin + path, { ...options,
  headers: { origin, 'cf-connecting-ip': '192.0.2.1', 'content-type': 'application/json', ...(cookie ? { cookie } : {}), ...options.headers } });
try {
  const db = await worker.getD1Database('DB');
  for (const file of (await readdir('drizzle')).filter(name => name.endsWith('.sql')).sort()) {
    for (const statement of (await readFile(resolve('drizzle', file), 'utf8')).split('--> statement-breakpoint').filter(part => part.trim())) await db.prepare(statement).run();
  }
  const page = await send('/'); assert.equal(page.status, 200);
  assert.match(await page.text(), /Saved in this browser/);
  const started = await send('/api/demo/session', '', { method: 'POST' }); assert.equal(started.status, 200);
  const cookie = started.headers.get('set-cookie').split(';')[0];
  const trip = { id: crypto.randomUUID(), name: 'Synthetic trip', destination: { id: 'seattle', name: 'Seattle', address: 'Washington, United States', lat: 47.6062, lng: -122.3321 }, start: '2026-11-04', end: '2026-11-06', stops: [], flights: [], version: 1 };
  const message = { id: crypto.randomUUID(), tripId: trip.id, message: 'Rename this trip', day: trip.start, trip, history: [] };
  assert.equal((await send('/api/chat', '', { method: 'POST', body: JSON.stringify(message) })).status, 401);
  assert.equal((await send('/api/chat', cookie, { method: 'POST', body: JSON.stringify({ ...message, tripId: crypto.randomUUID() }) })).status, 400);
  assert.equal(modelCalls, 0);
  const response = await send('/api/chat', cookie, { method: 'POST', body: JSON.stringify(message) }); assert.equal(response.status, 200);
  const events = (await response.text()).trim().split('\n').map(line => JSON.parse(line));
  const done = events.find(event => event.type === 'done');
  assert.ok(done, JSON.stringify({events,modelCalls})); assert.equal(done.trip.name, 'Browser-only verification');
  assert.equal(done.trip.version, 2); assert.equal(done.turn.changes.length, 1); assert.equal(modelCalls, 2);
  phase = 'recommendations'; modelCalls = 0;
  const recommendationResponse = await send('/api/chat', cookie, { method: 'POST', body: JSON.stringify({ ...message, id: crypto.randomUUID(), message: 'show me the best cafes in downtown seattle' }) });
  assert.equal(recommendationResponse.status, 200);
  const recommendationEvents = (await recommendationResponse.text()).trim().split('\n').map(line => JSON.parse(line));
  const recommended = recommendationEvents.find(event => event.type === 'done');
  assert.ok(recommended, JSON.stringify(recommendationEvents));
  assert.deepEqual(recommended.turn.places.map(place => place.name), cafes);
  assert.ok(recommended.turn.places.every(place => Number.isFinite(place.lat) && Number.isFinite(place.lng) && place.sourceUrl));
  assert.deepEqual(recommended.trip, trip); assert.deepEqual(recommended.turn.changes, []);
  assert.equal(modelCalls, 5); assert.equal(placeCalls, 4, 'one failed lookup is retried, then all three cafés resolve');
  for (const table of ['trips', 'chat_turns', 'service_cache']) assert.equal((await db.prepare(`SELECT COUNT(*) AS n FROM ${table}`).first()).n, 0, table + ' must contain no new demo content');
  assert.ok((await db.prepare('SELECT COUNT(*) AS n FROM demo_rate_limits').first()).n > 0);
  assert.equal((await send('/api/trips', cookie, { method: 'POST', body: JSON.stringify(trip) })).status, 404);

  // Real route migration remains cookie-scoped and deletes only the acknowledged workspace.
  const owner = (await (await send('/api/demo/migrate', cookie)).json()).migrationId;
  const otherCookie = (await send('/api/demo/session', '', { method: 'POST' })).headers.get('set-cookie').split(';')[0];
  const otherOwner = (await (await send('/api/demo/migrate', otherCookie)).json()).migrationId;
  const otherTrip = { ...trip, id: crypto.randomUUID() };
  for (const [item, id] of [[trip, owner], [otherTrip, otherOwner]]) await db.prepare('INSERT INTO trips (id,owner,data,version,updated_at) VALUES (?,?,?,1,?)').bind(item.id, id, JSON.stringify(item), Date.now()).run();
  await db.prepare("INSERT INTO chat_turns (id,owner,trip_id,user_text,assistant_text,status,created_at) VALUES (?,?,?,?,?,'complete',?)").bind(crypto.randomUUID(), owner, trip.id, 'Old conversation', 'Old answer', Date.now()).run();
  const legacy = await (await send('/api/demo/migrate', cookie)).json();
  assert.equal(legacy.trips.length, 1); assert.equal(legacy.trips[0].id, trip.id); assert.equal(legacy.turns[0].assistant, 'Old answer');
  assert.equal((await send('/api/demo/migrate', cookie, { method: 'DELETE' })).status, 200);
  assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM trips WHERE owner=?').bind(owner).first()).n, 0);
  assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM chat_turns WHERE owner=?').bind(owner).first()).n, 0);
  assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM trips WHERE owner=?').bind(otherOwner).first()).n, 1);
  console.log('PASS: production SSR, stateless AI edit, researched café cards and coordinates after transient provider failure, server quotas, zero content writes, blocked cloud CRUD, isolated legacy migration.');
} finally { await worker.dispose(); await mock.close(); }
