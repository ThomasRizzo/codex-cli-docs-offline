"""Create a reproducible, portable source download without hosted state."""

import json
import re
import zipfile
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
FOLDERS = ("app", "components", "db", "drizzle", "hooks", "lib", "public", "scripts", "tests", "worker")
FILES = (
    ".gitignore", ".env.example", "README.md", "package.json", "package-lock.json",
    "cloudflare-env.d.ts", "components.json", "drizzle.config.ts", "eslint.config.mjs",
    "next.config.ts", "postcss.config.mjs", "tsconfig.json", "vite.config.ts",
)
EXCLUDED = {"node_modules", "dist", "output", "outputs", "coverage", "work", "__pycache__"}
SECRET = re.compile(rb"\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}|-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----")
PRIVATE = re.compile(rb"CUSTOMER[_]HTTP[_]|(?:appgprj|appgver|appgdep)[_][A-Za-z0-9]+|openai[.]internal|api[.]openai[.]org|http://localhost[/]v1")
entries = {}


def add(path):
    relative = path.relative_to(ROOT)
    if path.is_symlink():
        raise RuntimeError(f"Source contains a symlink: {relative}")
    if any(part in EXCLUDED or (part.startswith(".") and str(relative) not in FILES) for part in relative.parts):
        return
    if path.suffix in {".zip", ".log", ".pem", ".key", ".tsbuildinfo", ".pyc", ".sqlite", ".db"} or not path.is_file():
        return
    data = path.read_bytes()
    # Public downloads work with ordinary API projects. Keep the live demo's
    # regional endpoint configuration out of the exported runtime and its tests.
    if path.suffix in {".ts", ".tsx", ".mjs", ".md"}:
        data = data.replace(b"https://us.api.openai.com", b"https://api.openai.com")
        data = data.replace(b"public US endpoint", b"public endpoint")
    entries[relative.as_posix()] = data


for folder in FOLDERS:
    for path in sorted((ROOT / folder).rglob("*")):
        add(path)
for name in FILES:
    if (ROOT / name).exists():
        add(ROOT / name)

entries[".openai/hosting.json"] = (json.dumps({"d1": "DB", "r2": None}, indent=2) + "\n").encode()
lock = json.loads(entries["package-lock.json"])
for package in lock["packages"].values():
    if "resolved" not in package:
        continue
    resolved = urlsplit(package["resolved"])
    tarball = re.search(r"/(?:@[^/]+/)?[^/]+/-/[^/]+\.tgz$", resolved.path)
    if resolved.scheme != "https" or resolved.query or resolved.fragment or not tarball or not package.get("integrity"):
        raise RuntimeError("Expected an HTTPS npm registry tarball in package-lock.json")
    package["resolved"] = "https://registry.npmjs.org" + tarball.group(0)
entries["package-lock.json"] = (json.dumps(lock, indent=2) + "\n").encode()
for name, data in entries.items():
    if SECRET.search(data) or PRIVATE.search(data):
        raise RuntimeError(f"Secret or private hosting reference in {name}")

target = ROOT / "public/trips-project.zip"
if target.is_symlink():
    raise RuntimeError("Download target must not be a symlink")
target.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        info = zipfile.ZipInfo("trips-planner/" + name, date_time=(2000, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (0o100755 if name.endswith(".sh") else 0o100644) << 16
        archive.writestr(info, data)
print(f"Packaged {len(entries)} source files into {target.name} ({target.stat().st_size} bytes).")
