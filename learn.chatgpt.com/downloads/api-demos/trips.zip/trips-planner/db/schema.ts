import { integer, sqliteTable, text, index } from 'drizzle-orm/sqlite-core';
export const demoSessions = sqliteTable('demo_sessions', {
  id: text('id').primaryKey(), expiresAt: integer('expires_at').notNull(),
}, t => [index('demo_sessions_expiry').on(t.expiresAt)]);
export const demoRateLimits = sqliteTable('demo_rate_limits', {
  key: text('key').primaryKey(),
  minuteWindow: integer('minute_window').notNull(), minuteCount: integer('minute_count').notNull(),
  dayWindow: integer('day_window').notNull(), dayCount: integer('day_count').notNull(),
  expiresAt: integer('expires_at').notNull(),
}, t => [index('demo_rate_limits_expiry').on(t.expiresAt)]);
export const trips = sqliteTable('trips', {
  id: text('id').primaryKey(), owner: text('owner').notNull(),
  data: text('data').notNull(), version: integer('version').notNull().default(1),
  updatedAt: integer('updated_at').notNull(), deletedAt: integer('deleted_at'),
}, (t) => [index('trips_owner').on(t.owner)]);
export const cache = sqliteTable('service_cache', {
  key: text('key').primaryKey(), data: text('data').notNull(), expires: integer('expires').notNull(),
});

export const calendarSubscriptions = sqliteTable('calendar_subscriptions', {
  owner: text('owner').primaryKey(),
  token: text('token').notNull(),
  tokenHash: text('token_hash').notNull().unique(),
  createdAt: integer('created_at').notNull(),
});

export const chatTurns = sqliteTable('chat_turns', {
  id: text('id').primaryKey(), owner: text('owner').notNull(), tripId: text('trip_id').notNull(),
  userText: text('user_text').notNull(), assistantText: text('assistant_text').notNull().default(''),
  places: text('places').notNull().default('[]'), sources: text('sources').notNull().default('[]'), changes: text('changes').notNull().default('[]'),
  status: text('status').notNull().default('running'), beforeData: text('before_data'),
  afterVersion: integer('after_version'), createdAt: integer('created_at').notNull(), archivedAt: integer('archived_at'),
}, t => [index('chat_turns_owner_trip').on(t.owner,t.tripId,t.createdAt)]);

export const tripShares = sqliteTable('trip_shares', {
  tripId: text('trip_id').primaryKey(), owner: text('owner').notNull(),
  token: text('token').notNull(), tokenHash: text('token_hash').notNull().unique(),
  createdAt: integer('created_at').notNull(),
});
