import { cached, upstream } from './server';
import type { Place, Route } from './trips';
function decode(str:string){const pts:[number,number][]=[];let i=0,lat=0,lng=0;while(i<str.length){let b,shift=0,result=0;do{b=str.charCodeAt(i++)-63;result|=(b&31)<<shift;shift+=5;}while(b>=32&&i<str.length);lat+=(result&1)?~(result>>1):(result>>1);shift=0;result=0;do{b=str.charCodeAt(i++)-63;result|=(b&31)<<shift;shift+=5;}while(b>=32&&i<str.length);lng+=(result&1)?~(result>>1):(result>>1);pts.push([lat/1e6,lng/1e6]);}return pts;}
export async function loadRoute(a:Pick<Place,'lat'|'lng'>,b:Pick<Place,'lat'|'lng'>,mode:'walk'|'uber'):Promise<Route>{
 const key=`route:${a.lat.toFixed(5)},${a.lng.toFixed(5)}:${b.lat.toFixed(5)},${b.lng.toFixed(5)}:${mode}`;
 return cached<Route>(key,86400*7,async()=>{const payload={locations:[{lat:a.lat,lon:a.lng},{lat:b.lat,lon:b.lng}],costing:mode==='walk'?'pedestrian':'auto',units:'kilometers',directions_options:{units:'kilometers'}};const d=await upstream('https://valhalla1.openstreetmap.de/route?json='+encodeURIComponent(JSON.stringify(payload)),{'X-Client-Id':'trips.haydenbleasel.chatgpt.site'});if(d.trip?.status!==0||!d.trip?.legs?.[0]?.shape)throw new Error('No route');return {minutes:Math.max(1,Math.ceil(d.trip.summary.time/60)),km:d.trip.summary.length,shape:d.trip.legs.flatMap((l:any)=>decode(l.shape)),source:'route',mode};});
}
