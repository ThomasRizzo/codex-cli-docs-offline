import { arrivalConnections } from './arrivals';
import { flightStatus } from './flightaware';
import { stopDuration } from './event-duration';
import { Temporal } from '@js-temporal/polyfill';
import tzlookup from '@photostructure/tz-lookup';
import { departureSchedule, wallDate } from './departures';
import { withHotelCheckIns, hasLocation, routeKey, type Flight, type Place, type Route, type Trip } from './trips';

export function placeTimeZone(place: Pick<Place, 'lat' | 'lng'>) { return tzlookup(place.lat, place.lng); }
export function departureTimeZone(flight: Flight) {
  return flight.departureTimeZone || (flight.departurePlan ? placeTimeZone(flight.departurePlan.airport) : null);
}
export function instant(date: string, time: string, zone: string): number | null {
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return null;
  try { return Temporal.PlainDateTime.from(`${date}T${time}:00`).toZonedDateTime(zone, { disambiguation: 'compatible' }).epochMilliseconds; }
  catch { return null; }
}
export function escapeText(value: string) {
  return value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').replace(/\\/g, '\\\\').replace(/\r\n|\r|\n/g, '\\n').replace(/;/g, '\\;').replace(/,/g, '\\,');
}
export function foldLine(value: string) {
  let line = '', size = 0; const lines: string[] = [];
  for (const char of value) { const n = new TextEncoder().encode(char).length; if (size + n > 75) { lines.push(line); line = ' '; size = 1; } line += char; size += n; }
  lines.push(line); return lines.join('\r\n');
}
function stamp(ms: number) { return new Date(ms).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, ''); }
function dateOnly(date: string) { return date.replace(/-/g, ''); }
type Event = { id: string; title: string; description: string; location?: string; start?: number | null; end?: number | null; date?: string; dateEnd?: string; busy?: boolean; geo?: Place };
export type CalendarTrip = { trip: Trip; updatedAt: number };
export function calendar(rows: CalendarTrip[], routes: Record<string, Route>, origin: string) {
  const out = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Trips//Calendar//EN', 'CALSCALE:GREGORIAN', 'X-WR-CALNAME:Trips', 'REFRESH-INTERVAL;VALUE=DURATION:PT15M', 'X-PUBLISHED-TTL:PT15M'];
  for (const { trip: stored, updatedAt } of rows) {
    const trip=withHotelCheckIns(stored);
    const url = `${origin}/?trip=${encodeURIComponent(trip.id)}`;
    function event(e: Event) {
      out.push('BEGIN:VEVENT', `UID:${encodeURIComponent(trip.id)}-${encodeURIComponent(e.id)}@simple-trips`, `DTSTAMP:${stamp(updatedAt)}`, `LAST-MODIFIED:${stamp(updatedAt)}`, `SEQUENCE:${trip.version}`, `SUMMARY:${escapeText(e.title)}`, `DESCRIPTION:${escapeText(`${trip.name}\n${e.description}`)}`, `URL:${url}`, `TRANSP:${e.busy ? 'OPAQUE' : 'TRANSPARENT'}`);
      if (e.start != null) { out.push(`DTSTART:${stamp(e.start)}`); if (e.end != null && e.end > e.start) out.push(`DTEND:${stamp(e.end)}`); }
      else if (e.date) { out.push(`DTSTART;VALUE=DATE:${dateOnly(e.date)}`, `DTEND;VALUE=DATE:${dateOnly(e.dateEnd || Temporal.PlainDate.from(e.date).add({ days: 1 }).toString())}`); }
      if (e.location) out.push(`LOCATION:${escapeText(e.location)}`);
      if (e.geo) out.push(`GEO:${e.geo.lat};${e.geo.lng}`);
      out.push('END:VEVENT');
    }
    for (const stop of trip.stops) {
      const zone = stop.timeZone || trip.timeZone || placeTimeZone(hasLocation(stop)?stop:trip.destination);
      const end=stop.time?Temporal.PlainDateTime.from(`${stop.date}T${stop.time}`).add({minutes:stopDuration(stop)}):null;
      event({ id: `stop-${stop.id}`, title: stop.name, date: stop.date, start: stop.time ? instant(stop.date, stop.time, zone) : null, end:end?instant(end.toPlainDate().toString(),end.toPlainTime().toString().slice(0,5),zone):null,busy:!!stop.time, description: `${stop.time ? `${stopDuration(stop)} minute visit in ${zone}.` : 'Time not set.'}${stop.kind!=='event'&&stop.booked?'\nBooked.':''}${stop.note ? `\n${stop.note}` : ''}`, location: stop.locationName?[stop.locationName,stop.address].filter(Boolean).join(', '):stop.address || (hasLocation(stop)?stop.name:undefined), geo: hasLocation(stop)?stop:undefined });
    }
    for (const hotel of trip.hotels || []) {
      event({id:`hotel-${hotel.id}`,title:`Hotel · ${hotel.name}`,date:hotel.checkIn,dateEnd:hotel.checkOut,location:hotel.address,geo:hotel,description:`Check-in: ${hotel.checkIn}\nCheck-out: ${hotel.checkOut}${hotel.note?'\n'+hotel.note:''}`});
    }
    for(const arrival of arrivalConnections(trip)){
      const zone=arrival.flight.arrivalTimeZone||placeTimeZone(arrival.from);
      const convert=(minute:number)=>instant(wallDate(minute),new Date(minute*60000).toISOString().slice(11,16),zone);
      if(arrival.ready>arrival.at)event({id:`arrival-${arrival.flight.id}`,title:`Arrival · ${arrival.flight.number} · ${arrival.flight.to}`,start:convert(arrival.at),end:convert(arrival.ready),busy:true,location:arrival.flight.arrivalAirport?.name,geo:arrival.from,description:`${arrival.from.durationMinutes} minutes to get off the plane and leave the airport.`});
      const route=routes[routeKey(arrival.from,arrival.to,arrival.to.mode)];
      if(route)event({id:`arrival-transfer-${arrival.flight.id}`,title:`${arrival.to.mode==='walk'?'Walk':'Uber'} to ${arrival.to.name}`,start:convert(arrival.ready),end:convert(arrival.ready+route.minutes),busy:true,location:`${arrival.flight.to} → ${arrival.to.locationName||arrival.to.name}`,description:`${route.minutes} minute route estimate after airport exit time. Excludes traffic and pickup waits.`});
    }
    for (const flight of trip.flights) {
      const zone = departureTimeZone(flight);
      const tracking=flight.flightaware;
      const start = tracking ? Date.parse(tracking.actualOut||tracking.estimatedOut||tracking.scheduledOut) : zone ? instant(flight.date, flight.departure, zone) : null;
      const end = tracking ? Date.parse(tracking.actualIn||tracking.estimatedIn||tracking.scheduledIn) : flight.arrivalTimeZone ? instant(flight.arrivalDate, flight.arrival, flight.arrivalTimeZone) : null;
      const description = [`${flight.number}: ${flight.from} → ${flight.to}`, `Departure: ${flight.date} ${flight.departure || 'time not set'}${zone ? ` (${zone})` : ' local time — set the departure time zone in Trips.'}`, `Arrival: ${flight.arrivalDate} ${flight.arrival || 'time not set'}${flight.arrivalTimeZone ? ` (${flight.arrivalTimeZone})` : ' local time.'}`, tracking?`${flightStatus(flight)}\nFlightAware checked ${tracking.checkedAt}. Updates while Trips is open.`:'Check your airline for flight changes.'].filter(Boolean).join('\n');
      event({ id: `flight-${flight.id}`, title: `${flight.number} · ${flight.from} → ${flight.to}${!zone ? ' · set time zone' : ''}`, date: flight.date, start, end, busy: true, location: flight.departurePlan?.airport.address || flight.from, description });
      const schedule = departureSchedule(flight, trip.stops, routes);
      if (!zone || !flight.departurePlan || schedule.depart === null || schedule.arrive === null) continue;
      // Preserve the exact wall-clock boundaries shown in the planner, including
      // previous-day blocks. Convert each boundary independently across DST.
      const convert = (minutes: number) => instant(wallDate(minutes), new Date(minutes * 60000).toISOString().slice(11, 16), zone);
      const depart = convert(schedule.depart), arrive = convert(schedule.arrive);
      event({ id: `airport-${flight.id}`, title: `Airport · ${flight.number}`, start: arrive, end: depart, busy: true, location: flight.departurePlan.airport.address, geo: flight.departurePlan.airport, description: `${schedule.bufferMinutes} minutes at the airport before the original scheduled departure. This buffer does not move later for a delay.\n${zone}` });
      if (schedule.leave !== null && schedule.origin) event({ id: `transfer-${flight.id}`, title: `Uber to ${flight.departurePlan.airport.name}`, start: convert(schedule.leave), end: arrive, busy: true, location: `${schedule.origin.name} → ${flight.departurePlan.airport.name}`, description: `${schedule.driveMinutes} minute drive + ${schedule.extraMinutes} minutes for pickup / traffic. Estimate, not a booking or live traffic forecast.\n${zone}` });
    }
  }
  out.push('END:VCALENDAR'); return out.map(foldLine).join('\r\n') + '\r\n';
}
