import { localFlightTime } from './flightaware';
import type { Flight, Place, Route, Stop, Trip } from './trips';
import { days, routeKey, hasLocation } from './trips';
import { stopDuration } from './event-duration';

// Floating local minutes: subtract buffers in the departure airport's wall clock,
// never in the viewer's computer timezone. No flight duration is inferred.
export function wallMinutes(date: string, time: string): number | null {
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return null;
  const timestamp = Date.parse(`${date}T${time}:00Z`);
  return Number.isFinite(timestamp) ? timestamp / 60000 : null;
}
export function wallDate(minutes: number) { return new Date(minutes * 60000).toISOString().slice(0, 10); }
export function wallTime(minutes: number) {
  return new Date(minutes * 60000).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', timeZone: 'UTC' }).toLowerCase();
}
export function departureOrigin(flight: Flight, stops: Stop[]): Place | null {
  const plan = flight.departurePlan;
  if (!plan) return null;
  return plan.originStopId ? stops.filter(hasLocation).find(s => s.id === plan.originStopId) || null : plan.originPlace;
}
export type DepartureSchedule = {
  flight: Flight; depart: number | null; arrive: number | null; leave: number | null;
  driveMinutes: number | null; extraMinutes: number; bufferMinutes: number;
  origin: Place | null; issue: string | null;
};
export function departureSchedule(flight: Flight, stops: Stop[], routes: Record<string, Route>, errors: Record<string, string> = {}): DepartureSchedule {
  const plan = flight.departurePlan;
  const depart = wallMinutes(flight.date, flight.scheduledDeparture || flight.departure);
  const bufferMinutes = plan?.arrivalMinutes ?? 120;
  const extraMinutes = plan?.extraMinutes ?? 10;
  const arrive = depart === null ? null : depart - bufferMinutes;
  const origin = departureOrigin(flight, stops);
  const key = origin && plan ? routeKey(origin, plan.airport, 'uber') : null;
  const driveMinutes = origin && plan ? plan.driveOverrideMinutes ?? (key && routes[key] ? routes[key].minutes : null) : null;
  const leave = arrive !== null && driveMinutes !== null ? arrive - driveMinutes - extraMinutes : null;
  let issue: string | null = null;
  if (depart === null) issue = 'Set the scheduled departure time to reserve airport time.';
  else if (!plan) issue = 'Choose the airport and where you’ll leave from to include your Uber.';
  else if (!origin) issue = 'Your starting place was removed. Choose another place.';
  else if (driveMinutes === null) issue = key && errors[key] ? 'Driving route unavailable. Set a travel estimate in airport timing.' : 'Calculating your drive to the airport…';
  return { flight, depart, arrive, leave, driveMinutes, extraMinutes, bufferMinutes, origin, issue };
}
export function planningDays(trip: Trip, schedules: DepartureSchedule[]) {
  const dates = new Set(days(trip.start, trip.end));
  schedules.forEach(s => {
    dates.add(s.flight.date);dates.add(s.flight.arrivalDate);
    const arrival=s.flight.flightaware?.actualIn||s.flight.flightaware?.estimatedIn||s.flight.flightaware?.scheduledIn;
    if(arrival&&s.flight.arrivalTimeZone){try{dates.add(localFlightTime(arrival,s.flight.arrivalTimeZone).date);}catch{}}
    if (s.depart !== null && s.arrive !== null) days(wallDate(s.leave ?? s.arrive), wallDate(s.depart)).forEach(d => dates.add(d));
  });
  return [...dates].sort();
}
export function onDay(s: DepartureSchedule, day: string) {
  if (s.depart === null || s.arrive === null) return s.flight.date === day;
  const start = wallMinutes(day, '00:00')!;
  return (s.leave ?? s.arrive) < start + 1440 && s.depart >= start;
}
export function clashesWithDeparture(stop: Stop, schedules: DepartureSchedule[]) {
  const at = wallMinutes(stop.date, stop.time);
  return at !== null && schedules.some(s => s.depart !== null && s.arrive !== null && at+stopDuration(stop) > (s.leave ?? s.arrive) && at < s.depart);
}
