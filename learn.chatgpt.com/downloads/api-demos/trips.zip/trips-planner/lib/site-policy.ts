export const robotsPolicy = 'noindex, nofollow, noarchive, nosnippet, noimageindex';
export const privateHeaders = {
  'Cache-Control': 'private, no-store',
  'X-Robots-Tag': robotsPolicy,
  'Referrer-Policy': 'no-referrer',
  'X-Content-Type-Options': 'nosniff',
};
export function discoveryResponse(path: string) {
  if (path === '/robots.txt') return new Response('User-agent: *\nDisallow: /\n', {headers: {...privateHeaders, 'Content-Type': 'text/plain; charset=utf-8'}});
  if (/^\/(?:sitemap[^/]*|sitemap\/.*)\.(?:xml|txt)(?:\.gz)?$/.test(path)) return new Response('Not found', {status:404,headers:privateHeaders});
  return null;
}
