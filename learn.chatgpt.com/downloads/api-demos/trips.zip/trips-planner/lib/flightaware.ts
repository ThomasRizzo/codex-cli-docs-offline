import { z } from 'zod';
import type { Flight, Place } from './trips';

const iso = z.string().datetime();
export const flightAwareSchema = z.object({
  ident:z.string().max(20), flightId:z.string().max(160).optional(),
  origin:z.string().max(8), destination:z.string().max(8),
  scheduledOut:iso, scheduledIn:iso,
  estimatedOut:iso.optional(), estimatedIn:iso.optional(), actualOut:iso.optional(), actualIn:iso.optional(),
  status:z.string().max(160), gate:z.string().max(40).optional(), terminal:z.string().max(40).optional(),
  checkedAt:iso, nextCheckAt:iso, complete:z.boolean(),
});
export type FlightAware = z.infer<typeof flightAwareSchema>;
export type FlightMatch = Pick<Flight,'number'|'date'|'from'|'to'|'departure'|'arrival'|'arrivalDate'|'departureTimeZone'|'arrivalTimeZone'|'arrivalAirport'> & {flightaware:FlightAware};
export type FlightLookup = {flights:FlightMatch[]; checkedAt:string; nextCheckAt:string; partial:boolean};
export class FlightError extends Error { constructor(message:string,public status=502){super(message);} }
const DAY=86400000;
export function flightInput(number:string,date:string,now=Date.now()) {
  const clean=number.replace(/\s/g,'').toUpperCase();
  const match=/^([A-Z]{3}|[A-Z\d]{2})(\d{1,4})$/.exec(clean);
  if(!match||!/[A-Z]/.test(match[1]))throw new FlightError('Use an airline flight number, such as DL1134, rather than a booking reference.',400);
  const stamp=Date.parse(date+'T00:00:00Z');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(stamp)||new Date(stamp).toISOString().slice(0,10)!==date)throw new FlightError('Choose a valid departure date.',400);
  if(stamp<now-8*DAY||stamp>now+364*DAY)throw new FlightError('Choose a departure within the past week or the next year.',400);
  return {number:match[1]+Number(match[2]),airline:match[1],flightNumber:Number(match[2]),date,stamp};
}
export function localFlightTime(value:string,zone:string) {
  const date=new Date(value);if(!Number.isFinite(+date))throw new FlightError('FlightAware returned an incomplete flight time.');
  try {const p=new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date);const get=(k:string)=>p.find(p=>p.type===k)?.value;return {date:`${get('year')}-${get('month')}-${get('day')}`,time:`${get('hour')}:${get('minute')}`};}
  catch {throw new FlightError('FlightAware did not return a valid airport time zone.');}
}
export function flightStatus(flight:Flight) {
  const f=flight.flightaware;if(!f)return '';
  const time=f.actualOut||f.estimatedOut;
  const local=time&&flight.departureTimeZone?localFlightTime(time,flight.departureTimeZone):null;
  return [f.status,local&&time!==f.scheduledOut?`${f.actualOut?'Departed':'Departure'} ${local.time}${local.date!==flight.date?' · '+local.date:''}`:'',f.gate?'Gate '+f.gate:f.terminal?'Terminal '+f.terminal:''].filter(Boolean).join(' · ');
}
export function matchingFlight(current:Flight,results:FlightMatch[]) {
  const tracking=current.flightaware;if(!tracking)return undefined;
  // Route matching avoids silently switching to another leg or a diversion.
  const matches=results.filter(f=>f.flightaware.origin===tracking.origin&&f.flightaware.destination===tracking.destination&&f.date===current.date);
  const exact=tracking.flightId?matches.find(f=>f.flightaware.flightId===tracking.flightId):undefined;
  return tracking.flightId?exact:(matches.length===1?matches[0]:undefined);
}
export type Airport={name?:string|null;city?:string|null;state?:string|null;country_code?:string|null;latitude?:number|null;longitude?:number|null;code?:string|null;code_icao?:string|null;code_iata?:string|null;timezone?:string|null};
type RawFlight={ident:string;ident_icao?:string|null;ident_iata?:string|null;actual_ident_icao?:string|null;actual_ident?:string|null;fa_flight_id?:string|null;origin:Airport|string|null;destination:Airport|string|null;origin_icao?:string|null;origin_iata?:string|null;destination_icao?:string|null;destination_iata?:string|null;scheduled_out:string;scheduled_in:string;estimated_out?:string|null;estimated_in?:string|null;actual_out?:string|null;actual_in?:string|null;status?:string;gate_origin?:string|null;terminal_origin?:string|null;codeshares?:string[];codeshares_iata?:string[]};
export type ProviderResult<T>={data:T;checkedAt:number;expires:number};
export type FlightQuery=<T>(path:string,ttl:number,cost:number)=>Promise<ProviderResult<T>>;
type RawResult={scheduled?:RawFlight[];flights?:RawFlight[];links?:{next?:string}|null};
function normalized(value:string){const m=/^([A-Z]{3}|[A-Z\d]{2})(\d{1,4})$/.exec(value);return m?m[1]+Number(m[2]):value;}
function identityMatches(raw:RawFlight,number:string){return [raw.ident,raw.ident_iata,raw.ident_icao,...raw.codeshares||[],...raw.codeshares_iata||[]].some(id=>id&&normalized(id)===number);}

export async function lookupFlight(number:string,date:string,query:FlightQuery,now=Date.now()):Promise<FlightLookup> {
  const input=flightInput(number,date,now);
  // A local calendar day can span UTC-14h to UTC+36h. Match only after resolving the origin zone.
  const start=input.stamp-14*3600000,end=input.stamp+36*3600000;
  const live=end<=now+2*DAY;
  const ttl=live?15*60:24*60*60;
  const params=new URLSearchParams({max_pages:'1'});
  let path:string;
  if(live){params.set('ident_type','designator');params.set('start',new Date(start).toISOString());params.set('end',new Date(end).toISOString());path=`/flights/${encodeURIComponent(input.number)}?${params}`;}
  else {params.set('airline',input.airline);params.set('flight_number',String(input.flightNumber));params.set('include_codeshares','true');path=`/schedules/${new Date(start).toISOString()}/${new Date(end).toISOString()}?${params}`;}
  let result=await query<RawResult>(path,ttl,live?5:20);
  // Near-term status may not have been loaded yet; the published schedule can still fill the form.
  let schedule=!live;
  if(live&&!result.data.flights?.length&&input.stamp>now-DAY){
    const p=new URLSearchParams({airline:input.airline,flight_number:String(input.flightNumber),max_pages:'1'});
    result=await query<RawResult>(`/schedules/${new Date(start).toISOString()}/${new Date(end).toISOString()}?${p}`,3600,20);schedule=true;
  }
  const raw=(schedule?result.data.scheduled:result.data.flights);
  if(!Array.isArray(raw))throw new FlightError('FlightAware returned an unexpected response. Try again later.');
  const airports=new Map<string,Promise<Airport>>();
  function airport(f:RawFlight,side:'origin'|'destination',coordinates=false):Promise<Airport>{
    const a=f[side];if(a&&typeof a==='object'&&a.timezone&&(!coordinates||airportPlace(a)))return Promise.resolve(a);
    const code=typeof a==='object'?a?.code_icao||a?.code:f[`${side}_icao`]||a;
    if(!code||!/^\w{2,8}$/.test(code))throw new FlightError('FlightAware did not identify both airports.');
    if(!airports.has(code)){
      if(airports.size>=4)throw new FlightError('This flight has several routes. Try a more specific operating flight number.',422);
      airports.set(code,query<Airport>(`/airports/${encodeURIComponent(code)}`,30*86400,15).then(r=>r.data));
    }
    return airports.get(code)!.catch(error=>{if(a&&typeof a==='object'&&a.timezone)return a;throw error;});
  }
  const flights:FlightMatch[]=[],seen=new Set<string>();let partial=!!result.data.links?.next;
  for(const f of raw.slice(0,15)){
    if(!identityMatches(f,input.number)||!f.scheduled_out||!f.scheduled_in)continue;
    const origin=await airport(f,'origin');
    if(!origin.timezone)throw new FlightError('FlightAware did not return the departure airport time zone.');
    const departure=localFlightTime(f.scheduled_out,origin.timezone);if(departure.date!==date)continue;
    const destination=await airport(f,'destination',true);
    if(!destination.timezone)throw new FlightError('FlightAware did not return the arrival airport time zone.');
    const arrival=localFlightTime(f.scheduled_in,destination.timezone);
    const from=origin.code_iata||origin.code_icao||origin.code||f.origin_iata||f.origin_icao;
    const to=destination.code_iata||destination.code_icao||destination.code||f.destination_iata||f.destination_icao;
    if(!from||!to){partial=true;continue;}
    const key=`${from}:${to}:${f.scheduled_out}`;if(seen.has(key))continue;seen.add(key);
    const complete=!!f.actual_in;
    const tracking=flightAwareSchema.parse({ident:f.actual_ident_icao||f.ident_icao||f.actual_ident||f.ident,flightId:f.fa_flight_id||undefined,origin:origin.code_icao||from,destination:destination.code_icao||to,scheduledOut:f.scheduled_out,scheduledIn:f.scheduled_in,estimatedOut:f.estimated_out||undefined,estimatedIn:f.estimated_in||undefined,actualOut:f.actual_out||undefined,actualIn:f.actual_in||undefined,status:schedule?'Scheduled':f.status||'Status unavailable',gate:f.gate_origin||undefined,terminal:f.terminal_origin||undefined,checkedAt:new Date(result.checkedAt).toISOString(),nextCheckAt:new Date(result.expires).toISOString(),complete});
    flights.push({number:input.number,date,from,to,departure:departure.time,arrival:arrival.time,arrivalDate:arrival.date,departureTimeZone:origin.timezone,arrivalTimeZone:destination.timezone,arrivalAirport:airportPlace(destination,to),flightaware:tracking});
  }
  return {flights,partial,checkedAt:new Date(result.checkedAt).toISOString(),nextCheckAt:new Date(result.expires).toISOString()};
}

export function airportPlace(airport:Airport,fallbackCode?:string):Place|undefined{
 const code=airport.code_icao||airport.code_iata||airport.code||fallbackCode;
 const location=z.object({latitude:z.number().min(-85).max(85),longitude:z.number().min(-180).max(180)}).safeParse(airport);
 if(!code||!location.success)return undefined;
 return {id:`airport:${code}`,name:airport.name||`${code} airport`,address:[airport.city,airport.state,airport.country_code].filter(Boolean).join(', '),lat:location.data.latitude,lng:location.data.longitude};
}
