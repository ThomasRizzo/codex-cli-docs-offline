// Public map providers can briefly reject a request. Retry safe reads within the
// original 15-second budget; never log the query, coordinates, or response body.
export async function upstream(url:string,headers:Record<string,string>={},signal?:AbortSignal):Promise<any>{
 const host=new URL(url).hostname;
 const service=host==='photon.komoot.io'?'places':host==='valhalla1.openstreetmap.de'?'routes':'upstream';
 const deadline=AbortSignal.any([AbortSignal.timeout(15000),...(signal?[signal]:[])]);
 let status:number|null=null,kind='network';
 for(let attempt=0;attempt<3;attempt++){
  let delay=250*2**attempt,retry=true;
  try{
   deadline.throwIfAborted();
   const response=await fetch(url,{headers:{'User-Agent':'Trips/1.0 (+https://trip-planner.openai.chatgpt.site)',...headers},signal:AbortSignal.any([deadline,AbortSignal.timeout(5000)])});
   status=response.status;
   if(response.ok){kind='invalid_response';return await response.json();}
   kind='http';retry=[408,429,500,502,503,504].includes(status);
   const retryAfter=response.headers.get('retry-after');
   if(retryAfter){const seconds=Number(retryAfter);const ms=Number.isFinite(seconds)?seconds*1000:Date.parse(retryAfter)-Date.now();if(Number.isFinite(ms)){if(ms>2000)retry=false;else delay=Math.max(delay,ms);}}
   await response.body?.cancel();
  }catch(error){
   if(signal?.aborted)throw signal.reason;
   if(deadline.aborted)break;
   if(error instanceof SyntaxError){kind='invalid_response';retry=false;}
  }
  if(!retry||attempt===2)break;
  await new Promise(resolve=>setTimeout(resolve,delay));
 }
 console.warn('Trips provider unavailable',JSON.stringify({service,status,kind}));
 throw new Error(service==='places'?'Place lookup is temporarily unavailable. Web search may still work.':service==='routes'?'Travel-time lookup is temporarily unavailable.':'The external service is temporarily unavailable.');
}
