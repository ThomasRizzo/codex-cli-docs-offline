import { headers } from 'next/headers';
import { cleanupDemoSessions, findDemoSession, requireDemoOrigin } from './demo-session';
import { env } from 'cloudflare:workers';
import { isTripOwner } from './access';
import { privateHeaders } from './site-policy';
import { getChatGPTUser } from '@/app/chatgpt-auth';
export function db(){if(!env.DB)throw new Error('Storage is unavailable.');return env.DB;}
export function requirePersistentWorkspace(){if(env.TRIPS_DEMO_MODE==='true')throw json({error:'This feature is unavailable in the demo.'},404);}
export async function user(request?:Request){
 if(env.TRIPS_DEMO_MODE==='true'){
  if(request&&!['GET','HEAD'].includes(request.method))requireDemoOrigin(request);
  const session=await findDemoSession(db(),request?.headers||await headers());
  if(!session)throw json({error:'Your demo connection expired. Reconnect to continue; your browser data is unchanged.'},401);
  await cleanupDemoSessions(db());
  return session.id;
 }
 const u=await getChatGPTUser();if(!u)throw new Response(JSON.stringify({error:'Please sign in again.'}),{status:401,headers:{'Content-Type':'application/json'}});if(!isTripOwner(u.userId,env.TRIPS_OWNER_ID))throw new Response(JSON.stringify({error:'Only the trip owner can do this.'}),{status:403,headers:{...privateHeaders,'Content-Type':'application/json'}});if(request && !['GET','HEAD'].includes(request.method)){const origin=request.headers.get('origin');if(origin && origin!==new URL(request.url).origin)throw new Response('Forbidden',{status:403});}return u.userId;}
export function json(data:unknown,status=200){return Response.json(data,{status,headers:privateHeaders});}
export function failure(e:unknown){if(e instanceof Response)return e;console.error(env.TRIPS_DEMO_MODE==='true'?'Demo request failed':e instanceof Error?e.message:'Request failed');return json({error:'Something went wrong. Please try again.'},500);}
export async function cached<T>(key:string,seconds:number,load:()=>Promise<T>):Promise<T>{if(env.TRIPS_DEMO_MODE==='true')return load();const hit=await db().prepare('SELECT data FROM service_cache WHERE key = ? AND expires > ?').bind(key,Date.now()).first<{data:string}>();if(hit)return JSON.parse(hit.data);const data=await load();await db().prepare('INSERT INTO service_cache (key,data,expires) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET data=excluded.data, expires=excluded.expires').bind(key,JSON.stringify(data),Date.now()+seconds*1000).run();return data;}
export { upstream } from './upstream';
