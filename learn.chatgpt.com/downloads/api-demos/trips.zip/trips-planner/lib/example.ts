import type { Trip, LocatedStop } from './trips';
export const example:Trip & {stops:LocatedStop[]}={id:'e57fc0d8-21d1-42f8-a48b-23ebc3b94238',name:'A few days in Seattle',destination:{id:'seattle',name:'Seattle',address:'Washington, United States',lat:47.6062,lng:-122.3321},start:'2026-11-06',end:'2026-11-08',version:0,flights:[],stops:[
{id:'market',name:'Pike Place Market',address:'85 Pike Street, Seattle',lat:47.6097,lng:-122.3422,date:'2026-11-06',time:'09:00',note:'Coffee, then a slow wander through the market.',mode:'walk'},
{id:'sculpture',name:'Olympic Sculpture Park',address:'2901 Western Avenue, Seattle',lat:47.6166,lng:-122.3553,date:'2026-11-06',time:'11:00',note:'A walk along the water.',mode:'walk'},
{id:'garden',name:'Chihuly Garden and Glass',address:'305 Harrison Street, Seattle',lat:47.6206,lng:-122.3505,date:'2026-11-06',time:'14:00',note:'Leave the afternoon open.',mode:'walk'}]};
