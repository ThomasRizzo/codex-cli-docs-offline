import { demoSample } from './demo-sample';
import { tripSchema, type Trip } from './trips';
import type { ChatTurn } from './chat-types';
import { fitChatRequest, type LocalChatRequest } from './local-chat-contract';

export type LocalTurn = ChatTurn & { tripId: string; before: Trip | null };
export type LegacyWorkspace = { migrationId: string; trips: Trip[]; turns: LocalTurn[] };
const DATABASE = 'trips-workspace';
const STORES = ['trips', 'turns', 'meta'];
const RUN_TIMEOUT = 240000;
let connection: Promise<IDBDatabase> | undefined;
let clientId: string | undefined;
function browserClientId() { return clientId ??= crypto.randomUUID(); }

function storageError(error: unknown): Error {
  if (error instanceof Error && error.name === 'QuotaExceededError') return new Error('This browser is out of storage. Free some space and try again; this change was not saved.');
  return error instanceof Error ? error : new Error('Browser storage is unavailable. Enable site storage and reload Trips.');
}
function openDatabase(): Promise<IDBDatabase> {
  if (!connection) connection = new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === 'undefined') return reject(new Error('Browser storage is unavailable. Enable site storage and reload Trips.'));
    const request = indexedDB.open(DATABASE, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      db.createObjectStore('trips', { keyPath: 'id' });
      db.createObjectStore('turns', { keyPath: 'id' }).createIndex('tripId', 'tripId');
      db.createObjectStore('meta', { keyPath: 'key' });
    };
    request.onerror = () => reject(new Error('Could not open browser storage. Enable site storage and reload Trips.'));
    request.onblocked = () => reject(new Error('Close other Trips tabs, then reload to update browser storage.'));
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => { db.close(); connection = undefined; };
      resolve(db);
    };
  }).catch(error => { connection = undefined; throw storageError(error); });
  return connection;
}
function result<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => { request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); });
}
async function transaction<T>(mode: IDBTransactionMode, work: (tx: IDBTransaction) => Promise<T>, broadcast = mode === 'readwrite'): Promise<T> {
  const db = await openDatabase(), tx = db.transaction(STORES, mode);
  const done = new Promise<void>((resolve, reject) => { tx.oncomplete = () => resolve(); tx.onabort = () => reject(tx.error || new Error('The change could not be saved.')); });
  // Attach immediately: an operation may fail before the transaction settles.
  void done.catch(() => {});
  try { const value = await work(tx); await done; if (broadcast) notify(); return value; }
  catch (error) { try { tx.abort(); } catch {} await done.catch(() => {}); throw storageError(error); }
}
function notify() {
  if (typeof window === 'undefined' || typeof BroadcastChannel === 'undefined') return;
  const channel = new BroadcastChannel(DATABASE); channel.postMessage(browserClientId()); channel.close();
}
export function subscribeLocalWorkspace(refresh: () => void): () => void {
  const channel = typeof BroadcastChannel === 'undefined' ? null : new BroadcastChannel(DATABASE);
  if (channel) channel.onmessage = event => { if (event.data !== browserClientId()) refresh(); };
  const visible = () => { if (document.visibilityState === 'visible') refresh(); };
  document.addEventListener('visibilitychange', visible);
  return () => { channel?.close(); document.removeEventListener('visibilitychange', visible); };
}
export async function initializeLocalWorkspace(legacy?: LegacyWorkspace): Promise<void> {
  await transaction('readwrite', async tx => {
    const trips = tx.objectStore('trips'), turns = tx.objectStore('turns'), meta = tx.objectStore('meta');
    if (legacy && !await result(meta.get('migrated:' + legacy.migrationId))) {
      if (!await result(meta.get('ignoreLegacy'))) {
        for (const trip of legacy.trips) if (!await result(trips.get(trip.id))) trips.put({ ...tripSchema.parse(trip), version: trip.version });
        for (const turn of legacy.turns) if (!await result(turns.get(turn.id))) turns.put(turn);
      }
      meta.put({ key: 'migrated:' + legacy.migrationId, value: true });
    }
    if (!await result(meta.get('initialized'))) {
      if (!await result(trips.count())) trips.put(demoSample());
      meta.put({ key: 'initialized', value: true });
    }
  });
}
export function listLocalTrips(): Promise<Trip[]> {
  return transaction('readonly', tx => result(tx.objectStore('trips').getAll()));
}
export function localWorkspaceInitialized(): Promise<boolean> {
  return transaction('readonly', async tx => !!await result(tx.objectStore('meta').get('initialized')));
}
export function saveLocalTrip(input: Trip, isNew = false): Promise<Trip> {
  const parsed = tripSchema.parse(input);
  return transaction('readwrite', async tx => {
    const store = tx.objectStore('trips'), old = await result<Trip | undefined>(store.get(input.id));
    if (isNew) {
      if (old) throw new Error('This trip already exists.');
      if (await result(store.count()) >= 3) throw new Error('This demo allows three trips. Delete one or reset the demo.');
    } else if (!old || old.version !== input.version) throw new Error('This trip changed in another tab. Reload before editing.');
    const saved = { ...parsed, version: isNew ? 1 : old!.version + 1 };
    store.put(saved); return saved;
  });
}
export function deleteLocalTrip(id: string): Promise<void> {
  return transaction('readwrite', async tx => {
    tx.objectStore('trips').delete(id);
    const turns = tx.objectStore('turns');
    for (const key of await result(turns.index('tripId').getAllKeys(id))) turns.delete(key);
  });
}
export function resetLocalWorkspace(): Promise<void> {
  return transaction('readwrite', async tx => {
    tx.objectStore('trips').clear(); tx.objectStore('turns').clear();
    // Keep migration receipts so a failed network acknowledgement cannot restore deleted data.
    tx.objectStore('meta').put({ key: 'initialized', value: true });
    tx.objectStore('meta').put({ key: 'ignoreLegacy', value: true });
    tx.objectStore('trips').put(demoSample());
  });
}
async function conversation(tx: IDBTransaction, tripId: string): Promise<LocalTurn[]> {
  const store = tx.objectStore('turns');
  const turns = await result<LocalTurn[]>(store.index('tripId').getAll(tripId));
  for (const turn of turns) if (turn.status === 'running' && turn.createdAt < Date.now() - RUN_TIMEOUT) {
    turn.status = 'error'; turn.assistant = 'The reply was interrupted. No itinerary changes were saved.'; store.put(turn);
  }
  return turns.sort((a, b) => a.createdAt - b.createdAt);
}
export function readLocalChat(tripId: string): Promise<{ turns: LocalTurn[]; trip: Trip | null }> {
  // Reading must not rebroadcast: two open tabs would otherwise refresh each other indefinitely.
  return transaction('readwrite', async tx => ({ turns: (await conversation(tx, tripId)).slice(-50), trip: await result(tx.objectStore('trips').get(tripId)) || null }), false);
}
export function beginLocalTurn(pending: ChatTurn, tripId: string, day?: string): Promise<LocalChatRequest> {
  return transaction('readwrite', async tx => {
    const turns = await conversation(tx, tripId);
    if (turns.some(turn => turn.status === 'running')) throw new Error('Wait for the current reply to finish.');
    const trip = await result<Trip | undefined>(tx.objectStore('trips').get(tripId));
    if (!trip && !['general', 'example'].includes(tripId)) throw new Error('This trip was deleted in another tab.');
    const payload = fitChatRequest({ id: pending.id, tripId, message: pending.user, day: day || undefined, trip: trip || null,
      history: turns.filter(t => ['complete', 'undone'].includes(t.status)).slice(-12).map(t => ({ user: t.user, assistant: t.assistant.slice(0, 24000), status: t.status as 'complete' | 'undone', places: t.places })) });
    tx.objectStore('turns').add({ ...pending, tripId, before: trip || null });
    return payload;
  });
}
export function finishLocalTurn(id: string, output: ChatTurn, draft: Trip | null): Promise<{ turn: LocalTurn; trip: Trip | null }> {
  return transaction('readwrite', async tx => {
    const store = tx.objectStore('turns'), pending = await result<LocalTurn | undefined>(store.get(id));
    if (!pending || pending.status !== 'running') throw new Error('This reply was cancelled or the demo was reset.');
    if (output.id !== id) throw new Error('The assistant returned a different reply. Please try again.');
    let current = await result<Trip | undefined>(tx.objectStore('trips').get(pending.tripId));
    let turn: LocalTurn = { ...output, tripId: pending.tripId, before: pending.before, createdAt: pending.createdAt, afterVersion: null };
    if (output.changes.length) {
      if (!current || !pending.before || current.version !== pending.before.version) {
        turn = { ...turn, status: 'conflict', assistant: 'Your trip changed while I was working. No chat edits were applied. Please send the request again.', changes: [], before: null };
      } else {
        if (!draft || draft.id !== current.id) throw new Error('The assistant returned an invalid itinerary. No changes were saved.');
        current = { ...tripSchema.parse(draft), version: current.version + 1 };
        tx.objectStore('trips').put(current); turn.afterVersion = current.version;
      }
    } else turn.before = null;
    store.put(turn); return { turn, trip: current || null };
  });
}
export function failLocalTurn(id: string, message: string): Promise<void> {
  return transaction('readwrite', async tx => {
    const store = tx.objectStore('turns'), turn = await result<LocalTurn | undefined>(store.get(id));
    if (turn?.status === 'running') store.put({ ...turn, status: 'error', assistant: message, before: null });
  });
}
export function undoLocalTurn(id: string, tripId: string): Promise<{ trip: Trip; turn: LocalTurn }> {
  return transaction('readwrite', async tx => {
    const turns = tx.objectStore('turns'), turn = await result<LocalTurn | undefined>(turns.get(id));
    const trips = tx.objectStore('trips'), trip = await result<Trip | undefined>(trips.get(tripId));
    if (!turn || turn.tripId !== tripId || !turn.before || turn.status !== 'complete' || !turn.afterVersion) throw new Error('This update can no longer be undone.');
    if (!trip || trip.version !== turn.afterVersion) throw new Error('This trip changed after that update. Undo would overwrite newer edits.');
    const restored = { ...tripSchema.parse(turn.before), version: trip.version + 1 };
    const undone = { ...turn, status: 'undone', before: null };
    trips.put(restored); turns.put(undone); return { trip: restored, turn: undone };
  });
}
export function clearLocalChat(tripId: string): Promise<void> {
  return transaction('readwrite', async tx => {
    const turns = await conversation(tx, tripId);
    if (turns.some(t => t.status === 'running')) throw new Error('Wait for the current reply to finish.');
    for (const turn of turns) tx.objectStore('turns').delete(turn.id);
  });
}
