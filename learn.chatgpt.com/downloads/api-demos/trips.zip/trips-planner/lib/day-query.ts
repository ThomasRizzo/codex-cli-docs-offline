import { departureSchedule, planningDays } from './departures';
import type { Trip } from './trips';

export function selectedCalendarDay(value:unknown,trip:Trip,dates=planningDays(trip,trip.flights.map(f=>departureSchedule(f,trip.stops,{})))) {
 return typeof value==='string'&&dates.includes(value)?value:trip.start;
}
export function calendarDayURL(href:string,day:string) {
 const url=new URL(href);url.searchParams.set('day',day);return url.href;
}
export function tripPath(trip:unknown,day?:unknown) {
 const query=new URLSearchParams();
 if(typeof trip==='string'&&trip)query.set('trip',trip);
 if(typeof day==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(day))query.set('day',day);
 return '/'+(query.size?'?'+query:'');
}
