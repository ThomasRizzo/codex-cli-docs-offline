import { hasLocation, sameLocation, type Stop } from './trips';
import { stopMinute, stopDuration } from './event-duration';
export { stopMinute } from './event-duration';

export function orderedDayStops(stops: Stop[], day: string) {
  return stops.filter(stop => stop.date === day).sort((a,b) => (a.time || '24:00').localeCompare(b.time || '24:00'));
}
// Event heights represent their saved duration, including compact 15-minute visits.
export function calendarTravelLayout(stops: Stop[], scale=1.5) {
  const timed=stops.filter(stop=>stop.time);
  const compactHeight=20;
  const heights=new Map(timed.map(stop=>[stop.id,stopDuration(stop)*scale]));
  const legs=timed.slice(1).flatMap((to,index)=>{
    const from=timed[index];
    if(!hasLocation(from)||!hasLocation(to)||sameLocation(from,to))return [];
    const gapTop=stopMinute(from)!*scale+heights.get(from.id)!+1;
    const gapBottom=stopMinute(to)!*scale-1;
    const above=gapBottom-gapTop<compactHeight;
    // Crowded cards stagger into columns. Reserve a separate row just above
    // the destination, without adding travel content to the event itself.
    const bottom=above?stopMinute(to)!*scale-2:gapBottom;
    const top=above?bottom-compactHeight:gapTop;
    return [{from,to,top,bottom,above,compact:bottom-top<36}];
  });
  const incoming=new Map(legs.map(leg=>[leg.to.id,leg]));
  const groups:Stop[][]=[];let end=-Infinity;
  for(const stop of timed){
    const at=stopMinute(stop)!*scale;
    const leg=incoming.get(stop.id);
    const occupiedTop=leg?.above?leg.top:at;
    if(occupiedTop>=end)groups.push([]);
    groups[groups.length-1].push(stop);
    end=Math.max(at+heights.get(stop.id)!,occupiedTop>=end?-Infinity:end);
  }
  const lanes=new Map(groups.flatMap(group=>group.map((stop,column)=>[stop.id,{column,columns:group.length,height:heights.get(stop.id)!}] as const)));
  return {legs,lanes};
}

// Hotels are untimed bookends attached to card edges, not invented stay times.
export function calendarHotelAnchors(stops: Stop[], layout: ReturnType<typeof calendarTravelLayout>, scale=1.5) {
  const cardHeight=76,travelHeight=44;
  const located=stops.filter(hasLocation);
  const first=located[0],last=located.at(-1);
  const firstTop=first?.time?stopMinute(first)!*scale:null;
  const lastBottom=last?.time?stopMinute(last)!*scale+layout.lanes.get(last.id)!.height:null;
  const cardsBottom=Math.max(0,...stops.filter(stop=>stop.time).map(stop=>stopMinute(stop)!*scale+layout.lanes.get(stop.id)!.height));
  return {
    start:firstTop!==null?{stop:first,top:firstTop-cardHeight-travelHeight,cardHeight,travelHeight}:null,
    end:lastBottom!==null?{stop:last!,top:lastBottom,cardHeight,travelHeight:Math.max(travelHeight,cardsBottom-lastBottom+travelHeight)}:null,
  };
}
