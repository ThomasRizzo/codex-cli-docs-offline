import { db } from './server';
import { example } from './example';
import type { Trip } from './trips';
import { loadTrip } from './load-trip';
import type { ChatTurn } from './chat-types';
export type TurnRow={id:string;owner:string;trip_id:string;user_text:string;assistant_text:string;sources:string;places:string;changes:string;status:string;before_data:string|null;after_version:number|null;created_at:number};
export function publicTurn(r:TurnRow):ChatTurn{return {id:r.id,user:r.user_text,assistant:r.assistant_text,sources:JSON.parse(r.sources),places:JSON.parse(r.places||'[]'),changes:JSON.parse(r.changes),status:r.status,afterVersion:r.after_version,createdAt:r.created_at};}
export async function loadChatTrip(owner:string,id:string):Promise<Trip|null>{if(id==='general')return null;if(id==='example')return example;const row=await db().prepare('SELECT data,version FROM trips WHERE id=? AND owner=? AND deleted_at IS NULL').bind(id,owner).first<{data:string;version:number}>();if(!row)throw new Response(JSON.stringify({error:'This trip is unavailable.'}),{status:404,headers:{'Content-Type':'application/json'}});return loadTrip(row.data,row.version);}
export async function expireRuns(owner:string,tripId:string){await db().prepare("UPDATE chat_turns SET status='error',assistant_text='The request was interrupted. No itinerary changes were saved.' WHERE owner=? AND trip_id=? AND status='running' AND created_at<?").bind(owner,tripId,Date.now()-240000).run();}
export async function getTurn(owner:string,id:string){return db().prepare('SELECT * FROM chat_turns WHERE id=? AND owner=?').bind(id,owner).first<TurnRow>();}
export async function finishTurn(owner:string,id:string,old:Trip|null,next:Trip|null,text:string,sources:unknown[],changes:string[],places:unknown[]=[]){
 if(old&&next&&changes.length){const results=await db().batch([
  db().prepare('UPDATE trips SET data=?,version=version+1,updated_at=? WHERE id=? AND owner=? AND version=? AND deleted_at IS NULL').bind(JSON.stringify(next),Date.now(),old.id,owner,old.version),
  db().prepare("UPDATE chat_turns SET status=CASE WHEN changes()=1 THEN 'complete' ELSE 'conflict' END,assistant_text=CASE WHEN changes()=1 THEN ? ELSE 'Your trip changed while I was working. No chat edits were applied. Please send the request again.' END,sources=?,places=?,changes=CASE WHEN changes()=1 THEN ? ELSE '[]' END,after_version=CASE WHEN changes()=1 THEN ? ELSE NULL END WHERE id=? AND owner=? AND status='running'").bind(text,JSON.stringify(sources),JSON.stringify(places),JSON.stringify(changes),old.version+1,id,owner)
 ]);return !!results[0].meta.changes;}
 await db().prepare("UPDATE chat_turns SET status='complete',assistant_text=?,sources=?,places=? WHERE id=? AND owner=? AND status='running'").bind(text,JSON.stringify(sources),JSON.stringify(places),id,owner).run();return false;
}
