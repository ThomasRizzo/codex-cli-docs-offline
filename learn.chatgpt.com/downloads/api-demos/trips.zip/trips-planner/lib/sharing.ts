import { tripSchema, type Trip } from './trips';
import { tokenHash, validCalendarToken } from './calendar-token';
export const shareURL = (origin:string, token:string) => `${origin}/share/${token}`;
export const calendarURL = (origin:string, token:string) => `${origin}/api/calendar/feed/${token}`;

// Only itinerary fields cross the public boundary. Notes and chat stay private.
export function sharedTrip(data:string, version:number):Trip {
  const trip=tripSchema.parse(JSON.parse(data));
  return {...trip, version, stops:trip.stops.map(stop=>({...stop,note:''})), hotels:trip.hotels?.map(hotel=>({...hotel,note:''}))};
}
export async function readSharedTrip(db:D1Database, token:string):Promise<Trip|null> {
  if (!validCalendarToken(token)) return null;
  const row=await db.prepare('SELECT t.data,t.version FROM trip_shares s JOIN trips t ON t.id=s.trip_id AND t.owner=s.owner WHERE s.token_hash=? AND t.deleted_at IS NULL').bind(await tokenHash(token)).first<{data:string;version:number}>();
  return row?sharedTrip(row.data,row.version):null;
}
