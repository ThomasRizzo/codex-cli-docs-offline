import { initializeLocalWorkspace, localWorkspaceInitialized, type LegacyWorkspace } from './local-workspace';

let enabled = false;
let renewal: Promise<void> | undefined;
async function checked<T>(response: Response): Promise<T> {
  const data = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(data.error || 'Could not connect. Please try again.');
  return data;
}
async function renewSession() {
  if (!renewal) renewal = fetch('/api/demo/session', { method: 'POST', signal: AbortSignal.timeout(10000) }).then(response => checked(response)).then(() => {}).finally(() => { renewal = undefined; });
  await renewal;
}
export async function initializeBrowserDemo() {
  enabled = true;
  if (await localWorkspaceInitialized()) {
    // Saved work remains usable even if the API is offline or its quota is exhausted.
    void synchronizeLegacyWorkspace().catch(() => {});
    return;
  }
  await synchronizeLegacyWorkspace();
}
async function synchronizeLegacyWorkspace() {
  const legacy = await checked<LegacyWorkspace | null>(await fetch('/api/demo/migrate', { signal: AbortSignal.timeout(10000) }));
  // Acknowledgement only follows a committed IndexedDB transaction. Receipts make retries idempotent.
  await initializeLocalWorkspace(legacy || undefined);
  if (legacy) await fetch('/api/demo/migrate', { method: 'DELETE', signal: AbortSignal.timeout(10000) }).then(response => checked(response)).catch(() => {});
  void renewSession().catch(() => {});
}
export async function workspaceFetch(path: string, options?: RequestInit): Promise<Response> {
  let response = await fetch(path, options);
  if (enabled && response.status === 401 && !path.startsWith('/api/demo/')) {
    // API authorization expires independently of browser-owned trips and chat.
    await renewSession(); options?.signal?.throwIfAborted();
    response = await fetch(path, options);
  }
  return response;
}
