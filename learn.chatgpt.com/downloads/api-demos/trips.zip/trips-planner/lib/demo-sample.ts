import { example } from './example';
import type { Trip } from './trips';

export function demoSample(now = Date.now()): Trip {
  const date = (offset: number) => new Date(now + offset * 86400000).toISOString().slice(0, 10);
  return { ...structuredClone(example), id: crypto.randomUUID(), version: 1,
    start: date(0), end: date(2), timeZone: 'America/Los_Angeles',
    stops: example.stops.map(stop => ({ ...stop, id: crypto.randomUUID(), date: date(0) })) };
}
