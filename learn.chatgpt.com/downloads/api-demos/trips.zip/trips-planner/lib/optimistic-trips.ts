import type { Trip } from './trips';

type Edit=(trip:Trip)=>Trip;
type Result={before:Trip;saved:Trip};
type Job={settled:Promise<Result>;edit:Edit;validate:(before:Trip,next:Trip)=>Promise<Trip>;resolve:(result:Result)=>void;reject:(error:Error)=>void};
type State={confirmed:Trip;remote?:Trip;jobs:Job[];running:boolean;recovering:boolean};
type Options={save:(trip:Trip)=>Promise<Trip>;reload:(id:string)=>Promise<Trip|undefined>;onChange:(trip:Trip)=>void;onPending:(pending:boolean)=>void;onError:(error:Error,tripId:string)=>void};

// Keep server versions authoritative. Reapply queued intentions after each
// acknowledgement so an older response cannot move the newest preview back.
export class OptimisticTrips {
 private states=new Map<string,State>();
 constructor(private options:Options){}
 get busy(){return [...this.states.values()].some(s=>s.running||s.jobs.length>0);}
 pending(id:string){const s=this.states.get(id);return !!s&&(s.running||s.jobs.length>0);}
 async waitForIdle(id:string){
  for(;;){
   const state=this.states.get(id),last=state?.jobs.at(-1);
   if(last){await last.settled;continue;}
   if(state?.recovering)throw new Error('Your calendar is reconnecting. Please try again in a moment.');
   return;
  }
 }
 private view(state:State){return state.jobs.reduce((trip,job)=>job.edit(trip),state.confirmed);}
 receive(trip:Trip){
  const state=this.states.get(trip.id);
  if(!state){this.options.onChange(trip);return;}
  if(trip.version<state.confirmed.version)return;
  if(state.running||state.jobs.length){if(!state.remote||trip.version>=state.remote.version)state.remote=trip;return;}
  state.confirmed=trip;this.options.onChange(trip);
 }
 enqueue(base:Trip,edit:Edit,validate:Job['validate']){
  let state=this.states.get(base.id);
  if(state?.recovering)throw new Error('Reconnecting your trip. Please try again in a moment.');
  if(!state||!state.running&&!state.jobs.length){state={confirmed:base,jobs:[],running:false,recovering:false};this.states.set(base.id,state);}
  const next=edit(this.view(state)); // Validate local input before changing anything.
  let resolve!:Job['resolve'],reject!:Job['reject'];
  const settled=new Promise<Result>((yes,no)=>{resolve=yes;reject=no;});
  state.jobs.push({settled,edit,validate,resolve,reject});
  this.options.onChange(next);this.options.onPending(true);
  void this.run(state);
  return {optimistic:next,settled};
 }
 private async run(state:State){
  if(state.running)return;state.running=true;
  try{
   while(state.jobs.length){
    const job=state.jobs[0],before=state.confirmed;
    try{
     const next=await job.validate(before,job.edit(before));
     const saved=await this.options.save({...next,version:before.version});
     state.confirmed=state.remote&&state.remote.version>saved.version?state.remote:saved;
     state.remote=undefined;state.jobs.shift();
     job.resolve({before,saved});this.options.onChange(this.view(state));
    }catch(cause){
     state.recovering=true;
     const rejected=state.jobs.splice(0);
     // A lost response may still have saved on the server. Read back before
     // restoring the UI, including when another tab or the assistant won a race.
     let refreshed=false;
     try{const latest=await this.options.reload(before.id);if(latest&&latest.version>=state.confirmed.version){state.confirmed=latest;refreshed=true;}}catch{}
     if(state.remote&&state.remote.version>state.confirmed.version)state.confirmed=state.remote;
     state.remote=undefined;
     this.options.onChange(state.confirmed);
     const message=cause instanceof Error?cause.message:'Could not save your changes.';
     const error=new Error(`${refreshed?message.replace('Reload before editing.','The latest version is loaded.'):message} Unsaved calendar changes were reverted.`);
     this.options.onError(error,before.id);rejected.forEach(job=>job.reject(error));
     state.recovering=false;break;
    }
   }
  }finally{state.running=false;this.options.onPending(this.busy);}
 }
}
