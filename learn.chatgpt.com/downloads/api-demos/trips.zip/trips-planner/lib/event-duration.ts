import type { Stop } from './trips';

export const DEFAULT_EVENT_MINUTES=45;
export function stopMinute(stop: Pick<Stop,'time'>) {
 if(!stop.time)return null;
 const [hour,minute]=stop.time.split(':').map(Number);
 return hour*60+minute;
}
export function stopDuration(stop: Pick<Stop,'time'|'durationMinutes'>) {
 return stop.durationMinutes??Math.min(DEFAULT_EVENT_MINUTES,1440-(stopMinute(stop)??0));
}
export function stopEndMinute(stop: Pick<Stop,'time'|'durationMinutes'>) {
 const start=stopMinute(stop);
 return start===null?null:start+stopDuration(stop);
}
export function maxEventDuration(stop: Pick<Stop,'time'>) {
 const remaining=1440-(stopMinute(stop)??0);
 return remaining<15?remaining:Math.floor(remaining/15)*15;
}
export function snapEventDuration(stop: Pick<Stop,'time'>, endMinute: number) {
 const max=maxEventDuration(stop),min=Math.min(15,max);
 return Math.max(min,Math.min(max,Math.round((endMinute-(stopMinute(stop)??0))/15)*15));
}
