import type { Trip } from './trips';
import type { RecommendedPlace } from './recommendations';
export type ChatSource={title:string;url:string};
export type ChatTurn={id:string;user:string;assistant:string;sources:ChatSource[];places:RecommendedPlace[];changes:string[];status:string;afterVersion:number|null;createdAt:number};
export type ChatEvent={type:'status';text:string}|{type:'delta';text:string}|{type:'done';turn:ChatTurn;trip:Trip|null}|{type:'error';message:string};
