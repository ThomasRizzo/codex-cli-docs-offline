import { dayRoute, type DayPoint } from './hotels';
import { days, routeKey, sameLocation, type Place, type Route, type Trip } from './trips';

export const MAX_WALK_MINUTES=15;
type Leg={from:DayPoint;to:DayPoint};
function legs(trip:Trip):Leg[]{
 return days(trip.start,trip.end).flatMap(day=>{const points=dayRoute(trip,day).points;return points.slice(1).flatMap((to,i)=>sameLocation(points[i],to)?[]:[{from:points[i],to}]);});
}
// Mode and clock changes alone do not create a new route, preserving deliberate
// overrides and avoiding requests when an event is only resized or renamed.
function identity({from,to}:Leg){return JSON.stringify([from.date,from.id,to.id,routeKey(from,to,'walk')]);}
export function newTravelLegs(before:Trip|undefined,next:Trip){
 const existing=new Set(before?legs(before).map(identity):[]);
 return legs(next).filter(leg=>!existing.has(identity(leg)));
}
function useUber(trip:Trip,to:DayPoint):Trip{
 if(to.hotelId)return {...trip,hotels:(trip.hotels||[]).map(h=>h.id===to.hotelId?{...h,returnModes:{...h.returnModes,[to.date]:'uber'}}:h)};
 return {...trip,stops:trip.stops.map(stop=>stop.id===to.id?{...stop,mode:'uber'}:stop)};
}
export function previewTravelModes(before:Trip,next:Trip,routes:Record<string,Route>,errors:Record<string,string>={}):Trip{
 let planned=next;
 for(const leg of newTravelLegs(before,next)){
  const key=routeKey(leg.from,leg.to,'walk');
  if(leg.to.mode==='walk'&&((routes[key]?.minutes??0)>MAX_WALK_MINUTES||errors[key]))planned=useUber(planned,leg.to);
 }
 return planned;
}
export async function chooseTravelModes(before:Trip|undefined,next:Trip,load:(a:Place,b:Place,mode:'walk'|'uber')=>Promise<Route>):Promise<Trip>{
 let planned=next;
 for(const leg of newTravelLegs(before,next)){
  if(leg.to.mode!=='walk')continue;
  let walk:Route|undefined;
  try{walk=await load(leg.from,leg.to,'walk');}catch{/* Try driving if a walking route is unavailable. */}
  if(walk&&walk.minutes<=MAX_WALK_MINUTES)continue;
  try{await load(leg.from,leg.to,'uber');}catch{throw new Error(`Travel to ${leg.to.name} could not be checked. Please try again.`);}
  planned=useUber(planned,leg.to);
 }
 return planned;
}
