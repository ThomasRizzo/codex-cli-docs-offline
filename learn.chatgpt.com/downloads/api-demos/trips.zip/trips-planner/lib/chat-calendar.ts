import { arrivalTravelLegs } from './arrivals';
import { calendarMinuteInZone, flightCalendarRange, flightDayBlock } from './calendar-flights';
import { orderedDayStops } from './calendar-travel';
import { departureOrigin, departureSchedule, planningDays, wallDate, wallMinutes } from './departures';
import { stopDuration } from './event-duration';
import { dayRoute } from './hotels';
import { changedTravelLegs } from './schedule-travel';
import { hasLocation, routeKey, sameLocation, type Place, type Route, type Trip } from './trips';

export const calendarTool={type:'function',name:'get_calendar',description:'Read the current calendar for a day, including staged edits, event durations, flights, airport buffers, hotel endpoints, actual route estimates, and gaps between events. Use it to check availability before planning and after changing the itinerary. It never changes the trip.',strict:true,parameters:{type:'object',properties:{date:{type:'string',description:'YYYY-MM-DD, or empty for the selected day'}},required:['date'],additionalProperties:false}};
const stamp=(minute:number)=>`${wallDate(minute)}T${new Date(minute*60000).toISOString().slice(11,16)}`;
export function calendarRoutePairs(trip:Trip,day:string){
 const points=dayRoute(trip,day).points;
 const pairs=points.slice(1).flatMap((to,i)=>sameLocation(points[i],to)?[]:[{from:points[i] as Place,to:to as Place,mode:to.mode}]);
 for(const flight of trip.flights){
  const plan=flight.departurePlan,origin=departureOrigin(flight,trip.stops);
  if(plan&&origin&&flight.date>=day&&flight.date<=wallDate(wallMinutes(day,'00:00')!+1440)&&plan.driveOverrideMinutes===null)pairs.push({from:origin,to:plan.airport,mode:'uber'});
 }
 return [...new Map(pairs.map(p=>[routeKey(p.from,p.to,p.mode),p])).values()];
}
export function summarizeCalendar(trip:Trip,day:string,routes:Record<string,Route>){
 const route=dayRoute(trip,day),stops=orderedDayStops(trip.stops,day),zone=trip.timeZone||route.arrival?.flight.arrivalTimeZone||trip.flights[0]?.arrivalTimeZone||trip.flights[0]?.departureTimeZone;
 const start=wallMinutes(day,'00:00')!,end=start+1440;
 const schedules=trip.flights.map(f=>departureSchedule(f,trip.stops,routes));
 const boundary=(minutes:number)=>stamp(minutes);
 const travelLegs=[...changedTravelLegs([],trip.stops),...arrivalTravelLegs(trip)].filter(l=>l.to.date===day);
 const travel=route.points.slice(1).map((to,i)=>{
  const from=route.points[i],key=routeKey(from,to,to.mode),estimate=sameLocation(from,to)?{minutes:0,km:0}:routes[key];
  const leg=travelLegs.find(l=>l.from.id===from.id&&l.to.id===to.id);
  const fromEnd=from.time?wallMinutes(from.date,from.time)!+(from.arrivalFlightId?from.durationMinutes??30:stopDuration(from)):null;
  return {from_id:from.id,from:from.name,to_id:to.id,to:to.name,mode:to.mode,minutes:estimate?.minutes??null,km:estimate?.km??null,estimate_status:estimate?'available':'unavailable',available_minutes:leg?.gap??null,slack_minutes:leg&&estimate?leg.gap-estimate.minutes:null,fits:leg&&estimate?leg.gap>=estimate.minutes:null,earliest_arrival:fromEnd!==null&&estimate?boundary(fromEnd+estimate.minutes):null};
 });
 const airport=schedules.flatMap(s=>{
  if(s.depart===null||s.arrive===null)return [];
  const convert=(minute:number)=>calendarMinuteInZone(minute,s.flight.departureTimeZone,zone),from=convert(s.leave??s.arrive),to=convert(s.depart);
  if(from>=end||to<=start)return [];
  return [{flight_id:s.flight.id,number:s.flight.number,start:boundary(from),end:boundary(to),airport_arrival:boundary(convert(s.arrive)),airport_buffer_minutes:s.bufferMinutes,uber_minutes:s.driveMinutes,pickup_allowance_minutes:s.leave!==null?s.extraMinutes:null,travel_included:s.leave!==null,issue:s.issue}];
 });
 const flights=trip.flights.flatMap(f=>{const r=flightCalendarRange(f,zone);if(!r||!flightDayBlock(r,day))return [];return [{id:f.id,number:f.number,from:f.from,to:f.to,departure:boundary(r.departure),arrival:boundary(r.arrival),airport_exit_until:boundary(r.ready),airport_exit_minutes:r.exitMinutes,status:f.flightaware?.status||null}];});
 const conflicts=travelLegs.flatMap(l=>{
  const estimate=hasLocation(l.from)&&hasLocation(l.to)&&!sameLocation(l.from,l.to)?routes[l.key]?.minutes:0;
  return l.gap<0||estimate!==undefined&&l.gap<estimate?[{type:l.gap<0?'overlap':'travel',from_id:l.from.id,to_id:l.to.id,available_minutes:l.gap,required_minutes:estimate??null}]:[];
 });
 return {trip_id:trip.id,trip_name:trip.name,version:trip.version,date:day,time_zone:zone||'local to each event',events:stops.filter(s=>s.time).map(s=>({id:s.id,title:s.name,kind:s.kind||'place',booked:s.kind!=='event'&&!!s.booked,start:`${s.date}T${s.time}`,end:boundary(wallMinutes(s.date,s.time)!+stopDuration(s)),duration_minutes:stopDuration(s),location:hasLocation(s)?s.locationName||s.name:null,time_zone:s.timeZone||zone||null,hotel_id:s.hotelCheckInId||null})),unscheduled:stops.filter(s=>!s.time).map(s=>({id:s.id,title:s.name,booked:s.kind!=='event'&&!!s.booked})),hotels:{start:route.start?{id:route.start.hotelId,name:route.start.name}:null,end:route.end?{id:route.end.hotelId,name:route.end.name}:null},flights,airport_blocks:airport,travel,conflicts,estimate_note:'Route estimates exclude live traffic and Uber pickup waits. Null means unknown, never zero. Gaps between located events exclude intervening appointments; do not assume those gaps are uninterrupted free time.'};
}
export function createCalendarReader(load:(from:Place,to:Place,mode:'walk'|'uber')=>Promise<Route>){
 const requests=new Map<string,Promise<Route>>();
 return async(trip:Trip,day:string)=>{
  const dates=planningDays(trip,trip.flights.map(f=>departureSchedule(f,trip.stops,{})));
  if(!/^\d{4}-\d{2}-\d{2}$/.test(day)||!dates.includes(day))throw new Error('Choose a day in this trip.');
  const pairs=calendarRoutePairs(trip,day),routes:Record<string,Route>={};
  // Bound routing concurrency and reuse the same cached estimate through a turn.
  let next=0;
  await Promise.all(Array.from({length:Math.min(3,pairs.length)},async()=>{while(next<pairs.length){const p=pairs[next++],key=routeKey(p.from,p.to,p.mode);try{if(!requests.has(key))requests.set(key,load(p.from,p.to,p.mode));routes[key]=await requests.get(key)!;}catch{}}}));
  return summarizeCalendar(trip,day,routes);
 };
}
