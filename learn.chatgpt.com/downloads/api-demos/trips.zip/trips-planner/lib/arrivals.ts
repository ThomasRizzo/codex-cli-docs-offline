import { localFlightTime } from './flightaware';
import { wallMinutes, wallDate, wallTime } from './departures';
import { hasLocation, routeKey, type Flight, type Trip, type LocatedStop, type Stop } from './trips';
import type { ScheduleTravelLeg } from './schedule-travel';

export const DEFAULT_AIRPORT_EXIT_MINUTES=30;
export function arrivalTime(flight:Flight){
 const tracking=flight.flightaware;
 const stamp=tracking?.actualIn||tracking?.estimatedIn||tracking?.scheduledIn;
 if(stamp&&flight.arrivalTimeZone){
  try{const local=localFlightTime(stamp,flight.arrivalTimeZone);return wallMinutes(local.date,local.time);}catch{}
 }
 return wallMinutes(flight.arrivalDate,flight.arrival);
}
function distance(a:{lat:number;lng:number},b:{lat:number;lng:number}){
 const r=Math.PI/180,dlat=(b.lat-a.lat)*r,dlng=(b.lng-a.lng)*r;
 return 6371*2*Math.asin(Math.min(1,Math.sqrt(Math.sin(dlat/2)**2+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(dlng/2)**2)));
}
export type ArrivalPoint=LocatedStop & {arrivalFlightId:string};
export type ArrivalDestination=LocatedStop & {arrivalTransferFlightId:string};
export type ArrivalConnection={flight:Flight;at:number;ready:number;from:ArrivalPoint;to:ArrivalDestination};
export function arrivalConnections(trip:Trip):ArrivalConnection[]{
 const stops=trip.stops.filter(hasLocation).sort((a,b)=>a.date.localeCompare(b.date)||(a.time||'24:00').localeCompare(b.time||'24:00'));
 const connections:ArrivalConnection[]=[];
 for(const flight of trip.flights){
  const at=arrivalTime(flight),airport=flight.arrivalAirport;
  if(at===null||!airport||flight.arrivalTransfer===false||/cancelled|canceled/i.test(flight.flightaware?.status||''))continue;
  const date=wallDate(at),to=stops.find(s=>s.date>=date);
  // Don't connect a return flight home back to events in the holiday city.
  // An explicitly enabled transfer can cover a more distant first stop.
  if(!to||(flight.arrivalTransfer!==true&&distance(airport,to)>250))continue;
  const exit=flight.arrivalExitMinutes??DEFAULT_AIRPORT_EXIT_MINUTES;
  const from:ArrivalPoint={...airport,id:`arrival:${flight.id}`,arrivalFlightId:flight.id,name:`${flight.number} arrival · ${flight.to}`,date,time:new Date(at*60000).toISOString().slice(11,16),durationMinutes:exit,note:'',mode:'uber',timeZone:flight.arrivalTimeZone};
  connections.push({flight,at,ready:at+exit,from,to:{...to,mode:flight.arrivalMode||'uber',arrivalTransferFlightId:flight.id}});
 }
 // A connecting itinerary can contain several flights into the same area.
 // The last arrival is the one that releases the traveler to their first stop.
 return connections.filter(c=>!connections.some(other=>other.to.id===c.to.id&&other.at>c.at));
}
export function arrivalTravelLegs(trip:Trip):ScheduleTravelLeg[]{
 return arrivalConnections(trip).filter(c=>c.to.time).map(c=>{
  const to=wallMinutes(c.to.date,c.to.time)!;
  const occupied=trip.stops.filter(s=>!hasLocation(s)&&s.time).reduce((sum,s)=>{const start=wallMinutes(s.date,s.time)!;return sum+Math.max(0,Math.min(to,start+(s.durationMinutes??45))-Math.max(c.ready,start));},0);
  return {from:c.from,to:c.to,gap:to-c.ready-occupied,key:routeKey(c.from,c.to,c.to.mode)};
 });
}
export function changedArrivalTravelLegs(before:Trip,after:Trip){
 const signature=(leg:ScheduleTravelLeg)=>JSON.stringify([leg.from.id,leg.to.id,leg.from.date,leg.from.time,leg.from.durationMinutes,leg.to.date,leg.to.time,leg.gap,leg.key]);
 const old=new Set(arrivalTravelLegs(before).map(signature));
 return arrivalTravelLegs(after).filter(leg=>!old.has(signature(leg)));
}

export function arrivalTimeIssue(stop:Stop,trip:Trip){
 if(!stop.time)return null;
 const at=wallMinutes(stop.date,stop.time)!;
 const arrival=arrivalConnections(trip).find(c=>stop.date===c.from.date&&at<c.ready);
 return arrival?`${arrival.flight.number} arrives at ${wallTime(arrival.at)}. Allow ${arrival.from.durationMinutes} minutes to leave the airport before your first event.`:null;
}
