import { z } from 'zod';
import type { Place } from './trips';
import { safeSource } from './chat-model';
export type RecommendedPlace=Place&{reason:string;sourceUrl:string|null};
export type RecommendationSet={turnId:string;places:RecommendedPlace[]};
export const recommendationTool={type:'function',name:'show_places',description:'Show researched recommendations as interactive chat cards and matching map pins. This does not change the itinerary. Find each location with search_places first. Usually show 3–5 choices, with a specific reason and research source for each.',strict:true,parameters:{type:'object',properties:{places:{type:'array',maxItems:6,items:{type:'object',properties:{place_id:{type:'string'},reason:{type:'string',description:'One concise sentence explaining why this fits the request, based on your web research; no invented ratings or opening hours.'},source_url:{type:['string','null'],description:'Supporting web source URL or null'}},required:['place_id','reason','source_url'],additionalProperties:false}}},required:['places'],additionalProperties:false}};
export function recommendedPlaces(args:unknown,verified:Map<string,Place>):RecommendedPlace[]{
 const parsed=z.object({places:z.array(z.object({place_id:z.string().min(1).max(100),reason:z.string().trim().min(1).max(300),source_url:z.string().max(2000).nullable()}).strict()).min(1).max(6)}).strict().parse(args);
 const seen=new Set<string>();return parsed.places.map(p=>{const place=verified.get(p.place_id);if(!place)throw new Error('Find every location with search_places before showing it.');if(seen.has(place.id))throw new Error('Show each place only once.');seen.add(place.id);if(p.source_url&&!safeSource(p.source_url))throw new Error('Use an HTTP or HTTPS research source.');return {...place,reason:p.reason,sourceUrl:p.source_url?safeSource(p.source_url):null};});
}
