import { arrivalConnections } from './arrivals';
import { hasLocation, sameLocation, type Hotel, type LocatedStop, type Trip } from './trips';
import { orderedDayStops } from './calendar-travel';
import { eventAccent } from './event-colors';

export type DayPoint = LocatedStop & { hotelId?: string; hotelRole?: 'start' | 'end'; stopIndex?: number; arrivalFlightId?:string; arrivalTransferFlightId?:string };
export const HOTEL_ACCENT = '#b39a7a';
export function hotelDayBounds(hotels: Hotel[] = [], day: string) {
  return {
    start: hotels.find(h => h.checkIn < day && day <= h.checkOut),
    end: hotels.find(h => h.checkIn <= day && day < h.checkOut),
  };
}
function hotelPoint(hotel: Hotel, day: string, role: 'start' | 'end'): DayPoint {
  return { ...hotel, id:`hotel:${hotel.id}:${role}`, hotelId:hotel.id, hotelRole:role,
    date:day, time:'', mode:role==='end'?(hotel.returnModes?.[day]||'walk'):'walk' };
}
export function dayRoute(trip: Trip, day: string) {
  const hotels=hotelDayBounds(trip.hotels,day);
  const arrival=arrivalConnections(trip).find(c=>c.to.date===day)||null;
  const start=!arrival&&hotels.start?hotelPoint(hotels.start,day,'start'):null;
  const end=hotels.end?hotelPoint(hotels.end,day,'end'):null;
  const stops:DayPoint[]=orderedDayStops(trip.stops,day).map((stop,stopIndex)=>({...stop,stopIndex})).filter(hasLocation).map(stop=>stop.id===arrival?.to.id?{...stop,...arrival.to}:stop);
  const points:DayPoint[]=[...(arrival?[arrival.from]:[]),...(start&&(!stops[0]||!sameLocation(start,stops[0]))?[start]:[]),...stops];
  // A hotel-only day has one map pin and no pointless route back to itself.
  if(end&&(stops.length||!start||start.hotelId!==end.hotelId)&&(!stops.at(-1)||!sameLocation(end,stops.at(-1)!)))points.push(end);
  return {start,end,points,hotels,arrival};
}
export function routePointAccent(point: DayPoint, fallbackIndex: number) {
  return point.arrivalFlightId||point.hotelId||point.hotelCheckInId?HOTEL_ACCENT:eventAccent(point.stopIndex??fallbackIndex);
}
