import { newCalendarToken, tokenHash, validCalendarToken } from './calendar-token';
import { privateHeaders } from './site-policy';

export const DEMO_LIFETIME = 24 * 60 * 60 * 1000;
// Allow bounded in-flight chat work to finish before removing the owner record.
const CLEANUP_GRACE = 5 * 60 * 1000;
const COOKIE = '__Host-trips-demo';
export type DemoSession = { id: string; expires_at: number };

export function demoCookie(token: string, maxAge = DEMO_LIFETIME / 1000): string {
  return `${COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}

export async function findDemoSession(database: D1Database, headers: Headers, now = Date.now()): Promise<DemoSession | null> {
  const token = (headers.get('cookie') || '').split(';').map(value => value.trim()).find(value => value.startsWith(COOKIE + '='))?.slice(COOKIE.length + 1);
  if (!token || !validCalendarToken(token)) return null;
  return database.prepare('SELECT id,expires_at FROM demo_sessions WHERE id=? AND expires_at>?')
    .bind('demo:' + await tokenHash(token), now).first<DemoSession>();
}

export function requireDemoOrigin(request: Request): void {
  if (request.headers.get('origin') !== new URL(request.url).origin || request.headers.get('sec-fetch-site') === 'cross-site') {
    throw Response.json({ error: 'Open Trips in its own tab and try again.' }, { status: 403, headers: privateHeaders });
  }
}

export async function createDemoSession(database: D1Database, now = Date.now()) {
  const token = newCalendarToken();
  const session = { id: 'demo:' + await tokenHash(token), expires_at: now + DEMO_LIFETIME };
  await database.prepare('INSERT INTO demo_sessions (id,expires_at) VALUES (?,?)').bind(session.id, session.expires_at).run();
  return { session, cookie: demoCookie(token) };
}

export async function clearDemoContent(database: D1Database, owner: string) {
  await database.batch(['trips', 'chat_turns', 'calendar_subscriptions', 'trip_shares'].map(table => database.prepare(`DELETE FROM ${table} WHERE owner=?`).bind(owner)));
}

export async function resetDemoSession(database: D1Database, session: DemoSession, now = Date.now()) {
  await database.batch([
    database.prepare('UPDATE demo_sessions SET expires_at=? WHERE id=?').bind(now, session.id),
    ...['trips', 'chat_turns', 'calendar_subscriptions', 'trip_shares'].map(table => database.prepare(`DELETE FROM ${table} WHERE owner=?`).bind(session.id)),
  ]);
}

// Expiry blocks access immediately. Physical deletion runs in bounded batches
// on subsequent demo requests, including a second sweep of reset sessions.
export async function cleanupDemoSessions(database: D1Database, now = Date.now()) {
  const expired = 'SELECT id FROM demo_sessions WHERE expires_at<=? ORDER BY expires_at LIMIT 25';
  await database.batch([
    ...['trips', 'chat_turns', 'calendar_subscriptions', 'trip_shares'].map(table =>
      database.prepare(`DELETE FROM ${table} WHERE owner IN (${expired})`).bind(now - CLEANUP_GRACE)),
    database.prepare(`DELETE FROM demo_sessions WHERE id IN (${expired})`).bind(now - CLEANUP_GRACE),
    // Demo requests no longer use durable content caches; retire old coordinates/searches too.
    database.prepare('DELETE FROM service_cache WHERE key IN (SELECT key FROM service_cache LIMIT 100)'),
  ]);
}
