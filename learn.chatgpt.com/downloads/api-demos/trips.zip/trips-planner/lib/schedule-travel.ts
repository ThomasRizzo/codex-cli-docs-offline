import { duration, routeKey, hasLocation, type Route, type Stop } from './trips';
import { stopMinute, stopEndMinute, stopDuration } from './event-duration';

export type ScheduleTravelLeg = { from: Stop; to: Stop; gap: number; key: string };
export type ScheduleAvailability = {
  status: 'ready' | 'checking' | 'blocked' | 'unavailable';
  label: string;
  message: string;
  missing: ScheduleTravelLeg[];
};

function timedLegs(stops: Stop[]): ScheduleTravelLeg[] {
  const timed=stops.filter(stop=>stop.time).sort((a,b)=>a.date.localeCompare(b.date)||a.time.localeCompare(b.time));
  const adjacent=timed.slice(1).flatMap((to,index)=>{
    const from=timed[index];
    if(from.date!==to.date)return [];
    return [{from,to,gap:stopMinute(to)!-stopEndMinute(from)!,key:hasLocation(from)&&hasLocation(to)?routeKey(from,to,to.mode):`time:${from.id}:${to.id}`}];
  });
  // Unknown locations reserve time without inventing pins or routes. Preserve
  // travel between the known locations on either side, excluding occupied time.
  const located=timed.filter(hasLocation);
  const bridges=located.slice(1).flatMap((to,index)=>{
    const from=located[index];
    if(from.date!==to.date)return [];
    const between=timed.slice(timed.indexOf(from)+1,timed.indexOf(to));
    if(!between.length)return [];
    const occupied=between.reduce((sum,event)=>sum+stopDuration(event),0);
    return [{from,to,gap:stopMinute(to)!-stopEndMinute(from)!-occupied,key:routeKey(from,to,to.mode)}];
  });
  return [...adjacent,...bridges];
}

function legSignature(leg: ScheduleTravelLeg) {
  return JSON.stringify([leg.from.id,leg.to.id,leg.from.date,leg.from.time,stopDuration(leg.from),leg.to.time,leg.gap,leg.key]);
}

// Check both sides of a moved/new event, including the route left behind on its old day.
// Unchanged conflicts elsewhere must not prevent someone from fixing their itinerary.
export function changedTravelLegs(before: Stop[], after: Stop[]) {
  const unchanged=new Set(timedLegs(before).map(legSignature));
  return timedLegs(after).filter(leg=>!unchanged.has(legSignature(leg)));
}

export function scheduleTravelAvailability(legs: ScheduleTravelLeg[], routes: Record<string,Route>, errors: Record<string,string> = {}): ScheduleAvailability {
  const samePlace=(leg:ScheduleTravelLeg)=>!hasLocation(leg.from)||!hasLocation(leg.to)||(leg.from.lat===leg.to.lat&&leg.from.lng===leg.to.lng);
  const missing=legs.filter(leg=>!samePlace(leg)&&!routes[leg.key]);
  for(const leg of legs){
    if(leg.gap<0)return {status:'blocked',label:'Events overlap',message:`${leg.from.name} would overlap ${leg.to.name}. Shorten the visit or move it earlier.`,missing};
    const minutes=samePlace(leg)?0:routes[leg.key]?.minutes;
    if(minutes!==undefined&&leg.gap<minutes){
      const mode=leg.to.mode==='walk'?'Walk':'Uber';
      return {status:'blocked',label:`${mode} needs ${duration(minutes)} · ${duration(leg.gap)} gap`,message:`${mode} from ${leg.from.name} to ${leg.to.name} takes ${duration(minutes)}. This leaves ${duration(leg.gap)} ${'arrivalFlightId' in leg.from?'after leaving the airport':'after the visit ends'}.`,missing};
    }
  }
  if(missing.some(leg=>errors[leg.key]))return {status:'unavailable',label:'Travel time unavailable',message:'Travel time could not be checked. Retry or choose another slot.',missing};
  if(missing.length)return {status:'checking',label:'Checking travel time…',message:'Checking travel time…',missing};
  return {status:'ready',label:'',message:'',missing:[]};
}
