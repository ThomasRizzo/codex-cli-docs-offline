import { airportPlace, type Airport, type FlightQuery } from './flightaware';
import type { Trip } from './trips';

export async function enrichArrivalAirports(trip:Trip,query:FlightQuery):Promise<Trip>{
 const requests=new Map<string,ReturnType<FlightQuery>>();
 const flights=await Promise.all(trip.flights.map(async flight=>{
  if(flight.arrivalAirport||flight.arrivalTransfer===false)return flight;
  const code=flight.flightaware?.destination||flight.to;
  if(!/^[A-Z0-9]{3,8}$/.test(code))return flight;
  try{
   if(!requests.has(code))requests.set(code,query<Airport>(`/airports/${code}`,30*86400,15));
   const result=await requests.get(code)!;
   const airport=airportPlace(result.data as Airport,code);
   return airport?{...flight,arrivalAirport:airport}:flight;
  }catch{return flight;}
 }));
 return {...trip,flights};
}

// Calendar subscription reads may use existing airport metadata, but never
// trigger a paid provider request through a public secret-link feed.
export function cachedAirportQuery(database:D1Database):FlightQuery{
 return async <T>(path:string)=>{
  if(!/^\/airports\/[A-Z0-9]{3,8}$/.test(path))throw new Error('Airport unavailable');
  const row=await database.prepare("SELECT data FROM service_cache WHERE key LIKE ? AND expires > ? ORDER BY expires DESC LIMIT 1").bind(`flightaware:v1:%:${path}`,Date.now()).first<{data:string}>();
  if(!row)throw new Error('Airport unavailable');
  const hit=JSON.parse(row.data);if(!hit.data)throw new Error('Airport unavailable');
  return {data:hit.data as T,checkedAt:hit.checkedAt,expires:hit.expires};
 };
}
