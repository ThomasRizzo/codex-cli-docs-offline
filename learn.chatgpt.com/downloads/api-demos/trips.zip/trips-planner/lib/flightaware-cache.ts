import { FlightError, type FlightQuery, type ProviderResult } from './flightaware';

// Amounts are thousandths of a US dollar, conservatively reserved before each call.
// This caps Trips' estimate, not the FlightAware account's bill or other applications.
export const MONTHLY_FLIGHT_LIMIT=5000;
type Stored<T>={data?:T;checkedAt:number;expires:number;error?:string;status?:number};
export function flightQuery(database:D1Database,key:string,fetcher:typeof fetch=fetch,clock=Date.now):FlightQuery {
  let fingerprint:Promise<string>|undefined;
  return async <T>(path:string,ttl:number,cost:number):Promise<ProviderResult<T>>=>{
    if(!key)throw new FlightError('Flight lookup is not connected yet.',503);
    if(!/^\/(flights|schedules|airports)\//.test(path)||path.includes('://')||![5,15,20].includes(cost))throw new FlightError('Invalid flight lookup.',400);
    fingerprint??=crypto.subtle.digest('SHA-256',new TextEncoder().encode(key)).then(bytes=>Array.from(new Uint8Array(bytes)).map(x=>x.toString(16).padStart(2,'0')).join('').slice(0,24));
    const cacheKey=`flightaware:v1:${await fingerprint}:${path}`,lockKey=`flightaware:lock:${cacheKey}`,token=crypto.randomUUID();
    const read=async()=>{
      const row=await database.prepare('SELECT data FROM service_cache WHERE key = ? AND expires > ?').bind(cacheKey,clock()).first<{data:string}>();
      if(!row)return null;const hit=JSON.parse(row.data) as Stored<T>;
      if(hit.error)throw new FlightError(hit.error,hit.status);
      return {data:hit.data!,checkedAt:hit.checkedAt,expires:hit.expires};
    };
    const cached=await read();if(cached)return cached;
    const lock=await database.prepare('INSERT INTO service_cache (key,data,expires) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET data=excluded.data, expires=excluded.expires WHERE service_cache.expires <= ? RETURNING key').bind(lockKey,token,clock()+30000,clock()).first();
    if(!lock){
      // A different tab or worker owns this paid request. Wait for its shared result.
      for(let i=0;i<40;i++){await new Promise(r=>setTimeout(r,400));const hit=await read();if(hit)return hit;}
      throw new FlightError('This lookup is still running. Try again in a moment.',429);
    }
    try {
      const hit=await read();if(hit)return hit;
      const at=clock(),month=new Date(at).toISOString().slice(0,7);
      const allowed=await database.prepare(`INSERT INTO service_cache (key,data,expires)
        SELECT ?,?,? WHERE
        (SELECT COALESCE(SUM(json_extract(data,'$.cost')),0) FROM service_cache WHERE key LIKE ?) + ? <= ?
        AND (SELECT COUNT(*) FROM service_cache WHERE key LIKE 'flightaware:usage:%' AND expires > ? AND json_extract(data,'$.at') > ?) < 10
        RETURNING key`).bind(`flightaware:usage:${month}:${token}`,JSON.stringify({cost,at}),at+62*86400000,`flightaware:usage:${month}:%`,cost,MONTHLY_FLIGHT_LIMIT,at,at-60000).first();
      if(!allowed)throw new FlightError('Flight lookup is paused by the request or monthly spending limit. Try again in a minute; Trips allows about $5 of AeroAPI requests per month.',429);
      let stored:Stored<T>;
      try {
        const response=await fetcher('https://aeroapi.flightaware.com/aeroapi'+path,{headers:{'x-apikey':key,Accept:'application/json'},signal:AbortSignal.timeout(15000),redirect:'manual'});
        if(!response.ok){
          const message=response.status===401?'FlightAware rejected the API key. Check the Trips secret.':response.status===402?'FlightAware requires billing to be enabled for this account.':response.status===403?'This AeroAPI account does not have access to this lookup. Check its plan and key permissions.':response.status===429?'FlightAware’s request limit was reached. Try again in a minute.':response.status===400?'FlightAware could not process this flight or date. Check the airline flight number.':'FlightAware is unavailable right now. Your saved flight is unchanged.';
          throw new FlightError(message,response.status===429?429:502);
        }
        const data=await response.json() as T;
        const empty=data&&typeof data==='object'&&['flights','scheduled'].some(k=>Array.isArray((data as Record<string,unknown>)[k])&&((data as Record<string,unknown[]>)[k]).length===0);
        stored={data,checkedAt:at,expires:at+(empty?Math.min(ttl,1800):ttl)*1000};
      }catch(e){console.error('AeroAPI request failed',e instanceof FlightError?e.status:e instanceof Error?e.name:'Unknown error');stored={error:e instanceof FlightError?e.message:'FlightAware did not respond. Try again in a minute.',status:e instanceof FlightError?e.status:502,checkedAt:at,expires:at+60000};}
      await database.prepare('INSERT INTO service_cache (key,data,expires) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET data=excluded.data, expires=excluded.expires').bind(cacheKey,JSON.stringify(stored),stored.expires).run();
      if(stored.error)throw new FlightError(stored.error,stored.status);
      return {data:stored.data!,checkedAt:stored.checkedAt,expires:stored.expires};
    }finally{await database.prepare('DELETE FROM service_cache WHERE key = ? AND data = ?').bind(lockKey,token).run();}
  };
}
