import { z } from 'zod';
import { placeSchema, tripSchema } from './trips';

export const chatMessageSchema = z.object({
  id: z.string().uuid(), tripId: z.union([z.string().uuid(), z.literal('general'), z.literal('example')]),
  message: z.string().trim().min(1).max(4000), day: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
}).strict();
export const versionedTripSchema = tripSchema.and(z.object({ version: z.number().int().positive() }));
export const localChatRequestSchema = chatMessageSchema.extend({
  trip: versionedTripSchema.nullable(),
  history: z.array(z.object({
    user: z.string().max(4000), assistant: z.string().max(24000), status: z.enum(['complete', 'undone']),
    places: z.array(placeSchema.extend({ reason: z.string().max(300), sourceUrl: z.string().max(2000).nullable() })).max(6),
  }).strict()).max(12),
}).superRefine((data, ctx) => {
  if (data.tripId === 'general' || data.tripId === 'example') {
    if (data.trip !== null) ctx.addIssue({ code: 'custom', message: 'Select your own trip to edit it.' });
  } else if (!data.trip || data.trip.id !== data.tripId) {
    ctx.addIssue({ code: 'custom', message: 'The current itinerary is required.' });
  }
});
export type LocalChatRequest = z.infer<typeof localChatRequestSchema>;

// Bound UTF-8 bytes as well as individual fields before the server's 100 KB gate.
export function fitChatRequest(request: LocalChatRequest): LocalChatRequest {
  const result = localChatRequestSchema.parse(request);
  while (new TextEncoder().encode(JSON.stringify(result)).byteLength > 95000) {
    if (!result.history.length) throw new Error('This itinerary is too large for the assistant. Try a smaller trip.');
    result.history.shift();
  }
  return result;
}
