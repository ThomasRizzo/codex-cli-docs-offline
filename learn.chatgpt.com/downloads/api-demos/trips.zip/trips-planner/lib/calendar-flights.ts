import { Temporal } from '@js-temporal/polyfill';
import { localFlightTime } from './flightaware';
import { DEFAULT_AIRPORT_EXIT_MINUTES } from './arrivals';
import { wallMinutes, wallDate } from './departures';
import type { Flight } from './trips';

// A continuous flight uses one calendar timezone, even when its two airports
// have different local clocks. Provider instants also cover overnight delays.
function flightInstant(flight:Flight,side:'departure'|'arrival') {
 const tracking=flight.flightaware;
 const stamp=side==='departure'?tracking?.actualOut||tracking?.estimatedOut||tracking?.scheduledOut:tracking?.actualIn||tracking?.estimatedIn||tracking?.scheduledIn;
 if(stamp&&Number.isFinite(Date.parse(stamp)))return Date.parse(stamp);
 const zone=side==='departure'?flight.departureTimeZone:flight.arrivalTimeZone;
 const date=side==='departure'?flight.date:flight.arrivalDate;
 const time=flight[side];
 if(!zone||wallMinutes(date,time)===null)return null;
 try{return Temporal.PlainDateTime.from(`${date}T${time}`).toZonedDateTime(zone,{disambiguation:'compatible'}).epochMilliseconds;}catch{return null;}
}
function localMinute(ms:number,zone:string){const local=localFlightTime(new Date(ms).toISOString(),zone);return wallMinutes(local.date,local.time)!;}
export function flightCalendarRange(flight:Flight,timeZone?:string){
 const zone=timeZone||flight.arrivalTimeZone||flight.departureTimeZone;
 const departureInstant=flightInstant(flight,'departure'),arrivalInstant=flightInstant(flight,'arrival');
 const departure=zone&&departureInstant!==null?localMinute(departureInstant,zone):wallMinutes(flight.date,flight.departure);
 const arrival=zone&&arrivalInstant!==null?localMinute(arrivalInstant,zone):wallMinutes(flight.arrivalDate,flight.arrival);
 if(departure===null||arrival===null||arrival<=departure)return null;
 const exitMinutes=flight.arrivalTransfer===false?0:flight.arrivalExitMinutes??DEFAULT_AIRPORT_EXIT_MINUTES;
 return {flight,departure,arrival,ready:arrival+exitMinutes,exitMinutes,zone};
}
export type FlightCalendarRange=NonNullable<ReturnType<typeof flightCalendarRange>>;
export function flightDayBlock(range:FlightCalendarRange,day:string){
 const start=wallMinutes(day,'00:00')!,from=Math.max(start,range.departure),to=Math.min(start+1440,range.ready);
 if(to<=from)return null;
 const flightEnd=Math.max(from,Math.min(to,range.arrival));
 return {...range,id:`flight:${range.flight.id}`,from:from-start,to:to-start,flightMinutes:flightEnd-from,exitMinutes:to-flightEnd,continuesBefore:range.departure<start,continuesAfter:range.ready>start+1440};
}
export function calendarMinuteInZone(minute:number,sourceZone?:string,targetZone?:string){
 if(!sourceZone||!targetZone||sourceZone===targetZone)return minute;
 const time=new Date(minute*60000).toISOString().slice(11,16);
 try{return localMinute(Temporal.PlainDateTime.from(`${wallDate(minute)}T${time}`).toZonedDateTime(sourceZone,{disambiguation:'compatible'}).epochMilliseconds,targetZone);}catch{return minute;}
}
