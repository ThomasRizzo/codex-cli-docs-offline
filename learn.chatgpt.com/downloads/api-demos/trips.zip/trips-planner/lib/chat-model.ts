import type { ChatSource, ChatEvent } from './chat-types';
export const CHAT_MODEL='gpt-6-astra';
export function safeSource(url:string):string|null {try{const u=new URL(url);return ['https:','http:'].includes(u.protocol)?u.href:null;}catch{return null;}}
export function extractAnswer(output:any[]):{text:string;sources:ChatSource[]} {
 const sources:ChatSource[]=[];
 const text=output.filter(x=>x.type==='message').flatMap(x=>x.content||[]).map(c=>{
  if(c.type==='refusal')return c.refusal||'';
  if(c.type!=='output_text')return '';
  let text=c.text||'';
  const annotations=(c.annotations||[]).filter((a:any)=>a.type==='url_citation'&&safeSource(a.url)).sort((a:any,b:any)=>b.start_index-a.start_index);
  for(const a of annotations){let index=sources.findIndex(s=>s.url===a.url);if(index<0){index=sources.length;sources.push({url:safeSource(a.url)!,title:String(a.title||new URL(a.url).hostname).slice(0,250)});}if(Number.isInteger(a.start_index)&&Number.isInteger(a.end_index)&&a.start_index>=0&&a.end_index<=text.length)text=text.slice(0,a.start_index)+`[${index+1}](${safeSource(a.url)!.replace(/\)/g,'%29')})`+text.slice(a.end_index);}
  return text;
 }).filter(Boolean).join('\n\n');
 return {text,sources};
}
export async function modelResponse(key:string,body:Record<string,unknown>,signal:AbortSignal,emit:(event:ChatEvent)=>void) {
 const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({...body,model:CHAT_MODEL,store:false,stream:true,reasoning:{effort:'low'},text:{verbosity:'low'},max_output_tokens:4000,max_tool_calls:3,include:['reasoning.encrypted_content','web_search_call.action.sources']}),signal,redirect:'manual'});
 if(!response.ok){let code='';try{code=(await response.json() as any).error?.code||'';}catch{}if(response.status===429)throw new Error(code==='insufficient_quota'?'OpenAI billing needs attention before chat can continue.':'The assistant is busy. Try again shortly.');if(response.status===401||response.status===403)throw new Error('The OpenAI connection needs attention.');throw new Error('The assistant could not complete this request. Please try again.');}
 if(!response.body)throw new Error('The assistant returned an empty response.');
 const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='',completed:any=null;
 const consume=(block:string)=>{const data=block.split('\n').filter(l=>l.startsWith('data:')).map(l=>l.slice(5).trim()).join('\n');if(!data||data==='[DONE]')return;const e=JSON.parse(data);if(e.type==='response.output_text.delta')emit({type:'delta',text:e.delta});if(e.type==='response.web_search_call.searching')emit({type:'status',text:'Searching the web…'});if(e.type==='response.completed')completed=e.response;if(e.type==='response.failed'||e.type==='error')throw new Error('The assistant could not finish. No itinerary changes were saved.');};
 try{for(;;){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true}).replace(/\r\n/g,'\n');let index;while((index=buffer.indexOf('\n\n'))>=0){consume(buffer.slice(0,index));buffer=buffer.slice(index+2);}}if(buffer.trim())consume(buffer);}finally{reader.releaseLock();}
 if(!completed||completed.status!=='completed')throw new Error('The response was interrupted. No itinerary changes were saved.');
 const searches=completed.output.filter((item:any)=>item.type==='web_search_call');
 if(searches.length)console.info('Trips web search',JSON.stringify(searches.map((item:any)=>({status:item.status,action:item.action?.type,sources:item.action?.sources?.length||0}))));
 return completed;
}
