let loading:Promise<any>|null=null;
export function loadGoogleMaps(key:string):Promise<any>{
 if((window as any).google?.maps?.Map)return Promise.resolve((window as any).google.maps);
 if(loading)return loading;
 loading=new Promise((resolve,reject)=>{const script=document.createElement('script');const timer=setTimeout(()=>{loading=null;reject(new Error('Google Maps is taking too long to load.'));},20000);(window as any).tripsGoogleMapsReady=()=>{clearTimeout(timer);resolve((window as any).google.maps);delete (window as any).tripsGoogleMapsReady;};script.src='https://maps.googleapis.com/maps/api/js?'+new URLSearchParams({key,v:'quarterly',loading:'async',callback:'tripsGoogleMapsReady'});script.async=true;script.onerror=()=>{clearTimeout(timer);loading=null;script.remove();reject(new Error('Google Maps could not load.'));};document.head.appendChild(script);});return loading;
}
