import type { Route } from './trips';
import { eventAccent } from './event-colors';

export const routeStroke={weight:6,outlineWeight:9,outlineColor:'#ffffff'};
type Point=Route['shape'][number];
type Segment={path:Point[];color:string};
const mix=(from:string,to:string,t:number)=>'#'+[1,3,5].map(i=>Math.round(parseInt(from.slice(i,i+2),16)*(1-t)+parseInt(to.slice(i,i+2),16)*t).toString(16).padStart(2,'0')).join('');

// Blend by distance along the road, retaining every bend. Both map renderers
// use a bounded number of adjoining solid strokes, with shared endpoints.
export function routeGradient(shape:Point[],fromIndex:number|string,toIndex:number|string):Segment[]{
 if(shape.length<2)return [];
 const distances=[0];
 for(let i=1;i<shape.length;i++){
  const [a,b]=[shape[i-1],shape[i]];
  distances.push(distances[i-1]+Math.hypot(b[0]-a[0],(b[1]-a[1])*Math.cos((a[0]+b[0])*Math.PI/360)));
 }
 const total=distances[distances.length-1];
 if(!total)return [];
 const from=typeof fromIndex==='string'?fromIndex:eventAccent(fromIndex),to=typeof toIndex==='string'?toIndex:eventAccent(toIndex);
 if(from===to)return [{path:shape,color:from}];
 const count=32,segments:Segment[]=[];
 let cursor=1,start=shape[0];
 for(let i=0;i<count;i++){
  const end=total*(i+1)/count,path:Point[]=[start];
  while(cursor<shape.length-1&&distances[cursor]<end){path.push(shape[cursor]);cursor++;}
  const a=shape[cursor-1],b=shape[cursor],span=distances[cursor]-distances[cursor-1];
  const t=span?(end-distances[cursor-1])/span:1;
  const point:Point=i===count-1?shape[shape.length-1]:[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];
  path.push(point);segments.push({path,color:mix(from,to,i/(count-1))});start=point;
 }
 return segments;
}
