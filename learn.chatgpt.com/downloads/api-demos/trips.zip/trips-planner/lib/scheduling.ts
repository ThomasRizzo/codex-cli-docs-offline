import { hotelCheckInIssue, hasLocation, sameLocation, routeKey, type Place, type Stop, type Trip, type Route } from './trips';
import { stopDuration, stopEndMinute, stopMinute } from './event-duration';

export type ScheduleItem = { place: Place | Stop; stopId?: string };
export type CalendarChange = {trip:Trip;stop:Stop;previous?:Stop;swapped?:Stop};
export function snapCalendarMinute(offset: number, firstMinute: number, lastMinute: number, scale = 1.5) {
  return Math.max(firstMinute, Math.min(Math.min(lastMinute, 1425), Math.round((firstMinute + offset / scale) / 15) * 15));
}
export function calendarTime(minute: number) {
  return `${String(Math.floor(minute / 60)).padStart(2, '0')}:${String(minute % 60).padStart(2, '0')}`;
}
function orderCalendarDays(stops:Stop[],dates:string[]) {
 for(const date of new Set(dates)){
  const ordered=stops.filter(s=>s.date===date).sort((a,b)=>(a.time||'24:00').localeCompare(b.time||'24:00'));
  let index=0;stops=stops.map(s=>s.date===date?ordered[index++]:s);
 }
 return stops;
}
// Swap whole visits, retaining the gaps between slots instead of assigning a
// longer visit to a shorter visit's start time. Rebuild from the original order
// on every pass so newly loaded routes and optimistic rebases cannot compound shifts.
export function fitCalendarSwap(before:Trip,change:CalendarChange,routes:Record<string,Route>={}):CalendarChange {
 if(!change.swapped)return change;
 const sourceId=change.stop.id,targetId=change.swapped.id;
 const previous=before.stops.find(s=>s.id===sourceId)!,target=before.stops.find(s=>s.id===targetId)!;
 const byId=new Map(change.trip.stops.map(s=>[s.id,s])),updates=new Map<string,Stop>();
 const travel=(from:Stop,to:Stop)=>hasLocation(from)&&hasLocation(to)&&!sameLocation(from,to)?routes[routeKey(from,to,to.mode)]?.minutes??0:0;
 for(const date of new Set([previous.date,target.date])){
  const original=before.stops.filter(s=>s.date===date&&s.time).sort((a,b)=>a.time.localeCompare(b.time));
  const affected=original.flatMap((s,i)=>s.id===sourceId||s.id===targetId?[i]:[]),first=affected[0],last=affected.at(-1)!;
  const ordered=original.map(s=>byId.get(s.id===sourceId?targetId:s.id===targetId?sourceId:s.id)!);
  for(let i=first;i<ordered.length;i++){
   const slot=original[i],event=ordered[i],prior=ordered[i-1];
   const oldStart=stopMinute(slot)!;
   const gap=i?Math.max(0,oldStart-stopEndMinute(original[i-1])!):0;
   let minute=i>first&&i<=last?stopEndMinute(prior)!+gap:oldStart;
   if(prior)minute=Math.max(minute,stopEndMinute(prior)!+travel(prior,event));
   // A custom event without a location still occupies time on the route
   // between the known places either side of it.
   if(hasLocation(event)){
    let occupied=0;
    for(let j=i-1;j>=0;j--){
     const from=ordered[j];
     if(hasLocation(from)){minute=Math.max(minute,stopEndMinute(from)!+occupied+travel(from,event));break;}
     occupied+=stopDuration(from);
    }
   }
   // Only the two explicitly swapped bookings may move. Other reservations
   // remain fixed, even if a longer journey would push the day into them.
   if(event.booked&&event.id!==sourceId&&event.id!==targetId){
    if(minute>oldStart)throw new Error(`This swap would move your booking at ${event.name}. Make more room before swapping.`);
    minute=oldStart;
   }
   if(minute!==oldStart)minute=Math.ceil(minute/15)*15;
   const time=calendarTime(minute),updated={...event,date,time,durationMinutes:stopDuration(event)};
   if(minute+stopDuration(updated)>1440)throw new Error(`${event.name} would end after midnight. Make more room before swapping.`);
   const issue=hotelCheckInIssue(updated,change.trip);if(issue)throw new Error(issue);
   ordered[i]=updated;
   updates.set(event.id,event.date===date&&event.time===time?event:updated);
   if(i>last&&hasLocation(event)&&minute===oldStart)break;
  }
 }
 const trip={...change.trip,stops:orderCalendarDays(change.trip.stops.map(s=>updates.get(s.id)||s),[previous.date,target.date])};
 return {...change,trip,stop:trip.stops.find(s=>s.id===sourceId)!,swapped:trip.stops.find(s=>s.id===targetId)!};
}
export function swapCalendarStops(trip:Trip,sourceId:string,targetId:string):CalendarChange {
 const previous=trip.stops.find(s=>s.id===sourceId),target=trip.stops.find(s=>s.id===targetId);
 if(!previous||!target)throw new Error('One of these events was removed. Refresh your trip.');
 if(sourceId===targetId)throw new Error('Choose another event to swap with.');
 if(!previous.time||!target.time)throw new Error('Both events need a scheduled time before swapping.');
 // Exchange identities first, then fit their complete durations into the order.
 const stop={...previous,date:target.date,time:target.time,durationMinutes:stopDuration(previous)};
 const swapped={...target,date:previous.date,time:previous.time,durationMinutes:stopDuration(target)};
 const stops=trip.stops.map(s=>s.id===sourceId?stop:s.id===targetId?swapped:s);
 return fitCalendarSwap(trip,{trip:{...trip,stops},stop,previous,swapped});
}
export function placeOnCalendar(trip: Trip, item: ScheduleItem, date: string, time: string, id: string, swapId?:string):CalendarChange {
  if (date < trip.start || date > trip.end) throw new Error('Choose a day within this trip.');
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new Error('Choose a valid time.');
  if(swapId){
   if(!item.stopId)throw new Error('Add this place to the calendar before swapping.');
   if(trip.stops.find(s=>s.id===swapId)?.date!==date)throw new Error('This event has moved. Choose it again to swap.');
   return swapCalendarStops(trip,item.stopId,swapId);
  }
  const previous = item.stopId ? trip.stops.find(s => s.id === item.stopId) : trip.stops.find(s => s.kind!=='event' && hasLocation(s) && hasLocation(item.place) && s.date === date && Math.abs(s.lat - item.place.lat) < .0001 && Math.abs(s.lng - item.place.lng) < .0001);
  if (item.stopId && !previous) throw new Error('This place was removed. Refresh your trip.');
  const {name,address,lat,lng}=item.place;
  const stop: Stop = previous ? {...previous,date,time,durationMinutes:stopDuration(previous)} : {id,name,address,lat,lng,date,time,note:'',mode:'walk',durationMinutes:stopDuration({time})};
  const checkInIssue=hotelCheckInIssue(stop,trip);if(checkInIssue)throw new Error(checkInIssue);
  if(stopEndMinute(stop)!>1440)throw new Error('This visit would end after midnight. Choose an earlier start.');
  const stops = previous ? trip.stops.map(s => s.id === previous.id ? stop : s) : [...trip.stops,stop];
  // Keep route order in step with the calendar without reordering other days.
  return {trip:{...trip,stops:orderCalendarDays(stops,[date])},stop,previous};
}

export function resizeCalendarStop(trip:Trip,id:string,durationMinutes:number) {
 const previous=trip.stops.find(stop=>stop.id===id);
 if(!previous)throw new Error('This place was removed. Refresh your trip.');
 if(!previous.time)throw new Error('Set a start time before resizing this place.');
 if(!Number.isInteger(durationMinutes)||durationMinutes<1||durationMinutes>1440)throw new Error('Choose a valid duration.');
 const stop={...previous,durationMinutes};
 const checkInIssue=hotelCheckInIssue(stop,trip);if(checkInIssue)throw new Error(checkInIssue);
 if(stopEndMinute(stop)!>1440)throw new Error('This visit would end after midnight. Shorten it or choose an earlier start.');
 return {trip:{...trip,stops:trip.stops.map(s=>s.id===id?stop:s)},stop,previous};
}
