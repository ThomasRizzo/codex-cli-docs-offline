import { z } from 'zod';
import { flightAwareSchema } from './flightaware';
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v => { const d=new Date(v+'T12:00:00Z'); return !isNaN(+d) && d.toISOString().slice(0,10)===v; }, 'Choose a valid date.');
const timeZone = z.string().max(80).refine(v => { try { new Intl.DateTimeFormat('en', {timeZone:v}); return true; } catch { return false; } }, 'Choose a valid time zone.');
const coordinate = { lat: z.number().min(-85).max(85), lng: z.number().min(-180).max(180) };
export const placeSchema = z.object({ id:z.string().max(100), name:z.string().trim().min(1).max(160), address:z.string().max(400), ...coordinate });
export const stopSchema = placeSchema.extend({id:z.string().max(160),hotelCheckInId:z.string().max(100).optional(),kind:z.enum(['place','event']).optional(),booked:z.boolean().optional(),locationName:z.string().max(160).optional(),lat:coordinate.lat.optional(),lng:coordinate.lng.optional(),date, time:z.string().regex(/^$|^([01]\d|2[0-3]):[0-5]\d$/), note:z.string().max(1500), mode:z.enum(['walk','uber']), durationMinutes:z.number().int().min(1).max(1440).optional(), timeZone:timeZone.optional()}).superRefine((s,ctx)=>{if((s.lat===undefined)!==(s.lng===undefined)||s.kind!=='event'&&(s.lat===undefined||s.lng===undefined))ctx.addIssue({code:'custom',message:'Choose a location for this place.'});});
export const hotelSchema = placeSchema.extend({checkIn:date,checkOut:date,checkInFrom:z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/).optional(),note:z.string().max(1500),returnModes:z.record(date,z.enum(['walk','uber'])).optional()}).refine(h=>h.checkOut>h.checkIn && (+new Date(h.checkOut)-+new Date(h.checkIn))/86400000<=91,'Check-out must be after check-in, within 91 nights.');
export const departurePlanSchema = z.object({
  airport: placeSchema,
  originStopId: z.string().max(100).nullable(),
  originPlace: placeSchema.nullable(),
  kind: z.enum(['domestic', 'international']),
  arrivalMinutes: z.number().int().min(30).max(480),
  extraMinutes: z.number().int().min(0).max(180),
  driveOverrideMinutes: z.number().int().min(1).max(1440).nullable(),
}).refine(p => !!p.originStopId || !!p.originPlace, 'Choose where you will leave from.');
export const flightSchema = z.object({ id:z.string().max(100), number:z.string().trim().min(2).max(12), date, from:z.string().max(80), to:z.string().max(80), departure:z.string().max(40), arrival:z.string().max(40), arrivalDate:date, arrivalAirport:placeSchema.optional(),arrivalExitMinutes:z.number().int().min(0).max(240).optional(),arrivalMode:z.enum(['walk','uber']).optional(),arrivalTransfer:z.boolean().optional(), scheduledDeparture:z.string().regex(/^$|^([01]\d|2[0-3]):[0-5]\d$/).optional(), departurePlan:departurePlanSchema.optional(), departureTimeZone:timeZone.optional(), arrivalTimeZone:timeZone.optional(), flightaware:flightAwareSchema.optional() });
const tripDataSchema = z.object({id:z.string().uuid(), name:z.string().trim().min(1).max(100), destination:placeSchema, timeZone:timeZone.optional(), start:date, end:date, stops:z.array(stopSchema).max(500), flights:z.array(flightSchema).max(30),hotels:z.array(hotelSchema).max(30).optional()});
// Existing stays acquire one normal calendar event on their arrival day. The
// stable ID lets the same event move, resize, sync, and survive a reload.
export function withHotelCheckIns<T extends z.infer<typeof tripDataSchema>>(trip:T):T {
 const hotels=trip.hotels||[];
 const stops=trip.stops.filter(s=>!s.hotelCheckInId||hotels.some(h=>h.id===s.hotelCheckInId&&h.checkIn>=trip.start&&h.checkIn<=trip.end));
 for(const hotel of hotels){
  if(hotel.checkIn<trip.start||hotel.checkIn>trip.end)continue;
  const old=stops.find(s=>s.hotelCheckInId===hotel.id);
  const time=old?.time||hotel.checkInFrom||'15:00';
  const event:z.infer<typeof stopSchema>={...old,id:old?.id||`check-in:${hotel.id}`,hotelCheckInId:hotel.id,kind:'event',name:`Check in · ${hotel.name}`.slice(0,160),locationName:hotel.name,address:hotel.address,lat:hotel.lat,lng:hotel.lng,date:hotel.checkIn,time,durationMinutes:old?.durationMinutes??Math.min(30,1440-Number(time.slice(0,2))*60-Number(time.slice(3))),mode:old?.mode||hotel.returnModes?.[hotel.checkIn]||'walk',note:old?.note||''};
  if(old)stops[stops.indexOf(old)]=event;else stops.push(event);
 }
 return {...trip,stops};
}
export function hotelCheckInIssue(stop:Pick<Stop,'hotelCheckInId'|'date'|'time'>,trip:Pick<Trip,'hotels'>){
 if(!stop.hotelCheckInId)return null;
 const hotel=trip.hotels?.find(h=>h.id===stop.hotelCheckInId);
 if(!hotel)return 'This hotel stay was removed.';
 if(stop.date!==hotel.checkIn)return 'Keep check-in on the hotel arrival day. Edit the hotel stay to change its dates.';
 const from=hotel.checkInFrom||'15:00';
 if(!stop.time||stop.time<from){const [h,m]=from.split(':').map(Number);return `Check-in opens at ${h%12||12}:${String(m).padStart(2,'0')} ${h<12?'am':'pm'}. Choose that time or later.`;}
 return null;
}
export const tripSchema = tripDataSchema.transform(withHotelCheckIns).superRefine((t,ctx)=>{for(const stop of t.stops){const issue=hotelCheckInIssue(stop,t);if(issue)ctx.addIssue({code:'custom',message:issue});}if(t.end<t.start || (+new Date(t.end)-+new Date(t.start))/86400000>90)ctx.addIssue({code:'custom',message:'Trips can be between 1 and 91 days.'}); if(t.stops.some(s=>s.date<t.start||s.date>t.end))ctx.addIssue({code:'custom',message:'Move or remove stops outside the new dates first.'});if(t.stops.some(s=>s.time&&s.durationMinutes!==undefined&&Number(s.time.slice(0,2))*60+Number(s.time.slice(3))+s.durationMinutes>1440))ctx.addIssue({code:'custom',message:'An event must finish by midnight. Shorten the visit or choose an earlier start.'});const hotels=[...(t.hotels||[])].sort((a,b)=>a.checkIn.localeCompare(b.checkIn));if(hotels.some(h=>h.checkOut<t.start||h.checkIn>t.end))ctx.addIssue({code:'custom',message:'Hotel stays must overlap the trip dates.'});if(hotels.some((h,i)=>i>0&&h.checkIn<hotels[i-1].checkOut))ctx.addIssue({code:'custom',message:'Hotel stays cannot overlap. Use the checkout date to change hotels.'});if(new Set(hotels.map(h=>h.id)).size!==hotels.length)ctx.addIssue({code:'custom',message:'Duplicate hotel IDs.'});const checkIns=t.stops.filter(s=>s.hotelCheckInId);if(new Set(checkIns.map(s=>s.hotelCheckInId)).size!==checkIns.length)ctx.addIssue({code:'custom',message:'Each hotel stay can have only one check-in event.'});if(new Set(t.stops.map(s=>s.id)).size!==t.stops.length || new Set(t.flights.map(f=>f.id)).size!==t.flights.length)ctx.addIssue({code:'custom',message:'Duplicate item IDs.'});});
export type Hotel = z.infer<typeof hotelSchema>;
export type Place = z.infer<typeof placeSchema>;
export type Stop = z.infer<typeof stopSchema>;
export type LocatedStop = Stop & Place;
export function hasLocation<T extends {lat?:number;lng?:number}>(item:T):item is T & {lat:number;lng:number}{return typeof item.lat==='number'&&typeof item.lng==='number';}
export function sameLocation(a:{lat?:number;lng?:number},b:{lat?:number;lng?:number}){return hasLocation(a)&&hasLocation(b)&&a.lat===b.lat&&a.lng===b.lng;}
export type DeparturePlan = z.infer<typeof departurePlanSchema>;
export type Flight = z.infer<typeof flightSchema>;
export type Trip = z.infer<typeof tripSchema> & {version:number};
export type Route = {minutes:number; km:number; shape:[number,number][]; source:'route'; mode:'walk'|'uber'};
export function days(start:string,end:string){const out:string[]=[];for(let d=new Date(start+'T12:00:00Z');d<=new Date(end+'T12:00:00Z')&&out.length<91;d.setUTCDate(d.getUTCDate()+1))out.push(d.toISOString().slice(0,10));return out;}
export function formatDate(date:string,options:Intl.DateTimeFormatOptions={month:'short',day:'numeric'}){return new Date(date+'T12:00:00Z').toLocaleDateString('en-US',{...options,timeZone:'UTC'});}
export function duration(minutes:number){return minutes>=60?`${Math.floor(minutes/60)} hr${minutes%60?` ${minutes%60} min`:''}`:`${minutes} min`;}
export function routeKey(a:Place,b:Place,mode:string){return `${a.lat.toFixed(5)},${a.lng.toFixed(5)}:${b.lat.toFixed(5)},${b.lng.toFixed(5)}:${mode}`;}
