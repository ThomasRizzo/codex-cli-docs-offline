// These accents match the calendar event borders in workspace.css.
export const eventAccents={lavender:'#9a86c3',blue:'#7ba6b9',sage:'#91aa83',rose:'#c398a0'} as const;
// Use each stop's position in the day's route, alternating contrasting hues.
// Calendar cards and both maps share this sequence, including untimed stops.
const tones=['lavender','sage','rose','blue'] as const;
export const eventTone=(index:number)=>tones[index%tones.length];
export const eventAccent=(index:number)=>eventAccents[eventTone(index)];
