export function assistantEnabled(config: {
  TRIPS_ASSISTANT_ENABLED?: string;
  OPENAI_API_KEY?: string;
}) {
  return config.TRIPS_ASSISTANT_ENABLED === 'true' && !!config.OPENAI_API_KEY;
}
