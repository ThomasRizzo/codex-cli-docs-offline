// Identity comes from the Sites gateway. Sign-in alone is not editing access.
export function isTripOwner(userId: string | null | undefined, ownerId: string | undefined) {
  return !!ownerId && !!userId && userId === ownerId;
}
