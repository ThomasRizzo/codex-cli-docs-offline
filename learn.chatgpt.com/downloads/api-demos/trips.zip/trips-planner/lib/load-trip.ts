import { env } from 'cloudflare:workers';
import { db } from './server';
import { flightQuery } from './flightaware-cache';
import { enrichArrivalAirports } from './arrival-airports';
import { chooseTravelModes } from './auto-travel';
import { loadRoute } from './route-service';
import { tripSchema, type Trip } from './trips';

// Older saved stays acquire a check-in event on read. Resolve its new travel
// legs too, just as when adding a hotel through the planner. Cached routes make
// repeated reads cheap until the next edit saves the expanded itinerary.
export async function loadTrip(data:string,version:number):Promise<Trip>{
 const stored={...JSON.parse(data),version} as Trip;
 let trip={...tripSchema.parse(stored),version};
 if(env.FLIGHTAWARE_API_KEY)trip=await enrichArrivalAirports(trip,flightQuery(db(),env.FLIGHTAWARE_API_KEY));
 try{return await chooseTravelModes(stored,trip,loadRoute);}
 catch{return trip;}
}
