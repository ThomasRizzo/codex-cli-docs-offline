import { enforceDemoRateLimit } from './demo-rate-limit';
import { requireDemoOrigin } from './demo-session';
import { privateHeaders } from './site-policy';

export function demoUnavailablePath(path: string): boolean {
  return /^\/(?:share(?:\/|$)|api\/(?:share|shared|calendar|account|flights)(?:\/|$))/.test(path);
}

/** Guard all demo APIs before framework dispatch, including public legacy links. */
export async function prepareDemoRequest(request: Request, database?: D1Database): Promise<Request | Response> {
  let path: string;
  try { path = decodeURIComponent(new URL(request.url).pathname).replace(/\/{2,}/g, '/'); }
  catch { return Response.json({ error: 'Invalid path.' }, { status: 400, headers: privateHeaders }); }
  if (demoUnavailablePath(path)) return Response.json({ error: 'This feature is unavailable in the demo.' }, { status: 404, headers: privateHeaders });
  if (!path.startsWith('/api/')) return request;
  try {
    if (!['GET', 'HEAD'].includes(request.method)) requireDemoOrigin(request);
    const limited = await enforceDemoRateLimit(database, request, 'api', { minute: 120, day: 2000 });
    if (limited) return limited;
    // Bound the body before authentication/DB work so slow uploads cannot leave
    // writes running after an expired session has been swept from storage.
    if (!request.body) return request;
    const reader = request.body.getReader(), chunks: Uint8Array[] = [];
    let size = 0, timedOut = false;
    const timer = setTimeout(() => { timedOut = true; void reader.cancel().catch(() => {}); }, 10000);
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (timedOut) throw Response.json({ error: 'The request took too long. Try again.' }, { status: 408, headers: privateHeaders });
        if (done) break;
        size += value.byteLength;
        if (size > 100000) {
          await reader.cancel();
          throw Response.json({ error: 'This demo request is too large.' }, { status: 413, headers: privateHeaders });
        }
        chunks.push(value);
      }
    } finally { clearTimeout(timer); reader.releaseLock(); }
    const body = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) { body.set(chunk, offset); offset += chunk.length; }
    return new Request(request, { body });
  } catch (error) {
    return error instanceof Response ? error : Response.json({ error: 'The demo is temporarily unavailable.' }, { status: 503, headers: privateHeaders });
  }
}
