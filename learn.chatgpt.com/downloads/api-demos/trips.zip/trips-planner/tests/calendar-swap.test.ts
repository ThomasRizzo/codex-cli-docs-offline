import test from 'node:test';
import assert from 'node:assert/strict';
import { example } from '../lib/example';
import { placeOnCalendar, swapCalendarStops, fitCalendarSwap } from '../lib/scheduling';
import { changedTravelLegs, scheduleTravelAvailability } from '../lib/schedule-travel';
import { previewTravelModes } from '../lib/auto-travel';
import { withHotelCheckIns, routeKey, type LocatedStop, type Route, type Trip } from '../lib/trips';
import { OptimisticTrips } from '../lib/optimistic-trips';

const a:LocatedStop={...example.stops[0],id:'a',name:'Coffee',time:'09:00',durationMinutes:30,booked:true,note:'Keep this reservation',timeZone:'America/Los_Angeles'};
const b:LocatedStop={...example.stops[1],id:'b',name:'Museum',time:'10:30',durationMinutes:60};
const c:LocatedStop={...example.stops[2],id:'c',name:'Lunch',time:'13:00',durationMinutes:45};
const trip:Trip={...example,stops:[a,b,c],flights:[],version:2};
const route=(minutes:number,mode:Route['mode']='walk'):Route=>({minutes,mode,km:1,shape:[],source:'route'});

test('a swap changes both slots together, preserves event details, and leaves other events untouched',()=>{
 const before=JSON.stringify(trip),result=swapCalendarStops(trip,a.id,b.id);
 assert.deepEqual(result.stop,{...a,time:'11:00'});assert.deepEqual(result.swapped,{...b,time:a.time});
 assert.deepEqual(result.trip.stops.map(s=>s.id),['b','a','c']);assert.equal(result.trip.stops[2],c);
 assert.equal(JSON.stringify(trip),before);assert.equal(result.trip.version,trip.version);
 const undone=swapCalendarStops(result.trip,a.id,b.id).trip;
 assert.deepEqual(undone,trip);
});
test('dropping anywhere on a card reorders complete visits, independent of pointer time',()=>{
 const result=placeOnCalendar(trip,{place:a,stopId:a.id},trip.start,'10:45','unused',b.id);
 assert.equal(result.stop.time,'11:00');assert.equal(result.swapped?.time,'09:00');
 assert.equal(result.trip.stops.length,3);
});

const leCoin:LocatedStop={...a,name:'Le Coin',time:'09:30',durationMinutes:45};
const milstead:LocatedStop={...b,name:'Milstead & Co.',time:'10:30',durationMinutes:30};
const needle:LocatedStop={...c,name:'Space Needle',time:'11:15',mode:'uber',durationMinutes:60};
const morning:Trip={...trip,stops:[leCoin,milstead,needle]};
const morningRoutes={
 [routeKey(milstead,leCoin,'walk')]:route(13),
 [routeKey(leCoin,needle,'uber')]:route(7,'uber'),
};
test('Le Coin and Milstead swap with their durations and 15-minute travel gaps intact',()=>{
 for(const [from,to] of [[leCoin,milstead],[milstead,leCoin]]){
  const result=fitCalendarSwap(morning,swapCalendarStops(morning,from.id,to.id),morningRoutes);
  assert.deepEqual(result.trip.stops.map(s=>[s.name,s.time,s.durationMinutes]),[
   ['Milstead & Co.','09:30',30],['Le Coin','10:15',45],['Space Needle','11:15',60],
  ]);
  assert.equal(scheduleTravelAvailability(changedTravelLegs(morning.stops,result.trip.stops),morningRoutes).status,'ready');
  assert.equal(result.trip.stops[2],needle);
  assert.equal(result.trip.stops[1].booked,true);
 }
});
test('new travel that exceeds the old gap shifts flexible events on the 15-minute grid',()=>{
 const cached={...morningRoutes,[routeKey(milstead,leCoin,'walk')]:route(22)};
 const change=swapCalendarStops(morning,leCoin.id,milstead.id),result=fitCalendarSwap(morning,change,cached);
 assert.deepEqual(result.trip.stops.map(s=>s.time),['09:30','10:30','11:30']);
 assert.equal(scheduleTravelAvailability(changedTravelLegs(morning.stops,result.trip.stops),cached).status,'ready');
 assert.deepEqual(fitCalendarSwap(morning,result,cached).trip,result.trip);
});
test('a longer route after the swapped pair also gets enough time',()=>{
 const cached={...morningRoutes,[routeKey(leCoin,needle,'uber')]:route(19,'uber')};
 const result=fitCalendarSwap(morning,swapCalendarStops(morning,leCoin.id,milstead.id),cached);
 assert.deepEqual(result.trip.stops.map(s=>s.time),['09:30','10:15','11:30']);
 assert.equal(scheduleTravelAvailability(changedTravelLegs(morning.stops,result.trip.stops),cached).status,'ready');
});
test('later slack absorbs a longer journey instead of moving the rest of the day',()=>{
 const source={...morning,stops:[leCoin,milstead,{...needle,time:'12:00'}]};
 const cached={...morningRoutes,[routeKey(milstead,leCoin,'walk')]:route(22)};
 const result=fitCalendarSwap(source,swapCalendarStops(source,leCoin.id,milstead.id),cached);
 assert.deepEqual(result.trip.stops.map(s=>s.time),['09:30','10:30','12:00']);
});
test('unselected bookings stay fixed and stop a swap that cannot fit',()=>{
 const source={...morning,stops:[leCoin,milstead,{...needle,booked:true}]};
 const swapped=swapCalendarStops(source,leCoin.id,milstead.id);
 assert.equal(fitCalendarSwap(source,swapped,morningRoutes).trip.stops[2].time,'11:15');
 assert.throws(()=>fitCalendarSwap(source,swapped,{...morningRoutes,[routeKey(leCoin,needle,'uber')]:route(19,'uber')}),/booking at Space Needle/);
});
test('a nonadjacent swap retains the intervening events and their travel gaps',()=>{
 const source={...trip,stops:[{...a,booked:false},{...b,durationMinutes:15},c]};
 const result=swapCalendarStops(source,a.id,c.id);
 assert.deepEqual(result.trip.stops.map(s=>[s.id,s.time,s.durationMinutes]),[['c','09:00',45],['b','10:45',15],['a','13:15',30]]);
 assert.deepEqual(changedTravelLegs(source.stops,result.trip.stops).map(l=>l.gap),[60,135]);
});
test('events without a location still reserve time between routed places',()=>{
 const call={...b,id:'call',name:'Call',kind:'event' as const,lat:undefined,lng:undefined,time:'11:15',durationMinutes:15};
 const source={...morning,stops:[leCoin,milstead,call,{...needle,time:'11:45'}]};
 const cached={...morningRoutes,[routeKey(leCoin,needle,'uber')]:route(40,'uber')};
 const result=fitCalendarSwap(source,swapCalendarStops(source,leCoin.id,milstead.id),cached);
 assert.deepEqual(result.trip.stops.map(s=>s.time),['09:30','10:15','11:15','12:00']);
 assert.equal(scheduleTravelAvailability(changedTravelLegs(source.stops,result.trip.stops),cached).status,'ready');
});
test('an existing conflict elsewhere does not get moved by the swap',()=>{
 const later={...c,id:'later',time:'11:30'};
 const source={...morning,stops:[...morning.stops,later]};
 const result=fitCalendarSwap(source,swapCalendarStops(source,leCoin.id,milstead.id),morningRoutes);
 assert.equal(result.trip.stops.find(s=>s.id==='later'),later);
});
test('cross-day swaps exchange dates too and preserve durations and unscheduled items',()=>{
 const second={...b,date:trip.end},untimed={...c,id:'later',time:''};
 const result=swapCalendarStops({...trip,stops:[a,c,second,untimed]},a.id,second.id);
 assert.equal(result.stop.date,trip.end);assert.equal(result.stop.time,b.time);
 assert.equal(result.swapped?.date,trip.start);assert.equal(result.swapped?.time,a.time);
 assert.equal(result.trip.stops.find(s=>s.id==='later'),untimed);
});
test('missing, stale, unscheduled and self targets cannot cause a partial move',()=>{
 for(const [source,target] of [['missing','b'],['a','missing'],['a','a']])assert.throws(()=>swapCalendarStops(trip,source,target));
 assert.throws(()=>swapCalendarStops({...trip,stops:[{...a,time:''},b]},a.id,b.id),/scheduled time/);
 assert.throws(()=>placeOnCalendar(trip,{place:a},trip.start,b.time,'new',b.id),/before swapping/);
 assert.throws(()=>placeOnCalendar(trip,{place:a,stopId:a.id},trip.end,b.time,'new',b.id),/has moved/);
});
test('both swapped events retain midnight and hotel check-in constraints',()=>{
 const late={...b,date:trip.end,time:'23:30',durationMinutes:15};
 assert.throws(()=>swapCalendarStops({...trip,stops:[{...a,durationMinutes:60},late]},a.id,b.id),/midnight/);
 const hotel={...a,id:'hotel',checkIn:trip.start,checkOut:trip.end,note:'',checkInFrom:'15:00'};
 const hotelTrip=withHotelCheckIns({...trip,hotels:[hotel]}),checkIn=hotelTrip.stops.find(s=>s.hotelCheckInId)!;
 assert.throws(()=>swapCalendarStops(hotelTrip,a.id,checkIn.id),/Check-in opens at/);
 assert.throws(()=>swapCalendarStops(hotelTrip,checkIn.id,a.id),/Check-in opens at/);
});
test('swapping checks the new travel route, without validating a temporary overlap',()=>{
 const next=swapCalendarStops(trip,a.id,b.id).trip,legs=changedTravelLegs(trip.stops,next.stops);
 assert.deepEqual(legs.map(l=>[l.from.id,l.to.id,l.gap]),[['b','a',60],['a','c',90]]);
 const oldRoutes={[routeKey(a,b,'walk')]:route(5),[routeKey(b,c,'walk')]:route(5)};
 assert.equal(scheduleTravelAvailability(legs,oldRoutes).status,'checking');
 const resolved={...oldRoutes,[routeKey(b,a,'walk')]:route(20),[routeKey(a,c,'walk')]:route(15)};
 assert.equal(scheduleTravelAvailability(legs,resolved).status,'ready');
 assert.equal(scheduleTravelAvailability(legs,{...resolved,[routeKey(b,a,'walk')]:route(70)}).status,'blocked');
 assert.equal(scheduleTravelAvailability(legs,{...resolved,[routeKey(a,c,'walk')]:route(130)}).status,'blocked');
 const ordinary=placeOnCalendar(trip,{place:a,stopId:a.id},trip.start,b.time,'unused').trip;
 assert.equal(scheduleTravelAvailability(changedTravelLegs(trip.stops,ordinary.stops),resolved).status,'blocked');
});
test('new long walking routes use the existing Uber rule when evaluating a swap',()=>{
 const next=swapCalendarStops(trip,a.id,b.id).trip;
 const routes={ [routeKey(b,a,'walk')]:route(40),[routeKey(b,a,'uber')]:route(10,'uber'),[routeKey(a,c,'walk')]:route(15) };
 const planned=previewTravelModes(trip,next,routes);
 assert.equal(planned.stops.find(s=>s.id===a.id)?.mode,'uber');
 assert.equal(scheduleTravelAvailability(changedTravelLegs(trip.stops,planned.stops),routes).status,'ready');
});
test('unequal durations preserve the travel gaps without overlapping the next event',()=>{
 const source={...trip,stops:[{...a,durationMinutes:90},{...b,time:'11:00',durationMinutes:30},{...c,time:'12:00'}]};
 const next=swapCalendarStops(source,a.id,b.id).trip;
 assert.deepEqual(next.stops.map(s=>[s.id,s.time]),[['b','09:00'],['a','10:00'],['c','12:00']]);
 assert.deepEqual(changedTravelLegs(source.stops,next.stops).map(l=>l.gap),[30,30]);
});
test('optimistic swapping is immediate and a failed save restores both events together',async()=>{
 let shown=trip,requests=0,rejectSave!:(e:Error)=>void;
 const queue=new OptimisticTrips({save:async()=>{requests++;return new Promise<Trip>((_,reject)=>{rejectSave=reject;});},reload:async()=>trip,onChange:t=>{shown=t;},onPending:()=>{},onError:()=>{}});
 const change=queue.enqueue(trip,t=>swapCalendarStops(t,a.id,b.id).trip,async(_,next)=>next);
 assert.equal(shown.stops.find(s=>s.id===a.id)?.time,'11:00');assert.equal(shown.stops.find(s=>s.id===b.id)?.time,a.time);
 const failed=assert.rejects(change.settled,/Offline/);
 await new Promise(resolve=>setImmediate(resolve));assert.equal(requests,1);
 rejectSave(new Error('Offline'));await failed;assert.deepEqual(shown,trip);
});
