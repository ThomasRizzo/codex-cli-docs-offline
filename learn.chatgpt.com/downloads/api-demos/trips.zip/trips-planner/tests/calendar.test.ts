import test from 'node:test';
import assert from 'node:assert/strict';
import { calendar, instant, foldLine, escapeText } from '../lib/calendar';
import { newCalendarToken, tokenHash, validCalendarToken } from '../lib/calendar-token';
import { tripSchema, type Trip } from '../lib/trips';
const place = {id:'p',name:'Pike Place',address:'Seattle, WA',lat:47.6096,lng:-122.3422};
const flight = {id:'flight',number:'AS331',date:'2026-11-06',from:'SEA',to:'JFK',departure:'18:30',scheduledDeparture:'16:00',arrival:'02:00',arrivalDate:'2026-11-07',departureTimeZone:'America/Los_Angeles',arrivalTimeZone:'America/New_York',departurePlan:{airport:{...place,id:'sea',name:'SeaTac',lat:47.4502,lng:-122.3088},originPlace:place,originStopId:null,kind:'domestic' as const,arrivalMinutes:120,extraMinutes:10,driveOverrideMinutes:35}};
const trip:Trip = {id:'205968a2-674e-4950-9132-7f48caad226f',name:'Seattle',destination:place,start:'2026-11-06',end:'2026-11-08',stops:[{...place,id:'stop',date:'2026-11-06',time:'09:00',note:'',mode:'walk'}],flights:[flight],version:1};
const render=(t:Trip)=>calendar([{trip:t,updatedAt:Date.UTC(2026,9,25)}],{},'https://trips.example');
const events=(s:string)=>s.split('\r\nBEGIN:VEVENT\r\n').slice(1).map(s=>s.split('END:VEVENT')[0]);
test('time zones, DST and cross-date-line times convert to real instants',()=>{
 assert.equal(new Date(instant('2026-11-06','09:00','America/Los_Angeles')!).toISOString(),'2026-11-06T17:00:00.000Z');
 assert.equal(new Date(instant('2026-07-06','09:00','America/Los_Angeles')!).toISOString(),'2026-07-06T16:00:00.000Z');
 assert.equal(new Date(instant('2026-11-06','09:00','Asia/Tokyo')!).toISOString(),'2026-11-06T00:00:00.000Z');
 assert.equal(new Date(instant('2026-11-01','01:30','America/Los_Angeles')!).toISOString(),'2026-11-01T08:30:00.000Z');
 assert.equal(instant('2026-11-06','oops','America/Los_Angeles'),null);
});
test('flights use both airport zones and airport blocks stay on original departure',()=>{
 const list=events(render(trip)); assert.equal(list.length,4);
 assert.match(list[0],/DTSTART:20261106T170000Z/);
 assert.match(list[1],/DTSTART:20261107T023000Z/); assert.match(list[1],/DTEND:20261107T070000Z/);
 assert.match(list[2],/DTSTART:20261106T220000Z/); assert.match(list[2],/DTEND:20261107T000000Z/);
 assert.match(list[3],/DTSTART:20261106T211500Z/); assert.match(list[3],/DTEND:20261106T220000Z/);
});
test('updates retain UID; removals disappear; untimed items are transparent all-day',()=>{
 const before=events(render(trip))[0]; const after=events(render({...trip,version:2,stops:[{...trip.stops[0],time:'',name:'New name'}]}))[0];
 assert.equal(before.match(/UID:.*/)?.[0],after.match(/UID:.*/)?.[0]);assert.match(after,/SEQUENCE:2/);assert.match(after,/DTSTART;VALUE=DATE:20261106/);assert.match(after,/DTEND;VALUE=DATE:20261107/);assert.match(after,/TRANSP:TRANSPARENT/);
 assert.equal(events(render({...trip,stops:[],flights:[]})).length,0);
});
test('unconfigured flight zones do not export guessed UTC times',()=>{
 const e=events(render({...trip,stops:[],flights:[{...flight,departureTimeZone:undefined,departurePlan:undefined}]}))[0];assert.match(e,/DTSTART;VALUE=DATE:/);assert.doesNotMatch(e,/DTSTART:.*Z/);assert.match(e,/set time zone/);
});
test('airport blocks can start on the previous day outside trip dates',()=>{
 const list=events(render({...trip,stops:[],flights:[{...flight,departure:'00:30',scheduledDeparture:'00:30'}]}));
 assert.match(list[2],/DTSTART:20261106T054500Z/);assert.match(list[2],/DTEND:20261106T063000Z/);
});
test('ICS content is escaped, folded by UTF-8 bytes, and cannot inject events',()=>{
 assert.equal(escapeText('a,b;c\\d\r\nEND:VEVENT'),'a\\,b\\;c\\\\d\\nEND:VEVENT');
 const folded=foldLine('DESCRIPTION:'+ '日本語✈️'.repeat(80));
 for(const line of folded.split('\r\n')) assert.ok(Buffer.byteLength(line)<=75);
 assert.equal(folded.replace(/\r\n /g,''),'DESCRIPTION:'+'日本語✈️'.repeat(80));
 const output=render({...trip,stops:[{...trip.stops[0],note:'\r\nEND:VEVENT\r\nBEGIN:VEVENT'}]});assert.equal(events(output).length,4);assert.equal(output.replace(/\r\n/g,'').includes('\n'),false);
});
test('tokens have 256 random bits, strict syntax and stable one-way hashes',async()=>{
 const a=newCalendarToken(),b=newCalendarToken(); assert.ok(validCalendarToken(a));assert.notEqual(a,b);assert.equal(a.length,64);assert.equal(validCalendarToken('../'+a),false);assert.equal(await tokenHash(a),await tokenHash(a));assert.notEqual(await tokenHash(a),a);
});
test('schema preserves valid zones and rejects invalid zones',()=>{
 assert.equal(tripSchema.parse({...trip,timeZone:'America/Los_Angeles'}).timeZone,'America/Los_Angeles');assert.equal(tripSchema.safeParse({...trip,timeZone:'not-a-zone'}).success,false);
});
