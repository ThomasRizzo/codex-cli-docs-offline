import test from 'node:test';
import assert from 'node:assert/strict';
import { summarizeCalendar,createCalendarReader } from '../lib/chat-calendar';
import { example } from '../lib/example';
import { routeKey,type Trip,type Route,type Flight } from '../lib/trips';
const day='2026-11-06';
const a={...example.stops[0],time:'11:00',durationMinutes:60},b={...example.stops[1],time:'12:15',durationMinutes:30};
const trip:Trip={...example,stops:[a,b],flights:[],hotels:[],timeZone:'America/Los_Angeles'};
const estimate:Route={minutes:25,km:3,mode:'walk',shape:[],source:'route'};
const routes={[routeKey(a,b,b.mode)]:estimate};
test('calendar context has actual start/end times, durations and chronological order',()=>{
 const c=summarizeCalendar({...trip,stops:[b,{...a,durationMinutes:undefined}]},day,routes);
 assert.equal(c.events[0].id,a.id);assert.equal(c.events[0].end,day+'T11:45');assert.equal(c.events[0].duration_minutes,45);assert.equal(c.version,trip.version);
 assert.equal(c.events[1].start,day+'T12:15');
});
test('computed travel gaps expose conflicts instead of treating gaps as free time',()=>{
 const c=summarizeCalendar(trip,day,routes),leg=c.travel[0];
 assert.equal(leg.minutes,25);assert.equal(leg.available_minutes,15);assert.equal(leg.slack_minutes,-10);assert.equal(leg.fits,false);assert.equal(c.conflicts[0].type,'travel');
});
test('airport reservations, full flight and airport exit allowance are explicit',()=>{
 const airport={id:'airport:KSEA',name:'SEA',address:'SeaTac',lat:47.449,lng:-122.309};
 const flight:Flight={id:'flight',number:'DL1134',from:'SFO',to:'SEA',date:day,arrivalDate:day,departure:'10:35',arrival:'12:57',departureTimeZone:'America/Los_Angeles',arrivalTimeZone:'America/Los_Angeles',arrivalAirport:airport};
 const stop={...a,time:'14:30'},c=summarizeCalendar({...trip,stops:[stop],flights:[flight]},day,{[routeKey(airport,stop,'uber')]:{...estimate,mode:'uber',minutes:33}});
 assert.equal(c.airport_blocks[0].start,day+'T08:35');assert.equal(c.airport_blocks[0].end,day+'T10:35');assert.equal(c.airport_blocks[0].travel_included,false);
 assert.equal(c.flights[0].arrival,day+'T12:57');assert.equal(c.flights[0].airport_exit_until,day+'T13:27');
 assert.equal(c.travel[0].available_minutes,63);assert.equal(c.travel[0].slack_minutes,30);assert.equal(c.travel[0].earliest_arrival,day+'T14:00');
});
test('intervening locationless appointments consume available travel time',()=>{
 const meeting={id:'meeting',kind:'event' as const,name:'Call',date:day,time:'12:15',durationMinutes:30,address:'',note:'',mode:'walk' as const};
 const c=summarizeCalendar({...trip,stops:[a,meeting,{...b,time:'13:00'}]},day,routes);
 assert.equal(c.events[1].location,null);assert.equal(c.travel[0].available_minutes,30);assert.equal(c.travel[0].slack_minutes,5);
});
test('route failures remain unknown and do not masquerade as zero-minute journeys',async()=>{
 const read=createCalendarReader(async()=>{throw new Error('Unavailable');}),c=await read(trip,day);
 assert.equal(c.travel[0].minutes,null);assert.equal(c.travel[0].fits,null);assert.equal(c.travel[0].estimate_status,'unavailable');
});
test('reading the staged calendar reflects edits and reuses route estimates',async()=>{
 let calls=0;const read=createCalendarReader(async()=>{calls++;return estimate;});
 const before=await read(trip,day),after=await read({...trip,stops:[a,{...b,time:'13:00'}]},day);
 assert.equal(before.travel[0].fits,false);assert.equal(after.travel[0].fits,true);assert.equal(after.events[1].start,day+'T13:00');assert.equal(calls,1);
 await assert.rejects(read(trip,'2026-12-31'),/Choose a day/);
});
test('hotel endpoints and unscheduled items are retained without inventing times',()=>{
 const hotel={...a,id:'hotel',checkIn:'2026-11-05',checkOut:'2026-11-08',note:''};
 const c=summarizeCalendar({...trip,stops:[{...a,time:''}],hotels:[hotel]},day,{});
 assert.equal(c.events.length,0);assert.equal(c.unscheduled[0].id,a.id);assert.equal(c.hotels.start?.id,'hotel');assert.equal(c.hotels.end?.id,'hotel');
});
