import test from 'node:test';
import assert from 'node:assert/strict';
import { chooseTravelModes, previewTravelModes, newTravelLegs } from '../lib/auto-travel';
import { changedTravelLegs, scheduleTravelAvailability } from '../lib/schedule-travel';
import { example } from '../lib/example';
import { routeKey, type Place, type Route, type Trip, type Hotel } from '../lib/trips';
import { applyChatTool } from '../lib/chat-tools';
const [p,q,r]=example.stops;
const previous:Trip={...example,stops:[{...p,time:'09:00',durationMinutes:30},{...r,time:'12:00',durationMinutes:30}],flights:[]};
const event={...q,id:'lunch',kind:'event' as const,name:'Visit Justin for Lunch',time:'10:00',durationMinutes:60};
const proposed:Trip={...previous,stops:[previous.stops[0],event,{...previous.stops[1],kind:'event',name:'Check in to hotel'}]};
const route=(minutes:number,mode:'walk'|'uber'):Route=>({minutes,mode,km:1,shape:[],source:'route'});
function loader(walk:number,drive=12){const calls:string[]=[],routes:Record<string,Route>={};return {calls,routes,load:async(a:Place,b:Place,mode:'walk'|'uber')=>{const key=routeKey(a,b,mode);calls.push(key);return routes[key]=route(mode==='walk'?walk:drive,mode);}};}

test('both new legs switch before schedule checks, including the existing next event',async()=>{
 const mock=loader(297,12),original=JSON.stringify(proposed);
 const planned=await chooseTravelModes(previous,proposed,mock.load);
 assert.equal(planned.stops[1].mode,'uber');assert.equal(planned.stops[2].mode,'uber');
 assert.equal(planned.stops[0].mode,'walk');assert.equal(mock.calls.length,4);
 assert.equal(scheduleTravelAvailability(changedTravelLegs(previous.stops,planned.stops),mock.routes).status,'ready');
 assert.equal(JSON.stringify(proposed),original);
});
test('15-minute walks stay walking; anything longer switches to Uber',async()=>{
 for(const [minutes,expected] of [[14,'walk'],[15,'walk'],[16,'uber']] as const){const mock=loader(minutes);const planned=await chooseTravelModes(previous,proposed,mock.load);assert.equal(planned.stops[1].mode,expected);assert.equal(mock.calls.length,expected==='walk'?2:4);}
});
test('Uber is still checked against the available gap',async()=>{
 const mock=loader(297,70),planned=await chooseTravelModes(previous,proposed,mock.load);
 const availability=scheduleTravelAvailability(changedTravelLegs(previous.stops,planned.stops),mock.routes);
 assert.equal(availability.status,'blocked');assert.match(availability.message,/Uber/);
});
test('same-day hotel departure and return routes use the same policy',async()=>{
 const hotel:Hotel={...r,id:'hotel',checkIn:'2026-11-05',checkOut:'2026-11-08',note:''};
 const before={...previous,stops:[],hotels:[hotel]},next={...before,stops:[event]};
 const planned=await chooseTravelModes(before,next,loader(40).load);
 assert.equal(planned.stops[0].mode,'uber');assert.equal(planned.hotels?.[0].returnModes?.[event.date],'uber');
 assert.equal(hotel.returnModes,undefined);
});
test('manual modes and unrelated routes are preserved when only timing or notes change',async()=>{
 const next={...proposed,stops:proposed.stops.map(s=>({...s,time:s.time==='10:00'?'10:15':s.time,note:'Updated'}))};
 const mock=loader(300);const planned=await chooseTravelModes(proposed,next,mock.load);
 assert.equal(mock.calls.length,0);assert.equal(planned.stops[1].mode,'walk');
});
test('unknown locations and co-located events do not request routes',async()=>{
 const mock=loader(50);const next={...previous,stops:[{...event,lat:undefined,lng:undefined}]};
 await chooseTravelModes({...previous,stops:[]},next,mock.load);
 await chooseTravelModes({...previous,stops:[]},{...previous,stops:[event,{...event,id:'next',time:'12:00'}]},mock.load);
 assert.equal(mock.calls.length,0);
});
test('walking unavailable falls back to a verified driving route; no driving route aborts',async()=>{
 const planned=await chooseTravelModes(previous,proposed,async(_a,_b,mode)=>{if(mode==='walk')throw new Error('No walking route');return route(20,mode);});
 assert.equal(planned.stops[1].mode,'uber');
 await assert.rejects(chooseTravelModes(previous,proposed,async()=>{throw new Error('Unavailable');}),/could not be checked/);
});
test('drag previews select the driving estimate once a long walk is known',()=>{
 const routes=Object.fromEntries(newTravelLegs(previous,proposed).map(l=>[routeKey(l.from,l.to,'walk'),route(297,'walk')]));
 const preview=previewTravelModes(previous,proposed,routes);
 assert.equal(preview.stops[1].mode,'uber');
 assert.equal(scheduleTravelAvailability(changedTravelLegs(previous.stops,preview.stops),routes).status,'checking');
});
test('chat-created custom events get the same automatic route selection',async()=>{
 const result=applyChatTool(previous,'save_event',{event_id:null,title:event.name,date:event.date,time:event.time,duration_minutes:60,place_id:q.id,note:'',mode:'walk'},new Map([[q.id,q]]),()=>event.id);
 const planned=await chooseTravelModes(previous,result.trip,loader(297).load);
 assert.equal(planned.stops.find(s=>s.id===event.id)?.mode,'uber');assert.equal(planned.stops.find(s=>s.id===r.id)?.mode,'uber');
});
