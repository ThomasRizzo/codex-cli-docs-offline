import test from 'node:test';
import assert from 'node:assert/strict';
import { upstream } from '../lib/upstream';

test('temporary place failure recovers without returning or persisting an empty result',async t=>{
 let calls=0;t.mock.method(globalThis,'fetch',async()=>++calls===1?new Response('Unavailable',{status:503}):Response.json({features:[{id:'verified'}]}));
 assert.deepEqual(await upstream('https://photon.komoot.io/api/?q=private-query'),{features:[{id:'verified'}]});assert.equal(calls,2);
});
test('permanent failures and long rate-limit backoffs are not retried; logs exclude location data',async t=>{
 for(const [status,headers] of [[400,{}],[429,{'Retry-After':'60'}]] as const){
  const fetch=t.mock.method(globalThis,'fetch',async()=>new Response('private upstream details',{status,headers}));
  const warnings=t.mock.method(console,'warn',()=>{});
  await assert.rejects(upstream('https://photon.komoot.io/api/?q=private-query'),/Place lookup/);assert.equal(fetch.mock.callCount(),1);
  assert.doesNotMatch(JSON.stringify(warnings.mock.calls),/private-query|private upstream/);t.mock.restoreAll();
 }
});
test('transport failures retry, while cancellation stops without another request',async t=>{
 let calls=0;t.mock.method(globalThis,'fetch',async()=>{if(++calls===1)throw new TypeError('connection reset');return Response.json({ok:true});});
 assert.deepEqual(await upstream('https://photon.komoot.io/api/?q=cafe'),{ok:true});assert.equal(calls,2);
 const controller=new AbortController();controller.abort();await assert.rejects(upstream('https://photon.komoot.io/api/?q=cafe',{},controller.signal),{name:'AbortError'});assert.equal(calls,2);
});
