import test from 'node:test';
import assert from 'node:assert/strict';
import { changedTravelLegs, scheduleTravelAvailability } from '../lib/schedule-travel';
import { placeOnCalendar } from '../lib/scheduling';
import { routeKey, type Route, type LocatedStop as Stop } from '../lib/trips';
import { example } from '../lib/example';

const a:Stop={...example.stops[0],time:'15:00'};
const b:Stop={...example.stops[1],name:'Chihuly Garden and Glass',time:'16:45'};
const c:Stop={...example.stops[2],name:'Canlis',time:'18:30'};
const trip={...example,stops:[a,b,c]};
const route=(minutes:number,mode:Stop['mode']='walk'):Route=>({minutes,mode,km:1,shape:[],source:'route'});
const routes={
 [routeKey(a,b,'walk')]:route(20),
 [routeKey(b,c,'walk')]:route(41),
 [routeKey(b,c,'uber')]:route(10,'uber'),
};
function move(stop:Stop,time:string,date=trip.start,source=trip){
 const changed=placeOnCalendar(source,{place:stop,stopId:stop.id},date,time,'unused');
 return changedTravelLegs(source.stops,changed.trip.stops);
}

test('41-minute walk blocks a 30-minute gap but allows the next 15-minute slot',()=>{
 const blocked=scheduleTravelAvailability(move(c,'18:00'),routes);
 assert.equal(blocked.status,'blocked');
 assert.match(blocked.message,/Walk.*Chihuly Garden and Glass.*Canlis.*41 min.*30 min/);
 assert.equal(scheduleTravelAvailability(move(c,'18:15'),routes).status,'ready');
});
test('switching the destination leg to Uber permits the smaller gap',()=>{
 const byCar={...trip,stops:[a,b,{...c,mode:'uber' as const}]};
 const legs=move(byCar.stops[2],'17:45',trip.start,byCar);
 assert.equal(legs[0].key,routeKey(b,c,'uber'));
 assert.equal(scheduleTravelAvailability(legs,routes).status,'ready');
 const walkOnly={ [routeKey(b,c,'walk')]:route(41) };
 assert.equal(scheduleTravelAvailability(legs,walkOnly).status,'checking');
});
test('moving the earlier event checks the outgoing route as well as the incoming route',()=>{
 const legs=move(b,'17:30');
 assert.equal(legs.length,2);
 const blocked=scheduleTravelAvailability(legs,routes);
 assert.equal(blocked.status,'blocked');assert.match(blocked.message,/Canlis/);
});
test('exact travel duration is enough and zero-length gaps are rejected',()=>{
 const legs=move(c,'18:15');
 assert.equal(scheduleTravelAvailability(legs,{[legs[0].key]:route(45)}).status,'ready');
 assert.equal(scheduleTravelAvailability(move(c,'16:45'),routes).status,'blocked');
});
test('reordering evaluates the new adjacent routes, not the old route estimates',()=>{
 const legs=move(b,'19:30');
 assert.deepEqual(legs.map(l=>[l.from.id,l.to.id]),[[a.id,c.id],[c.id,b.id]]);
 assert.equal(scheduleTravelAvailability(legs,routes).status,'checking');
 const resolved={...routes,[routeKey(a,c,'walk')]:route(25),[routeKey(c,b,'walk')]:route(41)};
 assert.equal(scheduleTravelAvailability(legs,resolved).status,'blocked');
});
test('cross-day moves check the new day and the route left behind',()=>{
 const next={...a,id:'next-day',date:trip.end,time:'10:00'};
 const source={...trip,stops:[a,b,c,next]};
 const legs=move(b,'11:00',trip.end,source);
 assert.deepEqual(legs.map(l=>[l.from.id,l.to.id]),[[a.id,c.id],[next.id,b.id]]);
 assert.equal(legs[1].gap,15);
});
test('new chat/map results must fit on both sides',()=>{
 const result={...a,id:'result',lat:47.64,name:'New cafe'};
 const changed=placeOnCalendar(trip,{place:result},trip.start,'17:15','new-stop');
 const legs=changedTravelLegs(trip.stops,changed.trip.stops);
 assert.deepEqual(legs.map(l=>[l.from.id,l.to.id]),[[b.id,'new-stop'],['new-stop',c.id]]);
 const estimates=Object.fromEntries(legs.map(l=>[l.key,route(40)]));
 assert.equal(scheduleTravelAvailability(legs,estimates).status,'blocked');
});
test('missing or failed route data never marks a drop ready',()=>{
 const legs=move(c,'18:00');
 assert.equal(scheduleTravelAvailability(legs,{}).status,'checking');
 assert.equal(scheduleTravelAvailability(legs,{}, {[legs[0].key]:'Unavailable'}).status,'unavailable');
 assert.equal(scheduleTravelAvailability(legs,routes).status,'blocked');
});
test('unchanged conflicts elsewhere do not block a separate valid move',()=>{
 const other={...a,id:'other',date:trip.end,time:'10:00'};
 const source={...trip,stops:[a,b,{...c,time:'17:00'},other]};
 assert.equal(changedTravelLegs(source.stops,source.stops).length,0);
 assert.equal(scheduleTravelAvailability(move(other,'11:00',trip.end,source),routes).status,'ready');
});
test('untimed places impose no deadline; equal locations need no route but cannot overlap',()=>{
 const after=[{...a,time:''},{...b,time:'10:00'},{...c,time:'10:45',lat:b.lat,lng:b.lng}];
 assert.equal(scheduleTravelAvailability(changedTravelLegs([],after),{}).status,'ready');
 assert.equal(scheduleTravelAvailability(changedTravelLegs([],after.map(s=>s.id===c.id?{...s,time:'10:30'}:s)),{}).status,'blocked');
 const before=JSON.stringify(trip);
 move(c,'18:00');assert.equal(JSON.stringify(trip),before);
});
