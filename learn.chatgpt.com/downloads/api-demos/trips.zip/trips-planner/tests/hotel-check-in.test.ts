import test from 'node:test';
import assert from 'node:assert/strict';
import { tripSchema, withHotelCheckIns, type Trip, type Hotel } from '../lib/trips';
import { placeOnCalendar, resizeCalendarStop } from '../lib/scheduling';
import { changedTravelLegs, scheduleTravelAvailability } from '../lib/schedule-travel';
import { dayRoute } from '../lib/hotels';
import { applyChatTool } from '../lib/chat-tools';
import { calendar } from '../lib/calendar';
import { chooseTravelModes } from '../lib/auto-travel';
import { example } from '../lib/example';

const hotel:Hotel={...example.destination,id:'stay',name:'Four Seasons Seattle',checkIn:example.start,checkOut:example.end,note:''};
const stored:Trip={...example,stops:[],flights:[],hotels:[hotel]};
const load=(t:Trip):Trip=>({...tripSchema.parse(t),version:t.version});
const checkIn=(t:Trip)=>t.stops.find(s=>s.hotelCheckInId===hotel.id)!;

test('existing and new stays create one stable 3 pm, 30-minute check-in event',()=>{
 const trip=load(stored),event=checkIn(trip);
 assert.equal(event.time,'15:00');assert.equal(event.durationMinutes,30);
 assert.equal(event.kind,'event');assert.equal(event.locationName,hotel.name);
 assert.deepEqual(load(trip),trip);assert.equal(stored.stops.length,0);
 assert.equal(dayRoute(trip,hotel.checkIn).points.length,1);
});
test('check-in moves and resizes through normal calendar actions, surviving reload',()=>{
 const trip=load(stored),event=checkIn(trip);
 const moved=placeOnCalendar(trip,{place:event,stopId:event.id},event.date,'17:15','unused').trip;
 const resized=resizeCalendarStop(moved,event.id,45).trip;
 assert.equal(checkIn(load(resized)).time,'17:15');assert.equal(checkIn(load(resized)).durationMinutes,45);
 assert.equal(checkIn(load(resized)).id,event.id);
 assert.deepEqual(resized.hotels,stored.hotels);
});
test('check-in stays on arrival day and honors the configurable opening time',()=>{
 const trip=load(stored),event=checkIn(trip);
 assert.throws(()=>placeOnCalendar(trip,{place:event,stopId:event.id},event.date,'14:45','x'),/opens at 3:00 pm/);
 assert.throws(()=>placeOnCalendar(trip,{place:event,stopId:event.id},'2026-11-07','16:00','x'),/arrival day/);
 const early=load({...stored,hotels:[{...hotel,checkInFrom:'12:00'}]});
 assert.equal(checkIn(early).time,'12:00');
 assert.doesNotThrow(()=>placeOnCalendar(early,{place:checkIn(early),stopId:checkIn(early).id},hotel.checkIn,'12:15','x'));
});
test('resizing reserves time and blocks overlap with the next event',()=>{
 const trip=load(stored),event=checkIn(trip);
 const next={...trip,stops:[event,{...event,id:'meeting',hotelCheckInId:undefined,name:'Meet Alex',time:'16:00'}]};
 const resized=resizeCalendarStop(next,event.id,75).trip;
 assert.equal(scheduleTravelAvailability(changedTravelLegs(next.stops,resized.stops),{}).status,'blocked');
});
test('checking in can be followed by activities and a separate nightly hotel return',()=>{
 const trip=load(stored),dinner={...example.stops[0],id:'dinner',time:'18:00'};
 const route=dayRoute({...trip,stops:[...trip.stops,dinner]},hotel.checkIn);
 assert.deepEqual(route.points.map(p=>p.id),[checkIn(trip).id,dinner.id,'hotel:stay:end']);
 assert.equal(route.points.at(-1)?.hotelRole,'end');
});
test('hotel edits follow the stay, and removing it also removes the linked check-in',()=>{
 const trip=load(stored),event=checkIn(trip);
 const edited=load({...trip,hotels:[{...hotel,name:'New hotel',lat:48,checkIn:'2026-11-07'}]});
 assert.equal(checkIn(edited).id,event.id);assert.equal(checkIn(edited).date,'2026-11-07');
 assert.equal(checkIn(edited).lat,48);assert.match(checkIn(edited).name,/New hotel/);
 assert.equal(load({...trip,hotels:[]}).stops.length,0);
 assert.equal(withHotelCheckIns({...trip,start:'2026-11-07'}).stops.length,0);
});
test('chat edits the linked event without detaching it or duplicating check-in',()=>{
 const trip=load(stored),event=checkIn(trip);
 const args={event_id:event.id,title:event.name,date:event.date,time:'17:00',duration_minutes:45,place_id:hotel.id,note:'',mode:'uber'};
 const places=new Map([[hotel.id,hotel]]);
 const changed=applyChatTool(trip,'save_event',args,places).trip;
 assert.equal(changed.stops.length,1);assert.equal(checkIn(changed).time,'17:00');
 assert.throws(()=>applyChatTool(trip,'save_event',{...args,time:'14:00'},places),/opens at/);
 assert.throws(()=>applyChatTool(trip,'remove_event',{event_id:event.id},places),/hotel stay/);
});
test('calendar subscriptions include the timed check-in and preserve its identity after edits',()=>{
 const trip=load(stored),event=checkIn(trip);
 const render=(t:Trip)=>calendar([{trip:t,updatedAt:Date.UTC(2026,9,25)}],{},'https://trips.example');
 const first=render(stored).split('BEGIN:VEVENT').find(e=>e.includes('SUMMARY:Check in'))!;
 assert.match(first,/DTSTART:20261106T230000Z/);assert.match(first,/DTEND:20261106T233000Z/);
 const moved=placeOnCalendar(trip,{place:event,stopId:event.id},event.date,'16:00','unused').trip;
 const next=render(resizeCalendarStop(moved,event.id,45).trip).split('BEGIN:VEVENT').find(e=>e.includes('SUMMARY:Check in'))!;
 assert.equal(next.match(/UID:.*/)?.[0],first.match(/UID:.*/)?.[0]);
 assert.match(next,/DTSTART:20261107T000000Z/);assert.match(next,/DTEND:20261107T004500Z/);
});

test('duplicate linked check-ins are rejected',()=>{
 const trip=load(stored),event=checkIn(trip);
 assert.equal(tripSchema.safeParse({...trip,stops:[event,{...event,id:'duplicate'}]}).success,false);
});

test('legacy hotel check-in conversion applies the long-walk default before display',async()=>{
 const before={...stored,stops:[{...example.stops[0],time:'12:00'}]};
 const expanded=load(before);
 const planned=await chooseTravelModes(before,expanded,async(_a,_b,mode)=>({mode,minutes:mode==='walk'?297:25,km:20,shape:[],source:'route'}));
 assert.equal(checkIn(planned).mode,'uber');
 assert.equal(checkIn(planned).time,'15:00');
});
