import test from 'node:test';
import assert from 'node:assert/strict';
import { arrivalConnections,arrivalTime,arrivalTimeIssue,arrivalTravelLegs,changedArrivalTravelLegs } from '../lib/arrivals';
import { enrichArrivalAirports } from '../lib/arrival-airports';
import { dayRoute } from '../lib/hotels';
import { scheduleTravelAvailability } from '../lib/schedule-travel';
import { calendar } from '../lib/calendar';
import { tripSchema,routeKey,type Flight,type Trip,type Route } from '../lib/trips';
import { example } from '../lib/example';
import { wallTime,wallDate } from '../lib/departures';

const airport={id:'airport:KSEA',name:'Seattle-Tacoma International Airport',address:'SeaTac, WA',lat:47.449,lng:-122.309};
const flight:Flight={id:'flight',number:'DL1134',from:'SFO',to:'SEA',date:'2026-11-06',arrivalDate:'2026-11-06',departure:'09:30',arrival:'11:30',arrivalTimeZone:'America/Los_Angeles',departureTimeZone:'America/Los_Angeles',arrivalAirport:airport};
const stop={...example.stops[0],time:'13:00',durationMinutes:60};
const trip:Trip={...example,stops:[stop],flights:[flight]};
const route:Route={minutes:35,km:25,mode:'uber',shape:[],source:'route'};
const routes={[routeKey(airport,stop,'uber')]:route};

test('arrival connects the airport to the first event with exit allowance and Uber',()=>{
 const [a]=arrivalConnections(trip);
 assert.equal(a.to.id,stop.id);assert.equal(a.to.mode,'uber');assert.equal(a.from.durationMinutes,30);
 assert.equal(wallTime(a.at),'11:30 am');assert.equal(wallTime(a.ready),'12:00 pm');
 assert.equal(arrivalTravelLegs(trip)[0].gap,60);
 const day=dayRoute(trip,stop.date);
 assert.equal(day.points[0].arrivalFlightId,flight.id);assert.equal(day.points[1].mode,'uber');
 assert.equal(trip.stops[0].mode,'walk');
});
test('dragging earlier checks time after arrival plus the route; later slots remain available',()=>{
 const moved={...trip,stops:[{...stop,time:'12:15'}]};
 assert.equal(scheduleTravelAvailability(changedArrivalTravelLegs(trip,moved),routes).status,'blocked');
 assert.equal(scheduleTravelAvailability(changedArrivalTravelLegs(trip,{...trip,stops:[{...stop,time:'12:45'}]}),routes).status,'ready');
 assert.match(arrivalTimeIssue({...stop,time:'11:45'},trip)!,/30 minutes/);
 assert.equal(arrivalTimeIssue(stop,trip),null);
});
test('reordering events reconnects the arrival to the new first stop',()=>{
 const next={...trip,stops:[stop,{...example.stops[1],time:'12:30'}]};
 assert.equal(arrivalConnections(next)[0].to.id,example.stops[1].id);
 assert.equal(changedArrivalTravelLegs(trip,next)[0].to.id,example.stops[1].id);
 assert.equal(changedArrivalTravelLegs(trip,{...trip,name:'Renamed'}).length,0);
});
test('destination-local estimated and actual arrival times take precedence',()=>{
 const tracking={ident:'DAL1134',origin:'KSFO',destination:'KSEA',scheduledOut:'2026-11-06T17:30:00Z',scheduledIn:'2026-11-06T19:30:00Z',estimatedIn:'2026-11-06T20:00:00Z',status:'Delayed',checkedAt:'2026-10-25T00:00:00Z',nextCheckAt:'2026-10-26T00:00:00Z',complete:false};
 assert.equal(wallTime(arrivalTime({...flight,flightaware:tracking})!),'12:00 pm');
 assert.equal(wallTime(arrivalTime({...flight,flightaware:{...tracking,actualIn:'2026-11-06T19:50:00Z'}})!),'11:50 am');
 const late={...flight,flightaware:{...tracking,estimatedIn:'2026-11-07T08:10:00Z'}};
 assert.equal(wallDate(arrivalTime(late)!),'2026-11-07');
});
test('overnight arrival gaps use absolute dates instead of clock subtraction',()=>{
 const overnight={...trip,flights:[{...flight,arrival:'23:30'}],stops:[{...stop,date:'2026-11-07',time:'01:00'}]};
 const [leg]=arrivalTravelLegs(overnight);
 assert.equal(leg.gap,60);assert.equal(scheduleTravelAvailability([leg],routes).status,'ready');
 assert.equal(dayRoute(overnight,'2026-11-07').arrival?.from.date,'2026-11-06');
});
test('airport exit allowance and manual travel mode are retained in saved trips',()=>{
 const saved=tripSchema.parse({...trip,flights:[{...flight,arrivalExitMinutes:0,arrivalMode:'walk'}]});
 const [a]=arrivalConnections({...saved,version:1});
 assert.equal(a.ready,a.at);assert.equal(a.to.mode,'walk');
 assert.equal(tripSchema.safeParse({...trip,flights:[{...flight,arrivalExitMinutes:-1}]}).success,false);
});
test('return flights home, disabled transfers, and unresolved airports do not create bogus routes',()=>{
 const home={...flight,to:'SFO',arrivalAirport:{...airport,lat:37.619,lng:-122.375}};
 assert.equal(arrivalConnections({...trip,flights:[home]}).length,0);
 assert.equal(arrivalConnections({...trip,flights:[{...flight,arrivalTransfer:false}]}).length,0);
 assert.equal(arrivalConnections({...trip,flights:[{...flight,arrivalAirport:undefined}]}).length,0);
});
test('an arrival replaces the starting hotel while preserving the final hotel return',()=>{
 const h={...stop,id:'hotel',checkIn:'2026-11-05',checkOut:'2026-11-08',lat:47.6};
 const route=dayRoute({...trip,hotels:[h]},stop.date);
 assert.equal(route.start,null);assert.equal(route.points[0].arrivalFlightId,flight.id);
 assert.equal(route.points.at(-1)?.hotelRole,'end');
});
test('legacy flights resolve airport metadata once per code and never fabricate coordinates',async()=>{
 let calls=0;
 const old={...trip,flights:[{...flight,arrivalAirport:undefined},{...flight,id:'second',arrivalAirport:undefined}]};
 const hydrated=await enrichArrivalAirports(old,async <T>()=>{calls++;return {data:{code_icao:'KSEA',name:airport.name,latitude:airport.lat,longitude:airport.lng} as T,checkedAt:0,expires:1};});
 assert.equal(calls,1);assert.equal(hydrated.flights[0].arrivalAirport?.lat,airport.lat);
 const missing=await enrichArrivalAirports(old,async()=>{throw new Error('Unavailable');});
 assert.equal(missing.flights[0].arrivalAirport,undefined);
});
test('Apple Calendar includes airport exit and the connecting transfer with stable IDs',()=>{
 const ics=calendar([{trip,updatedAt:Date.UTC(2026,9,25)}],routes,'https://trips.example');
 const arrival=ics.split('BEGIN:VEVENT').find(e=>e.includes('UID:')&&e.includes('-arrival-flight@'))!;
 const transfer=ics.split('BEGIN:VEVENT').find(e=>e.includes('-arrival-transfer-flight@'))!;
 assert.match(arrival,/DTSTART:20261106T193000Z/);assert.match(arrival,/DTEND:20261106T200000Z/);
 assert.match(transfer,/SUMMARY:Uber to Pike Place Market/);assert.match(transfer,/DTSTART:20261106T200000Z/);assert.match(transfer,/DTEND:20261106T203500Z/);
});
