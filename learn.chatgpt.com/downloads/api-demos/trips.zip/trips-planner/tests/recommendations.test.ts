import test from 'node:test';
import assert from 'node:assert/strict';
import { recommendedPlaces } from '../lib/recommendations';
const cafe={id:'N-cafe',name:'Coffee',address:'Seattle',lat:47.61,lng:-122.34};
const verified=new Map([[cafe.id,cafe]]);
const args={places:[{place_id:cafe.id,reason:'A quiet place near the market.',source_url:'https://example.com/coffee'}]};
test('recommendation cards use server-verified locations and preserve the research source',()=>{assert.deepEqual(recommendedPlaces(args,verified),[{...cafe,reason:args.places[0].reason,sourceUrl:args.places[0].source_url}]);assert.equal(verified.size,1);});
test('recommendation tool rejects invented coordinates, unknown IDs and duplicate places',()=>{assert.throws(()=>recommendedPlaces({places:[{...args.places[0],lat:0}]},verified));assert.throws(()=>recommendedPlaces({places:[{...args.places[0],place_id:'fake'}]},verified));assert.throws(()=>recommendedPlaces({places:[args.places[0],args.places[0]]},verified));});
test('recommendation sources reject unsafe URLs and excessive content',()=>{assert.throws(()=>recommendedPlaces({places:[{...args.places[0],source_url:'javascript:alert(1)'}]},verified));assert.throws(()=>recommendedPlaces({places:[{...args.places[0],reason:'x'.repeat(301)}]},verified));assert.throws(()=>recommendedPlaces({places:[]},verified));});
