import test from 'node:test';
import assert from 'node:assert/strict';
import { selectedCalendarDay, calendarDayURL, tripPath } from '../lib/day-query';
import { example } from '../lib/example';

test('a valid requested day wins over the trip start; missing or invalid days fall back',()=>{
 assert.equal(selectedCalendarDay('2026-11-07',example),'2026-11-07');
 for(const value of [null,undefined,'','garbage','2026-02-30','2026-11-09',['2026-11-07']])assert.equal(selectedCalendarDay(value,example),example.start);
});
test('flight days outside the stay and derived airport days remain addressable',()=>{
 const trip={...example,flights:[{...example.flights[0],date:'2026-11-05',arrivalDate:'2026-11-06',departure:'23:00',arrival:'01:00'}]};
 assert.equal(selectedCalendarDay('2026-11-05',trip),'2026-11-05');
 assert.equal(selectedCalendarDay('2026-11-04',trip,['2026-11-04',trip.start]),'2026-11-04');
});
test('day changes preserve trip identity, unrelated parameters and the fragment',()=>{
 const url=new URL(calendarDayURL('https://trips.example/?trip=example&day=2026-11-06&view=map#calendar','2026-11-07'));
 assert.equal(url.searchParams.get('trip'),'example');assert.equal(url.searchParams.get('day'),'2026-11-07');
 assert.equal(url.searchParams.getAll('day').length,1);assert.equal(url.searchParams.get('view'),'map');assert.equal(url.hash,'#calendar');
});
test('shared links carry the current day without changing or rotating the share token',()=>{
 const url=calendarDayURL('https://trips.example/share/'+'a'.repeat(64),'2026-11-08');
 assert.equal(new URL(url).pathname,'/share/'+'a'.repeat(64));
 assert.equal(new URL(url).searchParams.get('day'),'2026-11-08');
 assert.equal(selectedCalendarDay(new URL(url).searchParams.get('day'),example),'2026-11-08');
});
test('sign-in and edit links retain trip and day with safe query encoding',()=>{
 assert.equal(tripPath(example.id,'2026-11-07'),`/?trip=${example.id}&day=2026-11-07`);
 assert.equal(tripPath(undefined,'2026-11-07'),'/?day=2026-11-07');
 assert.equal(tripPath(undefined,undefined),'/');
 const path=tripPath('id&day=injected','2026-11-07');
 assert.equal(new URL(path,'https://trips.example').searchParams.get('trip'),'id&day=injected');
 assert.equal(new URL(path,'https://trips.example').searchParams.getAll('day').length,1);
 assert.equal(tripPath(example.id,['2026-11-07']),`/?trip=${example.id}`);
});
test('a selected day removed by a trip edit falls back to the new start',()=>{
 const updated={...example,start:'2026-11-08',end:'2026-11-10',flights:[]};
 assert.equal(selectedCalendarDay('2026-11-07',updated),updated.start);
});
