import test from 'node:test';
import assert from 'node:assert/strict';
import { OptimisticTrips } from '../lib/optimistic-trips';
import { example } from '../lib/example';
import type { Trip } from '../lib/trips';
const base:Trip={...example,version:1};
function deferred<T>(){let resolve!:(v:T)=>void,reject!:(e:Error)=>void;const promise=new Promise<T>((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};}
const move=(time:string)=>(trip:Trip)=>({...trip,stops:trip.stops.map((s,i)=>i===0?{...s,time}:s)});
const validate=async(_before:Trip,next:Trip)=>next;
const tick=async()=>{await new Promise<void>(resolve=>setImmediate(resolve));};
function harness(){
 let shown=base,pending=false;const errors:Error[]=[],requests:{trip:Trip;result:ReturnType<typeof deferred<Trip>>}[]=[];
 const queue=new OptimisticTrips({save:trip=>{const result=deferred<Trip>();requests.push({trip,result});return result.promise;},reload:async()=>undefined,onChange:trip=>{shown=trip;},onPending:value=>{pending=value;},onError:e=>errors.push(e)});
 return {queue,requests,errors,get shown(){return shown;},get pending(){return pending;}};
}
test('a drop appears before travel validation or persistence resolves',async()=>{
 const h=harness(),check=deferred<Trip>();const job=h.queue.enqueue(base,move('10:00'),()=>check.promise);
 assert.equal(h.shown.stops[0].time,'10:00');assert.equal(h.requests.length,0);assert.equal(h.pending,true);
 check.resolve(h.shown);await tick();assert.equal(h.requests.length,1);
 h.requests[0].result.resolve({...h.requests[0].trip,version:2});await job.settled;
 assert.equal(h.pending,false);assert.equal(h.shown.version,2);
});
test('rapid moves remain visible and serialize using acknowledged server versions',async()=>{
 const h=harness(),first=h.queue.enqueue(base,move('10:00'),validate);
 const second=h.queue.enqueue(h.shown,move('11:00'),validate);await tick();
 assert.equal(h.requests.length,1);assert.equal(h.shown.stops[0].time,'11:00');
 h.requests[0].result.resolve({...h.requests[0].trip,version:2});await first.settled;await tick();
 assert.equal(h.shown.stops[0].time,'11:00');assert.equal(h.requests[1].trip.version,2);
 h.requests[1].result.resolve({...h.requests[1].trip,version:3});await second.settled;
 assert.equal(h.shown.stops[0].time,'11:00');assert.equal(h.shown.version,3);assert.equal(h.pending,false);
});
test('rebasing a move keeps server-normalized fields and changes on other events',async()=>{
 const h=harness(),first=h.queue.enqueue(base,move('10:00'),validate);
 const second=h.queue.enqueue(h.shown,trip=>({...trip,stops:trip.stops.map((s,i)=>i===1?{...s,durationMinutes:90}:s)}),validate);await tick();
 const accepted={...h.requests[0].trip,version:2,stops:h.requests[0].trip.stops.map((s,i)=>i===0?{...s,mode:'uber' as const}:s)};
 h.requests[0].result.resolve(accepted);await first.settled;await tick();
 assert.equal(h.requests[1].trip.stops[0].mode,'uber');assert.equal(h.requests[1].trip.stops[1].durationMinutes,90);
 h.requests[1].result.resolve({...h.requests[1].trip,version:3});await second.settled;
});
test('failed saves restore confirmed state, cancel queued writes, and allow retry',async()=>{
 const h=harness(),first=h.queue.enqueue(base,move('10:00'),validate),second=h.queue.enqueue(h.shown,move('11:00'),validate);
 const results=Promise.allSettled([first.settled,second.settled]);await tick();h.requests[0].result.reject(new Error('Offline'));
 assert.ok((await results).every(r=>r.status==='rejected'));assert.equal(h.shown.stops[0].time,base.stops[0].time);assert.equal(h.requests.length,1);assert.equal(h.errors.length,1);assert.equal(h.pending,false);
 const retry=h.queue.enqueue(h.shown,move('12:00'),validate);await tick();h.requests[1].result.resolve({...h.requests[1].trip,version:2});await retry.settled;assert.equal(h.shown.stops[0].time,'12:00');
});
test('background chat snapshots cannot overwrite a pending move or a newer save',async()=>{
 const h=harness(),job=h.queue.enqueue(base,move('10:00'),validate);h.queue.receive(base);assert.equal(h.shown.stops[0].time,'10:00');await tick();
 h.requests[0].result.resolve({...h.requests[0].trip,version:2});await job.settled;h.queue.receive(base);assert.equal(h.shown.stops[0].time,'10:00');
});
test('a lost response is reconciled with the server without retrying the mutation',async()=>{
 const committed={...move('10:00')(base),version:2};let shown=base,calls=0;
 const q=new OptimisticTrips({save:async()=>{calls++;throw new Error('Connection lost');},reload:async()=>committed,onChange:t=>{shown=t;},onPending:()=>{},onError:()=>{}});
 await assert.rejects(q.enqueue(base,move('10:00'),validate).settled,/Connection lost/);
 assert.equal(shown.version,2);assert.equal(shown.stops[0].time,'10:00');assert.equal(calls,1);
});
test('validation failure never sends an invalid move to the server',async()=>{
 const h=harness();await assert.rejects(h.queue.enqueue(base,move('10:00'),async()=>{throw new Error('Not enough travel time');}).settled,/Not enough travel time/);
 assert.equal(h.requests.length,0);assert.equal(h.shown.stops[0].time,base.stops[0].time);
});
test('chat waits for pending edits, including moves queued while it is waiting',async()=>{
 const h=harness(),first=h.queue.enqueue(base,move('10:00'),validate);let ready=false;
 const wait=h.queue.waitForIdle(base.id).then(()=>{ready=true;});
 const second=h.queue.enqueue(h.shown,move('11:00'),validate);await tick();assert.equal(ready,false);
 h.requests[0].result.resolve({...h.requests[0].trip,version:2});await first.settled;await tick();assert.equal(ready,false);
 h.requests[1].result.resolve({...h.requests[1].trip,version:3});await second.settled;await wait;assert.equal(ready,true);assert.equal(h.shown.stops[0].time,'11:00');
});
test('chat does not continue against stale calendar data after a save fails',async()=>{
 const h=harness(),job=h.queue.enqueue(base,move('10:00'),validate);
 const waited=assert.rejects(h.queue.waitForIdle(base.id),/Offline/),saved=assert.rejects(job.settled,/Offline/);
 await tick();h.requests[0].result.reject(new Error('Offline'));await Promise.all([waited,saved]);
});
