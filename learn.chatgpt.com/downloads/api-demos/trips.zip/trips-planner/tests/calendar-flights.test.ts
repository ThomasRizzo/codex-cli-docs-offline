import test from 'node:test';
import assert from 'node:assert/strict';
import { flightCalendarRange,flightDayBlock,calendarMinuteInZone } from '../lib/calendar-flights';
import { wallMinutes,wallTime } from '../lib/departures';
import type { Flight } from '../lib/trips';
const flight:Flight={id:'f',number:'DL1134',date:'2026-11-06',arrivalDate:'2026-11-06',departure:'10:35',arrival:'12:57',from:'SFO',to:'SEA',departureTimeZone:'America/Los_Angeles',arrivalTimeZone:'America/Los_Angeles'};
test('flight fills departure to arrival, with an attached 30-minute exit allowance',()=>{
 const range=flightCalendarRange(flight)!;const block=flightDayBlock(range,flight.date)!;
 assert.equal(block.from,635);assert.equal(block.flightMinutes,142);assert.equal(block.exitMinutes,30);assert.equal(block.to,807);
 assert.equal(flightDayBlock(range,'2026-11-07'),null);
});
test('different airport clocks are projected onto the calendar timezone',()=>{
 const range=flightCalendarRange({...flight,from:'JFK',departure:'10:00',arrival:'13:00',departureTimeZone:'America/New_York'},'America/Los_Angeles')!;
 assert.equal(wallTime(range.departure),'7:00 am');assert.equal(range.arrival-range.departure,360);
 assert.equal(wallTime(calendarMinuteInZone(wallMinutes(flight.date,'08:00')!,'America/New_York','America/Los_Angeles')),'5:00 am');
});
test('overnight flights split at midnight without duplicated arrival or departure cards',()=>{
 const range=flightCalendarRange({...flight,departure:'23:00',arrivalDate:'2026-11-07',arrival:'02:00'})!;
 const first=flightDayBlock(range,'2026-11-06')!,second=flightDayBlock(range,'2026-11-07')!;
 assert.equal(first.flightMinutes,60);assert.equal(first.exitMinutes,0);assert.equal(first.continuesAfter,true);
 assert.equal(second.from,0);assert.equal(second.flightMinutes,120);assert.equal(second.exitMinutes,30);assert.equal(second.continuesBefore,true);
});
test('provider estimates and actual times set the continuous flight boundaries',()=>{
 const tracking={ident:'DAL1134',origin:'KSFO',destination:'KSEA',scheduledOut:'2026-11-06T18:35:00Z',scheduledIn:'2026-11-06T20:57:00Z',estimatedOut:'2026-11-06T19:00:00Z',actualOut:'2026-11-06T19:10:00Z',estimatedIn:'2026-11-06T21:30:00Z',status:'Delayed',checkedAt:'2026-10-25T00:00:00Z',nextCheckAt:'2026-10-26T00:00:00Z',complete:false};
 const range=flightCalendarRange({...flight,flightaware:tracking})!;
 assert.equal(wallTime(range.departure),'11:10 am');assert.equal(wallTime(range.arrival),'1:30 pm');
});
test('zero allowance has no footer and missing or invalid times do not invent a duration',()=>{
 assert.equal(flightDayBlock(flightCalendarRange({...flight,arrivalExitMinutes:0})!,flight.date)!.exitMinutes,0);
 assert.equal(flightCalendarRange({...flight,arrival:''}),null);
 assert.equal(flightCalendarRange({...flight,arrival:'09:00'}),null);
});
