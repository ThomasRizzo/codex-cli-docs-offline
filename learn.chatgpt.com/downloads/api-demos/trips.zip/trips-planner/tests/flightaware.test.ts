import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { flightInput,lookupFlight,matchingFlight,localFlightTime,type FlightQuery } from '../lib/flightaware';
import { flightQuery } from '../lib/flightaware-cache';
import { tripSchema } from '../lib/trips';
import { calendar } from '../lib/calendar';
import { example } from '../lib/example';

const now=Date.parse('2026-10-25T04:00:00Z');
const scheduled={ident:'DAL1134',ident_icao:'DAL1134',ident_iata:'DL1134',origin:'KSEA',origin_icao:'KSEA',origin_iata:'SEA',destination:'KSFO',destination_icao:'KSFO',destination_iata:'SFO',scheduled_out:'2026-11-07T02:00:00Z',scheduled_in:'2026-11-07T04:15:00Z'};
const airport={code_iata:'SEA',code_icao:'KSEA',timezone:'America/Los_Angeles',latitude:47.449,longitude:-122.309};
function mockQuery(rows:unknown[],calls:string[],live=false):FlightQuery{return async <T>(path:string,ttl:number)=>{calls.push(path);const data=path.startsWith('/airports/')?(path.includes('KSFO')?{...airport,code_iata:'SFO',code_icao:'KSFO',latitude:37.619,longitude:-122.375}:airport):live?{flights:rows}:{scheduled:rows};return {data:data as T,checkedAt:now,expires:now+ttl*1000};};}

test('future lookup uses schedules, one page, and the departure airport local date',async()=>{
 const calls:string[]=[];const r=await lookupFlight('DL 01134','2026-11-06',mockQuery([scheduled,{...scheduled,scheduled_out:'2026-11-06T02:00:00Z'}],calls),now).catch(e=>e);
 assert.match(r.message,/flight number/); // Flight numbers are at most four digits.
 const result=await lookupFlight('DL 1134','2026-11-06',mockQuery([scheduled,{...scheduled,scheduled_out:'2026-11-06T02:00:00Z'}],calls),now);
 assert.equal(result.flights.length,1);assert.equal(result.flights[0].departure,'18:00');assert.equal(result.flights[0].arrivalDate,'2026-11-06');
 assert.match(calls[0],/^\/schedules\//);assert.match(calls[0],/flight_number=1134/);assert.match(calls[0],/max_pages=1/);assert.equal(calls.length,3);
 assert.equal(result.flights[0].arrivalAirport?.id,'airport:KSFO');assert.equal(typeof result.flights[0].arrivalAirport?.lat,'number');
 assert.equal(result.flights[0].flightaware.ident,'DAL1134');assert.equal(result.flights[0].departureTimeZone,'America/Los_Angeles');
});
test('validates input and correctly converts DST and international date crossings',()=>{
 assert.throws(()=>flightInput('F9W2TE','2026-11-06',now),/booking reference/);
 assert.throws(()=>flightInput('DL1134','2026-02-30',now),/valid departure/);
 assert.equal(flightInput('AS0331','2026-11-06',now).number,'AS331');
 assert.equal(flightInput('6E123','2026-11-06',now).airline,'6E');
 assert.deepEqual(localFlightTime('2026-11-01T09:30:00Z','America/Los_Angeles'),{date:'2026-11-01',time:'01:30'});
 assert.deepEqual(localFlightTime('2026-11-06T15:00:00Z','Asia/Tokyo'),{date:'2026-11-07',time:'00:00'});
 assert.throws(()=>localFlightTime('2026-11-06T15:00:00Z','invalid'));
});
test('multiple flight legs remain distinct; refresh cannot pick the wrong route',async()=>{
 const result=await lookupFlight('DL1134','2026-11-06',mockQuery([scheduled,{...scheduled,destination:'KSFO',scheduled_out:'2026-11-06T22:00:00Z'}],[]),now);
 assert.equal(result.flights.length,2);
 assert.equal(matchingFlight({...result.flights[0],id:'f'},result.flights),undefined);
 const f={...result.flights[0],id:'f',flightaware:{...result.flights[0].flightaware,flightId:'specific'}};
 assert.equal(matchingFlight(f,[{...result.flights[1],flightaware:{...result.flights[1].flightaware,flightId:'other'}}]),undefined);
});
test('near-term lookup uses live status, gates, real instants, and never guesses airport zones',async()=>{
 const live={...scheduled,origin:airport,destination:{...airport,code_iata:'SFO',code_icao:'KSFO',latitude:37.619,longitude:-122.375},estimated_out:'2026-11-07T03:00:00Z',estimated_in:'2026-11-07T05:00:00Z',status:'Delayed',gate_origin:'A4',fa_flight_id:'specific'};
 const calls:string[]=[];const result=await lookupFlight('DL1134','2026-11-06',mockQuery([live],calls,true),Date.parse('2026-11-06T12:00:00Z'));
 assert.equal(calls.length,1);assert.match(calls[0],/^\/flights\/DL1134\?/);assert.match(calls[0],/ident_type=designator/);
 assert.equal(result.flights[0].flightaware.gate,'A4');assert.equal(result.flights[0].departure,'18:00');
 const trip=tripSchema.parse({...example,id:'205968a2-674e-4950-9132-7f48caad226f',stops:[],flights:[{...result.flights[0],id:'f',scheduledDeparture:'18:00',departurePlan:{airport:{id:'sea',name:'SeaTac',address:'',lat:47.45,lng:-122.30},originPlace:example.destination,originStopId:null,kind:'domestic',arrivalMinutes:120,extraMinutes:10,driveOverrideMinutes:30}}]});
 const ics=calendar([{trip:{...trip,version:1},updatedAt:now}],{},'https://trips.example');
 assert.match(ics,/DTSTART:20261107T030000Z/);assert.match(ics,/DTSTART:20261107T000000Z/);assert.match(ics,/DTEND:20261107T020000Z/);assert.match(ics,/Gate A4/);
 await assert.rejects(()=>lookupFlight('DL1134','2026-11-06',async <T>()=>({data:{scheduled:[scheduled],timezone:null} as T,checkedAt:now,expires:now+1000}),now),/time zone/);
});
function database(){const sqlite=new DatabaseSync(':memory:');sqlite.exec('CREATE TABLE service_cache (key TEXT PRIMARY KEY,data TEXT NOT NULL,expires INTEGER NOT NULL)');const db={prepare(sql:string){return {bind(...args:any[]){return {async first(){return sqlite.prepare(sql).get(...args)||null;},async run(){return {meta:{changes:sqlite.prepare(sql).run(...args).changes}};}};}};}} as unknown as D1Database;return {sqlite,db};}
test('shared cache collapses simultaneous paid calls and retains results across clients',async()=>{
 const {sqlite,db}=database();let count=0;
 const fetcher=(async(_url,init)=>{count++;assert.equal(init?.redirect,'manual');assert.equal(new Headers(init?.headers).get('x-apikey'),'test-key');await new Promise(r=>setTimeout(r,20));return Response.json({scheduled:[scheduled]});}) as typeof fetch;
 const a=flightQuery(db,'test-key',fetcher,()=>now),b=flightQuery(db,'test-key',fetcher,()=>now);
 await Promise.all([a('/schedules/a/b?max_pages=1',86400,20),b('/schedules/a/b?max_pages=1',86400,20)]);
 await b('/schedules/a/b?max_pages=1',86400,20);assert.equal(count,1);
 assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM service_cache WHERE key LIKE 'flightaware:usage:%'").get()!.n,1);sqlite.close();
});
test('errors are cached, keys stay out of URLs, and paid failures consume the conservative budget',async()=>{
 const {sqlite,db}=database();let count=0;
 const q=flightQuery(db,'private-key',(async url=>{count++;assert(!String(url).includes('private-key'));return new Response('private upstream body',{status:401});}) as typeof fetch,()=>now);
 await assert.rejects(q('/flights/DL1134?max_pages=1',900,5),/rejected the API key/);
 await assert.rejects(q('/flights/DL1134?max_pages=1',900,5),/rejected the API key/);assert.equal(count,1);
 assert.equal(sqlite.prepare("SELECT SUM(json_extract(data,'$.cost')) total FROM service_cache WHERE key LIKE 'flightaware:usage:%'").get()!.total,5);sqlite.close();
});
test('spending and rolling rate limits reserve atomically before sending requests',async()=>{
 const {sqlite,db}=database();let count=0;
 const q=flightQuery(db,'key',(async()=>{count++;return Response.json({flights:[]});}) as typeof fetch,()=>now);
 sqlite.prepare('INSERT INTO service_cache VALUES (?,?,?)').run('flightaware:usage:2026-10:spent',JSON.stringify({cost:4998,at:now-120000}),now+86400000);
 await assert.rejects(q('/flights/DL1?max_pages=1',900,5),/spending limit/);assert.equal(count,0);
 sqlite.exec('DELETE FROM service_cache');
 await Promise.all(Array.from({length:10},(_,i)=>q(`/flights/DL${i}?max_pages=1`,900,5)));
 await assert.rejects(q('/flights/DL11?max_pages=1',900,5),/request or monthly/);assert.equal(count,10);sqlite.close();
});
