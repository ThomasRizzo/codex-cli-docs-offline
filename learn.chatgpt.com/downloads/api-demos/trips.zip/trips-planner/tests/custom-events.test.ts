import test from 'node:test';
import assert from 'node:assert/strict';
import { example } from '../lib/example';
import { hasLocation, tripSchema, routeKey, type Stop, type Trip, type Route } from '../lib/trips';
import { dayRoute } from '../lib/hotels';
import { calendar } from '../lib/calendar';
import { calendarTravelLayout } from '../lib/calendar-travel';
import { placeOnCalendar, resizeCalendarStop } from '../lib/scheduling';
import { changedTravelLegs, scheduleTravelAvailability } from '../lib/schedule-travel';
import { applyChatTool } from '../lib/chat-tools';

const event:Stop={id:'meeting',kind:'event',name:'Meet with Alex',address:'',date:example.start,time:'10:00',durationMinutes:30,note:'Bring a notebook',mode:'walk'};
const trip:Trip={...example,timeZone:'America/Los_Angeles',stops:[event]};
const hotel={...example.destination,id:'hotel',name:'Seattle Hotel'};

test('custom events persist without coordinates; places still require them',()=>{
 const saved=tripSchema.parse(JSON.parse(JSON.stringify(trip))).stops[0];
 assert.equal(saved.kind,'event');assert.equal(saved.durationMinutes,30);assert.equal(hasLocation(saved),false);
 assert.equal(tripSchema.safeParse({...trip,stops:[{...event,kind:'place'}]}).success,false);
 assert.equal(tripSchema.safeParse({...trip,stops:[{...event,lat:47.6}]}).success,false);
});
test('no invented pin; located custom events retain their event number on the map',()=>{
 assert.equal(dayRoute(trip,trip.start).points.length,0);
 const located={...event,id:'check-in',name:'Check in to hotel',...{lat:hotel.lat,lng:hotel.lng,address:hotel.address,locationName:hotel.name}};
 const points=dayRoute({...trip,stops:[event,{...located,time:'11:00'}]},trip.start).points;
 assert.equal(points.length,1);assert.equal(points[0].name,'Check in to hotel');assert.equal(points[0].stopIndex,1);
});
test('locationless custom events export local start and end with no fake geo or location',()=>{
 const ics=calendar([{trip,updatedAt:Date.now()}],{},'https://trips.test');
 assert.match(ics,/SUMMARY:Meet with Alex/);assert.match(ics,/DTSTART:20261106T180000Z/);assert.match(ics,/DTEND:20261106T183000Z/);
 assert.doesNotMatch(ics,/GEO:|LOCATION:/);assert.match(ics,/Bring a notebook/);
});
test('located events export their title separately from their location',()=>{
 const located={...event,lat:hotel.lat,lng:hotel.lng,address:hotel.address,locationName:hotel.name};
 const ics=calendar([{trip:{...trip,stops:[located]},updatedAt:Date.now()}],{},'https://trips.test');
 assert.match(ics,/SUMMARY:Meet with Alex/);assert.match(ics,/LOCATION:Seattle Hotel/);assert.match(ics,/GEO:47/);
});
test('moving and resizing preserve custom title, kind, notes and absent location',()=>{
 const moved=placeOnCalendar(trip,{place:event,stopId:event.id},trip.start,'13:15','unused');
 const resized=resizeCalendarStop(moved.trip,event.id,60);
 assert.equal(resized.stop.kind,'event');assert.equal(resized.stop.name,event.name);assert.equal(resized.stop.time,'13:15');assert.equal(resized.stop.durationMinutes,60);assert.equal(resized.stop.note,event.note);assert.equal(hasLocation(resized.stop),false);
});
test('locationless overlap checks block conflicts without asking for a route',()=>{
 const next={...event,id:'call',time:'10:15'};
 const result=scheduleTravelAvailability(changedTravelLegs([event],[event,next]),{});
 assert.equal(result.status,'blocked');assert.equal(result.label,'Events overlap');assert.equal(result.missing.length,0);
});
test('custom time is excluded from travel between surrounding known locations',()=>{
 const a={...example.stops[0],time:'09:00',durationMinutes:60};
 const b={...example.stops[1],time:'11:00',durationMinutes:45};
 const key=routeKey(a,b,b.mode),route:Route={mode:'walk',source:'route',shape:[],km:3,minutes:40};
 const legs=changedTravelLegs([a,b],[a,event,b]);
 assert.equal(legs.find(l=>l.key===key)?.gap,30);
 assert.equal(scheduleTravelAvailability(legs,{[key]:route}).status,'blocked');
 assert.equal(calendarTravelLayout([a,event,b]).legs.length,0);
});
test('chat creates, updates and removes custom events using verified hotel locations',()=>{
 const args={event_id:null,title:'Check in to hotel',date:trip.start,time:'15:00',duration_minutes:30,place_id:hotel.id,note:'',mode:'uber'};
 const places=new Map([[hotel.id,hotel]]);
 const added=applyChatTool(trip,'save_event',args,places,()=> 'check-in');
 const saved=added.trip.stops.at(-1)!;assert.equal(saved.kind,'event');assert.equal(saved.name,'Check in to hotel');assert.equal(saved.locationName,hotel.name);assert.equal(saved.lat,hotel.lat);
 const edited=applyChatTool(added.trip,'save_event',{...args,event_id:saved.id,title:'Meet with Alex',place_id:null},places);
 assert.equal(hasLocation(edited.trip.stops.at(-1)!),false);assert.equal(edited.trip.stops.at(-1)!.name,'Meet with Alex');
 const removed=applyChatTool(edited.trip,'remove_event',{event_id:saved.id},places);assert.deepEqual(removed.trip.stops,[event]);
 assert.throws(()=>applyChatTool(trip,'save_event',{...args,place_id:'invented'},places),/search_places/);
});
test('hotel check-in at the hotel does not create a duplicate hotel pin or a zero-distance route',()=>{
 const located={...event,name:'Check in to hotel',lat:hotel.lat,lng:hotel.lng,address:hotel.address,locationName:hotel.name};
 const withHotel={...trip,stops:[located],hotels:[{...hotel,checkIn:trip.start,checkOut:trip.end,note:''}]};
 const points=dayRoute(withHotel,trip.start).points;
 assert.equal(points.length,1);assert.equal(points[0].name,'Check in to hotel');
});
