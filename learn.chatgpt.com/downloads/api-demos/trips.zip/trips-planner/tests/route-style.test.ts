import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { routeGradient } from '../lib/route-style';
import { eventAccent,eventAccents,eventTone } from '../lib/event-colors';
import type { Route } from '../lib/trips';

test('map accents stay matched to the existing calendar colors',()=>{
 const css=readFileSync(new URL('../app/workspace.css',import.meta.url),'utf8');
 for(const [tone,color] of Object.entries(eventAccents))assert.ok(css.includes(`[data-calendar-tone="${tone}"]`)&&css.split(`[data-calendar-tone="${tone}"]`)[1].split('}')[0].includes(`--event-accent:${color}`));
 assert.equal(eventTone(0),'lavender');assert.equal(eventTone(1),'sage');assert.equal(eventTone(2),'rose');
});
test('gradient preserves road corners, endpoints and continuous joins on unevenly sampled routes',()=>{
 const shape:Route['shape']=[[0,0],[0,.001],[0,.002],[.1,.002],[.1,.03]],before=structuredClone(shape);
 const segments=routeGradient(shape,0,1);
 assert.equal(segments[0].color,eventAccent(0));
 assert.equal(segments.at(-1)!.color,eventAccent(1));
 assert.deepEqual(segments[0].path[0],shape[0]);assert.deepEqual(segments.at(-1)!.path.at(-1),shape.at(-1));
 for(let i=1;i<segments.length;i++)assert.deepEqual(segments[i-1].path.at(-1),segments[i].path[0]);
 for(const point of shape)assert.ok(segments.some(s=>s.path.some(p=>p[0]===point[0]&&p[1]===point[1])));
 assert.deepEqual(shape,before);
 assert.ok(segments.length<=32);
});
test('sparse routes still blend; duplicate coordinates and matching colors remain safe',()=>{
 const segments=routeGradient([[47,-122],[47,-122],[47.1,-122]],0,1);
 assert.ok(segments.length>2);assert.ok(segments.every(s=>s.path.every(p=>p.every(Number.isFinite))));
 assert.deepEqual(routeGradient([[1,1],[1,1]],0,1),[]);
 assert.deepEqual(routeGradient([],0,1),[]);
 assert.equal(routeGradient([[1,1],[2,2]],0,4).length,1);
});

test('consecutive stops remain distinct through repeated palette cycles',()=>{
 for(let i=1;i<100;i++)assert.notEqual(eventTone(i-1),eventTone(i));
});
test('every route leg starts and ends with its consecutive calendar event colors',()=>{
 for(let i=0;i<12;i++){
  const segments=routeGradient([[47,-122],[47.01,-122.01]],i,i+1);
  assert.equal(segments[0].color,eventAccents[eventTone(i)]);
  assert.equal(segments.at(-1)!.color,eventAccents[eventTone(i+1)]);
  assert.notEqual(segments[0].color,segments.at(-1)!.color);
 }
});
