import 'fake-indexeddb/auto';
import test from 'node:test';
import assert from 'node:assert/strict';
import { demoSample } from '../lib/demo-sample';
import { initializeBrowserDemo, workspaceFetch } from '../lib/demo-client';
import { listLocalTrips, localWorkspaceInitialized, readLocalChat } from '../lib/local-workspace';

test('migration acknowledgement and API-session renewal preserve local ownership', async t => {
  let handle: (path: string, options?: RequestInit) => Promise<Response> = async () => { throw new Error('Offline'); };
  t.mock.method(globalThis, 'fetch', (path: string, options?: RequestInit) => handle(path, options));

  // Do not seed a blank replacement if the first legacy export fails.
  await assert.rejects(initializeBrowserDemo(), /Offline/);
  assert.equal(await localWorkspaceInitialized(), false);
  const trip = demoSample(), turn = { id: crypto.randomUUID(), tripId: trip.id, user: 'Existing message', assistant: 'Existing answer', sources: [], places: [], changes: [], status: 'complete', afterVersion: null, createdAt: Date.now(), before: null };
  const calls: string[] = [];
  handle = async (path, options) => {
    calls.push((options?.method || 'GET') + ' ' + path);
    if (path === '/api/demo/migrate' && options?.method !== 'DELETE') return Response.json({ migrationId: 'old-session', trips: [trip], turns: [turn] });
    if (options?.method === 'DELETE') {
      assert.deepEqual(await listLocalTrips(), [trip]);
      assert.equal((await readLocalChat(trip.id)).turns[0].assistant, turn.assistant);
    }
    return Response.json({});
  };
  await initializeBrowserDemo();
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(calls, ['GET /api/demo/migrate', 'DELETE /api/demo/migrate', 'POST /api/demo/session']);

  // A subsequent offline startup still returns the saved workspace.
  handle = async () => { throw new Error('Offline'); };
  await initializeBrowserDemo();
  assert.deepEqual(await listLocalTrips(), [trip]);
  await new Promise(resolve => setImmediate(resolve));

  let attempts = 0, renewals = 0;
  const body = JSON.stringify({ message: 'Synthetic check' });
  handle = async (path, options) => {
    if (path === '/api/demo/session') { renewals++; return Response.json({}); }
    assert.equal(path, '/api/chat'); assert.equal(options?.body, body);
    return attempts++ === 0 ? Response.json({ error: 'Expired' }, { status: 401 }) : Response.json({ ok: true });
  };
  assert.equal((await workspaceFetch('/api/chat', { method: 'POST', body })).status, 200);
  assert.equal(renewals, 1); assert.equal(attempts, 2);
  assert.equal((await readLocalChat(trip.id)).turns[0].assistant, turn.assistant);

  // Exhausted quotas do not trigger a fresh session or retry the paid request.
  handle = async path => { assert.equal(path, '/api/chat'); return Response.json({}, { status: 429 }); };
  assert.equal((await workspaceFetch('/api/chat', { method: 'POST', body })).status, 429);
});
