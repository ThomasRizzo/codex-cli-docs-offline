import 'fake-indexeddb/auto';
import { IDBObjectStore } from 'fake-indexeddb';
import test from 'node:test';
import assert from 'node:assert/strict';
import { demoSample } from '../lib/demo-sample';
import { fitChatRequest, localChatRequestSchema } from '../lib/local-chat-contract';
import { initializeLocalWorkspace, listLocalTrips, saveLocalTrip, deleteLocalTrip, resetLocalWorkspace,
  beginLocalTurn, finishLocalTurn, failLocalTurn, readLocalChat, undoLocalTurn, clearLocalChat } from '../lib/local-workspace';
import type { ChatTurn } from '../lib/chat-types';

const pending = (user = 'Add a reminder'): ChatTurn => ({ id: crypto.randomUUID(), user, assistant: '', sources: [], places: [], changes: [], status: 'running', afterVersion: null, createdAt: Date.now() });
const completed = (turn: ChatTurn): ChatTurn => ({ ...turn, assistant: 'Updated your trip.', status: 'complete', changes: ['Updated trip name'] });

test('browser-owned workspace transactions and lifecycle', async t => {
  await t.test('legacy import is atomic, retryable, and never overwrites local edits or restores cleared chat', async () => {
    const trip = demoSample(), turn = { ...completed(pending()), tripId: trip.id, before: trip, afterVersion: 1 };
    const legacy = { migrationId: 'legacy-session', trips: [trip], turns: [turn] };
    await initializeLocalWorkspace(legacy);
    assert.deepEqual(await listLocalTrips(), [trip]);
    assert.equal((await readLocalChat(trip.id)).turns[0].user, turn.user);
    await saveLocalTrip({ ...trip, name: 'Kept in this browser' });
    await clearLocalChat(trip.id);
    await initializeLocalWorkspace(legacy);
    assert.equal((await listLocalTrips())[0].name, 'Kept in this browser');
    assert.equal((await readLocalChat(trip.id)).turns.length, 0);
    await resetLocalWorkspace();
    await initializeLocalWorkspace({ ...legacy, migrationId: 'unacknowledged-session' });
    assert.notEqual((await listLocalTrips())[0].id, trip.id);
    assert.equal((await readLocalChat(trip.id)).turns.length, 0);
  });

  await t.test('manual edits survive rereads; concurrent stale saves cannot overwrite one another', async () => {
    await resetLocalWorkspace(); const [trip] = await listLocalTrips();
    const saves = await Promise.allSettled(['First tab', 'Second tab'].map(name => saveLocalTrip({ ...trip, name })));
    assert.equal(saves.filter(result => result.status === 'fulfilled').length, 1);
    assert.equal(saves.filter(result => result.status === 'rejected').length, 1);
    const [saved] = await listLocalTrips(); assert.equal(saved.version, 2);
    await initializeLocalWorkspace(); assert.deepEqual(await listLocalTrips(), [saved]);
  });

  await t.test('AI reply and itinerary commit together; Undo survives a reload and protects later edits', async () => {
    await resetLocalWorkspace(); const [trip] = await listLocalTrips(), turn = pending();
    const body = await beginLocalTurn(turn, trip.id, trip.start);
    assert.deepEqual(body.trip, trip);
    const saved = await finishLocalTurn(turn.id, completed(turn), { ...trip, name: 'AI edit' });
    assert.equal(saved.trip?.name, 'AI edit'); assert.equal(saved.turn.afterVersion, 2);
    const reloaded = await readLocalChat(trip.id);
    assert.equal(reloaded.turns[0].status, 'complete');
    const undone = await undoLocalTurn(turn.id, trip.id);
    assert.equal(undone.trip.name, trip.name); assert.equal(undone.trip.version, 3);
    assert.equal((await readLocalChat(trip.id)).turns[0].status, 'undone');
    const next = pending(); await beginLocalTurn(next, trip.id);
    const edited = await finishLocalTurn(next.id, completed(next), { ...undone.trip, name: 'Next AI edit' });
    const manual = await saveLocalTrip({ ...edited.trip!, name: 'Newer manual edit' });
    await assert.rejects(undoLocalTurn(next.id, trip.id), /overwrite newer edits/);
    assert.deepEqual((await listLocalTrips())[0], manual);
  });

  await t.test('a late AI reply records a conflict instead of overwriting another tab', async () => {
    await resetLocalWorkspace(); const [trip] = await listLocalTrips(), turn = pending();
    await beginLocalTurn(turn, trip.id);
    const manual = await saveLocalTrip({ ...trip, name: 'Another tab won' });
    const result = await finishLocalTurn(turn.id, completed(turn), { ...trip, name: 'Old AI draft' });
    assert.equal(result.turn.status, 'conflict'); assert.deepEqual(result.turn.changes, []);
    assert.deepEqual(result.trip, manual); assert.equal(result.turn.afterVersion, null);
  });

  await t.test('quota failure rolls back the itinerary as well as the reply', async () => {
    await resetLocalWorkspace(); const [trip] = await listLocalTrips(), turn = pending();
    await beginLocalTurn(turn, trip.id);
    const originalPut = IDBObjectStore.prototype.put;
    const mock = t.mock.method(IDBObjectStore.prototype, 'put', function(this: IDBObjectStore, value: any, key?: IDBValidKey) {
      if (this.name === 'turns' && value.status === 'complete') throw new DOMException('Storage full', 'QuotaExceededError');
      return originalPut.call(this, value, key);
    });
    try { await assert.rejects(finishLocalTurn(turn.id, completed(turn), { ...trip, name: 'Must roll back' }), /out of storage/); }
    finally { mock.mock.restore(); }
    assert.deepEqual((await listLocalTrips())[0], trip);
    assert.equal((await readLocalChat(trip.id)).turns[0].status, 'running');
    await failLocalTurn(turn.id, 'Storage full');
  });

  await t.test('concurrent sends claim once; stopped replies persist without itinerary edits', async () => {
    await resetLocalWorkspace(); const [trip] = await listLocalTrips(), turns = [pending('First'), pending('Second')];
    const claims = await Promise.allSettled(turns.map(turn => beginLocalTurn(turn, trip.id)));
    assert.equal(claims.filter(result => result.status === 'fulfilled').length, 1);
    const saved = (await readLocalChat(trip.id)).turns[0];
    await assert.rejects(clearLocalChat(trip.id), /Wait for the current reply/);
    await failLocalTurn(saved.id, 'Stopped');
    await assert.rejects(finishLocalTurn(saved.id, completed(saved), { ...trip, name: 'Late edit' }), /cancelled/);
    assert.equal((await readLocalChat(trip.id)).turns[0].assistant, 'Stopped');
    assert.deepEqual((await listLocalTrips())[0], trip);
  });

  await t.test('reset and trip deletion cannot be undone by an in-flight response', async () => {
    await resetLocalWorkspace(); const [trip] = await listLocalTrips(), turn = pending();
    await beginLocalTurn(turn, trip.id); await resetLocalWorkspace();
    await assert.rejects(finishLocalTurn(turn.id, completed(turn), trip), /reset/);
    assert.equal((await readLocalChat(trip.id)).turns.length, 0);
    const [fresh] = await listLocalTrips(), second = pending();
    await beginLocalTurn(second, fresh.id); await deleteLocalTrip(fresh.id);
    await assert.rejects(finishLocalTurn(second.id, completed(second), fresh), /reset/);
    await initializeLocalWorkspace(); assert.deepEqual(await listLocalTrips(), []);
  });

  await t.test('general chat has no trip; stale runs recover; New chat physically clears turns', async () => {
    const stale = { ...pending(), createdAt: Date.now() - 300000 };
    await beginLocalTurn(stale, 'general');
    assert.equal((await readLocalChat('general')).turns[0].status, 'error');
    const next = pending('Where should I travel?'), body = await beginLocalTurn(next, 'general');
    assert.equal(body.trip, null);
    await finishLocalTurn(next.id, { ...completed(next), changes: [] }, null);
    assert.equal((await readLocalChat('general')).turns.length, 2);
    await clearLocalChat('general'); assert.equal((await readLocalChat('general')).turns.length, 0);
  });
});

test('untrusted browser context has explicit bounds and cannot select another itinerary', () => {
  const trip = demoSample(), base = { id: crypto.randomUUID(), tripId: trip.id, message: 'Plan my day', trip, history: [] };
  assert.equal(localChatRequestSchema.safeParse({ ...base, tripId: crypto.randomUUID() }).success, false);
  assert.equal(localChatRequestSchema.safeParse({ ...base, history: [{ role: 'system', user: 'a', assistant: 'b', status: 'complete', places: [] }] }).success, false);
  const history = Array.from({ length: 12 }, () => ({ user: 'u', assistant: '旅'.repeat(24000), status: 'complete' as const, places: [] }));
  const fitted = fitChatRequest({ ...base, history });
  assert.ok(fitted.history.length < 12);
  assert.ok(new TextEncoder().encode(JSON.stringify(fitted)).byteLength <= 95000);
  const huge = { ...trip, stops: Array.from({ length: 500 }, (_, i) => ({ ...trip.stops[0], id: String(i), note: '旅'.repeat(1500) })) };
  assert.throws(() => fitChatRequest({ ...base, trip: huge }), /too large/);
});
