import assert from 'node:assert/strict';
import { test } from 'node:test';
import { departureSchedule, wallDate, wallTime, wallMinutes, planningDays, onDay, clashesWithDeparture } from '../lib/departures';
import { routeKey, tripSchema } from '../lib/trips';
import type { Flight, Trip, Stop, Route } from '../lib/trips';
const origin={id:'hotel',name:'Hotel',address:'Seattle',lat:47.6,lng:-122.3};
const airport={id:'SEA',name:'Seattle-Tacoma Airport',address:'SeaTac',lat:47.45,lng:-122.3};
const flight:Flight={id:'f',number:'AS331',date:'2026-11-08',from:'SEA',to:'SFO',departure:'16:00',arrival:'18:00',arrivalDate:'2026-11-08',departurePlan:{airport,originPlace:origin,originStopId:null,kind:'domestic',arrivalMinutes:120,extraMinutes:10,driveOverrideMinutes:null}};
const route:Route={minutes:35,km:25,shape:[],mode:'uber',source:'route'};
const routes={[routeKey(origin,airport,'uber')]:route};
const trip:Trip={id:'e57fc0d8-21d1-42f8-a48b-23ebc3b94238',name:'Seattle',destination:origin,start:'2026-11-08',end:'2026-11-10',stops:[],flights:[flight],version:1};

test('works backwards from departure including arrival buffer and extra travel allowance',()=>{const s=departureSchedule(flight,[],routes);assert.equal(wallTime(s.arrive!),'2:00 pm');assert.equal(wallTime(s.leave!),'1:15 pm');assert.equal(s.depart!-s.leave!,165);});
test('international buffer and manual drive override are respected',()=>{const f={...flight,departurePlan:{...flight.departurePlan!,kind:'international' as const,arrivalMinutes:180,extraMinutes:20,driveOverrideMinutes:45}};const s=departureSchedule(f,[],routes);assert.equal(wallTime(s.leave!),'11:55 am');assert.equal(s.driveMinutes,45);});
test('a flight delay never moves airport arrival later',()=>{const s=departureSchedule({...flight,scheduledDeparture:'16:00',departure:'18:30'},[],routes);assert.equal(wallTime(s.leave!),'1:15 pm');});
test('early flights reserve the preceding calendar day even outside trip dates',()=>{const f={...flight,departure:'00:30'};const s=departureSchedule(f,[],routes);assert.equal(wallDate(s.leave!),'2026-11-07');assert.equal(wallTime(s.leave!),'9:45 pm');assert(onDay(s,'2026-11-07'));assert(onDay(s,'2026-11-08'));assert.deepEqual(planningDays({...trip,flights:[f]},[s]),['2026-11-07','2026-11-08','2026-11-09','2026-11-10']);});
test('date arithmetic is stable across a daylight-saving date and year boundary',()=>{assert.equal(wallDate(wallMinutes('2027-01-01','00:30')!-120),'2026-12-31');const s=departureSchedule({...flight,date:'2026-11-01',departure:'03:30'},[],routes);assert.equal(wallTime(s.leave!),'12:45 am');});
test('unknown route or removed origin never produces a fabricated leave time',()=>{assert.equal(departureSchedule(flight,[],{}).leave,null);const f={...flight,departurePlan:{...flight.departurePlan!,originStopId:'gone',originPlace:null,driveOverrideMinutes:30}};const s=departureSchedule(f,[],routes);assert.equal(s.leave,null);assert.match(s.issue!,/removed/);});
test('legacy flights keep an airport block and prompt for travel details',()=>{const {departurePlan,...legacy}=flight;const s=departureSchedule(legacy,[],{});assert.equal(s.leave,null);assert.equal(s.bufferMinutes,120);assert.equal(wallTime(s.arrive!),'2:00 pm');assert.match(s.issue!,/Choose the airport/);});
test('missing departure time does not reserve an invented time',()=>{const s=departureSchedule({...flight,departure:''},[],routes);assert.equal(s.depart,null);assert.equal(s.arrive,null);assert.equal(s.leave,null);});
test('stop conflicts are checked against full reservation with exclusive end',()=>{const s=departureSchedule(flight,[],routes);const stop:Stop={...origin,date:flight.date,time:'13:15',note:'',mode:'walk'};assert(clashesWithDeparture(stop,[s]));assert(!clashesWithDeparture({...stop,time:'13:14',durationMinutes:1},[s]));assert(!clashesWithDeparture({...stop,time:'16:00'},[s]));assert(!clashesWithDeparture({...stop,time:''},[s]));});
test('server validation retains departure planning data and rejects unsafe buffers',()=>{const parsed=tripSchema.parse(trip);assert.deepEqual(parsed.flights[0].departurePlan,flight.departurePlan);assert(!tripSchema.safeParse({...trip,flights:[{...flight,departurePlan:{...flight.departurePlan!,arrivalMinutes:-10}}]}).success);});


test('previously imported flights still save with their times and airport timing intact',()=>{
 const imported={...flight,scheduledDeparture:'16:00',departure:'18:30',source:'aviationstack',status:'Delayed',delay:150,checkedAt:'2026-11-08T15:00:00Z',gate:'A1',terminal:'1'};
 const parsed=tripSchema.parse({...trip,flights:[imported]}).flights[0];
 assert.equal(parsed.number,flight.number);
 assert.equal(parsed.departure,'18:30');
 assert.deepEqual(parsed.departurePlan,flight.departurePlan);
 assert.equal(wallTime(departureSchedule(parsed,[],routes).leave!),'1:15 pm');
 assert(!('source' in parsed));
 assert(!('checkedAt' in parsed));
});
