import test from 'node:test';
import assert from 'node:assert/strict';
import { isTripOwner } from '../lib/access';
import { sharedTrip, readSharedTrip, calendarURL, shareURL } from '../lib/sharing';
import { discoveryResponse,robotsPolicy } from '../lib/site-policy';
import { example } from '../lib/example';
test('editing requires the exact configured Sites identity and fails closed',()=>{
  assert.equal(isTripOwner('owner','owner'),true);
  for(const [visitor,owner] of [[null,'owner'],['other','owner'],['owner',undefined],['',''],[undefined,undefined]])assert.equal(isTripOwner(visitor,owner??undefined),false);
});
test('shared itinerary excludes notes, chat, unknown fields and owner identity',()=>{
  const raw={...example,owner:'private-owner',chat:[{text:'private chat'}],stops:example.stops.map(s=>({...s,note:'PRIVATE NOTE',bookingReference:'PRIVATE BOOKING'})),hotels:[{...example.destination,id:'hotel',name:'Hotel',checkIn:example.start,checkOut:example.end,note:'PRIVATE HOTEL NOTE'}]};
  const trip=sharedTrip(JSON.stringify(raw),7),text=JSON.stringify(trip);
  assert.equal(trip.version,7);assert.equal(trip.name,example.name);assert.equal(trip.stops[0].name,example.stops[0].name);
  assert.ok(trip.stops.every(s=>s.note===''));assert.equal(trip.hotels?.[0].note,'');assert.doesNotMatch(text,/PRIVATE|private-owner|private chat/);
});
test('malformed share tokens never query storage',async()=>{
  const db={prepare:()=>{throw new Error('should not query');}} as unknown as D1Database;
  for(const token of ['',example.id,'../trips',"' OR 1=1",'a'.repeat(63)])assert.equal(await readSharedTrip(db,token),null);
});
test('unknown, revoked, or deleted-trip tokens do not return an itinerary',async()=>{
  let query='',hash='';const db={prepare:(sql:string)=>{query=sql;return {bind:(v:string)=>{hash=v;return {first:async()=>null};}};}} as unknown as D1Database;
  assert.equal(await readSharedTrip(db,'a'.repeat(64)),null);assert.match(query,/t.owner=s.owner/);assert.match(query,/t.deleted_at IS NULL/);assert.notEqual(hash,'a'.repeat(64));assert.match(hash,/^[a-f0-9]{64}$/);
});
test('calendar links are served directly from the same site and tokens stay distinct from sharing URLs',()=>{
  const origin='https://trips.example',token='b'.repeat(64);
  assert.equal(calendarURL(origin,token),origin+'/api/calendar/feed/'+token);
  assert.equal(shareURL(origin,token),origin+'/share/'+token);
});
test('crawler policy disallows all paths, omits sitemap discovery, and blocks sitemap responses',async()=>{
  const robots=discoveryResponse('/robots.txt')!;assert.equal(robots.status,200);assert.equal(await robots.text(),'User-agent: *\nDisallow: /\n');
  for(const path of ['/sitemap.xml','/sitemap_index.xml','/sitemap.xml.gz','/sitemap/0.xml']){const response=discoveryResponse(path)!;assert.equal(response.status,404);assert.equal(response.headers.get('X-Robots-Tag'),robotsPolicy);}
  assert.equal(discoveryResponse('/share/abc'),null);
});
