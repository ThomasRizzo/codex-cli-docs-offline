import test from 'node:test';
import assert from 'node:assert/strict';
import { tripSchema, hasLocation } from '../lib/trips';
import { example } from '../lib/example';
import { placeOnCalendar, resizeCalendarStop } from '../lib/scheduling';
import { applyChatTool } from '../lib/chat-tools';
import { summarizeCalendar } from '../lib/chat-calendar';
import { sharedTrip } from '../lib/sharing';
import { calendar } from '../lib/calendar';

const bookedTrip=()=>({...structuredClone(example),stops:example.stops.map((s,i)=>({...s,booked:i===0})),version:3});
test('booking status survives JSON validation; old trips remain valid and non-booleans are rejected',()=>{
 const trip=bookedTrip();
 assert.equal(tripSchema.parse(JSON.parse(JSON.stringify(trip))).stops[0].booked,true);
 assert.equal(tripSchema.parse({...trip,stops:trip.stops.map(s=>({...s,booked:false}))}).stops[0].booked,false);
 assert.equal(!!tripSchema.parse(example).stops[0].booked,false);
 assert.equal(tripSchema.safeParse({...trip,stops:[{...trip.stops[0],booked:'yes'}]}).success,false);
});
test('moving, resizing and unrelated assistant edits preserve the reservation',()=>{
 const trip=bookedTrip(),first=trip.stops[0];
 const moved=placeOnCalendar(trip,{place:first,stopId:first.id},trip.end,'18:00','unused');
 const resized=resizeCalendarStop(moved.trip,first.id,90);
 const edited=applyChatTool(resized.trip,'edit_place',{stop_id:first.id,place_id:null,date:null,time:null,duration_minutes:null,note:'Window seat',mode:null},new Map());
 const saved=edited.trip.stops.find(s=>s.id===first.id)!;
 assert.equal(saved.booked,true);assert.equal(saved.date,trip.end);assert.equal(saved.durationMinutes,90);assert.equal(saved.note,'Window seat');
 assert.equal(first.time,example.stops[0].time);
});
test('chat can mark and unmark one existing place without making a reservation or changing other stops',()=>{
 const trip=bookedTrip();
 const marked=applyChatTool(trip,'set_place_booked',{stop_id:trip.stops[1].id,booked:true},new Map());
 assert.equal(marked.trip.stops[1].booked,true);
 assert.deepEqual(marked.trip.stops[0],trip.stops[0]);assert.deepEqual(marked.trip.stops[2],trip.stops[2]);
 assert.equal(trip.stops[1].booked,false);
 const unmarked=applyChatTool(marked.trip,'set_place_booked',{stop_id:trip.stops[1].id,booked:false},new Map());
 assert.deepEqual(unmarked.trip.stops,trip.stops);
 assert.throws(()=>applyChatTool(trip,'set_place_booked',{stop_id:'missing',booked:true},new Map()));
 assert.throws(()=>applyChatTool(trip,'set_place_booked',{stop_id:trip.stops[0].id,booked:'true'},new Map()));
 const eventTrip={...trip,stops:[{...trip.stops[0],kind:'event' as const}]};
 assert.throws(()=>applyChatTool(eventTrip,'set_place_booked',{stop_id:trip.stops[0].id,booked:true},new Map()),/only available for places/);
});
test('adding a second visit to a booked location does not copy its reservation or other visit details',()=>{
 const trip=bookedTrip(),first=trip.stops[0];
 assert.ok(hasLocation(first));
 const result=applyChatTool(trip,'add_place',{place_id:first.id,date:trip.end,time:'18:00',duration_minutes:60,note:'',mode:'uber'},new Map([[first.id,first]]),()=> 'second-visit');
 const second=result.trip.stops.find(s=>s.id==='second-visit')!;
 assert.equal(second.booked,false);assert.equal(second.date,trip.end);assert.equal(second.time,'18:00');
 assert.equal(result.trip.stops[0].booked,true);
});
test('booking status is visible in calendar context, shared trips and subscriptions',()=>{
 const trip=bookedTrip();trip.stops[0].note='Private reservation reference';trip.stops[2].time='';trip.stops[2].booked=true;
 const context=summarizeCalendar(trip,trip.start,{});
 assert.equal(context.events[0].booked,true);assert.equal(context.events[1].booked,false);assert.equal(context.unscheduled[0].booked,true);
 const shared=sharedTrip(JSON.stringify(trip),trip.version);
 assert.equal(shared.stops[0].booked,true);assert.equal(shared.stops[0].note,'');
 const render=(booked:boolean)=>calendar([{trip:{...trip,stops:[{...trip.stops[0],booked}],flights:[]},updatedAt:Date.UTC(2026,9,25)}],{},'https://trips.example').replace(/\r\n /g,'');
 const booked=render(true),unbooked=render(false);
 assert.match(booked,/\\nBooked\./);assert.doesNotMatch(unbooked,/\\nBooked\./);
 assert.equal(booked.match(/^UID:.*$/m)?.[0],unbooked.match(/^UID:.*$/m)?.[0]);
});
