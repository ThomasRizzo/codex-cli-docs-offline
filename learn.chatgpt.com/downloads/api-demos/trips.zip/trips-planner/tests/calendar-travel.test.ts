import test from 'node:test';
import assert from 'node:assert/strict';
import { orderedDayStops, calendarTravelLayout, calendarHotelAnchors, stopMinute } from '../lib/calendar-travel';
import { example } from '../lib/example';
const [first,second,third]=example.stops;
test('calendar and map use chronological stops, followed by untimed places',()=>{
 const input=[third,{...second,time:''},first,{...second,date:example.end}];
 const ordered=orderedDayStops(input,example.start);
 assert.deepEqual(ordered.map(s=>s.id),[first.id,third.id,second.id]);
 assert.equal(input[0],third);
});
test('roomy events have a connector entirely between the cards',()=>{
 const {legs}=calendarTravelLayout(example.stops);
 for(const leg of legs){assert.equal(leg.above,false);assert.equal(leg.compact,false);assert.ok(leg.top>=stopMinute(leg.from)!*1.5+67.5);assert.ok(leg.bottom<stopMinute(leg.to)!*1.5);assert.ok(leg.bottom-leg.top>=36);}
});
test('15-minute events keep travel in its own row and both cards at their duration height',()=>{
 const stops=[{...first,time:'09:00'},{...second,time:'09:15'}];
 const {legs,lanes}=calendarTravelLayout(stops);
 const leg=legs[0];
 assert.equal(leg.compact,true);assert.equal(leg.above,true);
 assert.equal(leg.bottom-leg.top,20);
 assert.ok(leg.top>stopMinute(stops[0])!*1.5);
 assert.equal(leg.bottom,stopMinute(stops[1])!*1.5-2);
 assert.equal(lanes.get(first.id)!.height,67.5);
 assert.equal(lanes.get(second.id)!.height,67.5);
 assert.equal(lanes.get(second.id)!.columns,2);
 assert.notEqual(lanes.get(first.id)!.column,lanes.get(second.id)!.column);
});
test('a 15-minute gap fits a compact control without staggering the cards',()=>{
 const {legs,lanes}=calendarTravelLayout([{...first,time:'09:00'},{...second,time:'10:00'}]);
 assert.equal(legs[0].compact,true);assert.equal(legs[0].above,false);
 assert.equal(legs[0].bottom-legs[0].top,20.5);
 assert.equal(lanes.get(first.id)!.columns,1);
 assert.equal(lanes.get(second.id)!.columns,1);
});
test('column allocation reserves the compact row as well as its destination card',()=>{
 const stops=[{...first,time:'09:00'},{...second,time:'09:45'},{...third,time:'10:30'}];
 const {legs,lanes}=calendarTravelLayout(stops);
 assert.ok(legs.every(leg=>leg.above&&leg.compact));
 for(const stop of stops){assert.equal(lanes.get(stop.id)!.columns,3);assert.equal(lanes.get(stop.id)!.height,67.5);}
 assert.equal(new Set(stops.map(stop=>lanes.get(stop.id)!.column)).size,3);
 assert.deepEqual(stops.map(stop=>stop.time),['09:00','09:45','10:30']);
});
test('a single timed stop and untimed places do not invent calendar connectors',()=>{
 assert.equal(calendarTravelLayout([{...first,time:''}]).legs.length,0);
 assert.equal(calendarTravelLayout([first,{...second,time:''}]).legs.length,0);
});
test('hotel travel touches the first and last card and follows reordered events',()=>{
 for(const stops of [example.stops,orderedDayStops([{...first,time:'18:00'},second,third],example.start)]){
  const layout=calendarTravelLayout(stops),anchors=calendarHotelAnchors(stops,layout);
  assert.equal(anchors.start!.top+anchors.start!.cardHeight+anchors.start!.travelHeight,stopMinute(stops[0])!*1.5);
  assert.equal(anchors.end!.top,stopMinute(stops.at(-1)!)!*1.5+layout.lanes.get(stops.at(-1)!.id)!.height);
  assert.equal(anchors.start!.stop.id,stops[0].id);
  assert.equal(anchors.end!.stop.id,stops.at(-1)!.id);
 }
});
test('hotel bookends stay connected across midnight edges without changing event times',()=>{
 const stops=[{...first,time:'00:00'},{...second,time:'23:45'}];
 const anchors=calendarHotelAnchors(stops,calendarTravelLayout(stops));
 assert(anchors.start!.top<0);
 assert.equal(anchors.start!.top+anchors.start!.cardHeight+anchors.start!.travelHeight,0);
 assert(anchors.end!.top+anchors.end!.travelHeight+anchors.end!.cardHeight>1440*1.5);
 assert.deepEqual(stops.map(s=>s.time),['00:00','23:45']);
});
test('untimed stops keep their hotel bookends outside the timed grid',()=>{
 const stops=[first,{...second,time:''}];
 const anchors=calendarHotelAnchors(stops,calendarTravelLayout(stops));
 assert(anchors.start);assert.equal(anchors.end,null);
 assert.deepEqual(calendarHotelAnchors([] ,calendarTravelLayout([])),{start:null,end:null});
 const untimed=[{...first,time:''}];
 assert.deepEqual(calendarHotelAnchors(untimed,calendarTravelLayout(untimed)),{start:null,end:null});
});
