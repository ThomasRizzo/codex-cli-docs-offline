import test from 'node:test';
import assert from 'node:assert/strict';
import { hotelDayBounds, dayRoute, routePointAccent, HOTEL_ACCENT } from '../lib/hotels';
import { tripSchema, type Hotel } from '../lib/trips';
import { eventAccent } from '../lib/event-colors';
import { example } from '../lib/example';
import { calendar } from '../lib/calendar';
import { applyChatTool } from '../lib/chat-tools';
const hotel:Hotel={id:'hotel-a',name:'Hotel A',address:'Seattle',lat:47.61,lng:-122.34,checkIn:'2026-11-06',checkOut:'2026-11-08',note:''};

test('check-in ends at the hotel, middle days do both, and checkout starts there',()=>{
 assert.deepEqual(hotelDayBounds([hotel],'2026-11-05'),{start:undefined,end:undefined});
 assert.deepEqual(hotelDayBounds([hotel],'2026-11-06'),{start:undefined,end:hotel});
 assert.deepEqual(hotelDayBounds([hotel],'2026-11-07'),{start:hotel,end:hotel});
 assert.deepEqual(hotelDayBounds([hotel],'2026-11-08'),{start:hotel,end:undefined});
 assert.deepEqual(hotelDayBounds([hotel],'2026-11-09'),{start:undefined,end:undefined});
});
test('back-to-back stays transfer from the old hotel to the new one',()=>{
 const next={...hotel,id:'hotel-b',name:'Hotel B',checkIn:hotel.checkOut,checkOut:'2026-11-09',lng:-122.35};
 const trip={...example,hotels:[next,hotel]};
 assert(tripSchema.safeParse(trip).success);
 const route=dayRoute(trip,'2026-11-08');
 assert.deepEqual(route.points.map(p=>p.hotelId),[hotel.id,next.id]);
});
test('route bookends preserve chronological stops, numbering, and event colors',()=>{
 const trip={...example,hotels:[{...hotel,checkIn:'2026-11-05'}]};
 const route=dayRoute(trip,example.start);
 assert.equal(route.points.length,5);
 assert.deepEqual(route.points.slice(1,-1).map(p=>p.id),example.stops.map(s=>s.id));
 assert.deepEqual(route.points.slice(1,-1).map(p=>p.stopIndex),[0,1,2]);
 assert.equal(routePointAccent(route.points[0],0),HOTEL_ACCENT);
 assert.equal(routePointAccent(route.points[1],1),eventAccent(0));
 assert.equal(routePointAccent(route.points[3],3),eventAccent(2));
 assert.equal(trip.stops.length,3);
 const reordered=dayRoute({...trip,stops:[{...trip.stops[0],time:'15:00'},...trip.stops.slice(1)]},example.start);
 assert.equal(reordered.points.at(-2)?.id,trip.stops[0].id);
 assert.equal(reordered.points.at(-1)?.hotelRole,'end');
});
test('empty days retain a hotel pin without routing back to the same hotel',()=>{
 const route=dayRoute({...example,hotels:[hotel]},'2026-11-07');
 assert.equal(route.points.length,1);assert(route.start);assert(route.end);
 assert.equal(dayRoute(example,'2026-11-07').points.length,0);
});
test('return modes are independent per day, and old trips need no migration',()=>{
 const trip={...example,hotels:[{...hotel,returnModes:{'2026-11-06':'uber' as const}}]};
 assert.equal(dayRoute(trip,'2026-11-06').end?.mode,'uber');
 assert.equal(dayRoute(trip,'2026-11-07').end?.mode,'walk');
 assert(tripSchema.safeParse(example).success);
});
test('invalid, duplicate, overlapping and out-of-trip stays are rejected',()=>{
 for(const hotels of [
  [{...hotel,checkOut:hotel.checkIn}],
  [{...hotel,checkIn:'2026-02-30'}],
  [hotel,{...hotel}],
  [hotel,{...hotel,id:'hotel-b',checkIn:'2026-11-07',checkOut:'2026-11-09'}],
  [{...hotel,checkIn:'2026-12-01',checkOut:'2026-12-03'}],
 ])assert.equal(tripSchema.safeParse({...example,hotels}).success,false);
});
test('hotel stays sync as stable all-day calendar events, with checkout exclusive',()=>{
 const trip={...example,hotels:[{...hotel,note:'Booking note'}]};
 const render=()=>calendar([{trip,updatedAt:Date.UTC(2026,9,25)}],{},'https://trips.example');
 const event=render().split('BEGIN:VEVENT').find(e=>e.includes('hotel-hotel-a@'))!;
 assert.match(event,/DTSTART;VALUE=DATE:20261106/);assert.match(event,/DTEND;VALUE=DATE:20261108/);
 assert.match(event,/TRANSP:TRANSPARENT/);assert.match(event,/Booking note/);
 const uid=event.match(/UID:.*/)?.[0];trip.hotels[0].name='Updated hotel';assert(render().includes(uid!));
 assert(!calendar([{trip:{...trip,hotels:[]},updatedAt:Date.now()}],{},'https://trips.example').includes('hotel-hotel-a@'));
});
test('assistant can add, edit, route to, and remove verified hotel stays without losing other items',()=>{
 const places=new Map([[hotel.id,hotel]]);
 const args={hotel_id:null,place_id:hotel.id,check_in:hotel.checkIn,check_out:hotel.checkOut,note:''};
 assert.throws(()=>applyChatTool(example,'save_hotel',args,new Map()),/search_places/);
 const added=applyChatTool(example,'save_hotel',args,places,()=>hotel.id).trip;
 assert.deepEqual(added.stops.filter(s=>!s.hotelCheckInId),example.stops);assert.equal(added.stops.find(s=>s.hotelCheckInId===hotel.id)?.time,'15:00');assert.equal(added.hotels?.length,1);
 const edited=applyChatTool(added,'save_hotel',{...args,hotel_id:hotel.id,note:'Check-in reminder'},places).trip;
 assert.equal(edited.hotels?.[0].note,'Check-in reminder');assert.equal(edited.hotels?.length,1);
 const changed=applyChatTool(edited,'set_hotel_return_mode',{hotel_id:hotel.id,date:hotel.checkIn,mode:'uber'},places).trip;
 assert.equal(dayRoute(changed,hotel.checkIn).end?.mode,'uber');
 assert.throws(()=>applyChatTool(edited,'set_hotel_return_mode',{hotel_id:hotel.id,date:hotel.checkOut,mode:'uber'},places),/night/);
 const removed=applyChatTool(changed,'remove_hotel',{hotel_id:hotel.id},places).trip;
 assert.deepEqual(removed.hotels,[]);assert.deepEqual(removed.stops,example.stops);
});
