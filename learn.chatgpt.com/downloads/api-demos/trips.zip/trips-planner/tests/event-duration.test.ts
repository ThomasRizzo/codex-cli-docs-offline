import test from 'node:test';
import assert from 'node:assert/strict';
import { stopDuration,stopEndMinute,snapEventDuration } from '../lib/event-duration';
import { resizeCalendarStop,placeOnCalendar } from '../lib/scheduling';
import { calendarTravelLayout,calendarHotelAnchors } from '../lib/calendar-travel';
import { changedTravelLegs,scheduleTravelAvailability } from '../lib/schedule-travel';
import { calendar } from '../lib/calendar';
import { tripSchema,routeKey,type Route } from '../lib/trips';
import { applyChatTool } from '../lib/chat-tools';
import { clashesWithDeparture,departureSchedule } from '../lib/departures';
import { example } from '../lib/example';
const [first,second]=example.stops;
const trip={...example,stops:[{...first,time:'09:00',durationMinutes:45},{...second,time:'11:00',durationMinutes:45,mode:'uber' as const}],flights:[]};
const a=trip.stops[0],b=trip.stops[1];
const route=(minutes:number,mode:'walk'|'uber'='uber'):Route=>({minutes,mode,km:2,shape:[],source:'route'});

test('legacy events default to 45 minutes and stay within the day',()=>{
 assert.equal(stopDuration(first),45);assert.equal(stopDuration({...first,time:'23:45'}),15);
 assert.equal(stopDuration({...first,time:'23:58'}),2);assert.equal(stopEndMinute({...first,time:''}),null);
});
test('resize snaps to 15 minutes, with minimum and midnight limits',()=>{
 assert.equal(snapEventDuration(a,9*60+67),60);assert.equal(snapEventDuration(a,9*60+68),75);
 assert.equal(snapEventDuration(a,9*60),15);assert.equal(snapEventDuration({...a,time:'23:00'},1500),60);
});
test('resizing persists length while preserving the start, other stops and original trip',()=>{
 const before=JSON.stringify(trip),changed=resizeCalendarStop(trip,a.id,90);
 assert.equal(changed.stop.time,'09:00');assert.equal(changed.stop.durationMinutes,90);
 assert.equal(changed.trip.stops[1],trip.stops[1]);assert.equal(JSON.stringify(trip),before);
 assert.equal(tripSchema.parse(JSON.parse(JSON.stringify(changed.trip))).stops[0].durationMinutes,90);
 assert.equal(placeOnCalendar(changed.trip,{place:a,stopId:a.id},a.date,'12:00','unused').stop.durationMinutes,90);
 assert.throws(()=>resizeCalendarStop(trip,a.id,0));assert.throws(()=>resizeCalendarStop(trip,a.id,1000),/midnight/);
 assert.equal(tripSchema.safeParse({...trip,stops:[{...a,time:'23:45',durationMinutes:30}]}).success,false);
});
test('short and long events render to scale; hotel return follows the new end',()=>{
 const stops=[{...a,durationMinutes:15},{...b,durationMinutes:120}];
 const layout=calendarTravelLayout(stops);
 assert.equal(layout.lanes.get(a.id)!.height,22.5);assert.equal(layout.lanes.get(b.id)!.height,180);
 assert.equal(layout.legs[0].top,(9*60+15)*1.5+1);
 assert.equal(calendarHotelAnchors(stops,layout).end!.top,13*60*1.5);
});
test('resizing checks travel from the new end and changing mode changes available space',()=>{
 const resized=resizeCalendarStop(trip,a.id,105),legs=changedTravelLegs(trip.stops,resized.trip.stops);
 assert.equal(legs.length,1);assert.equal(legs[0].gap,15);
 assert.equal(scheduleTravelAvailability(legs,{[routeKey(a,b,'uber')]:route(6)}).status,'ready');
 assert.equal(scheduleTravelAvailability(legs,{[routeKey(a,b,'uber')]:route(20)}).status,'blocked');
 assert.equal(scheduleTravelAvailability(legs,{}).status,'checking');
 const walk=legs.map(l=>({...l,to:{...l.to,mode:'walk' as const},key:routeKey(a,b,'walk')}));
 assert.equal(scheduleTravelAvailability(walk,{[routeKey(a,b,'walk')]:route(21,'walk')}).status,'blocked');
 const overlap=resizeCalendarStop(trip,a.id,135);
 assert.match(scheduleTravelAvailability(changedTravelLegs(trip.stops,overlap.trip.stops),{}).message,/overlap/);
});
test('a visit ending exactly at airport time fits; extending into it is blocked',()=>{
 const flight={id:'f',number:'DL1134',date:a.date,from:'SEA',to:'SFO',departure:'12:00',arrival:'14:00',arrivalDate:a.date};
 const plan=departureSchedule(flight,trip.stops,{});
 assert.equal(clashesWithDeparture({...a,durationMinutes:60},[plan]),false);
 assert.equal(clashesWithDeparture({...a,durationMinutes:75},[plan]),true);
});
test('Apple Calendar uses the new duration without changing the event UID',()=>{
 const render=(t:typeof trip)=>calendar([{trip:t,updatedAt:Date.UTC(2026,9,25)}],{},'https://trips.example').replace(/\r\n /g,'');
 const before=render(trip),after=render({...trip,version:trip.version+1,stops:[{...a,durationMinutes:90},b]});
 assert.match(before,/DTEND:20261106T174500Z/);assert.match(after,/DTEND:20261106T183000Z/);
 assert.equal(before.match(/UID:.*stop-market.*/)?.[0],after.match(/UID:.*stop-market.*/)?.[0]);
 assert.match(after,/90 minute visit/);
});
test('assistant duration edits are retained and unrelated edits preserve them',()=>{
 const args={stop_id:a.id,place_id:null,date:null,time:null,note:null,mode:null,duration_minutes:90};
 const changed=applyChatTool(trip,'edit_place',args,new Map());
 assert.equal(changed.trip.stops[0].durationMinutes,90);
 const kept=applyChatTool(changed.trip,'edit_place',{...args,duration_minutes:null,note:'Lunch'},new Map());
 assert.equal(kept.trip.stops[0].durationMinutes,90);
});
