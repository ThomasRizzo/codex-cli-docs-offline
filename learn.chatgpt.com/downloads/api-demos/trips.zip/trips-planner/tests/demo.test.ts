import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { Miniflare, Log, LogLevel } from 'miniflare';
import { createDemoSession, findDemoSession, resetDemoSession, cleanupDemoSessions, DEMO_LIFETIME } from '../lib/demo-session';
import { enforceDemoRateLimit, normalizeClientIp, resolveTrustedClientIp } from '../lib/demo-rate-limit';
import { prepareDemoRequest } from '../lib/demo-request';
import { demoSample } from '../lib/demo-sample';
import { modelResponse } from '../lib/chat-model';

const now = Date.parse('2026-11-02T12:30:00Z');
const request = (path = '/api/trips', init: RequestInit = {}, ip = '192.0.2.1') => new Request('https://demo.test' + path, {
  ...init, headers: { 'cf-connecting-ip': ip, origin: 'https://demo.test', ...init.headers },
});

test('anonymous sessions, quotas, and request boundaries on real D1', { timeout: 60000 }, async t => {
  const worker = new Miniflare({ modules: true, script: 'export default { fetch() { return new Response("ok"); } };',
    d1Databases: { DB: 'trips-demo-test' }, compatibilityDate: '2026-05-15', host: '127.0.0.1', port: 0, cf: false, log: new Log(LogLevel.ERROR) });
  t.after(() => worker.dispose());
  const database = await worker.getD1Database('DB') as unknown as D1Database;
  const directory = new URL('../drizzle/', import.meta.url);
  for (const file of (await readdir(directory)).filter(name => name.endsWith('.sql')).sort()) {
    for (const statement of (await readFile(new URL(file, directory), 'utf8')).split('--> statement-breakpoint').filter(part => part.trim())) await database.prepare(statement).run();
  }

  await t.test('sessions store authorization metadata only; legacy data still expires and stays owner-isolated', async () => {
    const a = await createDemoSession(database, now), b = await createDemoSession(database, now + 1000);
    const headers = new Headers({ cookie: a.cookie.split(';')[0] });
    assert.match(a.cookie, /^__Host-trips-demo=[a-f0-9]{64}; Path=\/; HttpOnly; Secure; SameSite=Lax; Max-Age=86400$/);
    assert.notEqual(a.session.id, b.session.id);
    assert.ok(!a.session.id.includes(a.cookie.split('=')[1].split(';')[0]));
    assert.equal((await findDemoSession(database, headers, now + 1))?.id, a.session.id);
    assert.equal((await findDemoSession(database, headers, now + DEMO_LIFETIME - 1))?.expires_at, now + DEMO_LIFETIME);
    assert.equal(await findDemoSession(database, headers, now + DEMO_LIFETIME), null);
    assert.equal(await findDemoSession(database, new Headers({ cookie: '__Host-trips-demo=' + 'a'.repeat(64) }), now), null);
    assert.equal((await database.prepare('SELECT id FROM trips').all()).results.length, 0);
    assert.equal((await database.prepare('SELECT id FROM chat_turns').all()).results.length, 0);
    // Only pre-migration records have server-side content.
    for (const session of [a.session, b.session]) {
      const trip = demoSample(now);
      await database.prepare('INSERT INTO trips (id,owner,data,version,updated_at) VALUES (?,?,?,1,?)').bind(trip.id, session.id, JSON.stringify(trip), now).run();
    }
    const rows = (await database.prepare('SELECT id,owner FROM trips').all<{id:string;owner:string}>()).results;
    const other = await database.prepare('SELECT id FROM trips WHERE owner=? AND id=?').bind(b.session.id, rows.find(row => row.owner === a.session.id)!.id).first();
    assert.equal(other, null);
    await resetDemoSession(database, a.session, now + 2000);
    assert.equal(await findDemoSession(database, headers, now + 2001), null);
    assert.equal(await database.prepare('SELECT id FROM trips WHERE owner=?').bind(a.session.id).first(), null);
    assert.ok(await database.prepare('SELECT id FROM trips WHERE owner=?').bind(b.session.id).first());
    // Simulate work already in flight at reset, then verify the grace-period sweep.
    await database.prepare('INSERT INTO chat_turns (id,owner,trip_id,user_text,created_at) VALUES (?,?,?,?,?)').bind('late', a.session.id, 'general', 'late request', now).run();
    await database.prepare('INSERT INTO trips (id,owner,data,updated_at) VALUES (?,?,?,?)').bind('private', 'private-owner', '{}', now).run();
    await cleanupDemoSessions(database, now + 302001);
    assert.equal(await database.prepare('SELECT id FROM chat_turns WHERE owner=?').bind(a.session.id).first(), null);
    assert.equal(await database.prepare('SELECT id FROM demo_sessions WHERE id=?').bind(a.session.id).first(), null);
    assert.ok(await database.prepare('SELECT id FROM trips WHERE owner=?').bind(b.session.id).first());
    await cleanupDemoSessions(database, now + DEMO_LIFETIME + 302000);
    assert.equal(await database.prepare('SELECT id FROM trips WHERE owner=?').bind(b.session.id).first(), null);
    assert.ok(await database.prepare('SELECT id FROM trips WHERE owner=?').bind('private-owner').first());
  });

  await t.test('concurrent quotas persist across sessions and the site budget spans client IPs', async () => {
    const reserve = () => enforceDemoRateLimit(database, request(), 'burst', { minute: 3, day: 4 }, now);
    const burst = await Promise.all(Array.from({ length: 12 }, reserve));
    assert.equal(burst.filter(result => result === null).length, 3);
    assert.equal(burst.filter(result => result?.status === 429).length, 9);
    assert.equal(await enforceDemoRateLimit(database, request(), 'burst', { minute: 3, day: 4 }, now + 60000), null);
    assert.equal((await enforceDemoRateLimit(database, request(), 'burst', { minute: 3, day: 4 }, now + 120000))?.status, 429);
    assert.equal(await enforceDemoRateLimit(database, request(), 'shared', { minute: 1, day: 1 }, now, 'site'), null);
    assert.equal((await enforceDemoRateLimit(database, request('/api/chat', {}, '192.0.2.2'), 'shared', { minute: 1, day: 1 }, now, 'site'))?.status, 429);
    assert.equal(await enforceDemoRateLimit(database, request(), 'session:abc', { minute: 1, windowMs: 3600000 }, now, 'site'), null);
    assert.equal((await enforceDemoRateLimit(database, request(), 'session:abc', { minute: 1, windowMs: 3600000 }, now + 60000, 'site'))?.status, 429);
    assert.equal(await enforceDemoRateLimit(database, request(), 'session:abc', { minute: 1, windowMs: 3600000 }, now + 3600000, 'site'), null);
    const rows = await database.prepare('SELECT * FROM demo_rate_limits').all();
    assert.doesNotMatch(JSON.stringify(rows), /192\.0\.2\./);
    assert.equal((await enforceDemoRateLimit(undefined, request(), 'fail', { minute: 1 }, now))?.status, 503);
  });

  await t.test('legacy links are blocked and mutations require the exact Origin before reading bodies', async () => {
    for (const path of ['/share/test', '/api/share', '/api/shared/test', '/api/calendar/feed/test', '/api/account', '/api/flights', '/%61pi/share', '/api/%73hare', '/%73hare/test']) {
      assert.equal((await prepareDemoRequest(request(path), database) as Response).status, 404);
    }
    for (const headers of ([{ origin: 'https://elsewhere.test' }, { origin: '' }, { 'sec-fetch-site': 'cross-site' }] as Record<string, string>[])) {
      assert.equal((await prepareDemoRequest(request('/api/trips', { method: 'POST', headers }), database) as Response).status, 403);
    }
    const oversized = await prepareDemoRequest(request('/api/trips', { method: 'POST', body: 'a'.repeat(100001) }), database);
    assert.equal((oversized as Response).status, 413);
    const accepted = await prepareDemoRequest(request('/api/trips', { method: 'PATCH', body: '{"name":"Trip"}' }), database);
    assert.ok(accepted instanceof Request);
    assert.deepEqual(await accepted.json(), { name: 'Trip' });
  });
});

test('hosted limits trust only the edge IP, including canonical IPv6 forms', () => {
  assert.equal(resolveTrustedClientIp(new Request('https://demo.test/api/chat', { headers: { 'x-forwarded-for': '192.0.2.1' } })), null);
  assert.equal(normalizeClientIp('::ffff:192.0.2.1'), '192.0.2.1');
  assert.equal(normalizeClientIp('2001:DB8:0:0:0:0:0:1'), '2001:db8::1');
  for (const value of ['192.0.2.1, 192.0.2.2', '192.0.2.1:443', 'unknown']) assert.equal(normalizeClientIp(value), null);
});

test('Responses uses the public endpoint with enforced non-storage and refuses redirects', async t => {
  let calls = 0;
  t.mock.method(globalThis, 'fetch', async (url: string, init: RequestInit) => {
    calls++;
    assert.equal(url, 'https://api.openai.com/v1/responses');
    assert.equal(init.redirect, 'manual');
    const body = JSON.parse(init.body as string);
    assert.equal(body.store, false);
    assert.equal(body.max_output_tokens, 4000);
    assert.equal(body.max_tool_calls, 3);
    return new Response('', { status: 302, headers: { location: 'https://elsewhere.test' } });
  });
  await assert.rejects(() => modelResponse('test-only', { store: true, max_output_tokens: 100000 }, new AbortController().signal, () => {}), /could not complete/);
  assert.equal(calls, 1);
});
