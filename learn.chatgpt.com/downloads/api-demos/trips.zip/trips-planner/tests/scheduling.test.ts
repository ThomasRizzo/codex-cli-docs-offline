import test from 'node:test';
import assert from 'node:assert/strict';
import { calendarTime, placeOnCalendar, snapCalendarMinute } from '../lib/scheduling';
import { example } from '../lib/example';
const cafe={id:'coffee',name:'Coffee',address:'Seattle',lat:47.615,lng:-122.32};
test('calendar drop snaps to a quarter hour and stays inside the same day',()=>{
 assert.equal(snapCalendarMinute(34,480,1080),510);
 assert.equal(snapCalendarMinute(-100,480,1080),480);
 assert.equal(calendarTime(snapCalendarMinute(5000,0,1440)),'23:45');
});
test('scheduling a result preserves existing stops and places it in route order',()=>{
 const changed=placeOnCalendar(example,{place:cafe},example.start,'10:00','new-stop');
 assert.equal(changed.stop.id,'new-stop');
 assert.deepEqual(changed.trip.stops.filter(s=>s.date===example.start).map(s=>s.time),['09:00','10:00','11:00','14:00']);
 assert.equal(example.stops.length,3);
 assert.equal(changed.trip.flights,example.flights);
});
test('dropping the same result twice reschedules it without duplicating it',()=>{
 const first=placeOnCalendar(example,{place:cafe},example.start,'10:00','new-stop');
 first.stop.note='Reservation';first.stop.mode='uber';
 const second=placeOnCalendar(first.trip,{place:cafe},example.start,'12:15','unused-id');
 assert.equal(second.trip.stops.length,first.trip.stops.length);
 assert.equal(second.stop.id,first.stop.id);
 assert.equal(second.stop.note,'Reservation');assert.equal(second.stop.mode,'uber');
});
test('moving an existing stop to another day preserves its identity and details',()=>{
 const stop=example.stops[0];
 const changed=placeOnCalendar(example,{place:stop,stopId:stop.id},example.end,'08:30','unused-id');
 assert.equal(changed.trip.stops.length,example.stops.length);
 assert.deepEqual(changed.stop,{...stop,date:example.end,time:'08:30',durationMinutes:45});
});
test('stale stops, dates outside the trip, and invalid times cannot be saved',()=>{
 assert.throws(()=>placeOnCalendar(example,{place:cafe,stopId:'removed'},example.start,'10:00','id'));
 assert.throws(()=>placeOnCalendar(example,{place:cafe},'2026-01-01','10:00','id'));
 assert.throws(()=>placeOnCalendar(example,{place:cafe},example.start,'24:00','id'));
});
