import test from 'node:test';
import assert from 'node:assert/strict';
import { applyChatTool } from '../lib/chat-tools';
import { extractAnswer, safeSource, CHAT_MODEL } from '../lib/chat-model';
import { example } from '../lib/example';
const location={id:'verified',name:'Seattle Central Library',address:'1000 4th Ave, Seattle',lat:47.6067,lng:-122.3326};
const places=new Map([[location.id,location]]);
const trip=structuredClone({...example,version:7});
test('requested Astra model stays fixed',()=>assert.equal(CHAT_MODEL,'gpt-6-astra'));
test('new stops use verified coordinates and preserve unrelated itinerary',()=>{const r=applyChatTool(trip,'add_place',{place_id:'verified',date:trip.start,time:'12:00',note:'Books',mode:'walk'},places,()=> 'new-stop');assert.equal(r.trip.stops.length,4);assert.deepEqual(r.trip.stops.slice(0,3),trip.stops);assert.equal(r.trip.stops[3].lat,location.lat);assert.equal(r.trip.version,7);assert.equal(trip.stops.length,3);});
test('model cannot invent a location or write another trip',()=>{assert.throws(()=>applyChatTool(trip,'add_place',{place_id:'invented',date:trip.start,time:'12:00',note:'',mode:'walk'},places));assert.throws(()=>applyChatTool(trip,'edit_place',{stop_id:'another-trip-stop',place_id:null,date:null,time:null,note:null,mode:'uber'},places));});
test('trip dates, times, unknown fields and maximum sizes are validated',()=>{for(const patch of [{date:'2028-01-01'},{time:'25:00'},{note:'x'.repeat(1501)},{owner:'someone-else'}])assert.throws(()=>applyChatTool(trip,'add_place',{place_id:'verified',date:trip.start,time:'12:00',note:'',mode:'walk',...patch},places));});
test('partial edit preserves untouched fields and empty time unschedules',()=>{const r=applyChatTool(trip,'edit_place',{stop_id:'market',place_id:null,date:null,time:'',note:null,mode:'uber'},places);assert.equal(r.trip.stops[0].time,'');assert.equal(r.trip.stops[0].mode,'uber');assert.equal(r.trip.stops[0].note,trip.stops[0].note);});
test('reorder requires every stop exactly once',()=>{assert.throws(()=>applyChatTool(trip,'reorder_places',{date:trip.start,stop_ids:['market']},places));assert.throws(()=>applyChatTool(trip,'reorder_places',{date:trip.start,stop_ids:['market','market','garden']},places));assert.deepEqual(applyChatTool(trip,'reorder_places',{date:trip.start,stop_ids:['garden','market','sculpture']},places).trip.stops.map(s=>s.id),['garden','market','sculpture']);});
test('date edits cannot strand existing events',()=>{assert.throws(()=>applyChatTool(trip,'edit_trip',{name:null,start:'2026-11-07',end:null},places));});
test('airport planning requires verified airport and origin',()=>{assert.throws(()=>applyChatTool(trip,'plan_airport',{flight_id:'absent',airport_place_id:'verified',origin_stop_id:null,origin_place_id:'verified',kind:'domestic',arrival_minutes:120,extra_minutes:10,drive_minutes_override:null},places));});
test('citations become clickable links and unsafe protocols are discarded',()=>{const text='Visit here.';const r=extractAnswer([{type:'message',content:[{type:'output_text',text,annotations:[{type:'url_citation',start_index:6,end_index:10,url:'https://example.com/hours',title:'Hours'}]}]}]);assert.match(r.text,/\[1\]\(https:\/\/example.com\/hours\)/);assert.deepEqual(r.sources,[{url:'https://example.com/hours',title:'Hours'}]);assert.equal(safeSource('javascript:alert(1)'),null);assert.equal(safeSource('data:text/html,hi'),null);});


test('assistant saves manual flight details without an external flight service',()=>{
 const r=applyChatTool(trip,'save_flight',{flight_id:null,number:'AS331',date:trip.start,from:'SFO',to:'SEA',departure:'10:00',arrival:'12:00',arrival_date:trip.start,departure_time_zone:'America/Los_Angeles',arrival_time_zone:'America/Los_Angeles'},places,()=> 'manual-flight');
 const f=r.trip.flights.find(f=>f.id==='manual-flight')!;
 assert.equal(f.departure,'10:00');assert.equal(f.arrival,'12:00');
 assert.equal(f.scheduledDeparture,'10:00');
 assert.deepEqual(r.trip.stops,trip.stops);
 assert(!('source' in f));
});
