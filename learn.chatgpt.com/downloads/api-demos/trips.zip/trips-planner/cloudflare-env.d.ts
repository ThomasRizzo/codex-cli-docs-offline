declare namespace Cloudflare {
  interface Env { DB?: D1Database; BUCKET?: R2Bucket; TRIPS_OWNER_ID?: string; TRIPS_DEMO_MODE?: string; TRIPS_ASSISTANT_ENABLED?: string; OPENAI_API_KEY?: string; FLIGHTAWARE_API_KEY?: string; GOOGLE_MAPS_BROWSER_KEY?: string; }
}
