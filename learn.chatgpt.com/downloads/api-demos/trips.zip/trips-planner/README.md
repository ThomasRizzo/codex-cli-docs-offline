# Trips

Plan a trip with an interactive map, daily calendar, and assistant powered by the OpenAI Responses API. Research places, schedule visits, and organize hotels and flights. The anonymous demo saves trips and chat in the browser's IndexedDB.

## Run locally

Requires Node.js 22.13 or newer and Python 3.9 or newer.

```sh
npm ci
cp .env.example .dev.vars
```

Set `TRIPS_DEMO_MODE=true` in `.dev.vars`. To enable the assistant, also set
`TRIPS_ASSISTANT_ENABLED=true` and `OPENAI_API_KEY` to a project key with access
to `gpt-6-astra` and `web_search`. Keep `.dev.vars` private and untracked.
Leave the assistant flag blank to use the map and calendar without AI.

Build the Worker configuration, initialize a fresh local D1 database, and start
the development server:

```sh
npm run build
for migration in drizzle/*.sql; do
  node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file "$migration" || exit 1
done
npm run dev
```

Open the printed local URL. The example itinerary is ready to explore; AI runs
only after you send a message. Run database initialization once for a fresh
database. For an existing database, apply only migrations that have not already
run, in filename order.

## Hosting

The source download contains no hosted project ID, trip data, or API credentials.
It uses the standard public OpenAI API endpoint. To deploy, choose a compatible
Cloudflare Workers host, or use Sites if you have access. Provision the `DB`
D1 binding and apply every checked-in migration before serving requests. Configure
the demo flags and API key as server-side runtime settings. Keep the included
request limits and trusted edge-IP handling; do not expose the API key to the
browser. A different hosting stack needs equivalent durable quota storage and
trusted proxy handling.

The optional owner-only mode requires Sites authentication and an explicitly
configured `TRIPS_OWNER_ID`. It uses D1 for trip data and supports sharing and
calendar feeds. Leave `TRIPS_DEMO_MODE=true` for the anonymous browser-storage demo.

## Services

- Place search: Photon / OpenStreetMap, on explicit search, cached for one day.
- Map tiles: OpenStreetMap standard tiles with browser-managed caching and visible attribution. No offline downloads or prefetch. Tile requests send only the Site origin as their referrer, never a trip URL or share token.
- Walking and driving routes: FOSSGIS Valhalla, queried sequentially and cached for seven days. Driving times are estimates; they exclude live traffic and Uber pickup waits. An external Uber link opens the route without booking a ride.
- Flights: enter booking details manually or supply them to the assistant. Flights support airport timing and calendar subscriptions. There is no external flight provider or automatic status monitoring.

Place and routing services are community services with best-effort availability. Failures are shown explicitly and never replaced with invented routes.

## Verification

The initial version was checked in the browser for trip creation, dates, place search, map markers, route estimates, mode changes, manual flights, and persistence after reload. API checks cover anonymous access, cross-origin writes, stale versions, invalid ranges, airport timing, and calendar subscriptions.

## Airport calendar blocks

Each flight supports a departure airport, a starting place (either a linked itinerary stop or an address), flight type, arrival buffer, pickup/traffic allowance, and optional manual drive estimate. Default buffers are 120 minutes for domestic and 180 for international flights; these are editable planning defaults, not a guarantee for every airport or airline. The source for the defaults is https://www.phl.org/flights/security-information/screening.

The calendar reserves driving time + extra allowance + airport buffer, counting backward from scheduled departure. Existing original scheduled departure times are retained for airport planning. Missing route data is shown explicitly, with the airport buffer still visible. Times are floating local times at the departing airport; no flight duration is inferred from arrival time in another time zone. Overnight blocks appear on both dates, including dates outside the base trip range. Scheduled places inside the reserved period are flagged.

Run timing regression checks with `node --import tsx --test tests/departures.test.ts`.

## Hotels

Add hotels by name or address with check-in and check-out dates. Check-in day ends at the hotel; checkout day starts there; intervening days do both. Back-to-back stays can switch hotels on the same day, and overlapping nights are rejected. Hotel route endpoints are derived rather than copied into sightseeing stops, so moving events preserves the route and event colors. Each final hotel leg has a per-day Walk/Uber choice. Stays sync to the calendar feed as transparent all-day events covering their nights and can be added, edited, or removed by the assistant. New airport-timing plans default to the day’s hotel when available.

## Sharing and public access

In owner-only mode, the app supports a revocable 256-bit share link from the
floating toolbar; visitors also need access through the Site's hosting policy. Shared pages expose one
current itinerary, map, flights, and hotels, excluding notes and chat. Visitors
have no editing or AI controls. Shared views refresh every minute and on return
to the page. Tokens are checked server-side, including after route estimation;
deleting a trip or revoking its link prevents further reads. Private APIs still
require the configured owner. Search discovery is disabled with a deny-all
robots.txt, no sitemap, page metadata, and X-Robots-Tag headers. These directives
are for cooperative crawlers; access control is independent of them.

Calendar subscriptions now use `/api/calendar/feed/<token>` on this same site.
Existing tokens and event UIDs are preserved. The former calendar relay only
redirects legacy subscription URLs; no credentials or calendar logic remain in
that compatibility site. Calendar tokens remain separate from per-trip shares.


## Anonymous disposable demo

Set `TRIPS_DEMO_MODE=true` in the Sites runtime to serve an anonymous demo.
Publish the guarded demo build before making the Site audience public. With this
flag absent, the original `TRIPS_OWNER_ID` access check still applies.

Trips, conversation history, and Undo snapshots live in the browser's IndexedDB
`trips-workspace` database. The header says “Saved in this browser”. Local data
survives reloads and API-session expiry; clearing browser storage or Reset demo
removes it. There is no cross-device sync. Storage failures are surfaced instead
of silently falling back to memory. Trip version checks, a single running turn per
trip, and atomic trip/chat commits protect concurrent tabs and Undo. New chat
physically deletes that conversation locally.

The server stores only API-session authorization metadata and hashed quota
counters for new demo activity. Its HttpOnly, Secure, SameSite cookie expires
in 24 hours and is renewed on reconnect without deleting browser content. AI
requests carry the current validated itinerary and up to 12 recent completed
turns (bounded to 95 KB); the server returns a proposed update for the browser to
commit. The API key stays exclusively in the Worker. Demo place/route results
are not written to D1, and errors do not log content. The assistant's route cache
exists only for the duration of one request. AI and map/place/route services
still process the relevant content sent to them; browser storage does not mean
that all processing stays on the device.

Old D1 sessions migrate through a cookie-scoped `/api/demo/migrate` export. The
browser commits the imported workspace and a migration receipt before requesting
deletion of that session's server-side content. Repeated imports cannot overwrite
local changes or resurrect cleared chat; Reset demo also suppresses legacy imports.
Unvisited legacy sessions expire under their existing 24-hour policy, with physical
deletion on subsequent demo requests after a five-minute in-flight-work grace
period. Old content caches are retired in bounded batches on those requests.
This is request-driven cleanup, not deletion at an exact wall-clock time.

Visitors can keep three active trips. Persistent share links, calendar feeds,
account identity lookup, and paid flight lookup are unavailable in demo mode.
The original owner's data is never assigned to an anonymous session.

Usage protection uses D1 atomic counters and only the edge-provided client IP,
normalized and hashed before storage. Clearing cookies does not clear quotas.
API requests allow 120/minute and 2,000/day per network; new sessions allow
5/minute and 20/day. Assistant starts allow 3/minute and 20/day per network,
plus a shared site ceiling of 10/minute and 100/day, and 30 starts per API session per clock hour. Each turn permits at most
six Responses calls, with 4,000 output tokens and three hosted-tool calls per
response. These are request limits, not a dollar-denominated billing cap.
Limits fail closed if trusted client identity or durable storage is unavailable.

AI remains off unless both `TRIPS_ASSISTANT_ENABLED=true` and a dedicated
`OPENAI_API_KEY` secret are configured. Requests go server-side to
`https://api.openai.com/v1/responses`, with `store:false` enforced, redirect
following disabled, and no internal proxy or employee credential fallback.
The intended model is `gpt-6-astra`; model access and `web_search` entitlement
must be checked with the dedicated credential before enabling AI publicly.
API retention is separate from the browser's local history and the transitional cleanup of old D1 content.

Validation:

```sh
node --import tsx --test tests/*.test.ts
node node_modules/typescript/bin/tsc --noEmit
node scripts/smoke-demo.mjs http://127.0.0.1:5173
# After building: run the production Worker with synthetic AI responses.
node scripts/smoke-built-demo.mjs
```

The smoke test creates and removes two synthetic demo sessions. It expects demo
mode enabled and the assistant disabled. Do not pass any account or API credentials.

## Source download

`npm run package:source` regenerates `public/trips-project.zip`, which the
**Download project** button serves. The normal build runs this command first.
The ZIP includes source, dependencies' lockfile, database migrations, tests,
and the blank environment example. It excludes local credentials, browser or
database contents, build output, hosted project identifiers, and other ZIPs.
Package URLs use the public npm registry. Timestamps and file order are fixed
so unchanged source produces the same archive.

Run `npm test` and `npm run typecheck` to check a change. After building,
`node scripts/smoke-built-demo.mjs` verifies the compiled Worker with synthetic
AI responses and an isolated database; it does not need an API key.
