import handler from "vinext/server/fetch-handler";
import { runWithConnectorBinding } from "../lib/connector-context";
import type { ConnectorBinding } from "../lib/connector-contract.mjs";

import { discoveryResponse, privateHeaders } from '../lib/site-policy';
import { prepareDemoRequest } from '../lib/demo-request';

const worker = {
  async fetch(request: Request, env: Cloudflare.Env, ctx: ExecutionContext<{ CONNECTORS?: ConnectorBinding }>) {
    const discovery=discoveryResponse(new URL(request.url).pathname);
    if(discovery)return discovery;
    if (env.TRIPS_DEMO_MODE === 'true') {
      const prepared = await prepareDemoRequest(request, env.DB);
      if (prepared instanceof Response) return prepared;
      request = prepared;
    }
    let binding = ctx.props?.CONNECTORS;
    // Local preview emulates the same request-scoped capability. This branch and
    // the auxiliary service binding are absent from production builds.
    if (import.meta.env.DEV && !binding && env.CONNECTORS) {
      const preview = env.CONNECTORS;
      const expiresAt = Date.now() + 60_000;
      binding = {
        async getContext() {
          if (Date.now() >= expiresAt) return { status: "request_context_expired" };
          return preview.getContext?.() ?? { status: "binding_unavailable" };
        },
        async invoke(connectorId, actionName, args) {
          if (Date.now() >= expiresAt) {
            return { status: "request_context_expired", message: "This request has expired. Please try again." };
          }
          return preview.invoke(connectorId, actionName, args);
        },
      };
    }
    const response=await runWithConnectorBinding(binding, () => handler.fetch(request, env, ctx));
    const result=new Response(response.body,response);
    for(const [key,value] of Object.entries(privateHeaders))result.headers.set(key,value);
    return result;
  },
};

export default worker;
