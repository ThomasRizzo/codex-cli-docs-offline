# Facet

A CSV analyst demo built with the OpenAI Agents API. Upload a CSV or choose one of three synthetic sample datasets, ask a question, and explore a calculated report with metrics, a chart, and calculation notes.

## Run locally

Set `CLEANUP_PROVIDER_SCOPE` to a stable provider-project label (1–80 letters, digits, underscores or hyphens, starting with a letter or digit). Apply every D1 migration before API requests. Missing cleanup storage or scope blocks new provider work.

Use Node.js 22.13 or newer.

```sh
npm ci
cp .env.example .env.local
# Set OPENAI_API_KEY and CLEANUP_PROVIDER_SCOPE in .env.local.
npm run build
for migration in drizzle/*.sql; do
  node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file "$migration" || exit 1
done
npm run dev
```

Run database initialization once for a fresh database. For an existing database, apply only migrations that have not already run, in filename order.

Open the local URL printed by the development server. The key stays on the server. The project needs Agents API access, permission to create OpenAI-hosted environments, and access to `gpt-6-astra`. A local development signing key is generated in memory automatically; restarting the server expires outstanding local analysis handles.

## How analysis works

1. The browser parses and previews the CSV locally. It sends the CSV only when you run an analysis.
2. The server validates the CSV and creates an Agents session with an inline `/workspace/data.csv` file in an OpenAI-hosted sandbox. Network access is disabled.
3. The session streams public progress and answer text through the server to the Analysis tab. The agent uses Python for calculations, then streams structured JSON with a summary, up to three metrics, a chart, optional table, findings, and method. Title and summary appear progressively; metrics and charts appear when their complete sections validate. Private reasoning and raw tool output never reach the browser.
4. The server checks the completed root turn, validates the report, and requires a successful Python command for analytical reports. This execution check confirms that Python ran; it does not independently prove every model interpretation. The samples were checked against independently calculated totals.
5. The server requests deletion after completion, failure, cancellation or browser disconnection. The result lives only in the current tab. A durable metadata-only ledger retains failed cleanup for an owner-operated maintenance task, independently of browser acknowledgement. Infrastructure or scheduling failures can delay deletion; no provider expiry is assumed.

Each question starts a separate analysis. Follow-ups include the previous question and summary as context, and calculations are recomputed from the original CSV. Simple introductions use the supplied dataset metadata without running Python. Unclear or unrelated requests get a short clarification or redirection instead of fabricated analysis. The agent uses low reasoning effort for these compact tasks.

Analysis starts with `stream: true`, avoiding a gap between creation and subscribing to events. Event streams have no replay. An upstream interruption can be reconciled while the browser stays connected; a lost browser connection requests cleanup and asks you to retry. Partial output remains a draft until the completed root turn and report validate. Stop remains available during startup and streaming; a late session handle is still collected for cleanup.

CSV limits: 500 KB (512,000 bytes), 5,000 data rows, and 32 columns. Headers must be nonempty and unique. Quoted commas, newlines, escaped quotes, CRLF, and a UTF-8 BOM are supported. All bundled datasets are synthetic.

## Hosting

This project uses the Sites Vinext starter. Keep its build integration. Configure server-only `OPENAI_API_KEY` and a random `FACET_SESSION_SECRET` of at least 32 characters. The downloadable project calls `https://api.openai.com` directly from the server, using an API credential approved for that hosting environment. Managed hosting uses its configured server transport.

No visitor account or login is required. API requests must come from the same origin and include a random nonce held only in browser memory. HMAC-signed handles bind sessions to that nonce and expire after ten minutes. Analyses have a three-minute UI/server deadline. The app stores no analysis history; follow-up context stays in the tab.

## IP rate limits

Starting an analysis or generation is limited to **6 requests per UTC minute and 20 per UTC day, per IP address**. Both windows are reserved atomically in the Sites D1 `DB` binding and persist across Worker instances. Visitors on the same network share this allowance. Rotating the browser nonce does not reset this allowance.

The server trusts only the edge-provided `CF-Connecting-IP`, ignores caller-supplied forwarding headers, and stores a SHA-256 hash with usage counters rather than the raw IP address. Exhausted requests receive HTTP 429 with `Retry-After` and a reset time. If the trusted IP or D1 store is unavailable, new work fails closed with HTTP 503 before contacting OpenAI.

Status and Stop/session cleanup do not consume this IP generation allowance. They require same-origin requests, the original anonymous UUID, a correctly signed session handle, and an available cleanup ledger. During a D1 outage these operations fail closed; existing durable jobs remain pending for recovery.

The Run locally commands build the Worker configuration and apply every D1 migration before starting the development server.

The source download preserves the logical `DB` binding and all migrations, without a hosted project or database ID. Hosted deployment must provision D1 and apply every migration before serving API requests. These per-IP limits are usage safeguards, not a project-wide monetary budget.

## Validation and source download

```sh
npm test
npm run typecheck
npm run build
```

`npm run package:source` generates `public/downloads/facet-data-agent.zip`. The archive includes this source, the standalone public API adapter, and blank environment examples; it excludes local secrets, hosting identity, Git state, build output, browser artifacts, and dependencies. Font license information is in `public/fonts`.

## Durable cleanup and owner operation

The cleanup ledger stores only random run IDs, provider session IDs, logical scope, a SHA-256 fingerprint of the actual server API key and effective API origin, timestamps, leases, retry categories, sanitized incident summaries and ticket receipts. It never stores user content, prompts, uploads, model output, browser nonce values, signing capabilities or the key itself.

- A creation intent commits before the single provider creation POST. Server-generated provider metadata carries the app name, random intent ID and logical scope. The known session ID and fallback deletion job commit before a browser handle or result is exposed.
- Completion, failure, timeout and disconnect make the job eligible immediately. The fallback deadline is 210 seconds after intent creation, allowing the 180-second generation deadline and a short grace period. If recording the ID fails, output stops and an emergency deletion is attempted. A confirmed emergency deletion is recorded if D1 has recovered; otherwise the intent remains unresolved.
- Each deletion attempt has an eight-second network deadline. HTTP 409 requests cancellation and leaves deletion pending. Network errors, malformed success responses, 429, 5xx and authentication failures retain the job. Retries use persisted exponential backoff from roughly 15 seconds to 15 minutes, with jitter and bounded `Retry-After`. The ledger never discards a job because of its retry count.
- Atomic 60-second leases and fenced updates prevent concurrent workers from completing each other's jobs. A maintenance call has a 20-second network budget, at most 20 deletion attempts, and one reconciliation page of up to 10 sessions. `dueJobs` and `dueReconciliations` let the owner task repeat bounded calls when work remains.
- A definitive creation HTTP 400/401/403/404/422 rejection received before any session ID closes the intent without claiming a session was deleted. Other ambiguous creation outcomes remain pending. Reconciliation lists sessions in the current provider project, matches only metadata belonging to an existing same-scope intent, and persists pagination progress. It never retries creation. Empty scans do not prove absence. Failed or empty scans back off from one to 15 minutes; invalid cursors restart the scan.
- Only an exact documented deletion confirmation (`id`, `deleted: true`, `object: agent.session.deleted`) or HTTP 404 under the recorded key/origin/scope confirms cleanup. Confirmed records and proven rejected intents are eligible for bounded pruning after 24 hours. Unconfirmed jobs and unidentified intents do not expire.

Use a separate provider project/workload and key for each demo. Before changing the key, API origin or `CLEANUP_PROVIDER_SCOPE`, stop new work and drain until both `pending` and `unknown` are zero. Even a same-project key rotation changes the fingerprint and conservatively strands old records. Restore the original credential/origin/scope to drain those records; never relabel them or accept a new project's 404 as deletion proof.

Configure these server-only bindings on a Sites deployment:

| Binding | Purpose |
| --- | --- |
| `DB` | Existing D1 storage, with all checked-in migrations applied. |
| `OPENAI_API_KEY` | That demo's provider credential. |
| `FACET_SESSION_SECRET` | At least 32 random characters for anonymous browser handles. |
| `CLEANUP_PROVIDER_SCOPE` | Explicit stable provider-project label. Missing scope prevents generation. |
| `CLEANUP_OWNER_EMAIL` | The verified Sites account allowed to operate maintenance. |
| `CLEANUP_IDENTITY_PROVIDER` | Set to `sites` only behind Sites' verified identity ingress. Blank disables maintenance calls. |

The manifest enables the Sites MCP capability. `POST /mcp` implements protocol `2026-07-28`: `server/discover` and `tools/list` return static public metadata; every `tools/call` requires the configured identity-provider opt-in, a Sites-verified user ID, and an exact normalized match to the configured owner email. No maintenance tool accepts arbitrary provider session IDs, provider URLs, credentials or scopes. Ticket receipt URLs are validated as Linear issue links and are never fetched by the Site. Visitors remain anonymous and need no login.

**Do not set `CLEANUP_IDENTITY_PROVIDER=sites` on a raw Worker or other public server that accepts caller-supplied `oai-authenticated-user-*` headers.** A non-Sites deployment must supply its own verified maintenance identity integration and trusted scheduler before enabling equivalent operations. The downloadable example leaves this opt-in blank.

After deploying and verifying the owner can call the Site's tools, configure an owner-linked cloud task every 15 minutes with a connected Linear account and an explicit ticket team and owner:

1. Call `cleanup_run` and read `cleanup_status`. Repeat a bounded number of batches while cleanup work is due; leave future backoff queued. A failed maintenance, authentication or storage call must itself create or reuse a P0 outage ticket assigned to the configured owner, using a stable Site-specific marker in Linear.
2. Claim pending incidents with `cleanup_claim_alert`. The claim returns an incident ID, stable ticket marker and a fenced five-minute lease. Search Linear for that exact marker before creating a ticket. Create a `[P0]` issue with the highest priority in Linear (`1`, Urgent), assign the configured owner, and include only the sanitized incident summary, timestamps and recovery context. A synthetic incident must be marked `[DRILL]`.
3. Read the issue back and verify its marker, priority and assignee. Call `cleanup_ack_alert` with the exact incident ID, current lease token and verified receipt (`issue_id`, `identifier`, canonical Linear `url`, `assignee_email`, `priority: 1`). Notification success alone cannot acknowledge an incident. Read `cleanup_status` to confirm that the receipt persisted.
4. If looking up, creating or reading back a ticket fails, call `cleanup_retry_alert` with the incident ID, lease token and sanitized category. Respect provider retry delays. Pending incidents survive process restarts and recovery; a lost call or expired lease is retried on a later run. After an ambiguous create, search and recover the marker before attempting another create. Notify the owner of escalation failures, but leave the incident pending.

Unresolved jobs or unidentified intents older than 15 minutes, stranded scopes and provider-authentication failures open a durable incident. One active failure episode per Site retains its identity as counts change. Recovery is recorded separately and does not erase a pending ticket obligation. Ticket receipts and incident history are not pruned with confirmed session metadata. Ticketed failures continue cleanup retries; the task does not automatically close real tickets.

The server validates the authenticated owner's receipt and stores it durably; it relies on that trusted task to read Linear independently. Leases and stable-marker recovery reduce duplicate creation, but Linear search-before-create is not an atomic idempotency guarantee. A crash after issue creation can require reconciliation. The task must never silently acknowledge a failed or unverified ticket.

`cleanup_test_alert({test_id})` is an owner-only, idempotent failure drill. It inserts a synthetic incident through the same escalation outbox without creating a provider session, changing credentials or processing user content. Test the real ticket path with this tool, read back the assigned P0 and persisted receipt, then explicitly resolve the drill ticket. Provider deletion failure-to-incident behavior is also covered by real-D1 tests with mocked provider responses.

Source deployment does not itself create a schedule or connect Linear. Verify the actual unattended owner task after deployment. This app provides no Worker cron, independent missed-run monitor or scheduling/ticket-service SLA. If the task stops, durable records remain but cleanup and escalation wait for another invocation. A Site/D1 outage is escalated externally by the task, since unavailable storage cannot record its own incident. Project listing can be delayed or unable to identify an ambiguous creation; those intents remain visible rather than being discarded. No provider TTL is assumed. This session cleanup does not claim to remove unrelated provider resources or logs.

The lifecycle uses the documented Agents API [creation metadata](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/create), [project session listing and pagination](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/list), and [session deletion confirmation](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/delete).
