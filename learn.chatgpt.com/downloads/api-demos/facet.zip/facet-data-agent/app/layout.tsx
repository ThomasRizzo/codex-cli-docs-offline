import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Facet — Data analyst",
  description: "Explore a CSV, ask a question, and see an agent turn real calculations into clear answers.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" className="scheme-only-dark"><head><link rel="preload" href="/fonts/InterVariable.woff2" as="font" type="font/woff2" crossOrigin="anonymous" /></head><body className="antialiased">{children}</body></html>;
}
