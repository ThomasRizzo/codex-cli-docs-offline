export const DATA_LIMITS = {
  maxBytes: 512_000,
  maxRows: 5_000,
  maxColumns: 32,
} as const;

export type Dataset = {
  name: string;
  csv: string;
  headers: string[];
  rows: string[][];
  rowCount: number;
  columnCount: number;
};

/** Parse CSV without guessing types or changing cell values. */
export function parseDataset(source: string, name: string): Dataset {
  if (new TextEncoder().encode(source).byteLength > DATA_LIMITS.maxBytes) {
    throw new Error("This file is too large. Choose a CSV under 500 KB.");
  }
  const csv = source.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
  if (csv.includes("\0")) throw new Error("This file contains unreadable characters. Export it as a UTF-8 CSV and try again.");

  const headerState: { value: string[] | null } = { value: null };
  const rows: string[][] = [];
  let fields: string[] = [];
  let field = "";
  let state: "start" | "plain" | "quoted" | "closed" = "start";
  let blankRecord = true;
  let recordNumber = 1;
  let pendingBlankCount = 0;
  const pendingBlanks: string[][] = [];

  function addDataRow(row: string[], number: number) {
    if (row.length !== headerState.value!.length) {
      throw new Error(`Row ${number} has ${row.length} columns; the header has ${headerState.value!.length}. Check for missing cells or commas inside unquoted text.`);
    }
    rows.push(row);
  }

  function finishRecord() {
    fields.push(field);
    if (headerState.value === null) {
      if (fields.length > DATA_LIMITS.maxColumns) throw new Error("This CSV has too many columns. Keep up to 32 columns and try again.");
      const names = fields.map((header) => header.trim());
      if (names.some((header) => header.length === 0)) throw new Error("Every column needs a name in the first row.");
      if (new Set(names).size !== names.length) throw new Error("Column names must be unique. Rename repeated headers and try again.");
      headerState.value = fields;
    } else if (blankRecord) {
      // Blank lines at the end are harmless. Retain interior blank records, but
      // cap their storage even when a file ends with thousands of empty lines.
      pendingBlankCount += 1;
      if (pendingBlanks.length < DATA_LIMITS.maxRows) pendingBlanks.push(fields);
    } else {
      if (rows.length + pendingBlankCount + 1 > DATA_LIMITS.maxRows) {
        throw new Error("This CSV has too many rows. Keep up to 5,000 data rows and try again.");
      }
      for (let index = 0; index < pendingBlanks.length; index += 1) {
        addDataRow(pendingBlanks[index], recordNumber - pendingBlankCount + index);
      }
      pendingBlankCount = 0;
      pendingBlanks.length = 0;
      addDataRow(fields, recordNumber);
    }
    fields = [];
    field = "";
    state = "start";
    blankRecord = true;
    recordNumber += 1;
  }

  for (let index = 0; index < csv.length; index += 1) {
    const character = csv[index];
    if (state === "quoted") {
      if (character === '"') state = "closed";
      else field += character;
      continue;
    }
    if (state === "closed" && character === '"') {
      field += '"';
      state = "quoted";
      continue;
    }
    if (character === ",") {
      fields.push(field);
      field = "";
      state = "start";
      blankRecord = false;
      if (fields.length >= DATA_LIMITS.maxColumns) throw new Error("This CSV has too many columns. Keep up to 32 columns and try again.");
    } else if (character === "\n") {
      finishRecord();
    } else if (state === "closed") {
      throw new Error(`There is unexpected text after a closing quote in row ${recordNumber}. Check that commas separate the cells.`);
    } else if (character === '"') {
      if (state !== "start") throw new Error(`There is a quote inside unquoted text in row ${recordNumber}. Put the whole cell in quotes and escape quotes as two quote characters.`);
      state = "quoted";
      blankRecord = false;
    } else {
      field += character;
      state = "plain";
      if (character.trim()) blankRecord = false;
    }
  }
  if (state === "quoted") throw new Error(`A quoted cell in row ${recordNumber} is not closed. Add its closing quote and try again.`);
  if (field.length > 0 || fields.length > 0 || state === "closed") finishRecord();
  const headers = headerState.value;
  if (headers === null) throw new Error("This CSV is empty. Add column names and at least one data row.");
  if (rows.length === 0 || !rows.some((row) => row.some((cell) => cell.trim().length > 0))) {
    throw new Error("This CSV has no data. Add at least one nonempty row below the column names.");
  }

  return { name: name.trim() || "Uploaded data", csv, headers, rows, rowCount: rows.length, columnCount: headers.length };
}
