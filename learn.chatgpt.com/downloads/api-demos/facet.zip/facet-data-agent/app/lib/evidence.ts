// Conservatively recognize one Python command, never execute or expand shell text.
function words(source: string): string[] | null {
  const result: string[] = [];
  let word = "", quote = "", started = false;
  for (let i = 0; i < source.length; i++) {
    const char = source[i];
    if (quote) {
      if (char === quote) { quote = ""; continue; }
      if (quote === '"' && (char === "$" || char === "`")) return null;
      if (quote === '"' && char === "\\" && /[$`"\\\n]/.test(source[i + 1] ?? "")) {
        if (source[i + 1] !== "\n") word += source[i + 1];
        i++; continue;
      }
      word += char; continue;
    }
    if (char === "'" || char === '"') { quote = char; started = true; continue; }
    if (char === "\\") {
      if (++i >= source.length) return null;
      if (source[i] !== "\n") { word += source[i]; started = true; }
      continue;
    }
    if (/[\r\n;$`&|<>()]/.test(char)) return null;
    if (/\s/.test(char)) {
      if (started) { result.push(word); word = ""; started = false; }
    } else { word += char; started = true; }
    if (result.length > 128) return null;
  }
  if (quote) return null;
  if (started) result.push(word);
  return result;
}

function pythonArgs(args: string[], hasStdin: boolean): boolean {
  if (!/^python(?:3(?:\.\d+)?)?$/.test(args[0].split("/").at(-1) ?? "")) return false;
  if (args.slice(1).some((arg) => ["--version", "-V", "--help", "-h"].includes(arg))) return false;
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg === "-c" || arg === "-m") return Boolean(args[i + 1]?.trim());
    if (/^-[cm].+/.test(arg)) return true;
    if (arg === "-") return hasStdin;
    if (arg === "--") return Boolean(args[i + 1] && args[i + 1] !== "-");
    if (["-B", "-E", "-I", "-O", "-OO", "-q", "-s", "-S", "-u", "-v", "-x"].includes(arg)) continue;
    if (arg === "-W" || arg === "-X") { if (!args[++i]) return false; continue; }
    if (arg.startsWith("-")) return false;
    return Boolean(arg);
  }
  return hasStdin;
}

function recognize(command: string, depth: number): boolean {
  if (depth > 3 || command.length > 16_384) return false;
  const source = command.trim();
  let args: string[] | null;
  if (source.startsWith("[")) {
    try {
      const value: unknown = JSON.parse(source);
      if (!Array.isArray(value) || value.length > 128 || !value.every((part) => typeof part === "string")) return false;
      args = value;
    } catch { return false; }
  } else if (!(args = words(source))) {
    // A single heredoc is accepted only when its closing delimiter ends the command.
    const here = source.match(/^([^\n]*?)\s*<<\s*(?:'([A-Za-z_][\w]*)'|"([A-Za-z_][\w]*)"|([A-Za-z_][\w]*))\s*\n([\s\S]*)$/);
    if (here) {
      const delimiter = here[2] ?? here[3] ?? here[4];
      const lines = here[5].split("\n");
      const end = lines.indexOf(delimiter);
      if (end < 1 || lines.slice(end + 1).some((line) => line.trim()) || !lines.slice(0, end).join("\n").trim()) return false;
      args = words(here[1].trim());
      return Boolean(args?.length && pythonArgs(args, true));
    }
  }
  if (!args?.length) return false;
  const executable = args[0].split("/").at(-1);
  if (["bash", "sh", "dash", "zsh"].includes(executable ?? "")) {
    return args.length === 3 && ["-c", "-lc"].includes(args[1]) && recognize(args[2], depth + 1);
  }
  return pythonArgs(args, false);
}

/** Call only for completed command items with exitCode === 0; this does not verify numeric results. */
export function isPythonExecution(command: string): boolean {
  return recognize(command, 0);
}
