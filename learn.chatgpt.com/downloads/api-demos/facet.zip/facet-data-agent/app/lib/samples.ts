export type SampleDataset = {
  id: string;
  name: string;
  description: string;
  csv: string;
  questions: string[];
};

function dateFor(day: number) {
  const date = new Date(Date.UTC(2026, 8, day + 1));
  return { date: date.toISOString().slice(0, 10), weekend: date.getUTCDay() === 0 || date.getUTCDay() === 6 };
}

function toCsv(headers: string[], rows: (string | number)[][]) {
  const cell = (value: string | number) => {
    const text = String(value);
    return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
  };
  return [headers, ...rows].map((row) => row.map(cell).join(",")).join("\n") + "\n";
}

function studioOrders() {
  const rows: (string | number)[][] = [];
  const categories = ["Prints", "Ceramics", "Textiles"];
  const channels = ["Online", "Retail", "Wholesale"];
  const prices = [42, 86, 65];
  for (let day = 0; day < 28; day += 1) {
    const { date, weekend } = dateFor(day);
    categories.forEach((category, categoryIndex) => channels.forEach((channel, channelIndex) => {
      const noise = (day * 5 + categoryIndex * 7 + channelIndex * 3) % 9 - 4;
      const orders = [32, 24, 16][channelIndex] + [7, 0, 3][categoryIndex] + Math.floor(day / 7) * 2 + noise + (weekend && channel !== "Wholesale" ? 10 : 0);
      const price = prices[categoryIndex] * (channel === "Wholesale" ? 0.72 : 1) * (1 + ((day + categoryIndex) % 3 - 1) * 0.04);
      const revenue = (orders * price).toFixed(2);
      const refundRate = category === "Ceramics" && channel === "Online" ? 0.1 : category === "Textiles" ? 0.045 : 0.018;
      const refunds = Math.round(orders * refundRate);
      rows.push([date, category, channel, orders, revenue, refunds, "USD"]);
    }));
  }
  return toCsv(["date", "category", "channel", "orders", "revenue", "refunds", "currency"], rows);
}

function cityBikes() {
  const rows: (string | number)[][] = [];
  const stations = ["Central", "Riverside", "University", "Old Town"];
  for (let day = 0; day < 28; day += 1) {
    const { date, weekend } = dateFor(day);
    const temperature = 17 + ((day * 7) % 13) + (day % 3) * 0.3;
    stations.forEach((station, stationIndex) => ["Member", "Casual"].forEach((riderType, riderIndex) => {
      const commuter = station === "Central" || station === "University";
      const base = riderType === "Member" ? [148, 64, 125, 78][stationIndex] : [48, 108, 30, 81][stationIndex];
      const weekendChange = weekend ? (commuter && riderType === "Member" ? -62 : riderType === "Casual" ? 48 : 8) : 0;
      const weather = Math.round((temperature - 22) * (riderType === "Casual" ? 5 : 2));
      const noise = (day * 11 + stationIndex * 5 + riderIndex * 3) % 15 - 7;
      const rides = base + weekendChange + weather + noise;
      const duration = (riderType === "Member" ? 11 : 23) + stationIndex * 1.1 + (weekend ? 4.5 : 0) + ((day + stationIndex) % 5) * 0.4;
      rows.push([date, station, riderType, rides, duration.toFixed(1), temperature.toFixed(1)]);
    }));
  }
  return toCsv(["date", "station", "rider_type", "rides", "avg_duration_min", "temperature_c"], rows);
}

function coffeeShops() {
  const rows: (string | number)[][] = [];
  const stores = ["Northside", "Market", "Harbor"];
  const drinks = ["Espresso", "Latte", "Cappuccino", "Cold brew"];
  const prices = [3.2, 4.5, 4.1, 4.8];
  for (let day = 0; day < 28; day += 1) {
    const { date, weekend } = dateFor(day);
    stores.forEach((store, storeIndex) => drinks.forEach((drink, drinkIndex) => {
      const noise = (day * 3 + drinkIndex * 7 + storeIndex * 5) % 13 - 6;
      const weekendChange = weekend ? [ -12, 14, 28 ][storeIndex] : 0;
      const sold = [42, 74, 51, 38][drinkIndex] + [8, 16, 0][storeIndex] + weekendChange + noise + (drink === "Cold brew" ? Math.floor(day / 7) * 5 : 0);
      const wasteRate = drink === "Cold brew" ? (store === "Harbor" && !weekend ? 0.2 : 0.12) : drink === "Cappuccino" ? 0.055 : 0.025;
      const wasted = Math.round(sold * wasteRate);
      const price = prices[drinkIndex] * (drink === "Cold brew" && day >= 14 ? 0.9 : 1);
      rows.push([date, store, drink, sold, wasted, (sold * price).toFixed(2), "USD"]);
    }));
  }
  return toCsv(["date", "store", "drink", "sold", "wasted", "revenue", "currency"], rows);
}

export const SAMPLES: SampleDataset[] = [
  {
    id: "studio-orders",
    name: "Studio orders",
    description: "Synthetic orders, gross revenue in USD, and refunded orders across 28 days.",
    csv: studioOrders(),
    questions: [
      "Which category brings in the most revenue?",
      "How do sales channels compare on revenue per order?",
      "Which category has the highest refund rate?",
    ],
  },
  {
    id: "city-bikes",
    name: "City bikes",
    description: "Synthetic daily bike rides and average trip times at four stations.",
    csv: cityBikes(),
    questions: [
      "Which stations are busiest, and does that change on weekends?",
      "How do ride durations differ for members and casual riders?",
      "Do warmer days have more rides?",
    ],
  },
  {
    id: "coffee-shops",
    name: "Coffee shops",
    description: "Synthetic drink sales, waste, and revenue in USD at three coffee shops.",
    csv: coffeeShops(),
    questions: [
      "Which drinks bring in the most revenue?",
      "Which drink has the highest waste rate?",
      "How do sales change on weekends at each store?",
    ],
  },
];
