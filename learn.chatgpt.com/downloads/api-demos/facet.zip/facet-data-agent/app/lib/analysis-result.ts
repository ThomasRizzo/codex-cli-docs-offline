import type { AnalysisSessionState } from "./agents.ts";
import { reportSchema } from "./contracts.ts";
import { isPythonExecution } from "./evidence.ts";

/** Only persisted, validated results can become a finished report. */
export function analysisResult(state: Pick<AnalysisSessionState, "report" | "commands">) {
  const parsed = reportSchema.safeParse(state.report);
  const successfulPython = state.commands.filter(command => command.status === "completed" && command.exitCode === 0 && isPythonExecution(command.command));
  if (!parsed.success || (parsed.data.status === "complete" && successfulPython.length === 0)) return null;
  return { report: parsed.data, execution: { steps: successfulPython.length, verified: parsed.data.status === "complete" && successfulPython.length > 0 } };
}
