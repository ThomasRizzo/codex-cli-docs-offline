import { z } from "zod";
import { DATA_LIMITS } from "./data.ts";

// Count Unicode characters consistently with JSON Schema's maxLength.
function text(maximum: number, minimum = 0) {
  const schema = z.string().regex(new RegExp(`^[\\s\\S]{${minimum},${maximum}}$`, "u"));
  return {
    schema: minimum > 0 ? schema.regex(/\S/u) : schema,
    json: { type: "string", minLength: minimum, maxLength: maximum, ...(minimum > 0 ? { pattern: "\\S" } : {}) },
  };
}

const fields = {
  title: text(100, 1), summary: text(1_400, 1), metricLabel: text(64),
  metricValue: text(100), metricDetail: text(180), axis: text(80),
  pointLabel: text(100), method: text(1_000), finding: text(500, 1),
  tableHeader: text(80, 1), tableCell: text(200),
};

const metricSchema = z.object({
  label: fields.metricLabel.schema,
  value: fields.metricValue.schema,
  detail: fields.metricDetail.schema,
}).strict();

const chartSchema = z.object({
  kind: z.enum(["bar", "line"]),
  title: fields.title.schema,
  xLabel: fields.axis.schema,
  yLabel: fields.axis.schema,
  points: z.array(z.object({ label: fields.pointLabel.schema, value: z.number().finite() }).strict()).min(1).max(24),
}).strict();

const tableSchema = z.object({
  columns: z.array(fields.tableHeader.schema).min(1).max(6),
  rows: z.array(z.array(fields.tableCell.schema).max(6)).max(12),
}).strict().superRefine((table, context) => {
  table.rows.forEach((row, index) => {
    if (row.length !== table.columns.length) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["rows", index], message: "Each table row must have a value for every column." });
    }
  });
});

export const reportSchema = z.object({
  status: z.enum(["complete", "explanation", "clarification", "off_topic"]),
  title: fields.title.schema,
  summary: fields.summary.schema,
  metrics: z.array(metricSchema).max(3),
  chart: chartSchema.nullable(),
  table: tableSchema.nullable(),
  findings: z.array(fields.finding.schema).max(4),
  method: fields.method.schema,
}).strict().superRefine((report, context) => {
  if (report.status === "complete") return;
  for (const key of ["metrics", "findings"] as const) {
    if (report[key].length) context.addIssue({ code: z.ZodIssueCode.custom, path: [key], message: "Conversational replies cannot contain analysis results." });
  }
  for (const key of ["chart", "table"] as const) {
    if (report[key] !== null) context.addIssue({ code: z.ZodIssueCode.custom, path: [key], message: "Conversational replies cannot contain analysis results." });
  }
  if (report.method !== "") context.addIssue({ code: z.ZodIssueCode.custom, path: ["method"], message: "Conversational replies must leave the analysis method empty." });
});

export type AnalysisReport = z.infer<typeof reportSchema>;

/**
 * Provider-safe wire schema. reportSchema enforces the same field bounds plus
 * cross-field rules the structured-output subset cannot express: table widths
 * must match their headers, and conversational statuses cannot contain results.
 * Always run reportSchema after receiving model output.
 */
export const reportJsonSchema = {
  type: "object",
  properties: {
    status: { type: "string", enum: ["complete", "explanation", "clarification", "off_topic"] },
    title: fields.title.json,
    summary: fields.summary.json,
    metrics: {
      type: "array", maxItems: 3,
      items: {
        type: "object", additionalProperties: false,
        properties: { label: fields.metricLabel.json, value: fields.metricValue.json, detail: fields.metricDetail.json },
        required: ["label", "value", "detail"],
      },
    },
    chart: {
      anyOf: [{
        type: "object", additionalProperties: false,
        properties: {
          kind: { type: "string", enum: ["bar", "line"] },
          title: fields.title.json, xLabel: fields.axis.json, yLabel: fields.axis.json,
          points: {
            type: "array", minItems: 1, maxItems: 24,
            items: {
              type: "object", additionalProperties: false,
              properties: { label: fields.pointLabel.json, value: { type: "number" } },
              required: ["label", "value"],
            },
          },
        },
        required: ["kind", "title", "xLabel", "yLabel", "points"],
      }, { type: "null" }],
    },
    table: {
      anyOf: [{
        type: "object", additionalProperties: false,
        properties: {
          columns: { type: "array", minItems: 1, maxItems: 6, items: fields.tableHeader.json },
          rows: { type: "array", maxItems: 12, items: { type: "array", maxItems: 6, items: fields.tableCell.json } },
        },
        required: ["columns", "rows"],
      }, { type: "null" }],
    },
    findings: { type: "array", maxItems: 4, items: fields.finding.json },
    method: fields.method.json,
  },
  required: ["status", "title", "summary", "metrics", "chart", "table", "findings", "method"],
  additionalProperties: false,
};

export const analysisRequestSchema = z.object({
  filename: z.string().trim().min(1).max(180),
  csv: z.string().min(1).max(DATA_LIMITS.maxBytes).refine(
    (value) => new TextEncoder().encode(value).byteLength <= DATA_LIMITS.maxBytes,
    "This file is too large. Choose a CSV under 500 KB.",
  ),
  question: z.string().trim().min(1, "Ask a question about this dataset.").max(500),
  previousQuestion: z.string().trim().max(500).optional(),
  previousSummary: z.string().trim().max(1_400).optional(),
}).strict();

export type AnalysisRequest = z.infer<typeof analysisRequestSchema>;
