import { AgentsError, type AnalysisSessionState, type AnalysisStreamEvent } from "./agents.ts";
import { analysisResult } from "./analysis-result.ts";
import { ANALYSIS_DEADLINE_MS, ApiError, errorResponse } from "./server.ts";

type Dependencies = {
  start: (signal: AbortSignal) => AsyncIterable<AnalysisStreamEvent>;
  poll: (id: string, signal: AbortSignal) => Promise<AnalysisSessionState>;
  sign: (id: string) => Promise<string>;
  record: (id: string) => Promise<void>;
  cleanup: (id: string) => Promise<void>;
  deadlineMs?: number;
  pollDelayMs?: number;
};

/** The browser receives only public text and safe progress, never upstream events. */
export function analysisStream(deps: Dependencies): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  const observer = new AbortController();
  let disconnected = false, handleSent = false, timedOut = false;
  let sessionId: string | null = null;
  let deadline: ReturnType<typeof setTimeout> | undefined;
  let heartbeat: ReturnType<typeof setInterval> | undefined;
  let cleanupPromise: Promise<void> | undefined;
  const cleanup = () => sessionId ? cleanupPromise ??= deps.cleanup(sessionId).catch(() => {
    console.error(JSON.stringify({ event: "analysis_cleanup_failed", sessionId }));
  }) : Promise.resolve();

  return new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (event: string, data: unknown) => {
        if (!disconnected) controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
      };
      send("start", { progress: "Starting your analysis…" });
      deadline = setTimeout(() => { timedOut = true; observer.abort(); }, deps.deadlineMs ?? ANALYSIS_DEADLINE_MS);
      heartbeat = setInterval(() => {
        if (!disconnected) controller.enqueue(encoder.encode(": keep-alive\n\n"));
      }, 10_000);
      try {
        try {
          for await (const event of deps.start(observer.signal)) {
            if (event.type === "session") {
              try { await deps.record(event.id); }
              catch (error) { observer.abort(); throw error; }
              sessionId = event.id;
              observer.signal.throwIfAborted();
              // Do not abandon creation before obtaining an ID for cleanup.
              if (disconnected) { await cleanup(); observer.abort(); return; }
              const token = await deps.sign(sessionId);
              observer.signal.throwIfAborted();
              if (disconnected) { await cleanup(); observer.abort(); return; }
              send("session", { token }); handleSent = true;
            } else if (event.type === "finished") {
              break;
            } else {
              const { type, ...data } = event;
              send(type, data);
            }
          }
        } catch (error) {
          if (!sessionId || observer.signal.aborted) throw error;
          // Event streams do not replay. Reconcile persisted output after a dropped stream.
          send("progress", { progress: "Reconnecting to your analysis…" });
        }
        if (disconnected) return;
        if (!sessionId || !handleSent) throw new ApiError(502, "The analysis could not start. Please try again.");
        let failures = 0, lastProgress = "";
        while (!observer.signal.aborted) {
          let state: AnalysisSessionState;
          try {
            state = await deps.poll(sessionId, observer.signal);
            observer.signal.throwIfAborted();
            failures = 0;
          }
          catch (error) {
            if (observer.signal.aborted || !(error instanceof AgentsError || error instanceof ApiError) || error.status < 500 || ++failures > 2) throw error;
            send("progress", { progress: "Reconnecting to your analysis…" });
            await pause(deps.pollDelayMs ?? 1500, observer.signal);
            continue;
          }
          if (state.status === "complete") {
            const result = analysisResult(state);
            if (!result) throw new ApiError(502, "The analyst could not produce a complete report. Your data is still here; try again.");
            send("complete", result);
            // The result stays in this tab; finally releases the temporary provider session.
            return;
          }
          if (["failed", "cancelled", "waiting"].includes(state.status)) throw new ApiError(502, state.error || "The analysis could not finish. Please try again.");
          if (state.progress !== lastProgress) { send("progress", { progress: state.progress }); lastProgress = state.progress; }
          await pause(deps.pollDelayMs ?? 1500, observer.signal);
        }
        if (timedOut) throw new ApiError(408, "This analysis took too long. Try a more focused question.");
      } catch (error) {
        if (!disconnected) {
          const response = errorResponse(timedOut ? new ApiError(408, "This analysis took too long. Try a more focused question.") : error);
          send("error", await response.json());
          await cleanup();
        }
      } finally {
        clearTimeout(deadline); clearInterval(heartbeat);
        await cleanup();
        if (!disconnected) controller.close();
      }
    },
    cancel() {
      disconnected = true;
      clearInterval(heartbeat);
      // A lost browser ends this ephemeral session. Keep observing startup
      // until a late-created session ID can be collected and deleted.
      if (sessionId) clearTimeout(deadline);
      if (sessionId) observer.abort();
      if (sessionId) return cleanup();
    },
  });
}

function pause(ms: number, signal: AbortSignal) {
  return new Promise<void>((resolve, reject) => {
    if (signal.aborted) { reject(signal.reason); return; }
    const timer = setTimeout(() => { signal.removeEventListener("abort", abort); resolve(); }, ms);
    const abort = () => { clearTimeout(timer); signal.removeEventListener("abort", abort); reject(signal.reason); };
    signal.addEventListener("abort", abort, { once: true });
  });
}
