import { reportSchema, type AnalysisReport } from "./contracts.ts";

/** A display-only draft. A completed report still requires full server validation. */
export type PartialAnalysisReport = Partial<AnalysisReport>;

const fields = reportSchema.innerType().shape;
const MAX_BYTES = 64 * 1024;
type StringToken = { end: number; value: string; complete: boolean };
type ValueToken = { end: number; complete: boolean };

function whitespace(text: string, index: number) {
  while (index < text.length && /[\t\n\r ]/.test(text[index])) index += 1;
  return index;
}

// Decode only complete JSON escapes. A split Unicode pair must not flash a
// replacement character before the remainder of the streamed string arrives.
function stringToken(text: string, start: number): StringToken | null {
  function prefix(end: number): StringToken {
    let value = JSON.parse(`${text.slice(start, end)}"`) as string;
    if (/[\uD800-\uDBFF]$/.test(value)) value = value.slice(0, -1);
    return { end: text.length, value, complete: false };
  }
  for (let index = start + 1; index < text.length; index += 1) {
    const character = text[index];
    if (character === '"') {
      return { end: index + 1, value: JSON.parse(text.slice(start, index + 1)) as string, complete: true };
    }
    if (character.charCodeAt(0) < 0x20) return null;
    if (character !== "\\") continue;
    const escape = text[index + 1];
    if (escape === undefined) return prefix(index);
    if (escape === "u") {
      const hexadecimal = text.slice(index + 2, index + 6);
      if (!/^[\da-f]{0,4}$/i.test(hexadecimal)) return null;
      if (hexadecimal.length < 4) return prefix(index);
      index += 5;
    } else {
      if (!'"\\/bfnrt'.includes(escape)) return null;
      index += 1;
    }
  }
  return prefix(text.length);
}

// Top-level report values are strings, null, arrays, or objects. Leave nested
// JSON to JSON.parse once balanced; never synthesize a closing bracket or digit.
function valueToken(text: string, start: number): ValueToken | null {
  const first = text[start];
  if (first === '"') return stringToken(text, start);
  if (first !== "[" && first !== "{") {
    if (text.startsWith("null", start)) return { end: start + 4, complete: true };
    return "null".startsWith(text.slice(start)) ? { end: text.length, complete: false } : null;
  }
  const closing = [first === "[" ? "]" : "}"];
  for (let index = start + 1; index < text.length; index += 1) {
    const character = text[index];
    if (character === '"') {
      const token = stringToken(text, index);
      if (!token || !token.complete) return token;
      index = token.end - 1;
    } else if (character === "[" || character === "{") {
      closing.push(character === "[" ? "]" : "}");
    } else if (character === "]" || character === "}") {
      if (closing.pop() !== character) return null;
      if (!closing.length) return { end: index + 1, complete: true };
    }
  }
  return { end: text.length, complete: false };
}

function visible(draft: PartialAnalysisReport): PartialAnalysisReport {
  if (draft.status === "complete") return draft;
  const { status, title, summary } = draft;
  return {
    ...(status !== undefined ? { status } : {}),
    ...(title !== undefined ? { title } : {}),
    ...(summary !== undefined ? { summary } : {}),
  };
}

/** Read a bounded prefix of the model's final JSON, without inventing results. */
export function parsePartialReport(text: string): PartialAnalysisReport {
  if (text.length > MAX_BYTES || new TextEncoder().encode(text).byteLength > MAX_BYTES) return {};
  let index = whitespace(text, 0);
  if (text[index++] !== "{") return {};
  const draft: PartialAnalysisReport = {};
  const seen = new Set<string>();
  let afterComma = false;
  while (index < text.length) {
    index = whitespace(text, index);
    if (index === text.length) break;
    if (text[index] === "}") {
      return !afterComma && whitespace(text, index + 1) === text.length ? visible(draft) : {};
    }
    if (text[index] !== '"') return {};
    const key = stringToken(text, index);
    if (!key) return {};
    if (!key.complete) break;
    if (!Object.hasOwn(fields, key.value) || seen.has(key.value)) return {};
    seen.add(key.value);
    index = whitespace(text, key.end);
    if (index === text.length) break;
    if (text[index++] !== ":") return {};
    index = whitespace(text, index);
    if (index === text.length) break;
    const token = valueToken(text, index);
    if (!token) return {};
    const field = key.value as keyof AnalysisReport;
    if (!token.complete) {
      if ((field === "title" || field === "summary") && text[index] === '"') {
        const prefix = stringToken(text, index)!;
        const parsed = fields[field].safeParse(prefix.value);
        if (parsed.success) draft[field] = parsed.data;
      }
      break;
    }
    let value: unknown;
    try { value = JSON.parse(text.slice(index, token.end)); } catch { return {}; }
    const parsed = fields[field].safeParse(value);
    if (!parsed.success) return {};
    Object.assign(draft, { [field]: parsed.data });
    index = whitespace(text, token.end);
    if (index === text.length) break;
    if (text[index] === "}") {
      return whitespace(text, index + 1) === text.length ? visible(draft) : {};
    }
    if (text[index++] !== ",") return {};
    afterComma = true;
  }
  return visible(draft);
}
