import { memo } from "react";

function columnLabel(value: string) {
  const label = value.replaceAll("_", " ");
  return label.charAt(0).toUpperCase() + label.slice(1);
}


const DataTable = memo(function DataTable({ headers, rows, numbered = false }: { headers: string[]; rows: string[][]; numbered?: boolean }) {
  const numeric = headers.map((_, index) => rows.slice(0, 20).some(row => row[index]?.trim()) && rows.slice(0, 20).every(row => !row[index]?.trim() || /^-?\d+(?:\.\d+)?$/.test(row[index].trim())));
  return (
    <div className="table-scroll -mx-5 -my-2 overflow-auto whitespace-nowrap sm:-mx-8" tabIndex={0} aria-label="Scrollable data table">
      <div className="inline-block min-w-full px-5 py-2 align-middle sm:px-8">
        <table className="w-full border-collapse text-left">
          <thead><tr>
            {numbered && <th scope="col" className="row-number"><span className="sr-only">Row</span></th>}
            {headers.map((header, index) => <th key={`${header}-${index}`} scope="col" className={numeric[index] ? "numeric" : ""}>{columnLabel(header)}</th>)}
          </tr></thead>
          <tbody>{rows.map((row, rowIndex) => <tr key={rowIndex}>
            {numbered && <td className="row-number tabular-nums">{rowIndex + 1}</td>}
            {headers.map((_, index) => <td key={index} className={numeric[index] ? "numeric tabular-nums" : ""} title={row[index] || undefined}>{row[index] || <span className="empty-cell">—</span>}</td>)}
          </tr>)}</tbody>
        </table>
      </div>
    </div>
  );
});

export default DataTable;
