"use client";

import type { ReactNode } from "react";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { AnalysisReport } from "../lib/contracts";
import DataTable from "./data-table";

function shortNumber(value: number) {
  return new Intl.NumberFormat("en", { notation: Math.abs(value) >= 10000 ? "compact" : "standard", maximumFractionDigits: 2 }).format(value);
}


function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: readonly { value?: string | number }[]; label?: ReactNode }) {
  if (!active || !payload?.length) return null;
  return <div className="chart-tooltip"><p>{label}</p><p className="font-medium tabular-nums text-white">{shortNumber(Number(payload[0].value))}</p></div>;
}

export default function ReportChart({ chart, reducedMotion }: { chart: NonNullable<AnalysisReport["chart"]>; reducedMotion: boolean }) {
  const axes = <>
    <CartesianGrid vertical={false} stroke="var(--line)" />
    <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: "var(--color-muted)", fontSize: 12 }} tickMargin={12} minTickGap={20} tickFormatter={(value: string) => value.length > 18 ? `${value.slice(0, 16)}…` : value} />
    <YAxis axisLine={false} tickLine={false} tick={{ fill: "var(--color-muted)", fontSize: 12 }} tickMargin={10} width={56} tickFormatter={shortNumber} />
    <Tooltip content={<ChartTooltip />} cursor={chart.kind === "bar" ? { fill: "var(--chart-hover)" } : { stroke: "var(--color-muted)" }} />
  </>;
  return <figure className="chart-figure @container">
    <div className="flex min-w-0 items-baseline justify-between gap-4"><h3 className="min-w-0 text-balance font-medium text-white">{chart.title}</h3><p className="shrink-0 text-muted">{chart.yLabel}</p></div>
    <div className="chart-canvas" aria-label={chart.title}>
      <ResponsiveContainer width="100%" height="100%" minWidth={0}>
        {chart.kind === "bar" ? <BarChart data={chart.points} margin={{ top: 16, right: 8, bottom: 4, left: -10 }} accessibilityLayer>{axes}<Bar dataKey="value" name={chart.yLabel} fill="var(--color-raspberry)" radius={[5, 5, 0, 0]} maxBarSize={72} isAnimationActive={!reducedMotion} animationDuration={450} /></BarChart> : <LineChart data={chart.points} margin={{ top: 16, right: 12, bottom: 4, left: -10 }} accessibilityLayer>{axes}<Line type="monotone" dataKey="value" name={chart.yLabel} stroke="var(--color-raspberry)" strokeWidth={3} dot={{ r: 3, fill: "var(--color-raspberry)", strokeWidth: 0 }} activeDot={{ r: 5, strokeWidth: 0 }} isAnimationActive={!reducedMotion} animationDuration={450} /></LineChart>}
      </ResponsiveContainer>
    </div>
    <div className="chart-footer"><figcaption className="chart-caption text-muted">{chart.xLabel}</figcaption>
    <details className="chart-data"><summary>View chart data</summary><DataTable headers={[chart.xLabel, chart.yLabel]} rows={chart.points.map(point => [point.label, String(point.value)])} /></details></div>
  </figure>;
}

