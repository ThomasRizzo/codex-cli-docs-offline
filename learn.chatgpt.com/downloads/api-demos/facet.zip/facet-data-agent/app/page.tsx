"use client";

import { useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import DataTable from "./components/data-table";
import {
  ArrowDownTrayIcon, ArrowPathIcon, ArrowUpIcon, ArrowUpRightIcon, Bars3Icon,
  ChartBarIcon, CheckCircleIcon, ChevronDownIcon, CircleStackIcon,
  DocumentArrowUpIcon, QuestionMarkCircleIcon, StopIcon, TableCellsIcon, XMarkIcon,
} from "@heroicons/react/16/solid";
import { parseDataset } from "./lib/data";
import { reportSchema, type AnalysisReport } from "./lib/contracts";
import { parsePartialReport, type PartialAnalysisReport } from "./lib/partial-report";
import { readSSE } from "./lib/sse";
import { SAMPLES } from "./lib/samples";

type Dataset = ReturnType<typeof parseDataset>;
type AnalysisStatus = {
  status: "preparing" | "running" | "complete" | "failed" | "cancelled" | "waiting";
  progress?: string;
  report?: AnalysisReport;
  execution?: { steps: number; verified: boolean };
  error?: string;
};
type Run = { controller: AbortController; observer: AbortController; token: string | null };
const INITIAL_SAMPLE = SAMPLES[0];
const UPLOAD_LIMIT = 512000;
const GENERIC_QUESTIONS = ["What are the most useful patterns in this data?", "Which values stand out, and why?", "Summarize the key numbers in this dataset."];
const ICON = "size-4 shrink-0 fill-current";
const ReportChart = dynamic(() => import("./components/report-chart"), {
  ssr: false, loading: () => <div className="chart-placeholder text-muted" role="status">Preparing chart…</div>,
});

function TouchTarget() {
  return <span className="pointer-fine:hidden pointer-events-none absolute left-1/2 top-1/2 size-[max(100%,3rem)] -translate-1/2" aria-hidden="true" />;
}


class ApiError extends Error {
  constructor(message: string, readonly status: number) { super(message); this.name = "ApiError"; }
}

function Report({ report, question, execution, reducedMotion }: { report: PartialAnalysisReport; question: string; execution: AnalysisStatus["execution"]; reducedMotion: boolean }) {
  return <article className="analysis-report animate-arrive @container">
    <div className="report-heading">
      <p className="report-question text-muted">{question}</p>
      <h1 className="text-balance text-2xl font-medium tracking-tight text-white sm:text-3xl">{report.title || "Your answer"}</h1>
      <p className="report-summary text-pretty text-body">{report.summary}</p>
    </div>
    {((report.metrics?.length ?? 0) > 0 || report.chart) && <div className={`report-visual ${report.chart ? "with-chart" : ""} ${report.chart && (report.metrics?.length ?? 0) > 0 ? "has-metrics" : ""}`}>
      {(report.metrics?.length ?? 0) > 0 && <dl className="metric-grid">{report.metrics?.map((metric, index) => <div key={index} className="min-w-0"><dt className="truncate font-medium text-body" title={metric.label}>{metric.label}</dt><dd className="metric-value truncate tabular-nums text-white" title={metric.value}>{metric.value}</dd><dd className="text-pretty text-muted">{metric.detail}</dd></div>)}</dl>}
      {report.chart && <ReportChart chart={report.chart} reducedMotion={reducedMotion} />}
    </div>}
    {(report.findings?.length ?? 0) > 0 && <section className="findings"><h3 className="text-balance font-medium text-white">What stands out</h3><ol role="list" className="findings-list">{report.findings?.map((finding, index) => <li key={index}><div className="finding-number tabular-nums">{String(index + 1).padStart(2, "0")}</div><p className="text-pretty text-body">{finding}</p></li>)}</ol></section>}
    {report.table && <section className="report-table"><h3 className="text-balance font-medium text-white">The numbers</h3><DataTable headers={report.table.columns} rows={report.table.rows} /></section>}
    {(execution?.verified || report.method) && <div className="method-row">
      {execution?.verified && <p className="flex items-center gap-2 text-muted"><CheckCircleIcon className={`${ICON} text-raspberry`} />Python execution complete</p>}
      {report.method && <details className="method-details"><summary>How this was calculated</summary><p className="text-pretty text-body">{report.method}</p></details>}
    </div>}
  </article>;
}

export default function Home() {
  const [dataset, setDataset] = useState<Dataset>(() => parseDataset(INITIAL_SAMPLE.csv, INITIAL_SAMPLE.name));
  const [sampleId, setSampleId] = useState(INITIAL_SAMPLE.id);
  const [question, setQuestion] = useState("");
  const [view, setView] = useState<"data" | "analysis">("data");
  const [report, setReport] = useState<AnalysisReport | null>(null);
  const [reportQuestion, setReportQuestion] = useState("");
  const [previousContext, setPreviousContext] = useState<{ question: string; summary: string } | null>(null);
  const [reply, setReply] = useState<AnalysisReport | null>(null);
  const [execution, setExecution] = useState<AnalysisStatus["execution"]>();
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<PartialAnalysisReport>({});
  const [streamQuestion, setStreamQuestion] = useState("");
  const [commentary, setCommentary] = useState<{ id: string; text: string }[]>([]);
  const [progress, setProgress] = useState("");
  const [elapsed, setElapsed] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [retryQuestion, setRetryQuestion] = useState<string | null>(null);
  const [notice, setNotice] = useState("");
  const [showHelp, setShowHelp] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(true);
  const activeRun = useRef<Run | null>(null);
  const pendingCleanup = useRef(new Set<string>());
  const cleanupInFlight = useRef(new Set<string>());
  const session = useRef<string | null>(null);
  function requestHeaders() {
    session.current ??= crypto.randomUUID();
    return { "Content-Type": "application/json", "X-Facet-Session": session.current };
  }
  const fileInput = useRef<HTMLInputElement>(null);
  const textarea = useRef<HTMLTextAreaElement>(null);
  const helpDialog = useRef<HTMLDialogElement>(null);
  const menuDialog = useRef<HTMLDialogElement>(null);
  const uploadVersion = useRef(0);
  const dataTab = useRef<HTMLButtonElement>(null);
  const analysisTab = useRef<HTMLButtonElement>(null);
  const analysisPanel = useRef<HTMLDivElement>(null);
  const previewRows = useMemo(() => dataset.rows.slice(0, 200), [dataset]);
  const sample = SAMPLES.find(item => item.id === sampleId);
  const suggestions = sample?.questions ?? GENERIC_QUESTIONS;

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(media.matches);
    update(); media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  useEffect(() => {
    if (busy && view === "analysis") analysisPanel.current?.scrollTo({ top: 0 });
  }, [busy, view]);
  useEffect(() => {
    const dialog = helpDialog.current;
    if (showHelp && dialog && !dialog.open) dialog.showModal();
    else if (!showHelp && dialog?.open) dialog.close();
  }, [showHelp]);
  useEffect(() => {
    const dialog = menuDialog.current;
    if (showMenu && dialog && !dialog.open) dialog.showModal();
    else if (!showMenu && dialog?.open) dialog.close();
  }, [showMenu]);
  useEffect(() => {
    if (!busy) return;
    const started = Date.now();
    const timer = window.setInterval(() => setElapsed(Math.floor((Date.now() - started) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, [busy]);
  useEffect(() => {
    function releaseOnExit() {
      const token = activeRun.current?.token;
      if (token) pendingCleanup.current.add(token);
      for (const pending of pendingCleanup.current) {
        void fetch("/api/analysis/cancel", { method: "POST", headers: requestHeaders(), body: JSON.stringify({ token: pending }), keepalive: true }).catch(() => undefined);
      }
    }
    window.addEventListener("pagehide", releaseOnExit);
    return () => {
      window.removeEventListener("pagehide", releaseOnExit);
      releaseOnExit();
      const run = activeRun.current;
      activeRun.current = null;
      run?.controller.abort();
      if (run?.token) run.observer.abort();
    };
  }, []);

  function releaseWorkspace(token: string) {
    pendingCleanup.current.add(token);
    if (cleanupInFlight.current.has(token)) return;
    cleanupInFlight.current.add(token);
    void (async () => {
      try {
        for (let attempt = 0; attempt < 3; attempt += 1) {
          try {
            const response = await fetch("/api/analysis/cancel", {
              method: "POST", headers: requestHeaders(),
              body: JSON.stringify({ token }), keepalive: true, signal: AbortSignal.timeout(50000),
            });
            if (response.ok) { pendingCleanup.current.delete(token); return; }
          } catch { /* Keep this handle for the bounded retry or pagehide cleanup. */ }
          if (attempt < 2) await new Promise(resolve => window.setTimeout(resolve, (attempt + 1) * 1000));
        }
      } finally { cleanupInFlight.current.delete(token); }
    })();
  }

  function cancelAnalysis(quiet = false) {
    const run = activeRun.current;
    activeRun.current = null;
    run?.controller.abort();
    if (run?.token) { releaseWorkspace(run.token); run.observer.abort(); }
    setBusy(false); setProgress(""); setDraft({}); setCommentary([]);
    if (!report && !reply) setView("data");
    if (!quiet) setNotice("Analysis stopped. Your data is still here.");
  }

  function replaceDataset(next: Dataset, nextSampleId: string) {
    cancelAnalysis(true);
    setDataset(next); setSampleId(nextSampleId); setView("data"); setReport(null); setReply(null);
    setReportQuestion(""); setPreviousContext(null); setQuestion(""); setRetryQuestion(null); setExecution(undefined); setError(null); setNotice("");
  }

  function chooseSample(id: string) {
    const chosen = SAMPLES.find(item => item.id === id);
    if (!chosen) return;
    uploadVersion.current += 1;
    replaceDataset(parseDataset(chosen.csv, chosen.name), chosen.id);
  }

  async function upload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    const version = ++uploadVersion.current;
    try {
      if (file.size > UPLOAD_LIMIT) throw new Error("Choose a CSV smaller than 500 KB.");
      const csv = await file.text();
      if (version !== uploadVersion.current) return;
      replaceDataset(parseDataset(csv, file.name), "uploaded");
      setNotice("Your file is ready. Ask a question to analyze it.");
      setShowMenu(false);
    } catch (cause) {
      if (version === uploadVersion.current) {
        setRetryQuestion(null);
        setError(cause instanceof Error ? cause.message : "That file could not be read. Try another CSV.");
      }
    }
  }

  async function analyze(value = question) {
    const prompt = value.trim();
    if (!prompt || activeRun.current) return;
    const run: Run = { controller: new AbortController(), observer: new AbortController(), token: null };
    activeRun.current = run;
    setQuestion(prompt); setRetryQuestion(null); setBusy(true); setElapsed(0);
    setError(null); setNotice(""); setProgress("Preparing your data…");
    setDraft({}); setCommentary([]); setStreamQuestion(prompt);
    const finish = (state: Pick<AnalysisStatus, "report" | "execution">) => {
      const parsed = reportSchema.safeParse(state.report);
      if (!parsed.success) throw new Error("The analysis was incomplete. Please try again.");
      setPreviousContext({ question: prompt, summary: parsed.data.summary });
      if (parsed.data.status === "complete") {
        setReport(parsed.data); setReportQuestion(prompt); setExecution(state.execution); setReply(null);
      } else setReply(parsed.data);
      setQuestion(""); setProgress("");
      if (run.token) releaseWorkspace(run.token);
    };
    try {
      // Keep reading until the session handle arrives even if Stop was pressed during startup.
      const response = await fetch("/api/analysis/start", {
        method: "POST", headers: { ...requestHeaders(), Accept: "text/event-stream" },
        body: JSON.stringify({ filename: dataset.name, csv: dataset.csv, question: prompt,
          ...(previousContext ? { previousQuestion: previousContext.question, previousSummary: previousContext.summary } : {}) }),
        signal: AbortSignal.any([run.observer.signal, AbortSignal.timeout(185000)]),
      });
      if (!response.ok) {
        const problem = await response.json().catch(() => null);
        const message = problem && typeof problem === "object" && "error" in problem && typeof problem.error === "string" ? problem.error : "The analysis could not start. Please try again.";
        throw new ApiError(message, response.status);
      }
      if (!response.body || !response.headers.get("content-type")?.includes("text/event-stream")) throw new Error("The live response could not be read. Please try again.");
      if (activeRun.current === run) setView("analysis");
      let finalId = "", finalText = "", streamError: string | null = null;
      try {
        for await (const event of readSSE(response.body, { signal: run.observer.signal })) {
          const data = JSON.parse(event.data);
          if (event.event === "session") {
            if (typeof data.token !== "string" || !data.token) throw new Error("The analysis session was incomplete.");
            run.token = data.token;
            if (activeRun.current !== run) { releaseWorkspace(data.token); run.observer.abort(); return; }
          }
          if (activeRun.current !== run) continue;
          if (event.event === "start" || event.event === "progress") {
            if (typeof data.progress === "string") setProgress(data.progress);
          } else if (event.event === "text" || event.event === "text_done") {
            const text = event.event === "text_done" ? data.text : data.delta;
            if (typeof text !== "string" || typeof data.itemId !== "string") continue;
            if (data.phase === "commentary") {
              setCommentary(current => {
                const existing = current.find(item => item.id === data.itemId);
                const updated = { id: data.itemId, text: (event.event === "text_done" ? text : (existing?.text ?? "") + text).slice(0, 8000) };
                return existing ? current.map(item => item.id === data.itemId ? updated : item) : [...current.slice(-7), updated];
              });
            } else if (data.phase === "final_answer") {
              if (finalId !== data.itemId) { finalId = data.itemId; finalText = ""; }
              finalText = event.event === "text_done" ? text : finalText + text;
              if (finalText.length > 65536) throw new Error("The report was too large. Please narrow your question.");
              setDraft(parsePartialReport(finalText));
            }
          } else if (event.event === "complete") {
            finish(data); return;
          } else if (event.event === "error") {
            streamError = typeof data.error === "string" ? data.error : "The analysis could not finish. Please try again.";
            break;
          }
        }
      } catch (cause) {
        if (run.controller.signal.aborted) throw cause;
        throw new Error("The connection ended before the analysis finished. Please try again.");
      }
      if (streamError) throw new Error(streamError);
      if (activeRun.current !== run) return;
      throw new Error("The connection ended before the analysis finished. Please try again.");
    } catch (cause) {
      if (activeRun.current === run && !run.controller.signal.aborted) {
        setRetryQuestion(prompt);
        setError(cause instanceof Error ? cause.message : "The analysis could not finish. Please try again.");
        if (!report && !reply) setView("data");
        if (run.token) releaseWorkspace(run.token);
      }
    } finally {
      if (activeRun.current === run) { activeRun.current = null; setBusy(false); setProgress(""); setDraft({}); setCommentary([]); }
    }
  }

  const picker = (id: string) => <div className="dataset-picker inline-grid min-w-0 grid-cols-[1fr_--spacing(8)]">
    <select id={id} name="dataset" aria-label="Choose a dataset" value={sampleId} disabled={busy} onChange={event => chooseSample(event.target.value)} className="col-span-full row-start-1 min-w-0 appearance-none pr-8">
      {SAMPLES.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
      {sampleId === "uploaded" && <option value="uploaded">{dataset.name}</option>}
    </select>
    <ChevronDownIcon className={`${ICON} pointer-events-none col-start-2 row-start-1 place-self-center fill-muted`} />
  </div>;
  const uploadButton = <button type="button" className="button button-small button-secondary" disabled={busy} onClick={() => fileInput.current?.click()}><DocumentArrowUpIcon className={ICON} />Upload CSV<TouchTarget /></button>;
  const downloadButton = <a className="button button-small button-ghost" href="/downloads/facet-data-agent.zip" download><ArrowDownTrayIcon className={ICON} />Download project<TouchTarget /></a>;

  return <>
    <main className="app-shell isolate">
      <header className="app-toolbar">
        <Link href="/" aria-label="Homepage" className="brand"><ChartBarIcon className={`${ICON} fill-raspberry`} /><div className="text-xl font-medium tracking-tight text-white">Facet</div></Link>
        <div className="desktop-file-tools flex min-w-0 flex-1 items-center gap-4 max-lg:hidden"><div className="toolbar-divider" />{picker("desktop-dataset")}{uploadButton}</div>
        <div className="desktop-actions flex shrink-0 items-center gap-4 max-lg:hidden">{downloadButton}<button type="button" className="button button-small button-icon button-ghost" aria-label="How Facet works" title="How it works" onClick={() => setShowHelp(true)}><QuestionMarkCircleIcon className={ICON} /><TouchTarget /></button></div>
        <p className="mobile-dataset min-w-0 flex-1 truncate text-muted lg:hidden">{dataset.name}</p>
        <button type="button" className="button button-small button-icon button-ghost mobile-menu-toggle" aria-label="Open dataset and project menu" aria-haspopup="dialog" onClick={() => setShowMenu(true)}><Bars3Icon className={ICON} /><TouchTarget /></button>
        <input ref={fileInput} type="file" name="csv-file" accept=".csv,text/csv" aria-label="Upload a CSV" className="sr-only" disabled={busy} onChange={upload} />
      </header>

      <section className="workspace" aria-label="Data workspace">
        <div className="workspace-toolbar">
          <div role="tablist" aria-label="Workspace view" className="view-tabs" onKeyDown={event => {
            if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
            event.preventDefault();
            const next = event.key === "Home" ? "data" : event.key === "End" ? "analysis" : view === "data" ? "analysis" : "data";
            if (next === "analysis" && !report && !reply && !busy) return;
            setView(next); (next === "data" ? dataTab : analysisTab).current?.focus();
          }}>
            <button ref={dataTab} type="button" role="tab" id="data-tab" aria-controls="data-panel" aria-selected={view === "data"} tabIndex={view === "data" ? 0 : -1} className="button button-small view-tab" onClick={() => setView("data")}>Data<TouchTarget /></button>
            <button ref={analysisTab} type="button" role="tab" id="analysis-tab" aria-controls="analysis-panel" aria-selected={view === "analysis"} tabIndex={view === "analysis" ? 0 : -1} disabled={!report && !reply && !busy} className="button button-small view-tab" onClick={() => setView("analysis")}>Analysis<TouchTarget /></button>
          </div>
          <p className="dataset-meta tabular-nums text-muted"><span>{dataset.rowCount.toLocaleString()} rows</span><span aria-hidden="true">·</span><span>{dataset.columnCount} columns</span><span className="sample-label">{sample ? "Sample data" : "Your CSV"}</span></p>
        </div>

        {view === "data" ? <div id="data-panel" role="tabpanel" aria-labelledby="data-tab" className="data-panel">
          <div className="dataset-heading"><div className="flex min-w-0 flex-col gap-1.5"><h1 className="truncate text-2xl font-medium tracking-tight text-white" title={dataset.name}>{dataset.name.replace(/\.csv$/i, "")}</h1><p className="text-pretty text-muted">{sample ? sample.description : "Ready to explore. Your file stays here until you ask a question."}</p></div><TableCellsIcon className={`${ICON} max-sm:hidden fill-muted`} /></div>
          <DataTable headers={dataset.headers} rows={previewRows} numbered />
          <p className="table-note text-muted">{dataset.rowCount > 200 ? `Previewing 200 of ${dataset.rowCount.toLocaleString()} rows. Every row is included in your analysis.` : "All rows are included in your analysis."}</p>
        </div> : <div ref={analysisPanel} id="analysis-panel" role="tabpanel" aria-labelledby="analysis-tab" className="analysis-panel">
          {busy && <div className="streaming-analysis">
            <div className="streaming-status text-muted" role="status"><span className="progress-orbit" aria-hidden="true" /><p className="min-w-0 flex-1 text-pretty">{progress}</p><p className="shrink-0 tabular-nums">{elapsed}s</p></div>
            {draft.title || draft.summary ? <Report report={draft} question={streamQuestion} execution={undefined} reducedMotion={true} /> : <div className="report-heading"><p className="report-question text-muted">{streamQuestion}</p><h1 className="text-balance text-2xl font-medium tracking-tight text-white sm:text-3xl">Exploring your data</h1><div className="streaming-commentary">{commentary.map(item => <p key={item.id} className="text-pretty text-body">{item.text}</p>)}</div></div>}
          </div>}
          {!busy && reply && <div className="conversation-answer animate-arrive"><h2 className="text-balance text-xl font-medium text-white">{reply.title}</h2><p className="text-pretty text-body">{reply.summary}</p>{report && <p className="text-muted">Your previous analysis is below.</p>}</div>}
          {!busy && report && <Report report={report} question={reportQuestion} execution={execution} reducedMotion={reducedMotion} />}
        </div>}
      </section>

      <div className="composer-area">
        {busy && view === "data" && <div className="run-progress" role="status"><div className="flex min-w-0 items-center gap-3"><span className="progress-orbit" aria-hidden="true" /><p className="min-w-0 truncate text-body">{progress}</p><p className="shrink-0 tabular-nums text-muted">{elapsed}s</p></div></div>}
        {error && <div className="feedback-message" role="alert"><p className="min-w-0 flex-1 text-pretty">{error}</p>{retryQuestion && <button type="button" className="button button-small button-ghost shrink-0" disabled={busy} onClick={() => void analyze(retryQuestion)}><ArrowPathIcon className={ICON} />Retry<TouchTarget /></button>}<button type="button" className="button button-small button-icon button-ghost shrink-0" aria-label="Dismiss error" onClick={() => setError(null)}><XMarkIcon className={ICON} /><TouchTarget /></button></div>}
        {!busy && !error && notice && <p className="composer-notice text-pretty text-muted" role="status">{notice}</p>}
        {!busy && !report && !reply && !error && <div className="suggestions" aria-label="Suggested questions">{suggestions.slice(0, 3).map(suggestion => <button key={suggestion} type="button" className="button button-small suggestion-button" title={suggestion} onClick={() => void analyze(suggestion)}><div className="min-w-0 truncate">{suggestion}</div><ArrowUpRightIcon className={ICON} /><TouchTarget /></button>)}</div>}
        <form className="composer" onSubmit={event => { event.preventDefault(); void analyze(); }}>
          <textarea ref={textarea} name="question" aria-label="Ask a question about your data" maxLength={500} rows={2} value={question} disabled={busy} placeholder={report ? "Ask a follow-up about this dataset…" : "What would you like to know about this data?"} onChange={event => setQuestion(event.target.value)} onKeyDown={event => {
            if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing && event.keyCode !== 229) { event.preventDefault(); void analyze(); }
          }} />
          <div className="composer-footer">
            <div className="composer-caption text-muted"><CircleStackIcon className={ICON} /><p className="truncate">{dataset.name.replace(/\.csv$/i, "")}</p><p className="keyboard-hint">Enter to submit<span className="keyboard-secondary"> · Shift + Enter for a new line</span></p>{question.length > 400 && <p className="tabular-nums">{question.length}/500</p>}</div>
            <button type={busy ? "button" : "submit"} className="button button-primary composer-submit" disabled={!busy && !question.trim()} onClick={busy ? event => { event.preventDefault(); cancelAnalysis(); } : undefined}>{busy ? <StopIcon className={ICON} /> : <ArrowUpIcon className={ICON} />}{busy ? "Stop" : "Analyze"}<TouchTarget /></button>
          </div>
        </form>
      </div>
      <div className="sr-only" role="status" aria-live="polite">{!busy && report ? `Analysis ready: ${report.title}` : ""}{!busy && reply ? reply.summary : ""}</div>
    </main>

    <dialog ref={helpDialog} className="facet-dialog" aria-labelledby="help-title" onClose={() => setShowHelp(false)} onClick={event => { if (event.target === event.currentTarget) setShowHelp(false); }}>
      <div className="dialog-content"><div className="flex items-center justify-between gap-4"><h2 id="help-title" className="text-balance text-2xl font-medium tracking-tight text-white">A closer look at your data</h2><button type="button" autoFocus className="button button-small button-icon button-ghost" aria-label="Close help" onClick={() => setShowHelp(false)}><XMarkIcon className={ICON} /><TouchTarget /></button></div>
        <ol role="list" className="help-steps"><li><div className="help-step-number">01</div><div><h3 className="font-medium text-white">Bring a question</h3><p className="text-pretty text-muted">Try a synthetic sample dataset or upload a CSV, up to 500 KB, 5,000 rows, and 32 columns.</p></div></li><li><div className="help-step-number">02</div><div><h3 className="font-medium text-white">Let the agent work</h3><p className="text-pretty text-muted">Your data is sent to OpenAI only when you ask for an analysis. An agent uses Python in a sandbox to calculate its answer.</p></div></li><li><div className="help-step-number">03</div><div><h3 className="font-medium text-white">See what’s behind the answer</h3><p className="text-pretty text-muted">Explore the chart, inspect the numbers, and open the calculation notes. Ask a follow-up to look from another angle.</p></div></li></ol>
      </div>
    </dialog>
    <dialog ref={menuDialog} className="facet-dialog menu-dialog" aria-labelledby="menu-title" onClose={() => setShowMenu(false)} onClick={event => { if (event.target === event.currentTarget) setShowMenu(false); }}><div className="dialog-content"><div className="flex items-center justify-between gap-4"><h2 id="menu-title" className="text-balance text-xl font-medium text-white">Your workspace</h2><button type="button" autoFocus className="button button-small button-icon button-ghost" aria-label="Close menu" onClick={() => setShowMenu(false)}><XMarkIcon className={ICON} /><TouchTarget /></button></div><div className="menu-file-tools"><label htmlFor="mobile-dataset" className="font-medium text-body">Dataset</label>{picker("mobile-dataset")}{uploadButton}</div><div className="menu-actions">{downloadButton}<button type="button" className="button button-small button-ghost" onClick={() => { setShowMenu(false); setShowHelp(true); }}><QuestionMarkCircleIcon className={ICON} />How it works<TouchTarget /></button></div></div></dialog>
  </>;
}
