import { analysisResult } from "../../../lib/analysis-result";
import { pollAnalysisSession } from "../../../lib/agents";
import { ANALYSIS_DEADLINE_MS, ApiError, errorResponse, getRuntime, guardRequest, limitSessionRequests, parseBody, privateHeaders, tokenRequestSchema, verifyHandle } from "../../../lib/server";

export async function POST(request: Request) {
  let cleanupOnError: (() => Promise<unknown>) | undefined;
  try {
    const owner = guardRequest(request);
    const { token } = await parseBody(request, tokenRequestSchema);
    const runtime = await getRuntime();
    const handle = await verifyHandle(token, owner, runtime.secret);
    limitSessionRequests(owner, "status");
    const queue = await runtime.cleanup();
    try { await queue.assertSession(handle.id); }
    catch { throw new ApiError(503, "This generation session is no longer available."); }
    const cleanup = () => queue.release(handle.id).catch(() => console.error(JSON.stringify({ event: "analysis_cleanup_failed", sessionId: handle.id })));
    cleanupOnError = cleanup;
    if (Date.now() - handle.created > ANALYSIS_DEADLINE_MS) {
      await cleanup();
      throw new ApiError(408, "This analysis took too long. Try a more focused question.");
    }
    const state = await pollAnalysisSession(runtime.transport, handle.id);
    if (["failed", "cancelled", "waiting"].includes(state.status)) {
      await cleanup();
      return Response.json({ status: state.status, progress: state.progress, error: state.error }, { headers: privateHeaders });
    }
    if (state.status !== "complete") return Response.json({ status: state.status, progress: state.progress }, { headers: privateHeaders });
    const result = analysisResult(state);
    if (!result) {
      await cleanup();
      return Response.json({ status: "failed", progress: "Analysis incomplete", error: "The analyst could not produce a complete report. Your data is still here; try again." }, { headers: privateHeaders });
    }
    // Completed results stay in the current tab; release provider storage now.
    await cleanup();
    return Response.json({ status: "complete", progress: "Analysis ready", ...result }, { headers: privateHeaders });
  } catch (error) { await cleanupOnError?.(); return errorResponse(error); }
}
