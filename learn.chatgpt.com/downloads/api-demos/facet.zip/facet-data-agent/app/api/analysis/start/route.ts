import { analysisRequestSchema, reportJsonSchema } from "../../../lib/contracts";
import { parseDataset } from "../../../lib/data";
import { AgentsError, pollAnalysisSession, streamAnalysisSession } from "../../../lib/agents";
import { analysisStream } from "../../../lib/analysis-stream";
import { ANALYST_INSTRUCTIONS } from "../../../lib/instructions";
import { ApiError, createHandle, errorResponse, getRuntime, guardRequest, parseBody, privateHeaders } from "../../../lib/server";
import { enforceIpRateLimit } from "../../../lib/ip-rate-limit";
import { IP_LIMITS } from "../../../lib/rate-limit-policy";

export async function POST(request: Request) {
  try {
    const owner = guardRequest(request);
    const limited = await enforceIpRateLimit(request, "start", IP_LIMITS.start);
    if (limited) return limited;
    const input = await parseBody(request, analysisRequestSchema, 3_100_000);
    let dataset;
    try { dataset = parseDataset(input.csv, input.filename); }
    catch (error) { throw new ApiError(400, error instanceof Error ? error.message : "Choose a valid CSV file."); }
    const runtime = await getRuntime();
    const question = JSON.stringify({ question: input.question, dataset: { name: dataset.name, rows: dataset.rowCount, columns: dataset.headers }, previousContext: input.previousQuestion ? { question: input.previousQuestion, summary: input.previousSummary ?? "" } : null });
    const cleanup = await runtime.cleanup();
    const intent = await cleanup.begin();
    const stream = analysisStream({
      start: async function* (signal) {
        let identified = false;
        try {
          for await (const event of streamAnalysisSession(runtime.transport, { csv: dataset.csv, question, instructions: ANALYST_INSTRUCTIONS, reportSchema: reportJsonSchema, signal, metadata: cleanup.metadata(intent) })) {
            if (event.type === "session") identified = true;
            yield event;
          }
        } catch (error) {
          if (!identified && error instanceof AgentsError && [400, 401, 403, 404, 422].includes(error.status)) {
            await cleanup.rejected(intent, error.status);
          }
          throw error;
        }
      },
      record: async id => {
        try { await cleanup.track(intent, id); }
        catch (error) {
          try { await cleanup.emergencyDelete(intent, id); }
          catch { console.error(JSON.stringify({ event: "cleanup_tracking_failed", intentId: intent })); }
          throw error;
        }
      },
      poll: (id, signal) => pollAnalysisSession(runtime.transport, id, { signal }),
      sign: id => createHandle(id, owner, runtime.secret),
      cleanup: async id => { await cleanup.release(id); },
    });
    return new Response(stream, { headers: { ...privateHeaders, "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-store, no-transform", "X-Accel-Buffering": "no" } });
  } catch (error) { return errorResponse(error); }
}
