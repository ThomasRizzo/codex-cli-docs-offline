"""Build the public, reproducible source download without checkout secrets."""
from pathlib import Path
import json, re, zipfile
from urllib.parse import urlsplit

root = Path(__file__).resolve().parent.parent
folders = ('app', 'public', 'components', 'hooks', 'lib', 'scripts', 'tests', 'db', 'drizzle', 'vendor', 'source-download')
files = ('.gitignore', 'README.md', 'package.json', 'package-lock.json', 'components.json',
         'cloudflare-env.d.ts', 'drizzle.config.ts', 'eslint.config.mjs', 'next.config.ts',
         'postcss.config.mjs', 'tsconfig.json', 'vite.config.ts',
         'build/connector-preview-plugin.mjs', 'build/connector-preview-worker.mjs',
         'build/sites-vite-plugin.LICENSE', 'build/sites-vite-plugin.ts', 'build/sites-worker.ts')
excluded = {'node_modules','dist','output','outputs','coverage','work','__pycache__'}
entries = {}
public_replacements = {"app/lib/openai-fetch.ts": "source-download/openai-fetch.ts", "tests/fixtures/provider.mjs": "source-download/provider.mjs"}
secret = re.compile(rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}|-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----')
def add(path):
    relative = path.relative_to(root)
    if path.is_symlink(): raise RuntimeError(f'Symlink excluded: {relative}')
    if any(p.startswith('.') or p in excluded for p in relative.parts): return
    if path.suffix in ('.zip','.log','.pem','.key','.tsbuildinfo','.pyc'): return
    if path.is_file():
        replacement=root/public_replacements.get(str(relative), str(relative))
        source=replacement
        if source.is_symlink(): raise RuntimeError(f'Symlink excluded: {relative}')
        data=source.read_bytes()
        if secret.search(data): raise RuntimeError(f'Possible secret: {relative}')
        entries[str(relative)]=data
for folder in folders:
    if (root/folder).exists():
        for path in sorted((root/folder).rglob('*')): add(path)
for name in files:
    path=root/name
    if path.exists():
        if path.is_symlink(): raise RuntimeError(f'Symlink excluded: {name}')
        data=path.read_bytes()
        if secret.search(data): raise RuntimeError(f'Possible secret: {name}')
        entries[name]=data
# Keep registry tarballs public without changing pinned versions or integrity hashes.
lock = json.loads(entries['package-lock.json'])
for package in lock['packages'].values():
    if 'resolved' not in package: continue
    resolved = urlsplit(package['resolved'])
    pathname = resolved.path.removeprefix('/npm')
    if resolved.scheme != 'https' or resolved.query or resolved.fragment or not re.fullmatch(r'/(?:@[^/]+/)?[^/]+/-/[^/]+\.tgz', pathname):
        raise RuntimeError('Expected an HTTPS npm registry tarball in package-lock.json')
    package['resolved'] = 'https://registry.npmjs.org' + pathname
entries['package-lock.json'] = (json.dumps(lock, indent=2) + '\n').encode()
entries['.openai/hosting.json']=(json.dumps({'d1':'DB','r2':None},indent=2)+'\n').encode()
entries['.env.example']=b'OPENAI_API_KEY=\n'
target=root/'public/ticker-project.zip'
if target.is_symlink(): raise RuntimeError('Download target must not be a symlink')
target.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(entries.items()):
        info=zipfile.ZipInfo('ticker-trading-demo/'+name,date_time=(2000,1,1,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=(0o100755 if name.endswith('.sh') else 0o100644)<<16
        archive.writestr(info,data)
print(f'Packaged {len(entries)} source files into {target.name} ({target.stat().st_size} bytes).')
