"use client";

import { useEffect, useRef, useState, type CSSProperties } from "react";
import { ArrowPathIcon, ArrowUpRightIcon, ChevronDownIcon } from "@heroicons/react/16/solid";
import type { ApiReceipt, AppliedNews, NewsDraft } from "../lib/types";

const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
const percent = (value: number) => `${value > 0 ? "+" : ""}${value.toFixed(2)}%`;
const elapsed = (tick: number) => `${String(Math.floor(tick / 60)).padStart(2, "0")}:${String(tick % 60).padStart(2, "0")}`;

export function ApiReceiptDetails({ receipt, responseId }: { receipt: ApiReceipt; responseId?: string }) {
  return <details className="receipt">
    <summary><span>API receipt</span><span className="receipt-duration">{receipt.durationMs.toLocaleString()} ms<ChevronDownIcon /></span></summary>
    <dl>
      <div><dt>Model</dt><dd>{receipt.model}</dd></div>
      <div><dt>HTTP status</dt><dd>{receipt.status}</dd></div>
      <div><dt>Time</dt><dd>{new Date(receipt.at).toLocaleTimeString("en-US", { hour12: false })}</dd></div>
      {receipt.usage && <div><dt>Tokens</dt><dd>{receipt.usage.totalTokens.toLocaleString()}</dd></div>}
      <div className="receipt-id"><dt>Request ID</dt><dd>{receipt.requestId ?? "Not available"}</dd></div>
      {responseId && <div className="receipt-id"><dt>Response ID</dt><dd>{responseId}</dd></div>}
    </dl>
  </details>;
}

type NewsFeedProps = {
  articles: AppliedNews[];
  draft: NewsDraft | null;
  busy: boolean;
  selectedArticle: string | null;
  revealVersion: number;
};

export function NewsFeed({ articles, draft, busy, selectedArticle, revealVersion }: NewsFeedProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!scrollRef.current) return;
    if (!selectedArticle) { scrollRef.current.scrollTop = 0; return; }
    const article = document.getElementById(`news-${selectedArticle}`);
    if (!article) return;
    const scroller = scrollRef.current;
    scroller.scrollTop += article.getBoundingClientRect().top - scroller.getBoundingClientRect().top;
    article.focus({ preventScroll: true });
  }, [selectedArticle, revealVersion]);

  return <div className="activity-scroll news-scroll" ref={scrollRef}>
    {busy && <article className="news-article news-draft" aria-busy="true">
      <div className="news-article-meta"><p className="fictional-label">Fictional</p><p className="news-stream-status" role="status"><ArrowPathIcon className="spin" />Writing</p></div>
      <h3>{draft?.headline || "Writing the next story"}</h3>
      {draft?.body ? <div className="news-body">{draft.body.split(/\n\s*\n/).map((paragraph, index) => <p key={index}>{paragraph}{index === draft.body.split(/\n\s*\n/).length - 1 && <span className="stream-cursor" aria-hidden="true" />}</p>)}</div> : <p className="news-starting">Waiting for the first words…</p>}
      <p className="news-pending-impact">Price impact pending</p>
    </article>}
    {articles.map(article => <article key={article.id} id={`news-${article.id}`} tabIndex={-1} className="news-article" data-selected={article.id === selectedArticle}>
      <div className="news-article-meta"><p className="fictional-label">Fictional</p><p>{article.symbol} <span>·</span> {elapsed(article.tick)}</p></div>
      <h3>{article.headline}</h3>
      <div className="news-body">{article.body.split(/\n\s*\n/).map((paragraph, index) => <p key={index}>{paragraph}</p>)}</div>
      <div className="news-impact"><p>Applied to {article.symbol}<span data-positive={article.impactPct >= 0}>{percent(article.impactPct)}</span></p><p>{money.format(article.priceBefore)} <span aria-label="to">→</span> {money.format(article.priceAfter)}</p></div>
      <ApiReceiptDetails receipt={article.receipt} responseId={article.responseId} />
    </article>)}
    {!busy && !articles.length && <div className="empty-tape"><div className="empty-tape-lines" aria-hidden="true"><i /><i /><i /><i /></div><h3>Waiting for market news</h3><p>Run the market to generate fictional stories that move prices.</p><p className="news-empty-detail">Written live with the Responses API.</p></div>}
  </div>;
}

function Headline({ article, duplicate, onOpen }: { article: AppliedNews; duplicate: boolean; onOpen: (id: string | null) => void }) {
  return <button type="button" className="marquee-headline" tabIndex={duplicate ? -1 : 0} onClick={() => onOpen(article.id)} aria-label={`${article.headline}. ${article.symbol} ${percent(article.impactPct)}. Read article.`}>
    <span className="marquee-symbol">{article.symbol}</span><span className="marquee-title">{article.headline}</span><span className="marquee-impact" data-positive={article.impactPct >= 0}>{percent(article.impactPct)}</span><ArrowUpRightIcon />
  </button>;
}

export function NewsMarquee({ articles, busy, onOpen }: { articles: AppliedNews[]; busy: boolean; onOpen: (id: string | null) => void }) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const groupRef = useRef<HTMLDivElement>(null);
  const [overflow, setOverflow] = useState(false);
  const [distance, setDistance] = useState(0);
  useEffect(() => {
    const viewport = viewportRef.current, group = groupRef.current;
    if (!viewport || !group) return;
    const measure = () => {
      const width = group.getBoundingClientRect().width;
      setOverflow(width > viewport.clientWidth + 1);
      setDistance(width + 32);
    };
    const observer = new ResizeObserver(measure);
    observer.observe(viewport); observer.observe(group); measure();
    return () => observer.disconnect();
  }, [articles.length]);
  const marqueeStyle = { "--marquee-distance": `${distance}px`, "--marquee-duration": `${Math.max(22, distance / 35)}s` } as CSSProperties;
  return <header className="news-marquee" aria-label="Fictional market news">
    <button type="button" className="news-wire-label" onClick={() => onOpen(null)}><span className="wire-dot" />News wire</button>
    <div className="news-marquee-viewport" ref={viewportRef} data-overflow={overflow}>
      {articles.length ? <div className="news-marquee-track" data-overflow={overflow} style={marqueeStyle}>
        <div className="news-marquee-group" ref={groupRef}>{articles.map(article => <Headline key={article.id} article={article} duplicate={false} onOpen={onOpen} />)}</div>
        {overflow && <div className="news-marquee-group marquee-duplicate" aria-hidden="true">{articles.map(article => <Headline key={article.id} article={article} duplicate onOpen={onOpen} />)}</div>}
      </div> : <button type="button" className="news-wire-empty" onClick={() => onOpen(null)}>{busy ? "Writing the first market story…" : "Run the market to start the news wire."}</button>}
    </div>
    {busy && <p className="wire-writing" role="status"><ArrowPathIcon className="spin" /><span>Writing</span></p>}
  </header>;
}
