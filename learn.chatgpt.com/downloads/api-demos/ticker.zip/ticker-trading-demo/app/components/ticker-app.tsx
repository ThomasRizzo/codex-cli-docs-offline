"use client";

import { useEffect, useId, useMemo, useRef, useState } from "react";
import {
  ArrowDownIcon, ArrowDownTrayIcon, ArrowPathIcon, ArrowUpIcon,
  CheckIcon, ChevronDownIcon, ClockIcon, PauseIcon,
  PlayIcon, QuestionMarkCircleIcon, SpeakerWaveIcon,
  SpeakerXMarkIcon, XMarkIcon,
} from "@heroicons/react/16/solid";
import { ASSETS, SCENARIOS, STRATEGIES } from "../lib/market";
import { useTicker } from "../lib/use-ticker";
import { ApiReceiptDetails, NewsFeed, NewsMarquee } from "./news-feed";
import { INITIAL_CASH, RUN_LIMIT_MS, type AssetState, type DecisionEvent, type PricePoint, type Scenario, type Strategy } from "../lib/types";

const dollars = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 });
const wholeDollars = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
const decimal = new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const quantity = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const clock = (ms: number) => `${String(Math.floor(ms / 60_000)).padStart(2, "0")}:${String(Math.floor(ms / 1_000) % 60).padStart(2, "0")}`;
const change = (value: number) => `${value > 0 ? "+" : ""}${decimal.format(value)}%`;
const signedMoney = (value: number) => `${value > 0 ? "+" : value < 0 ? "−" : ""}${dollars.format(Math.abs(value))}`;

function TouchTarget() { return <span className="touch-target" aria-hidden="true" />; }

function Sparkline({ history, positive }: { history: PricePoint[]; positive: boolean }) {
  const prices = history.slice(-32).map(point => point.price);
  const min = Math.min(...prices), max = Math.max(...prices);
  const path = prices.map((price, i) => `${i === 0 ? "M" : "L"}${(i / Math.max(1, prices.length - 1) * 58).toFixed(2)},${(24 - (price - min) / Math.max(.01, max - min) * 20).toFixed(2)}`).join(" ");
  return <svg className="sparkline" viewBox="0 0 60 28" aria-hidden="true" data-positive={positive}><path d={path} /></svg>;
}

function PriceChart({ asset, running }: { asset: AssetState; running: boolean }) {
  const gradientId = useId().replaceAll(":", "");
  const svgRef = useRef<SVGSVGElement>(null);
  const [size, setSize] = useState({ width: 800, height: 330 });
  const [hovered, setHovered] = useState<number | null>(null);
  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;
    const observer = new ResizeObserver(([entry]) => {
      const width = Math.max(240, Math.round(entry.contentRect.width));
      const height = Math.max(130, Math.round(entry.contentRect.height));
      setSize(previous => previous.width === width && previous.height === height ? previous : { width, height });
    });
    observer.observe(svg);
    return () => observer.disconnect();
  }, []);
  const points = asset.history;
  const { width, height } = size;
  const top = 16, bottom = height - 29, right = width - 62, left = 10;
  const values = points.map(point => point.price);
  const low = Math.min(asset.open, ...values), high = Math.max(asset.open, ...values);
  const padding = Math.max((high - low) * .2, asset.open * .0025);
  const min = low - padding, max = high + padding;
  const x = (index: number) => left + index / Math.max(1, points.length - 1) * (right - left);
  const y = (price: number) => bottom - (price - min) / (max - min) * (bottom - top);
  const line = points.map((point, index) => `${index ? "L" : "M"}${x(index).toFixed(2)},${y(point.price).toFixed(2)}`).join(" ");
  const selectedIndex = hovered === null ? points.length - 1 : Math.min(hovered, points.length - 1);
  const selectedPoint = points[selectedIndex];
  const cursorX = x(selectedIndex), cursorY = y(selectedPoint.price);
  const tickLabel = (tick: number) => tick < 0 ? `${Math.abs(tick)}s before` : clock(tick * 1000);
  return <div className="chart-wrap">
    <svg ref={svgRef} className="price-chart" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" role="img" aria-label={`${asset.symbol} price chart, ${dollars.format(points[0].price)} to ${dollars.format(asset.price)}. ${points.length} market observations.`} onPointerMove={event => {
      const rect = event.currentTarget.getBoundingClientRect();
      const position = (event.clientX - rect.left) / rect.width * width;
      setHovered(Math.max(0, Math.min(points.length - 1, Math.round((position - left) / (right - left) * (points.length - 1)))));
    }} onPointerLeave={() => setHovered(null)}>
      <defs><linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" className="chart-gradient-top" /><stop offset="100%" className="chart-gradient-bottom" /></linearGradient></defs>
      {[0, 1, 2, 3, 4].map(index => {
        const value = max - (max - min) / 4 * index;
        return <g key={index}><line className="chart-grid" x1={left} x2={right} y1={y(value)} y2={y(value)} /><text className="chart-axis" x={width - 2} y={y(value) + 4} textAnchor="end">{decimal.format(value)}</text></g>;
      })}
      <line className="chart-open" x1={left} x2={right} y1={y(asset.open)} y2={y(asset.open)} />
      <path className="chart-area" d={`${line} L${right},${bottom} L${left},${bottom} Z`} fill={`url(#${gradientId})`} />
      <path className="chart-line" d={line} />
      <circle className="chart-point-halo" cx={right} cy={y(asset.price)} r={10} data-running={running} />
      <circle className="chart-point" cx={right} cy={y(asset.price)} r={4} />
      {hovered !== null && <g className="chart-crosshair"><line x1={cursorX} x2={cursorX} y1={top} y2={bottom} /><circle cx={cursorX} cy={cursorY} r={4} /><g transform={`translate(${Math.min(right - 92, Math.max(left, cursorX - 46))}, ${Math.max(0, cursorY - 39)})`}><rect width="92" height="28" rx="5" /><text x="46" y="18" textAnchor="middle">{dollars.format(selectedPoint.price)}</text></g></g>}
      {[0, 1, 2, 3, 4].map(index => {
        const i = Math.round(index / 4 * (points.length - 1));
        if (width < 430 && index % 2 === 1) return null;
        return <text key={index} className="chart-axis chart-time" x={x(i)} y={height - 5} textAnchor={index === 0 ? "start" : index === 4 ? "end" : "middle"}>{tickLabel(points[i].tick)}</text>;
      })}
    </svg>
  </div>;
}

function DecisionItem({ event }: { event: DecisionEvent }) {
  const title = event.state === "pending" ? "Making a decision" : event.state === "failed" ? "Request failed" : event.state === "cancelled" ? "Request cancelled" : event.state === "skipped" ? "Trade skipped" : event.action?.kind === "buy" ? `Buy ${event.action.quantity} ${event.action.symbol}` : event.action?.kind === "sell" ? `Sell ${event.action.quantity} ${event.action.symbol}` : "Hold position";
  const kind = event.state === "pending" ? "pending" : event.state === "failed" ? "failed" : event.action?.kind ?? event.state;
  return <li className="decision-item" data-kind={kind}>
    <div className="decision-title"><div className="decision-action">{kind === "buy" ? <ArrowUpIcon /> : kind === "sell" ? <ArrowDownIcon /> : kind === "pending" ? <ArrowPathIcon className="spin" /> : event.state === "failed" ? <XMarkIcon /> : <span className="hold-mark" aria-hidden="true">—</span>}<h3>{title}</h3></div><time dateTime={new Date(event.startedAt).toISOString()}>{new Date(event.startedAt).toLocaleTimeString("en-US", { hour12: false })}</time></div>
    <p className="decision-detail">{event.detail}</p>
    {event.price !== undefined && event.state === "executed" && <p className="execution-price">Filled at {dollars.format(event.price)}</p>}
    {event.receipt && <ApiReceiptDetails receipt={event.receipt} />}
  </li>;
}

export default function TickerApp() {
  const ticker = useTicker();
  const [panel, setPanel] = useState<"market" | "activity">("market");
  const [activityView, setActivityView] = useState<"decisions" | "news">("decisions");
  const [selectedArticle, setSelectedArticle] = useState<string | null>(null);
  const [revealVersion, setRevealVersion] = useState(0);
  const manualActivityChoice = useRef(false);
  const autoOpenedNews = useRef(false);
  const previousNewsRequests = useRef(0);
  const chooseActivityView = (view: "decisions" | "news") => {
    manualActivityChoice.current = true;
    setActivityView(view);
    setSelectedArticle(null);
  };
  const openArticle = (id: string | null) => {
    manualActivityChoice.current = true;
    setActivityView("news");
    setPanel("activity");
    setSelectedArticle(id);
    setRevealVersion(value => value + 1);
  };
  useEffect(() => {
    if (ticker.newsRequestCount === 0 && previousNewsRequests.current > 0) {
      autoOpenedNews.current = false;
      manualActivityChoice.current = false;
      setSelectedArticle(null);
    }
    previousNewsRequests.current = ticker.newsRequestCount;
  }, [ticker.newsRequestCount]);
  useEffect(() => {
    if (!ticker.newsDraft?.headline && !ticker.newsDraft?.body) return;
    if (autoOpenedNews.current || manualActivityChoice.current) return;
    autoOpenedNews.current = true;
    setActivityView("news");
    setPanel("activity");
  }, [ticker.newsDraft]);
  const helpRef = useRef<HTMLDialogElement>(null);
  const asset = ticker.market.assets.find(item => item.symbol === ticker.selectedSymbol)!;
  const spec = ASSETS.find(item => item.symbol === ticker.selectedSymbol)!;
  const priceChange = (asset.price / asset.open - 1) * 100;
  const sortedEvents = useMemo(() => [...ticker.events].sort((a, b) => b.startedAt - a.startedAt || b.id - a.id), [ticker.events]);
  const heldAssets = ticker.market.assets.filter(item => ticker.portfolio.positions[item.symbol].quantity > 0);
  const invested = ticker.equity - ticker.portfolio.cash;
  const runLabel = ticker.status === "complete" ? "Run again" : ticker.running ? "Pause" : ticker.status === "paused" ? "Resume" : "Run market";
  const scenario = SCENARIOS.find(item => item.id === ticker.scenario)!;
  const activeStrategy = STRATEGIES.find(item => item.id === ticker.strategy)!;
  const articles = useMemo(() => [...ticker.articles].sort((a, b) => b.tick - a.tick), [ticker.articles]);
  const panelBusy = activityView === "news" ? ticker.newsBusy : ticker.busy;
  const panelError = activityView === "news" ? ticker.newsError : ticker.error;

  return <>
    <main className="ticker-app" data-panel={panel}>
      <NewsMarquee articles={articles} busy={ticker.newsBusy} onOpen={openArticle} />

      <nav className="mobile-panel-tabs" aria-label="Workspace"><button type="button" aria-pressed={panel === "market"} onClick={() => { manualActivityChoice.current = true; setPanel("market"); }}>Market</button><button type="button" aria-pressed={panel === "activity"} onClick={() => { manualActivityChoice.current = true; setPanel("activity"); }}>Activity{ticker.requestCount + ticker.newsRequestCount > 0 && <span>{ticker.requestCount + ticker.newsRequestCount}</span>}</button></nav>

      <div className="workspace">
        <aside className="market-sidebar">
          <div className="sidebar-brand"><a href="/" className="brand" aria-label="Ticker homepage"><img src="/ticker-icon.svg" alt="" width="30" height="30" /><h1>Ticker</h1><TouchTarget /></a></div>
          <div className="section-heading watchlist-heading"><h2>Watchlist</h2><p>06</p></div>
          <div className="watchlist" role="group" aria-label="Select a fictional asset">
            {ASSETS.map(item => {
              const quote = ticker.market.assets.find(quote => quote.symbol === item.symbol)!;
              const percent = (quote.price / quote.open - 1) * 100;
              return <button type="button" key={item.symbol} className="asset-option" aria-pressed={ticker.selectedSymbol === item.symbol} onClick={() => ticker.setSelectedSymbol(item.symbol)}>
                <div className="asset-identity"><p className="asset-symbol">{item.symbol}</p><p className="asset-name">{item.name}</p></div>
                <Sparkline history={quote.history} positive={percent >= 0} />
                <div className="asset-quote"><p>{decimal.format(quote.price)}</p><p data-positive={percent >= 0}>{change(percent)}</p></div>
              </button>;
            })}
          </div>
          <div className="experiment-settings">
            <div className="section-heading"><h2>The experiment</h2></div>
            <div className="setting"><label htmlFor="strategy">Strategy</label><div className="select-wrap"><select id="strategy" name="strategy" title={activeStrategy.description} value={ticker.strategy} disabled={ticker.running} onChange={event => ticker.setStrategy(event.target.value as Strategy)}>{STRATEGIES.map(item => <option value={item.id} key={item.id}>{item.name}</option>)}</select><ChevronDownIcon /></div></div>
            <div className="setting"><label htmlFor="scenario">Market mood</label><div className="select-wrap"><select id="scenario" name="scenario" title={scenario.description} value={ticker.scenario} disabled={ticker.running} onChange={event => ticker.setScenario(event.target.value as Scenario)}>{SCENARIOS.map(item => <option value={item.id} key={item.id}>{item.name}</option>)}</select><ChevronDownIcon /></div></div>
            <div className="starting-capital"><p>Starting capital</p><p>{wholeDollars.format(INITIAL_CASH)}</p></div>
          </div>
        </aside>

        <div className="market-workspace">
          <section className="chart-panel" aria-labelledby="asset-title">
            <div className="chart-heading"><div><div className="chart-asset-name"><h2 id="asset-title">{spec.name}</h2><p>{spec.symbol}</p></div><div className="price-heading"><p className="current-price">{dollars.format(asset.price)}</p><p className="price-change" data-positive={priceChange >= 0}>{priceChange >= 0 ? <ArrowUpIcon /> : <ArrowDownIcon />}{change(priceChange)}</p></div></div><div className="chart-context"><p>{spec.sector}</p><p><span data-running={ticker.running} />{ticker.running ? "Live simulation" : ticker.status === "complete" ? "Session complete" : ticker.status === "paused" ? "Market paused" : "Ready to run"}</p></div></div>
            <PriceChart asset={asset} running={ticker.running} />
            <div className="chart-caption"><p><span className="legend-line" />Price<span className="legend-dash" />Session open</p><p>USD · Simulated prices</p></div>
          </section>

          <section className="portfolio-panel" aria-labelledby="portfolio-title">
            <div className="section-heading portfolio-heading"><h2 id="portfolio-title">Your portfolio</h2><p>{ticker.tradeCount} {ticker.tradeCount === 1 ? "trade" : "trades"}</p></div>
            <div className="portfolio-metrics"><div><p>Portfolio value</p><h3>{dollars.format(ticker.equity)}</h3></div><div><p>Total return</p><h3 className="return-value" data-positive={ticker.pnl.amount >= 0}>{signedMoney(ticker.pnl.amount)}<small>{change(ticker.pnl.percent)}</small></h3></div><div><p>Available cash</p><h3>{dollars.format(ticker.portfolio.cash)}</h3></div></div>
            <div className="holdings-area">
              {heldAssets.length ? <table className="holdings-table"><thead><tr><th>Position</th><th>Shares</th><th>Value</th><th>Return</th></tr></thead><tbody>{heldAssets.map(item => {
                const position = ticker.portfolio.positions[item.symbol];
                const gain = (item.price - position.averageCost) * position.quantity;
                return <tr key={item.symbol}><th scope="row"><button type="button" onClick={() => ticker.setSelectedSymbol(item.symbol)}>{item.symbol}</button></th><td>{quantity.format(position.quantity)}</td><td>{dollars.format(position.quantity * item.price)}</td><td data-positive={gain >= 0}>{signedMoney(gain)}</td></tr>;
              })}</tbody></table> : <div className="empty-holdings"><p>No positions yet</p><p>Positions appear when the decision engine makes its first trade.</p></div>}
            </div>
            <div className="portfolio-footer"><p><span className="allocation-dot" />{Math.round(invested / Math.max(1, ticker.equity) * 100)}% invested</p><p>Market benchmark <span data-positive={ticker.benchmarkPct >= 0}>{change(ticker.benchmarkPct)}</span></p></div>
          </section>
        </div>

        <aside className="activity-panel" aria-label="Market activity">
          <div className="activity-heading"><div>
            <div className="activity-tabs" role="tablist" aria-label="Activity feed">{(["decisions", "news"] as const).map(view => <button key={view} id={`${view}-tab`} role="tab" type="button" aria-selected={activityView === view} aria-controls={`${view}-feed`} tabIndex={activityView === view ? 0 : -1} onClick={() => chooseActivityView(view)} onKeyDown={event => {
              if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
              event.preventDefault();
              const next = event.key === "Home" ? "decisions" : event.key === "End" ? "news" : view === "decisions" ? "news" : "decisions";
              chooseActivityView(next);
              document.getElementById(`${next}-tab`)?.focus();
            }}>{view === "decisions" ? "Decisions" : "News"}{view === "news" && ticker.newsBusy && <span className="news-tab-dot" />}</button>)}</div>
            <p>{activityView === "news" ? "OpenAI Responses API · Fast" : "OpenAI Decisions API"}</p>
          </div><div className="api-indicator" data-busy={panelBusy} title={panelBusy ? "A request is in progress" : "No request in progress"}><span />{panelBusy ? activityView === "news" ? "Writing" : "Thinking" : "Ready"}</div></div>
          <div className="activity-content" role="tabpanel" id={`${activityView}-feed`} aria-labelledby={`${activityView}-tab`}>
            <div className="activity-stats">{activityView === "decisions" ? <><p><span>{ticker.requestCount}</span> {ticker.requestCount === 1 ? "request" : "requests"}</p><p>{ticker.lastLatencyMs === null || ticker.lastLatencyMs === undefined ? "—" : `${ticker.lastLatencyMs.toLocaleString()} ms`} <span>last call</span></p></> : <><p><span>{ticker.newsRequestCount}</span> {ticker.newsRequestCount === 1 ? "request" : "requests"}</p><p>{articles.length} <span>{articles.length === 1 ? "article" : "articles"}</span></p></>}</div>
            {panelError && <p className="api-error" role="alert">{panelError}</p>}
            {activityView === "news" ? <NewsFeed articles={articles} draft={ticker.newsDraft} busy={ticker.newsBusy} selectedArticle={selectedArticle} revealVersion={revealVersion} /> : <div className="activity-scroll">
              {sortedEvents.length ? <ol className="decision-list" role="list">{sortedEvents.map(event => <DecisionItem event={event} key={event.id} />)}</ol> : <div className="empty-tape"><div className="empty-tape-lines" aria-hidden="true"><i /><i /><i /><i /></div><h3>Waiting for decisions</h3><p>Run the market to see real buy, hold, and sell decisions as they happen.</p><div className="empty-tape-key"><p><CheckIcon />Actual API requests</p><p><ClockIcon />Receipts and timing</p></div></div>}
            </div>}
            <div className="tape-footer"><span className="tape-dot" /><p>{activityView === "news" ? "Fictional stories. Price jumps capped at ±3%." : ticker.status === "complete" ? "Session complete. Review your decisions above." : ticker.running ? "Decisions are made about every 3 seconds." : "The decision engine waits until you press Run."}</p></div>
          </div>
        </aside>
      </div>

      <footer className="run-bar">
        <div className="session-status"><p><span data-running={ticker.running} />{ticker.status === "complete" ? "Experiment complete" : ticker.running ? "Market is running" : ticker.status === "paused" ? "Experiment paused" : "Ready to trade"}</p><p>{ticker.status === "complete" ? "Review the tape, or run a new experiment." : "Choose a strategy, then run."}</p></div>
        <div className="session-timer"><div><p>Session</p><p>{clock(ticker.elapsedMs)} <span>/ 02:00</span></p></div><progress max={RUN_LIMIT_MS} value={ticker.elapsedMs} aria-label="Session elapsed time" /></div>
        <div className="run-actions"><button className="icon-button sound-control" type="button" aria-label={ticker.soundEnabled ? "Mute sound" : "Enable sound"} title={ticker.soundEnabled ? "Mute sound" : "Enable sound"} aria-pressed={ticker.soundEnabled} onClick={ticker.toggleSound}>{ticker.soundEnabled ? <SpeakerWaveIcon /> : <SpeakerXMarkIcon />}<TouchTarget /></button><button className="icon-button restart-control" type="button" aria-label="Restart experiment" title="Restart experiment" onClick={ticker.restart}><ArrowPathIcon /><TouchTarget /></button><a className="icon-button download-control" href="/ticker-project.zip" download aria-label="Download project" title="Download project"><ArrowDownTrayIcon /><TouchTarget /></a><button type="button" className="icon-button help-control" aria-label="How Ticker works" title="How Ticker works" onClick={() => helpRef.current?.showModal()}><QuestionMarkCircleIcon /><TouchTarget /></button><button type="button" className="button run-button" onClick={ticker.toggleRun}>{ticker.running ? <PauseIcon /> : <PlayIcon />}<span>{runLabel}</span></button></div>
      </footer>
    </main>
    <dialog className="help-dialog" aria-labelledby="help-title" ref={helpRef} onClick={event => { if (event.target === event.currentTarget) helpRef.current?.close(); }}>
      <div className="help-heading"><div><p>Ticker</p><h2 id="help-title">How Ticker works</h2></div><button type="button" className="icon-button" aria-label="Close help" onClick={() => helpRef.current?.close()}><XMarkIcon /><TouchTarget /></button></div>
      <div className="help-content"><p>Give a decision engine {wholeDollars.format(INITIAL_CASH)} in paper money and watch it navigate six fictional stocks.</p><ol><li><h3>Set the experiment</h3><p>Choose a strategy and market mood. Changing either starts a fresh portfolio.</p></li><li><h3>Follow the news</h3><p>The Responses API, using Fast mode, writes a short fictional article about every 20 seconds. A completed story moves its stock by up to 3% in either direction.</p></li><li><h3>Watch the decisions</h3><p>The Decisions API reacts to prices and news, choosing to buy, sell, or hold. Open any receipt to inspect the real request, model, and timing.</p></li></ol><p className="help-note">Runs stop after two minutes of active time. Pause or leave the tab to stop both APIs. There are no real assets or real-money trades.</p></div>
    </dialog>
  </>;
}
