import { enforceIpRateLimit } from "@/app/lib/ip-rate-limit";
import { IP_LIMITS } from "@/app/lib/rate-limit-policy";
import { buildTradingDecisionRequest, decisionInputSchema, parseTradingDecision, tradeDecisionSchema } from "@/app/lib/trading-contract";
import type { DecisionInput, TradeDecision } from "@/app/lib/types";
import { ApiError, boundedText, errorResponse, guardRequest, openAIResponse, parseBody, privateHeaders } from "@/app/lib/server";
import type { OpenAIPath } from "@/app/lib/server";

type Transport = (path: OpenAIPath, payload: unknown, signal: AbortSignal) => Promise<Response>;

/** Exactly one native Decisions request; all action sizes come from the offered candidates. */
export async function getTradingDecision(input: DecisionInput, signal: AbortSignal, transport: Transport = openAIResponse): Promise<TradeDecision> {
  signal.throwIfAborted();
  const started = performance.now();
  const response = await transport("/decisions", buildTradingDecisionRequest(input), signal);
  if (!response.ok) {
    await response.body?.cancel().catch(() => undefined);
    throw new ApiError(response.status === 429 ? 429 : 502, "Ticker could not obtain a decision. Your portfolio is unchanged; try again.");
  }
  let body: unknown;
  try { body = JSON.parse(await boundedText(response.body, 16_384, signal)); }
  catch (error) {
    if (error instanceof ApiError && error.status === 413) throw new ApiError(502, "The decision response exceeded its bounds. Your portfolio is unchanged; try again.");
    throw error;
  }
  signal.throwIfAborted();
  const { model, usage, ...decision } = parseTradingDecision(input, body);
  const id = response.headers.get("x-request-id");
  return tradeDecisionSchema.parse({
    ...decision,
    receipt: {
      at: new Date().toISOString(),
      model,
      durationMs: Math.max(0, Math.round(performance.now() - started)),
      status: response.status,
      ...(id && /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(id) ? { requestId: id } : {}),
      ...(usage ? { usage } : {}),
    },
  });
}

export async function handleDecisionRequest(request: Request, transport: Transport = openAIResponse, limit: typeof enforceIpRateLimit = enforceIpRateLimit): Promise<Response> {
  try {
    guardRequest(request);
    const blocked = await limit(request, "decisions", IP_LIMITS.decisions);
    if (blocked) return blocked;
    const signal = AbortSignal.any([request.signal, AbortSignal.timeout(8_000)]);
    // Preserve Vinext's Request proxy: Workerd cannot clone it through new Request(proxy).
    const input = await parseBody(request, decisionInputSchema, signal);
    const decision = await getTradingDecision(input, signal, transport);
    return Response.json(decision, { headers: privateHeaders });
  } catch (error) { return errorResponse(error); }
}

export async function POST(request: Request): Promise<Response> { return handleDecisionRequest(request); }
