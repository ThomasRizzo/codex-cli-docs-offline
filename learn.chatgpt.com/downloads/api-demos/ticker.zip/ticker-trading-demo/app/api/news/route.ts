import { enforceIpRateLimit } from "@/app/lib/ip-rate-limit";
import { IP_LIMITS } from "@/app/lib/rate-limit-policy";
import { buildNewsRequest, newsInputSchema, parseCompletedNews, readNewsDraft, readNewsSSE } from "@/app/lib/news-contract";
import { ApiError, guardRequest, openAIResponse, parseBody, privateHeaders, publicError } from "@/app/lib/server";
import type { OpenAIPath } from "@/app/lib/server";
import type { NewsInput, NewsStreamEvent } from "@/app/lib/types";

type Transport = (path: OpenAIPath, payload: unknown, signal: AbortSignal) => Promise<Response>;

export async function* streamNews(input: NewsInput, signal: AbortSignal, transport: Transport = openAIResponse): AsyncGenerator<NewsStreamEvent> {
  signal.throwIfAborted();
  const started = performance.now();
  const response = await transport("/responses", buildNewsRequest(input), signal);
  if (!response.ok || !response.body || !response.headers.get("content-type")?.toLowerCase().includes("text/event-stream")) {
    await response.body?.cancel().catch(() => undefined);
    throw new ApiError(response.status === 429 ? 429 : 502, "Ticker could not stream the news article. No news impact was applied.");
  }
  let text = "", lastDraft = "", channel: string | undefined;
  for await (const frame of readNewsSSE(response.body, signal, 524_288)) {
    if (frame === "[DONE]") break;
    const event = JSON.parse(frame) as Record<string, unknown>;
    if (!event || typeof event !== "object" || typeof event.type !== "string") throw new Error("Malformed news stream event.");
    if (["response.failed", "response.incomplete", "error", "response.refusal.delta", "response.refusal.done"].includes(event.type)) throw new Error("The article was incomplete or declined.");
    if (event.type === "response.output_text.delta") {
      if (typeof event.delta !== "string") throw new Error("Malformed news text.");
      const nextChannel = `${event.output_index ?? 0}:${event.content_index ?? 0}:${event.item_id ?? ""}`;
      if (channel !== undefined && channel !== nextChannel) throw new Error("Unexpected multiple article outputs.");
      channel = nextChannel;
      text += event.delta;
      if (text.length > 12_000) throw new Error("The article exceeded its size limit.");
      const draft = readNewsDraft(text), serialized = JSON.stringify(draft);
      if (serialized !== lastDraft && (draft.headline || draft.body)) { lastDraft = serialized; yield { type: "draft", draft }; }
    } else if (event.type === "response.completed") {
      const id = response.headers.get("x-request-id");
      const result = parseCompletedNews(input, event.response, {
        at: new Date().toISOString(), durationMs: Math.max(0, Math.round(performance.now() - started)), status: response.status,
        ...(id && /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(id) ? { requestId: id } : {}),
      });
      signal.throwIfAborted();
      yield { type: "complete", result };
      return;
    }
  }
  throw new Error("The article stream ended before completion.");
}

function newsError(error: unknown) {
  const known = publicError(error);
  return { status: known.status, message: error instanceof ApiError && ![502].includes(error.status) ? known.message
    : known.status === 504 ? "The news article took too long. No news impact was applied."
    : known.status === 408 ? "The news request was stopped. No news impact was applied."
    : "The news article was interrupted or incomplete. No news impact was applied." };
}

export async function handleNewsRequest(request: Request, transport: Transport = openAIResponse, limit: typeof enforceIpRateLimit = enforceIpRateLimit): Promise<Response> {
  try {
    guardRequest(request);
    const blocked = await limit(request, "news", IP_LIMITS.news);
    if (blocked) return blocked;
    const cancellation = new AbortController();
    const signal = AbortSignal.any([request.signal, cancellation.signal, AbortSignal.timeout(15_000)]);
    // Use the original Vinext proxy; reconstructing it as Request fails in Workerd.
    const input = await parseBody(request, newsInputSchema, signal);
    const iterator = streamNews(input, signal, transport), encoder = new TextEncoder();
    const body = new ReadableStream<Uint8Array>({
      async pull(controller) {
        try {
          const item = await iterator.next();
          if (item.done) { controller.close(); return; }
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(item.value)}\n\n`));
          if (item.value.type === "complete") { await iterator.return(undefined); controller.close(); }
        } catch (error) {
          const { message } = newsError(error);
          if (!cancellation.signal.aborted) {
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: "error", message })}\n\n`));
            controller.close();
          }
        }
      },
      async cancel() { cancellation.abort(); await iterator.return(undefined); },
    });
    return new Response(body, { headers: { ...privateHeaders, "Content-Type": "text/event-stream; charset=utf-8", "X-Accel-Buffering": "no" } });
  } catch (error) {
    const { status, message } = newsError(error);
    return Response.json({ error: message }, { status, headers: { ...privateHeaders, ...(status === 429 ? { "Retry-After": "60" } : {}) } });
  }
}

export async function POST(request: Request): Promise<Response> { return handleNewsRequest(request); }
