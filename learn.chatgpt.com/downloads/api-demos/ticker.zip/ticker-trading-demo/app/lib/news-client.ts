import { newsInputSchema, newsStreamEventSchema, readNewsSSE } from "./news-contract";
import type { NewsDraft, NewsInput, NewsResult } from "./types";
import { NewsRequestError, retryAfterMs } from "./request-cooldown";

async function errorMessage(response: Response, fallback: string): Promise<string> {
  const reader = response.body?.getReader();
  if (!reader) return fallback;
  let text = "", bytes = 0;
  const decoder = new TextDecoder();
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > 4_096) return fallback;
      text += decoder.decode(value, { stream: true });
    }
    const body: unknown = JSON.parse(text + decoder.decode());
    return body && typeof body === "object" && "error" in body && typeof body.error === "string"
      ? body.error.slice(0, 500) : fallback;
  } catch { return fallback; }
  finally { await reader.cancel().catch(() => undefined); reader.releaseLock(); }
}

export async function requestNews(input: NewsInput, signal: AbortSignal, onDraft: (draft: NewsDraft) => void, send: typeof fetch = fetch): Promise<NewsResult> {
  const active = AbortSignal.any([signal, AbortSignal.timeout(18_000)]);
  try {
    active.throwIfAborted();
    const response = await send("/api/news", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(newsInputSchema.parse(input)), signal: active });
    if (!response.ok) {
      const fallback = response.status === 429 ? "News is cooling down. Try again after the usage limit resets."
        : response.status === 401 ? "Ticker could not start the news request. Please try again."
        : "The news article could not start. No news impact was applied.";
      const message = await errorMessage(response, fallback);
      throw new NewsRequestError(message, retryAfterMs(response.headers.get("Retry-After")) || (response.status === 429 ? 60_000 : 0));
    }
    if (!response.headers.get("content-type")?.toLowerCase().includes("text/event-stream") || !response.body) {
      await response.body?.cancel().catch(() => undefined);
      throw new Error("The news article could not start. No news impact was applied.");
    }
    for await (const frame of readNewsSSE(response.body, active)) {
      const event = newsStreamEventSchema.parse(JSON.parse(frame));
      active.throwIfAborted();
      if (event.type === "error") throw new Error(event.message);
      if (event.type === "draft") onDraft(event.draft);
      else {
        if (event.result.revision !== input.revision || event.result.symbol !== input.target) throw new Error("The news article no longer matches this market. It was not applied.");
        return event.result;
      }
    }
    throw new Error("The news stream ended before the article was complete. No news impact was applied.");
  } catch (error) {
    signal.throwIfAborted();
    if (active.aborted || (error instanceof Error && error.name === "TimeoutError")) throw new Error("The news article took too long. No news impact was applied.");
    if (error instanceof Error && !["ZodError", "SyntaxError", "TypeError"].includes(error.name)) throw error;
    throw new Error("The news article could not be read. No news impact was applied.");
  }
}
