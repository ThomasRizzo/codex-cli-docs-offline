import { RequestCooldown } from "./request-cooldown.ts";
import { DECISION_INTERVAL_MS, RUN_LIMIT_MS, type DecisionInput, type TradeDecision } from "./types.ts";

export class TradingRequestError extends Error {
  retryAfterMs: number;
  fatal: boolean;
  constructor(message: string, retryAfterMs = 0, fatal = false) {
    super(message); this.retryAfterMs = retryAfterMs; this.fatal = fatal;
  }
}

type Callbacks = {
  observe: () => DecisionInput | null;
  submit: (input: DecisionInput, signal: AbortSignal) => Promise<TradeDecision>;
  nextId: () => number;
  started: (id: number) => void;
  completed: (id: number, input: DecisionInput, decision: TradeDecision) => void;
  failed: (id: number, error: Error) => void;
  stopped: (id: number) => void;
  backoff: (fatal: boolean) => void;
};

/** At most one request in flight; cancellation invalidates even an unabortable response. */
export class TradingDecisionLoop {
  private closed = false;
  private pending: { id: number; controller: AbortController } | null = null;
  private nextAt = -Infinity;
  private failures = 0;
  private cooldown: RequestCooldown;
  private callbacks: Callbacks;
  private now: () => number;

  constructor(callbacks: Callbacks, now: () => number = () => performance.now(), cooldown?: RequestCooldown) {
    this.callbacks = callbacks; this.now = now;
    this.cooldown = cooldown ?? new RequestCooldown(now);
  }

  tick(): void {
    if (this.closed || this.pending || this.now() < this.nextAt || this.cooldown.active) return;
    const input = this.callbacks.observe();
    if (!input) return;
    const id = this.callbacks.nextId();
    const controller = new AbortController();
    this.pending = { id, controller };
    this.nextAt = this.now() + DECISION_INTERVAL_MS;
    this.callbacks.started(id);
    void this.run(id, input, controller);
  }

  private async run(id: number, input: DecisionInput, controller: AbortController): Promise<void> {
    try {
      const decision = await this.callbacks.submit(input, controller.signal);
      if (this.closed || controller.signal.aborted) return;
      this.failures = 0;
      this.callbacks.completed(id, input, decision);
    } catch (error) {
      if (this.closed || controller.signal.aborted) return;
      const problem = error instanceof Error ? error : new Error("This decision was interrupted.");
      this.failures += 1;
      const fatal = this.failures >= 3 || (problem instanceof TradingRequestError && (problem.fatal || problem.retryAfterMs >= RUN_LIMIT_MS));
      const delay = Math.max(4_000 * 2 ** Math.min(this.failures - 1, 3), problem instanceof TradingRequestError ? problem.retryAfterMs : 0);
      this.cooldown.defer(delay, problem.message);
      this.nextAt = Math.max(this.nextAt, this.now() + delay);
      this.callbacks.failed(id, problem);
      this.callbacks.backoff(fatal);
      if (fatal) this.stop();
    } finally {
      if (this.pending?.id === id) this.pending = null;
    }
  }

  stop(): void {
    if (this.closed) return;
    this.closed = true;
    if (this.pending) {
      const { id, controller } = this.pending;
      this.pending = null;
      controller.abort();
      this.callbacks.stopped(id);
    }
  }
}
