"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export type SoundCue = "tap" | "phase" | "plan" | "complete" | "notice";

type Tone = {
  frequency: number;
  endFrequency?: number;
  duration: number;
  volume: number;
  delay?: number;
  waveform?: OscillatorType;
};

const PREFERENCE_KEY = "ticker-sound-enabled";
const TONES: Record<SoundCue, readonly Tone[]> = {
  tap: [{ frequency: 620, endFrequency: 420, duration: .045, volume: .012 }],
  phase: [{ frequency: 320, endFrequency: 240, duration: .075, volume: .009, waveform: "triangle" }],
  plan: [
    { frequency: 440, duration: .11, volume: .014 },
    { frequency: 554.37, duration: .15, volume: .011, delay: .065 },
  ],
  complete: [
    { frequency: 523.25, duration: .12, volume: .012 },
    { frequency: 659.25, duration: .16, volume: .009, delay: .07 },
  ],
  notice: [{ frequency: 230, endFrequency: 185, duration: .08, volume: .012 }],
};

function releaseVoice(oscillator: OscillatorNode, gain: GainNode) {
  oscillator.onended = null;
  try { oscillator.stop(); } catch { /* Already stopped. */ }
  oscillator.disconnect();
  gain.disconnect();
}

/** Soft interaction and trade cues, never a continuous soundtrack. */
export function useSoundEffects() {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const enabled = useRef(true);
  const mounted = useRef(false);
  const context = useRef<AudioContext | null>(null);
  const voices = useRef(new Map<OscillatorNode, GainNode>());
  const generation = useRef(0);
  const lastPhase = useRef(-Infinity);
  const recentCues = useRef<number[]>([]);

  const cancelSounds = useCallback(() => {
    generation.current += 1;
    for (const [oscillator, gain] of voices.current) releaseVoice(oscillator, gain);
    voices.current.clear();
  }, []);

  useEffect(() => {
    mounted.current = true;
    try {
      enabled.current = localStorage.getItem(PREFERENCE_KEY) !== "false";
      setSoundEnabled(enabled.current);
    } catch { /* Keep the in-memory preference if storage is unavailable. */ }

    const onVisibilityChange = () => {
      if (!document.hidden) return;
      cancelSounds();
      const audio = context.current;
      if (audio?.state === "running") void audio.suspend().catch(() => {});
    };
    document.addEventListener("visibilitychange", onVisibilityChange);
    return () => {
      mounted.current = false;
      document.removeEventListener("visibilitychange", onVisibilityChange);
      cancelSounds();
      const audio = context.current;
      context.current = null;
      if (audio && audio.state !== "closed") void audio.close().catch(() => {});
    };
  }, [cancelSounds]);

  const playSound = useCallback((cue: SoundCue) => {
    if (!mounted.current || !enabled.current || document.hidden) return;
    const userGesture = navigator.userActivation?.isActive === true;
    let audio = context.current;
    if (!audio || audio.state === "closed") {
      if (!userGesture) return;
      const Audio = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Audio) return;
      try {
        audio = new Audio();
        context.current = audio;
      } catch { return; }
    }

    const currentAudio = audio;
    const currentGeneration = generation.current;
    const requestedAt = performance.now();
    const play = () => {
      if (!mounted.current || !enabled.current || document.hidden
        || currentGeneration !== generation.current || context.current !== currentAudio
        || currentAudio.state !== "running") return;
      const now = performance.now();
      // A delayed resume must not replay old interactions or produce a sudden burst.
      if (now - requestedAt > 400) return;
      if (cue === "phase" && now - lastPhase.current < 1_500) return;
      recentCues.current = recentCues.current.filter(time => now - time < 750);
      if (recentCues.current.length >= 3) return;
      recentCues.current.push(now);
      if (cue === "phase") lastPhase.current = now;

      for (const tone of TONES[cue]) {
        let oscillator: OscillatorNode | undefined;
        let gain: GainNode | undefined;
        try {
          const start = currentAudio.currentTime + (tone.delay ?? 0);
          oscillator = currentAudio.createOscillator();
          gain = currentAudio.createGain();
          oscillator.type = tone.waveform ?? "sine";
          oscillator.frequency.setValueAtTime(tone.frequency, start);
          oscillator.frequency.exponentialRampToValueAtTime(tone.endFrequency ?? tone.frequency, start + tone.duration);
          gain.gain.setValueAtTime(0, start);
          gain.gain.linearRampToValueAtTime(tone.volume, start + .006);
          gain.gain.exponentialRampToValueAtTime(.0001, start + tone.duration);
          oscillator.connect(gain);
          gain.connect(currentAudio.destination);
          voices.current.set(oscillator, gain);
          const voice = oscillator;
          const envelope = gain;
          oscillator.onended = () => {
            voices.current.delete(voice);
            voice.disconnect();
            envelope.disconnect();
          };
          oscillator.start(start);
          oscillator.stop(start + tone.duration + .015);
        } catch {
          if (oscillator) {
            voices.current.delete(oscillator);
            try { oscillator.stop(); } catch { /* May not have started. */ }
            oscillator.disconnect();
          }
          gain?.disconnect();
        }
      }
    };

    if (audio.state === "running") play();
    else if (userGesture) {
      void audio.resume().then(() => {
        // Mute/visibility may have changed while the browser resumed the context.
        if ((!enabled.current || document.hidden) && currentAudio.state === "running") {
          void currentAudio.suspend().catch(() => {});
          return;
        }
        play();
      }).catch(() => {});
    }
  }, []);

  const toggleSound = useCallback(() => {
    const next = !enabled.current;
    enabled.current = next;
    setSoundEnabled(next);
    try { localStorage.setItem(PREFERENCE_KEY, String(next)); } catch { /* Optional preference storage. */ }
    cancelSounds();
    if (next) playSound("tap");
    else if (context.current?.state === "running") void context.current.suspend().catch(() => {});
  }, [cancelSounds, playSound]);

  return { soundEnabled, toggleSound, playSound, cancelSounds };
}
