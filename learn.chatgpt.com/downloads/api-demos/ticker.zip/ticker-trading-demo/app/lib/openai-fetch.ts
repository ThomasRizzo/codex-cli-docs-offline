/** The downloadable project calls OpenAI directly with its own server-side key. */
export function createApiFetch(_bindings: unknown, directFetch: typeof fetch = fetch): typeof fetch {
  return directFetch;
}
