import {
  INITIAL_CASH, POSITION_LIMIT, SYMBOLS,
  type AssetSpec, type DecisionInput, type Execution,
  type MarketState, type NewsResult, type Portfolio, type Scenario, type Strategy, type TradeDecision,
} from "./types.ts";

export const ASSETS: AssetSpec[] = [
  { symbol: "ARC", name: "Arc Works", sector: "Industrial design", initialPrice: 84.2, color: "#83a8ff" },
  { symbol: "BLOOM", name: "Bloom Foods", sector: "Food systems", initialPrice: 46.8, color: "#f19fcb" },
  { symbol: "CIRR", name: "Cirrus Cloud", sector: "Cloud software", initialPrice: 128.4, color: "#a5a2ff" },
  { symbol: "DRFT", name: "Drift Mobility", sector: "Transport", initialPrice: 62.5, color: "#f4bb81" },
  { symbol: "EMBER", name: "Ember Materials", sector: "Materials", initialPrice: 35.6, color: "#ee8a7e" },
  { symbol: "VOLT", name: "Volt Storage", sector: "Energy storage", initialPrice: 97.3, color: "#9dce8b" },
];

export const SCENARIOS: { id: Scenario; name: string; description: string }[] = [
  { id: "opening", name: "Opening bell", description: "A mixed market finding its direction." },
  { id: "rally", name: "Risk-on rally", description: "Broad momentum, with occasional pullbacks." },
  { id: "turbulent", name: "Choppy waters", description: "Sharp reversals and shifting sector leaders." },
];

export const STRATEGIES: { id: Strategy; name: string; description: string }[] = [
  { id: "balanced", name: "Balanced", description: "Spread exposure and weigh momentum against risk." },
  { id: "momentum", name: "Momentum", description: "Follow strength, then trim when the trend fades." },
  { id: "defensive", name: "Defensive", description: "Favor smaller positions and keep more cash." },
];

const MAX_HISTORY = 180;
const MAX_NEWS = 8;
const MAX_QUOTE_AGE = 6;
const MAX_SLIPPAGE = .03;
const EPSILON = 1e-8;
const cents = (value: number) => Math.round((value + Number.EPSILON) * 100);
const money = (value: number) => cents(value) / 100;
const rounded = (value: number) => Math.round(value * 1_000) / 1_000;

// Stateless seeded noise keeps the market reproducible, including after pause.
function noise(seed: number, tick: number, channel: number): number {
  let value = (seed ^ Math.imul(tick, 0x9e3779b1) ^ Math.imul(channel, 0x85ebca6b)) >>> 0;
  value = Math.imul(value ^ (value >>> 16), 0x7feb352d);
  value = Math.imul(value ^ (value >>> 15), 0x846ca68b);
  return ((value ^ (value >>> 16)) >>> 0) / 4_294_967_296;
}

function movement(seed: number, tick: number, index: number, scenario: Scenario): number {
  const common = noise(seed, tick, 101) + noise(seed, tick, 102) - 1;
  const individual = noise(seed, tick, index + 1) + noise(seed, tick, index + 11) - 1;
  const rotation = Math.sin(tick / 13 + index * 1.3);
  if (scenario === "rally") return .00048 + common * .0014 + individual * .0012 + rotation * .0003;
  if (scenario === "turbulent") return common * .0032 + individual * .0038 + rotation * .001;
  return common * .0012 + individual * .0015 + rotation * .00035;
}

export function createMarket(seed: number, scenario: Scenario): MarketState {
  const normalizedSeed = seed >>> 0;
  return {
    seed: normalizedSeed, scenario, tick: 0, newsVersion: 0,
    news: [{ id: "news-0", tick: 0, symbol: null, title: "Fictional market open. All prices and headlines are simulated." }],
    assets: ASSETS.map((asset, index) => {
      let price = asset.initialPrice;
      const history = Array.from({ length: 40 }, (_, point) => {
        const tick = point - 39;
        price *= 1 + movement(normalizedSeed, tick, index, scenario);
        return { tick, price };
      });
      const scale = asset.initialPrice / history[history.length - 1].price;
      return {
        symbol: asset.symbol, open: asset.initialPrice, price: asset.initialPrice,
        history: history.map(point => ({ tick: point.tick, price: money(point.price * scale) })),
        volume: 8_000 + Math.floor(noise(normalizedSeed, 0, index + 301) * 12_000),
      };
    }),
  };
}

export function advanceMarket(market: MarketState): MarketState {
  const tick = market.tick + 1;
  return {
    ...market, tick,
    assets: market.assets.map((asset, index) => {
      const change = movement(market.seed, tick, index, market.scenario);
      const price = Math.max(.01, Math.min(1_000_000, money(asset.price * (1 + change))));
      return {
        ...asset, price,
        history: [...asset.history, { tick, price }].slice(-MAX_HISTORY),
        volume: asset.volume + 120 + Math.floor(noise(market.seed, tick, index + 401) * 1_200 * (1 + Math.abs(change) * 50)),
      };
    }),
  };
}

/** A completed, validated Responses story is the only source of a news shock. */
export function applyNews(market: MarketState, result: NewsResult): MarketState {
  if (!result || !Number.isSafeInteger(result.revision) || result.revision < 0 || result.revision > 10_000_000
    || !SYMBOLS.includes(result.symbol) || !Number.isFinite(result.impactPct) || Math.abs(result.impactPct) > 3
    || typeof result.responseId !== "string" || result.responseId.length > 200 || !/^resp_[A-Za-z0-9_-]+$/.test(result.responseId)
    || typeof result.headline !== "string" || !result.headline.trim() || result.headline.length > 180
    || typeof result.body !== "string" || !result.body.trim() || result.body.length > 2_000) return market;
  const articles = market.news.flatMap(item => item.article ? [item.article] : []);
  if (articles.some(article => article.responseId === result.responseId)
    || result.revision <= articles.reduce((latest, article) => Math.max(latest, article.revision), -1)) return market;
  const target = market.assets.find(asset => asset.symbol === result.symbol);
  if (!target || !Number.isFinite(target.price) || target.price <= 0) return market;
  const priceAfter = Math.max(.01, Math.min(1_000_000, money(target.price * (1 + result.impactPct / 100))));
  const id = `news-${result.responseId}`;
  const article = { ...result, id, tick: market.tick, priceBefore: target.price, priceAfter };
  return {
    ...market,
    newsVersion: market.newsVersion + 1,
    news: [{ id, tick: market.tick, title: result.headline, symbol: result.symbol, article }, ...market.news].slice(0, MAX_NEWS),
    assets: market.assets.map(asset => asset.symbol !== result.symbol ? asset : {
      ...asset, price: priceAfter,
      // Publication is instantaneous; it updates this tick instead of inventing time.
      history: [...asset.history.filter(point => point.tick !== market.tick), { tick: market.tick, price: priceAfter }].slice(-MAX_HISTORY),
    }),
  };
}

export function createPortfolio(): Portfolio {
  return {
    cash: INITIAL_CASH, realizedPnl: 0, trades: 0,
    positions: Object.fromEntries(SYMBOLS.map(symbol => [symbol, { quantity: 0, averageCost: 0 }])) as Portfolio["positions"],
  };
}

export function portfolioValue(portfolio: Portfolio, market: MarketState): number {
  return money(portfolio.cash + market.assets.reduce((total, asset) => total + portfolio.positions[asset.symbol].quantity * asset.price, 0));
}

export function portfolioPnl(portfolio: Portfolio, market: MarketState): { amount: number; percent: number } {
  const amount = money(portfolioValue(portfolio, market) - INITIAL_CASH);
  return { amount, percent: amount / INITIAL_CASH * 100 };
}

export function benchmarkReturn(market: MarketState): number {
  // A buy-and-hold, equal-dollar basket at the opening quotes, with fractional units.
  return market.assets.reduce((total, asset) => total + (asset.price / asset.open - 1), 0) / market.assets.length * 100;
}

export function buildDecisionInput(market: MarketState, portfolio: Portfolio, strategy: Strategy, revision: number): DecisionInput {
  return {
    revision, tick: market.tick, strategy, scenario: market.scenario, cash: portfolio.cash,
    newsVersion: market.newsVersion,
    news: market.news.flatMap(item => item.article ? [{ headline: item.article.headline, symbol: item.article.symbol, impactPct: item.article.impactPct }] : []).slice(0, 3),
    positions: Object.fromEntries(SYMBOLS.map(symbol => [symbol, portfolio.positions[symbol].quantity])) as DecisionInput["positions"],
    assets: market.assets.map(asset => {
      const recent = asset.history.slice(-12);
      const returns = recent.slice(1).map((point, index) => (point.price / recent[index].price - 1) * 100);
      const meanReturn = returns.reduce((sum, value) => sum + value, 0) / Math.max(1, returns.length);
      const variance = returns.reduce((sum, value) => sum + (value - meanReturn) ** 2, 0) / Math.max(1, returns.length);
      const momentumBase = recent[Math.max(0, recent.length - 7)]?.price ?? asset.price;
      return {
        symbol: asset.symbol, price: asset.price, open: asset.open,
        mean: money(recent.reduce((sum, point) => sum + point.price, 0) / Math.max(1, recent.length)),
        momentumPct: rounded((asset.price / momentumBase - 1) * 100),
        volatilityPct: rounded(Math.sqrt(variance)),
      };
    }),
  };
}

export function executeDecision(portfolio: Portfolio, market: MarketState, decision: TradeDecision, strategy: Strategy, observed: DecisionInput): Execution {
  const skip = (detail: string): Execution => ({ portfolio, state: "skipped", detail });
  if (decision.refused) return skip("The model declined this decision; no trade was placed.");
  if (!Number.isSafeInteger(decision.revision) || decision.revision < 0 || decision.revision !== observed.revision) return skip("The decision belongs to an earlier market view.");
  if ((observed.newsVersion ?? 0) !== market.newsVersion) return skip("A new story arrived after this decision's snapshot. No trade was placed.");
  if (observed.strategy !== strategy || observed.scenario !== market.scenario) return skip("The strategy or market changed before this decision arrived.");
  if (!Number.isSafeInteger(observed.tick) || observed.tick < 0 || market.tick < observed.tick || market.tick - observed.tick > MAX_QUOTE_AGE) return skip("The quote is more than six ticks old or belongs to another run.");
  if (Math.abs(portfolio.cash - observed.cash) > EPSILON || !Number.isFinite(observed.cash) || SYMBOLS.some(symbol => portfolio.positions[symbol].quantity !== observed.positions?.[symbol])) return skip("The portfolio changed while this decision was pending.");
  const action = decision.action;
  if (!action || !["buy", "sell", "hold"].includes(action.kind)) return skip("The decision did not contain a supported trade.");
  if (action.kind === "hold") {
    if (action.quantity !== 0 || action.symbol !== null) return skip("A hold decision cannot contain an order.");
    return { portfolio, state: "held", detail: "Held the portfolio unchanged." };
  }
  if (!Number.isSafeInteger(action.quantity) || action.quantity <= 0 || !action.symbol || !SYMBOLS.includes(action.symbol)) return skip("The order needs a valid symbol and a positive whole-share quantity.");
  const symbol = action.symbol;
  const asset = market.assets.find(item => item.symbol === symbol);
  const quote = Array.isArray(observed.assets) ? observed.assets.find(item => item.symbol === symbol) : undefined;
  if (!asset || !quote || !Number.isFinite(asset.price) || asset.price <= 0 || !Number.isFinite(quote.price) || quote.price <= 0 || quote.open !== asset.open) return skip("A valid current and observed quote are required.");
  if (Math.abs(asset.price / quote.price - 1) > MAX_SLIPPAGE + EPSILON) return skip("The price moved more than 3% since the decision's quote.");
  const position = portfolio.positions[symbol];
  const orderCents = cents(asset.price) * action.quantity;
  if (!Number.isSafeInteger(orderCents)) return skip("The order quantity is outside the supported range.");
  const total = orderCents / 100;
  if (action.kind === "buy") {
    if (orderCents > cents(portfolio.cash)) return skip("The purchase exceeds the available cash.");
    const value = portfolioValue(portfolio, market);
    const limit = POSITION_LIMIT[strategy];
    if (!Number.isFinite(value) || value <= 0 || !limit || (position.quantity + action.quantity) * asset.price > value * limit + EPSILON) return skip(`The purchase exceeds the ${Math.round(limit * 100)}% position limit.`);
    const quantity = position.quantity + action.quantity;
    return {
      state: "executed", price: asset.price,
      detail: `Bought ${action.quantity} ${symbol} at $${asset.price.toFixed(2)}.`,
      portfolio: {
        ...portfolio, cash: (cents(portfolio.cash) - orderCents) / 100, trades: portfolio.trades + 1,
        positions: { ...portfolio.positions, [symbol]: { quantity, averageCost: (position.quantity * position.averageCost + total) / quantity } },
      },
    };
  }
  if (action.quantity > position.quantity) return skip("The sale exceeds the shares held; short selling is disabled.");
  const quantity = position.quantity - action.quantity;
  return {
    state: "executed", price: asset.price,
    detail: `Sold ${action.quantity} ${symbol} at $${asset.price.toFixed(2)}.`,
    portfolio: {
      ...portfolio, cash: (cents(portfolio.cash) + orderCents) / 100,
      realizedPnl: portfolio.realizedPnl + total - position.averageCost * action.quantity, trades: portfolio.trades + 1,
      positions: { ...portfolio.positions, [symbol]: { quantity, averageCost: quantity === 0 ? 0 : position.averageCost } },
    },
  };
}
