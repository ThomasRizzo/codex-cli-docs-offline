import { RequestCooldown, NewsRequestError } from "./request-cooldown.ts";
import { MAX_NEWS_REQUESTS, NEWS_INTERVAL_MS, RUN_LIMIT_MS, type NewsDraft, type NewsInput, type NewsResult } from "./types.ts";

/** Kept across pauses so resuming cannot bypass the news interval or request cap. */
export class NewsSchedule {
  attempts = 0;
  nextAt = 0;

  claim(elapsedMs: number): number | null {
    if (!Number.isFinite(elapsedMs) || elapsedMs < this.nextAt || elapsedMs >= RUN_LIMIT_MS || this.attempts >= MAX_NEWS_REQUESTS) return null;
    this.nextAt = elapsedMs + NEWS_INTERVAL_MS;
    return ++this.attempts;
  }
}

type Callbacks = {
  elapsed: () => number;
  observe: (sequence: number) => NewsInput | null;
  submit: (input: NewsInput, signal: AbortSignal, onDraft: (draft: NewsDraft) => void) => Promise<NewsResult>;
  started: () => void;
  draft: (draft: NewsDraft) => void;
  completed: (result: NewsResult) => void;
  failed: (error: Error) => void;
  stopped: () => void;
};

/** Stream at most one article at a time; stopped streams can never publish. */
export class NewsLoop {
  private closed = false;
  private pending: AbortController | null = null;
  private schedule: NewsSchedule;
  private callbacks: Callbacks;
  private cooldown: RequestCooldown;

  constructor(schedule: NewsSchedule, callbacks: Callbacks, cooldown = new RequestCooldown()) {
    this.schedule = schedule; this.callbacks = callbacks; this.cooldown = cooldown;
  }

  tick(): void {
    if (this.closed || this.pending || this.cooldown.active) return;
    const sequence = this.schedule.claim(this.callbacks.elapsed());
    if (sequence === null) return;
    const input = this.callbacks.observe(sequence);
    if (!input) return;
    const controller = new AbortController();
    this.pending = controller;
    this.callbacks.started();
    void this.run(input, controller);
  }

  private async run(input: NewsInput, controller: AbortController): Promise<void> {
    const active = () => !this.closed && !controller.signal.aborted;
    try {
      const result = await this.callbacks.submit(input, controller.signal, draft => {
        if (active()) this.callbacks.draft(draft);
      });
      if (active()) this.callbacks.completed(result);
    } catch (error) {
      if (active()) {
        const problem = error instanceof Error ? error : new Error("The article was interrupted. Prices are unchanged.");
        if (problem instanceof NewsRequestError) this.cooldown.defer(problem.retryAfterMs, problem.message);
        this.callbacks.failed(problem);
      }
    } finally {
      if (this.pending === controller) this.pending = null;
    }
  }

  stop(): void {
    if (this.closed) return;
    this.closed = true;
    if (this.pending) {
      this.pending.abort(); this.pending = null;
      this.callbacks.stopped();
    }
  }
}
