// Per-IP request allowances. Windows reset at UTC minute/day boundaries.
// Keep simulation allowances large enough for a complete normal run.
export const IP_LIMITS = {
  "decisions": {
    "minute": 30,
    "day": 240
  },
  "news": {
    "minute": 6,
    "day": 24
  }
} as const;
