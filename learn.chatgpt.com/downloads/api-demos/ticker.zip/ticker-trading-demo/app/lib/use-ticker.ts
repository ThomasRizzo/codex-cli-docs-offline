"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { advanceMarket, applyNews, benchmarkReturn, buildDecisionInput, createMarket, createPortfolio, executeDecision, portfolioPnl, portfolioValue } from "./market";
import { tradeDecisionSchema } from "./trading-contract";
import { ActiveRunBudget } from "./run-budget";
import { TradingDecisionLoop, TradingRequestError } from "./trading-loop";
import { useSoundEffects } from "./use-sound-effects";
import { requestNews } from "./news-client";
import { RequestCooldown, retryAfterMs } from "./request-cooldown";
import { NewsLoop, NewsSchedule } from "./news-loop";
import { RUN_LIMIT_MS, SYMBOLS, type AppliedNews, type NewsDraft, type DecisionEvent, type DecisionInput, type MarketState, type Portfolio, type RunStatus, type Scenario, type Strategy, type Symbol, type TradeDecision } from "./types";

async function requestDecision(input: DecisionInput, signal: AbortSignal): Promise<TradeDecision> {
  const deadline = AbortSignal.any([signal, AbortSignal.timeout(10_000)]);
  const response = await fetch("/api/decision", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input), signal: deadline,
  });
  const reader = response.body?.getReader();
  const decoder = new TextDecoder();
  let text = "", bytes = 0;
  if (reader) {
    try {
      while (true) {
        deadline.throwIfAborted();
        const { done, value } = await reader.read();
        if (done) break;
        bytes += value.byteLength;
        if (bytes > 16_384) throw new TradingRequestError("The decision receipt was too large.");
        text += decoder.decode(value, { stream: true });
      }
      text += decoder.decode();
    } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
  }
  let value: unknown;
  try { value = JSON.parse(text); }
  catch { throw new TradingRequestError("The decision receipt was interrupted. Retrying shortly."); }
  if (!response.ok) {
    const message = value && typeof value === "object" && "error" in value && typeof value.error === "string"
      ? value.error.slice(0, 500) : "Ticker could not get a decision. Retrying shortly.";
    throw new TradingRequestError(message, retryAfterMs(response.headers.get("Retry-After")), [400, 401, 403, 503].includes(response.status));
  }
  const parsed = tradeDecisionSchema.safeParse(value);
  if (!parsed.success || parsed.data.revision !== input.revision) throw new TradingRequestError("The decision did not match this market snapshot.");
  return parsed.data;
}

export function useTicker() {
  const { soundEnabled, toggleSound, playSound, cancelSounds } = useSoundEffects();
  const [market, setMarket] = useState(() => createMarket(42, "opening"));
  const [portfolio, setPortfolio] = useState(createPortfolio);
  const marketRef = useRef<MarketState>(market), portfolioRef = useRef<Portfolio>(portfolio);
  const [strategy, updateStrategy] = useState<Strategy>("balanced");
  const [scenario, updateScenario] = useState<Scenario>("opening");
  const [selectedSymbol, setSelectedSymbol] = useState<Symbol>("ARC");
  const [status, setStatus] = useState<RunStatus>("ready");
  const [elapsedMs, setElapsedMs] = useState(0);
  const [events, setEvents] = useState<DecisionEvent[]>([]);
  const [requestCount, setRequestCount] = useState(0);
  const [lastLatencyMs, setLastLatencyMs] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [newsBusy, setNewsBusy] = useState(false);
  const [newsDraft, setNewsDraft] = useState<NewsDraft | null>(null);
  const [newsError, setNewsError] = useState<string | null>(null);
  const [newsRequestCount, setNewsRequestCount] = useState(0);
  const [generation, setGeneration] = useState(0);
  const budget = useRef<ActiveRunBudget | null>(null);
  if (!budget.current) budget.current = new ActiveRunBudget(RUN_LIMIT_MS);
  const loopRef = useRef<TradingDecisionLoop | null>(null);
  const newsLoopRef = useRef<NewsLoop | null>(null);
  const newsSchedule = useRef(new NewsSchedule());
  const decisionCooldown = useRef(new RequestCooldown());
  const newsCooldown = useRef(new RequestCooldown());
  const newsRevision = useRef(0);
  const runToken = useRef(0), sequence = useRef(0), revision = useRef(0);
  const updateEvent = useCallback((id: number, patch: Partial<DecisionEvent>) => {
    setEvents(items => items.map(item => item.id === id ? { ...item, ...patch } : item));
  }, []);

  useEffect(() => {
    if (status !== "running") return;
    const clock = budget.current!;
    if (document.hidden || !clock.start()) { setStatus(clock.expired ? "complete" : "paused"); return; }
    const token = ++runToken.current;
    let ended = false;
    let lastStep = performance.now(), lastSecond = -1;
    const finish = () => {
      if (ended || runToken.current !== token || !clock.expired) return;
      ended = true;
      clock.pause(); loopRef.current?.stop(); newsLoopRef.current?.stop(); cancelSounds();
      setElapsedMs(RUN_LIMIT_MS); setStatus("complete"); setBusy(false);
      playSound("complete");
    };
    const active = () => {
      if (ended || runToken.current !== token || !clock.running) return false;
      if (clock.expired) { finish(); return false; }
      return true;
    };
    const newsLoop = new NewsLoop(newsSchedule.current, {
      elapsed: () => clock.elapsedMs,
      observe: sequence => active() ? {
        revision: ++newsRevision.current, sequence, scenario,
        target: SYMBOLS[(sequence - 1) % SYMBOLS.length],
        assets: marketRef.current.assets.map(({ symbol, price, open }) => ({ symbol, price, open })),
        recentHeadlines: marketRef.current.news.filter(item => item.article).map(item => item.title).slice(0, 6),
      } : null,
      submit: requestNews,
      started: () => { setNewsBusy(true); setNewsDraft({ headline: "", body: "" }); setNewsError(null); setNewsRequestCount(count => count + 1); },
      draft: draft => { if (active()) setNewsDraft(draft); },
      completed: result => {
        if (!active()) return;
        const next = applyNews(marketRef.current, result);
        if (next === marketRef.current) setNewsError("This article could not be applied. Prices are unchanged.");
        else { marketRef.current = next; setMarket(next); setNewsError(null); playSound("plan"); }
        setNewsDraft(null); setNewsBusy(false);
      },
      failed: problem => { if (active()) { setNewsError(problem.message); setNewsDraft(null); setNewsBusy(false); } },
      stopped: () => { setNewsDraft(null); setNewsBusy(false); },
    }, newsCooldown.current);
    newsLoopRef.current = newsLoop;
    const loop = new TradingDecisionLoop({
      observe: () => active() ? buildDecisionInput(marketRef.current, portfolioRef.current, strategy, ++revision.current) : null,
      submit: (input, signal) => active() ? requestDecision(input, signal) : Promise.reject(new DOMException("Run stopped", "AbortError")),
      nextId: () => ++sequence.current,
      started: id => {
        setBusy(true); setRequestCount(count => count + 1);
        setEvents(items => [{ id, startedAt: Date.now(), state: "pending" as const, detail: "Choosing the next move…" }, ...items].slice(0, 64));
      },
      completed: (id, observed, decision) => {
        if (!active()) return;
        const outcome = executeDecision(portfolioRef.current, marketRef.current, decision, strategy, observed);
        portfolioRef.current = outcome.portfolio; setPortfolio(outcome.portfolio);
        updateEvent(id, { completedAt: Date.now(), state: outcome.state, detail: `${outcome.detail} ${decision.context}`.trim(), action: decision.action, receipt: decision.receipt, price: outcome.price });
        setLastLatencyMs(decision.receipt.durationMs); setError(null); setBusy(false);
        if (outcome.state === "executed") playSound("phase");
      },
      failed: (id, problem) => {
        if (!active()) return;
        updateEvent(id, { state: "failed", completedAt: Date.now(), detail: problem.message });
        setError(problem.message); setBusy(false);
      },
      stopped: id => {
        setEvents(items => items.map(item => item.id === id && item.state === "pending" ? { ...item, state: "cancelled" as const, completedAt: Date.now(), detail: "Request stopped. No trade applied." } : item));
        setBusy(false);
      },
      backoff: fatal => {
        if (fatal && active()) { clock.pause(); newsLoop.stop(); setElapsedMs(clock.elapsedMs); setStatus("paused"); cancelSounds(); }
      },
    }, () => performance.now(), decisionCooldown.current);
    loopRef.current = loop;
    const tick = () => {
      if (!active() || document.hidden) return;
      const now = performance.now();
      if (now - lastStep >= 1_000) {
        // Never accelerate the market to catch up after a suspended browser.
        marketRef.current = advanceMarket(marketRef.current);
        setMarket(marketRef.current); lastStep = now;
      }
      const second = Math.floor(clock.elapsedMs / 1_000);
      if (second !== lastSecond) { lastSecond = second; setElapsedMs(clock.elapsedMs); }
      loop.tick();
      newsLoop.tick();
    };
    const pause = () => {
      if (ended) return;
      clock.pause(); loop.stop(); newsLoop.stop(); cancelSounds();
      setElapsedMs(clock.elapsedMs); setStatus(clock.expired ? "complete" : "paused");
    };
    const hide = () => { if (document.hidden) pause(); };
    document.addEventListener("visibilitychange", hide);
    window.addEventListener("pagehide", pause);
    tick();
    const scheduler = setInterval(tick, 100);
    const deadline = setTimeout(finish, clock.remainingMs);
    return () => {
      ended = true; clock.pause(); loop.stop(); newsLoop.stop();
      clearInterval(scheduler); clearTimeout(deadline);
      document.removeEventListener("visibilitychange", hide); window.removeEventListener("pagehide", pause);
      if (loopRef.current === loop) loopRef.current = null;
      if (newsLoopRef.current === newsLoop) newsLoopRef.current = null;
    };
  }, [status, strategy, scenario, generation, cancelSounds, playSound, updateEvent]);

  const resetTo = useCallback((nextScenario: Scenario, nextStrategy: Strategy) => {
    ++runToken.current; budget.current!.pause(); loopRef.current?.stop(); newsLoopRef.current?.stop();
    budget.current = new ActiveRunBudget(RUN_LIMIT_MS);
    newsSchedule.current = new NewsSchedule();
    marketRef.current = createMarket(42, nextScenario); portfolioRef.current = createPortfolio();
    setMarket(marketRef.current); setPortfolio(portfolioRef.current);
    updateScenario(nextScenario); updateStrategy(nextStrategy); setStatus("ready");
    setElapsedMs(0); setEvents([]); setRequestCount(0); setLastLatencyMs(null); setError(decisionCooldown.current.active ? decisionCooldown.current.message : null); setBusy(false);
    setNewsDraft(null); setNewsBusy(false); setNewsError(newsCooldown.current.active ? newsCooldown.current.message : null); setNewsRequestCount(0);
    setGeneration(value => value + 1); cancelSounds();
  }, [cancelSounds]);
  const toggleRun = useCallback(() => {
    cancelSounds(); playSound("tap");
    if (status === "running") {
      budget.current!.pause(); loopRef.current?.stop(); newsLoopRef.current?.stop();
      setElapsedMs(budget.current!.elapsedMs); setStatus(budget.current!.expired ? "complete" : "paused");
    } else {
      if (document.hidden) return;
      if (decisionCooldown.current.active) { setError(decisionCooldown.current.message); return; }
      if (status === "complete" || budget.current!.expired) resetTo(scenario, strategy);
      setError(null); setStatus("running");
    }
  }, [status, scenario, strategy, resetTo, cancelSounds, playSound]);
  const restart = useCallback(() => { resetTo(scenario, strategy); playSound("tap"); }, [resetTo, scenario, strategy, playSound]);
  const setScenario = useCallback((value: Scenario) => { if (status !== "running" && value !== scenario) resetTo(value, strategy); }, [status, scenario, strategy, resetTo]);
  const setStrategy = useCallback((value: Strategy) => { if (status !== "running" && value !== strategy) resetTo(scenario, value); }, [status, scenario, strategy, resetTo]);
  const articles = useMemo(() => market.news.flatMap(item => item.article ? [item.article] : []) as AppliedNews[], [market.news]);

  return {
    market, portfolio, selectedSymbol, setSelectedSymbol, strategy, setStrategy, scenario, setScenario,
    status, elapsedMs, remainingMs: Math.max(0, RUN_LIMIT_MS - elapsedMs), running: status === "running", busy,
    events, requestCount, error, lastLatencyMs, toggleRun, restart, soundEnabled, toggleSound,
    newsDraft, newsBusy, newsError, newsRequestCount,
    articles,
    equity: portfolioValue(portfolio, market), pnl: portfolioPnl(portfolio, market), benchmarkPct: benchmarkReturn(market), tradeCount: portfolio.trades,
  };
}
