import { z } from "zod";
import { createApiFetch } from "./openai-fetch.ts";

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) { super(message); this.status = status; }
}

export const privateHeaders = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };

export function guardRequest(request: Request): void {
  const url = new URL(request.url);
  if (request.headers.get("origin") !== url.origin || request.headers.get("sec-fetch-site") === "cross-site") {
    throw new ApiError(403, "Open Ticker in its own tab and try again.");
  }

}

export async function boundedText(body: ReadableStream<Uint8Array> | null, maxBytes: number, signal?: AbortSignal): Promise<string> {
  if (!body) return "";
  const reader = body.getReader();
  const decoder = new TextDecoder("utf-8", { fatal: true });
  const abort = () => { void reader.cancel().catch(() => undefined); };
  signal?.addEventListener("abort", abort, { once: true });
  let bytes = 0, text = "";
  try {
    while (true) {
      signal?.throwIfAborted();
      const chunk = await reader.read();
      signal?.throwIfAborted();
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > maxBytes) throw new ApiError(413, "This request is too large. Reset the simulation and try again.");
      text += decoder.decode(chunk.value, { stream: true });
    }
    return text + decoder.decode();
  } finally {
    signal?.removeEventListener("abort", abort);
    await reader.cancel().catch(() => undefined);
    reader.releaseLock();
  }
}

export async function parseBody<S extends z.ZodTypeAny>(request: Request, schema: S, signal: AbortSignal): Promise<z.output<S>> {
  if (request.headers.get("content-type")?.split(";")[0].trim().toLowerCase() !== "application/json") throw new ApiError(415, "Send this request as JSON.");
  if (Number(request.headers.get("content-length") ?? 0) > 16_384) throw new ApiError(413, "This request is too large. Reset the simulation and try again.");
  try {
    const raw = JSON.parse(await boundedText(request.body, 16_384, signal));
    const result = schema.safeParse(raw);
    if (!result.success) throw new ApiError(400, "The portfolio or market observations could not be read. Reset the simulation and try again.");
    return result.data;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    signal.throwIfAborted();
    throw new ApiError(400, "The request could not be read. Please try again.");
  }
}

export type OpenAIPath = "/decisions" | "/responses";
export type WorkerBindings = { OPENAI_API_KEY?: string };

async function workerEnvironment(): Promise<WorkerBindings | null> {
  try { const { env } = await import("cloudflare:workers"); return env as unknown as WorkerBindings; }
  catch { return null; }
}

export async function openAIResponse(
  path: OpenAIPath, payload: unknown, signal: AbortSignal,
  dependencies: { key?: string; fetch?: typeof fetch; bindings?: WorkerBindings | null } = {},
): Promise<Response> {
  signal.throwIfAborted();
  if (path !== "/decisions" && path !== "/responses") throw new ApiError(500, "Unsupported API operation.");
  const bindings = dependencies.bindings === undefined ? await workerEnvironment() : dependencies.bindings;
  const key = dependencies.key ?? bindings?.OPENAI_API_KEY ?? (process.env.NODE_ENV === "development" ? process.env.OPENAI_API_KEY : undefined);
  if (!key) throw new ApiError(503, "Ticker needs its API key connected. Ask the site owner to check its settings.");
  let send: typeof fetch;
  try { send = createApiFetch(bindings, dependencies.fetch); }
  catch { throw new ApiError(503, "Ticker’s API connection is not configured yet."); }
  try {
    const response = await send(`https://api.openai.com/v1${path}`, {
      method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` }, body: JSON.stringify(payload), signal, redirect: "manual",
    });
    if (response.status >= 300 && response.status < 400) {
      await response.body?.cancel().catch(() => undefined);
      throw new ApiError(502, "Ticker could not reach OpenAI. Please try again.");
    }
    if (!response.ok) {
      const requestId = response.headers.get("x-request-id");
      console.error(JSON.stringify({ event: "openai_request_failed", status: response.status, requestId: requestId && /^req_[A-Za-z0-9]{1,100}$/.test(requestId) ? requestId : undefined }));
      await response.body?.cancel().catch(() => undefined);
      if (response.status === 429) throw new ApiError(429, "Ticker has reached its API limit. Try again shortly, or ask the site owner to check the project quota.");
      if ([401, 403, 404].includes(response.status)) throw new ApiError(503, "Ticker cannot access its OpenAI model. Ask the site owner to check the API key and project permissions.");
      throw new ApiError(502, path === "/responses" ? "Ticker could not finish the news article. No news impact was applied." : "Ticker could not obtain a decision. Your portfolio is unchanged; try again.");
    }
    return response;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    signal.throwIfAborted();
    throw new ApiError(502, "Ticker could not reach OpenAI. Your portfolio is unchanged; try again.");
  }
}

export function publicError(error: unknown): { status: number; message: string } {
  if (error instanceof ApiError) return { status: error.status, message: error.message };
  if (error instanceof Error && error.name === "TimeoutError") return { status: 504, message: "The decision took too long. Your portfolio is unchanged; try again." };
  if (error instanceof Error && error.name === "AbortError") return { status: 408, message: "The decision request was stopped. Your portfolio is unchanged." };
  return { status: 502, message: "Ticker could not obtain a valid decision. Your portfolio is unchanged; try again." };
}

export function errorResponse(error: unknown): Response {
  const { status, message } = publicError(error);
  return Response.json({ error: message }, { status, headers: { ...privateHeaders, ...(status === 429 ? { "Retry-After": "60" } : {}) } });
}
