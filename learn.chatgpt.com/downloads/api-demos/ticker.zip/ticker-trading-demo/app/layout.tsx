import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Ticker — A paper-trading playground",
  description: "A fictional market. A real decision engine. Watch the OpenAI Decisions API manage a paper portfolio in real time.",
  icons: { icon: "/ticker-icon.svg", shortcut: "/ticker-icon.svg" },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><head><link rel="preload" href="/fonts/InterVariable.woff2" as="font" type="font/woff2" crossOrigin="anonymous" /></head><body className="antialiased">{children}</body></html>;
}
