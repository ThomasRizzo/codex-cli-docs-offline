import { test } from "node:test";
import assert from "node:assert/strict";
import { NewsLoop, NewsSchedule } from "../app/lib/news-loop.ts";
import { ActiveRunBudget } from "../app/lib/run-budget.ts";
import type { NewsDraft, NewsInput, NewsResult } from "../app/lib/types.ts";
import { NewsRequestError, RequestCooldown } from "../app/lib/request-cooldown.ts";
import { IP_LIMITS } from "../app/lib/rate-limit-policy.ts";

const flush = () => new Promise<void>(resolve => setImmediate(resolve));

test("news uses active time, preserves cadence across pauses, and caps attempts including failures", async () => {
  let time = 0, calls = 0;
  const budget = new ActiveRunBudget(120_000, () => time);
  const schedule = new NewsSchedule();
  const makeLoop = () => new NewsLoop(schedule, {
    elapsed: () => budget.elapsedMs,
    observe: sequence => ({ revision: sequence, sequence } as NewsInput),
    submit: async () => { calls++; throw new Error("Unavailable"); },
    started() {}, draft() {}, completed() { assert.fail("Unexpected publication"); }, failed() {}, stopped() {},
  });
  budget.start(); let loop = makeLoop(); loop.tick(); await flush();
  time = 5_000; budget.pause(); loop.stop();
  time = 200_000; budget.start(); loop = makeLoop(); loop.tick(); await flush();
  assert.equal(calls, 1, "Resume does not immediately dispatch another article");
  time = 214_999; loop.tick(); assert.equal(calls, 1);
  time = 215_000; loop.tick(); await flush(); assert.equal(calls, 2);
  for (let index = 0; index < 4; index++) { time += 20_000; loop.tick(); await flush(); }
  assert.equal(calls, 6);
  time += 20_000; loop.tick(); await flush(); assert.equal(budget.expired, true); assert.equal(calls, 6);
  loop.stop();
});

test("slow news never overlaps; stop aborts and discards both late drafts and final stories", async () => {
  let elapsed = 0, calls = 0, drafts = 0, publications = 0, stopped = 0;
  let deliver!: (value: NewsResult) => void;
  let onDraft!: (value: NewsDraft) => void;
  let signal!: AbortSignal;
  const loop = new NewsLoop(new NewsSchedule(), {
    elapsed: () => elapsed, observe: sequence => ({ sequence } as NewsInput),
    submit: async (_, value, callback) => {
      calls++; signal = value; onDraft = callback;
      return await new Promise(resolve => { deliver = resolve; });
    },
    started() {}, draft() { drafts++; }, completed() { publications++; },
    failed() { assert.fail("Stopped news must not show an error"); }, stopped() { stopped++; },
  });
  loop.tick(); onDraft({ headline: "An incoming story", body: "" });
  elapsed = 60_000; loop.tick(); assert.equal(calls, 1);
  loop.stop(); assert.equal(signal.aborted, true); assert.equal(stopped, 1);
  onDraft({ headline: "Too late", body: "Must not enter the feed" });
  deliver({ revision: 1 } as NewsResult); await flush(); loop.tick();
  assert.equal(drafts, 1); assert.equal(publications, 0); assert.equal(calls, 1);
});

test("news does not catch up missed slots in a burst or dispatch after the run budget", async () => {
  let elapsed = 0, calls = 0, publications = 0;
  const loop = new NewsLoop(new NewsSchedule(), {
    elapsed: () => elapsed, observe: sequence => ({ sequence } as NewsInput),
    submit: async () => { calls++; return { revision: calls } as NewsResult; },
    started() {}, draft() {}, completed() { publications++; }, failed() {}, stopped() {},
  });
  loop.tick(); await flush(); elapsed = 95_000; loop.tick(); await flush();
  loop.tick(); await flush(); assert.equal(calls, 2);
  elapsed = 115_000; loop.tick(); await flush(); assert.equal(calls, 3); assert.equal(publications, 3);
  elapsed = 120_000; loop.tick(); elapsed = 1_000_000; loop.tick(); assert.equal(calls, 3);
  loop.stop();
});

test("a fresh explicit run gets a new news allowance while invalid clocks never dispatch", () => {
  const old = new NewsSchedule();
  for (let index = 0; index < 6; index++) assert.equal(old.claim(index * 20_000), index + 1);
  assert.equal(old.claim(100_000), null);
  const fresh = new NewsSchedule();
  assert.equal(fresh.claim(-1), null); assert.equal(fresh.claim(NaN), null); assert.equal(fresh.claim(Infinity), null);
  assert.equal(fresh.claim(0), 1);
});

test("news honors a daily cooldown across pause and Run again without consuming new slots", async () => {
  let time = 0, elapsed = 0, calls = 0;
  const cooldown = new RequestCooldown(() => time);
  const sequences: number[] = [];
  const makeLoop = (schedule: NewsSchedule) => new NewsLoop(schedule, {
    elapsed: () => elapsed, observe: sequence => { sequences.push(sequence); return { sequence } as NewsInput; },
    submit: async () => { calls++; throw new NewsRequestError("Daily network limit reached", 86_400_000); },
    started() {}, draft() {}, completed: () => assert.fail("Unexpected publication"), failed() {}, stopped() {},
  }, cooldown);
  let loop = makeLoop(new NewsSchedule()); loop.tick(); await flush();
  assert.equal(cooldown.until, 86_400_000);
  elapsed = 20_000; time = 20_000; loop.tick(); assert.equal(calls, 1);
  loop.stop(); const freshSchedule = new NewsSchedule(); loop = makeLoop(freshSchedule); elapsed = 0;
  for (const now of [60_000, 120_000, 43_200_000, 86_399_999]) { time = now; loop.tick(); }
  assert.equal(calls, 1);
  time = 86_400_000; loop.tick(); await flush(); assert.equal(calls, 2);
  assert.deepEqual(sequences, [1, 1], "Waiting must not consume the next run's article allowance");
  loop.stop();
});

test("a full normal news run fits the IP allowance", async () => {
  let elapsed = 0, calls = 0;
  const minutes = new Map<number, number>();
  const loop = new NewsLoop(new NewsSchedule(), {
    elapsed: () => elapsed, observe: sequence => ({ sequence } as NewsInput),
    submit: async () => {
      calls++; const minute = Math.floor(elapsed / 60_000);
      minutes.set(minute, (minutes.get(minute) ?? 0) + 1); return { revision: calls } as NewsResult;
    }, started() {}, draft() {}, completed() {}, failed: () => assert.fail("Unexpected failure"), stopped() {},
  });
  for (; elapsed < 120_000; elapsed += 1_000) { loop.tick(); await flush(); }
  loop.stop(); assert.equal(calls, 6); assert.ok(calls <= IP_LIMITS.news.day);
  assert.ok([...minutes.values()].every(count => count <= IP_LIMITS.news.minute));
});
