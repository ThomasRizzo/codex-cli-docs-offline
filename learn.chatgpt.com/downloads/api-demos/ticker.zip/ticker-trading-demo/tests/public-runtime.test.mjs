import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { Log, LogLevel, Miniflare } from "miniflare";
import { providerConfiguration } from "./fixtures/provider.mjs";

test("anonymous native Worker requests use server credentials and never store generated news", { timeout: 30_000 }, async t => {
  const root = fileURLToPath(new URL("../", import.meta.url));
  const bundle = await build({
    stdin: { resolveDir: root, loader: "ts", contents: `
      import { POST as decision } from './app/api/decision/route';
      import { POST as news } from './app/api/news/route';
      export default { fetch(request) { return new URL(request.url).pathname.endsWith('/news') ? news(request) : decision(request); } };
    ` },
    bundle: true, format: "esm", platform: "neutral", target: "es2022",
    conditions: ["workerd", "worker", "browser"], external: ["cloudflare:workers", "node:net"],
    define: { "process.env.NODE_ENV": '"production"' }, write: false, logLevel: "silent",
  });
  const observed = [];
  const worker = new Miniflare({
    modules: true, script: bundle.outputFiles[0].text,
    compatibilityDate: "2026-05-15", compatibilityFlags: ["nodejs_compat"],
    host: "127.0.0.1", port: 0, cf: false, log: new Log(LogLevel.ERROR),
    d1Databases: ["DB"], bindings: { OPENAI_API_KEY: "test-only-provider-key" },
    ...providerConfiguration(async request => {
      const url = new URL(request.url), payload = await request.json();
      assert.equal(url.origin, "https://api.openai.com");
      assert.equal(request.headers.get("authorization"), "Bearer test-only-provider-key");
      observed.push(url.pathname);
      if (url.pathname === "/v1/decisions") return Response.json({ model: "gpt-6-luna", answers: [{ type: "choice", name: "trade", choice: "buy_ARC" }] });
      assert.equal(url.pathname, "/v1/responses");
      assert.equal(payload.store, false);
      assert.equal(payload.stream, true);
      const article = { symbol: "ARC", impactPct: 1.2, headline: "Arc Works expands a fictional pilot", body: "Arc Works has expanded a fictional production trial following encouraging early demand. The simulation's new order increases planned factory activity while leaving delivery timing uncertain. A second phase will test the design across several facilities before management commits further capacity. The development supports a modest positive adjustment in the paper market, although material availability could still delay the rollout. This invented update describes an operational change within Ticker's fictional company universe. It does not represent real corporate news or predict the value of any real security." };
      return new Response(`data: ${JSON.stringify({ type: "response.completed", response: { id: "resp_fixture_public", status: "completed", model: "gpt-6-luna", output: [{ type: "message", role: "assistant", content: [{ type: "output_text", text: JSON.stringify(article) }] }] } })}\n\n`, { headers: { "content-type": "text/event-stream" } });
    }),
  });
  t.after(() => worker.dispose()); await worker.ready;
  const db = await worker.getD1Database("DB");
  const sql = await readFile(new URL("../drizzle/0000_fantastic_wolf_cub.sql", import.meta.url), "utf8");
  for (const statement of sql.split("--> statement-breakpoint")) await db.prepare(statement).run();
  const symbols = ["ARC", "BLOOM", "CIRR", "DRFT", "EMBER", "VOLT"];
  const headers = { origin: "https://ticker.test", "content-type": "application/json", "cf-connecting-ip": "203.0.113.7" };
  const decision = await worker.dispatchFetch("https://ticker.test/api/decision", { method: "POST", headers, body: JSON.stringify({ revision: 1, tick: 1, strategy: "balanced", scenario: "opening", cash: 10000, positions: Object.fromEntries(symbols.map(symbol => [symbol, 0])), assets: symbols.map(symbol => ({ symbol, price: 100, open: 100, mean: 98, momentumPct: 1, volatilityPct: .5 })) }) });
  assert.equal(decision.status, 200, await decision.clone().text());
  assert.equal((await decision.json()).action.kind, "buy");
  const news = await worker.dispatchFetch("https://ticker.test/api/news", { method: "POST", headers, body: JSON.stringify({ revision: 1, sequence: 1, scenario: "opening", target: "ARC", assets: symbols.map(symbol => ({ symbol, price: 100, open: 100 })), recentHeadlines: [] }) });
  assert.equal(news.status, 200);
  const events = (await news.text()).split("\n\n").filter(Boolean).map(frame => JSON.parse(frame.slice(6)));
  assert.equal(events.at(-1).type, "complete");
  assert.equal(events.at(-1).result.symbol, "ARC");
  assert.deepEqual(observed, ["/v1/decisions", "/v1/responses"]);
});
