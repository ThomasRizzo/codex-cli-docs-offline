import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { Log, LogLevel, Miniflare } from "miniflare";

test("native Worker routes share durable IP quotas across anonymous visitors before upstream", { timeout: 30_000 }, async t => {
  const bundled = await build({
    absWorkingDir: fileURLToPath(new URL("../", import.meta.url)),
    entryPoints: ["tests/fixtures/rate-limit-worker.ts"], bundle: true, format: "esm", platform: "neutral", target: "es2022",
    conditions: ["workerd", "worker", "browser"], external: ["cloudflare:workers", "node:net"],
    define: { "process.env.NODE_ENV": '"production"' }, write: false, logLevel: "silent",
  });
  let outbound = 0;
  const worker = new Miniflare({
    modules: true, script: bundled.outputFiles[0].text, d1Databases: ["DB"],
    compatibilityDate: "2026-05-15", compatibilityFlags: ["nodejs_compat"],
    host: "127.0.0.1", port: 0, cf: false, log: new Log(LogLevel.ERROR),
    outboundService: async () => { outbound++; return new Response("No external requests", { status: 503 }); },
  });
  t.after(() => worker.dispose()); await worker.ready;
  const db = await worker.getD1Database("DB");
  const sql = await readFile(new URL("../drizzle/0000_fantastic_wolf_cub.sql", import.meta.url), "utf8");
  for (const statement of sql.split("--> statement-breakpoint")) await db.prepare(statement).run();
  const headers = {
    origin: "https://ticker.test", "content-type": "application/json", "cf-connecting-ip": "203.0.113.42",
  };
  for (const route of ["decision", "news"]) {
    await t.test(`${route}: daily exhaustion returns accurate HTTP 429, with no body parsing or upstream`, async () => {
      // An admitted but malformed body creates the real durable counter without making an API call.
      const admitted = await worker.dispatchFetch(`https://ticker.test/api/${route}`, { method: "POST", headers, body: "{}" });
      assert.equal(admitted.status, 400);
      await db.prepare("UPDATE demo_ip_rate_limits SET day_count = 240").run();
      const blocked = await worker.dispatchFetch(`https://ticker.test/api/${route}`, {
        method: "POST", headers: { ...headers, "x-demo-session": crypto.randomUUID() }, body: "malformed JSON",
      });
      assert.equal(blocked.status, 429); assert.equal(blocked.headers.get("x-fixture-upstream-calls"), "0");
      assert.equal(blocked.headers.get("Retry-After"), "43190"); assert.equal(blocked.headers.get("Cache-Control"), "no-store");
      assert.equal((await blocked.json()).code, "RATE_LIMIT_EXCEEDED");
    });
  }
  assert.equal(outbound, 0);
});
