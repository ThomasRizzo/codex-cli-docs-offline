import { env } from "cloudflare:workers";
import { handleDecisionRequest } from "../../app/api/decision/route";
import { handleNewsRequest } from "../../app/api/news/route";
import { enforceIpRateLimitWithDb } from "../../app/lib/ip-rate-limit";

let calls = 0;
export default {
  async fetch(incoming: Request): Promise<Response> {
    // Match Vinext's property-forwarding Request proxy in native Workerd.
    const request = new Proxy(incoming, {
      get(target, property) {
        const value = Reflect.get(target, property, target);
        return typeof value === "function" ? value.bind(target) : value;
      },
    });
    const handler = new URL(incoming.url).pathname === "/api/news" ? handleNewsRequest : handleDecisionRequest;
    const response = await handler(request, async () => {
      calls++; throw new Error("Upstream must not be reached in the blocked-request fixture.");
    }, (request, bucket, policy) => enforceIpRateLimitWithDb(env.DB, request, bucket, policy, Date.UTC(2026, 9, 19, 12, 0, 10)));
    response.headers.set("x-fixture-upstream-calls", String(calls));
    return response;
  },
};
