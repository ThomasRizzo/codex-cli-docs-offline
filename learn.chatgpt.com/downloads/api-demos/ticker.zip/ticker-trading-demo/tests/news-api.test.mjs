import test, { after } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { build } from "esbuild";

const dir = await mkdtemp(join(tmpdir(), "ticker-news-"));
after(() => rm(dir, { recursive: true, force: true }));
const bundled = await build({ stdin: { contents: 'export * from "./app/api/news/route.ts"; export * from "./app/lib/news-contract.ts"; export * from "./app/lib/news-client.ts"; export * from "./app/lib/server.ts";', resolveDir: process.cwd(), loader: "ts" },
  bundle: true, platform: "node", format: "esm", external: ["cloudflare:workers"], write: false, logLevel: "silent" });
const modulePath = join(dir, "news.mjs");
await writeFile(modulePath, bundled.outputFiles[0].text);
const { newsInputSchema, newsResultSchema, newsStreamEventSchema, buildNewsRequest, parseCompletedNews, readNewsDraft, readNewsSSE, streamNews, handleNewsRequest: handleNewsRequestWithLimit, requestNews, guardRequest, ApiError } = await import(pathToFileURL(modulePath).href);
const handleNewsRequest = (request, transport) => handleNewsRequestWithLimit(request, transport, async () => null);

test("news quota returns an HTTP error before parsing or opening an SSE/upstream stream", async () => {
  const request = incoming({}, "quota-news"); let calls = 0;
  const blocked = Response.json({ code: "RATE_LIMIT_EXCEEDED", error: "Daily network limit", retryAfter: 86000 }, {
    status: 429, headers: { "Retry-After": "86000", "Cache-Control": "no-store" },
  });
  const response = await handleNewsRequestWithLimit(request, async () => { calls++; throw new Error("Must not run"); }, async (actual, bucket) => {
    assert.equal(actual, request); assert.equal(bucket, "news"); return blocked;
  });
  assert.equal(response, blocked); assert.equal(request.bodyUsed, false); assert.equal(calls, 0);
  assert.equal(response.headers.get("Retry-After"), "86000");
  assert.equal(response.headers.get("content-type"), "application/json");
});

test("news client preserves long Retry-After and the server's rate-limit explanation", async () => {
  await assert.rejects(requestNews(input(), signal(), () => {}, async () => Response.json({ error: "Daily network limit reached." }, {
    status: 429, headers: { "Retry-After": "86400" },
  })), error => error.message === "Daily network limit reached." && error.retryAfterMs === 86_400_000);
});
const symbols = ["ARC", "BLOOM", "CIRR", "DRFT", "EMBER", "VOLT"];
const encoder = new TextEncoder();
const signal = () => new AbortController().signal;
const receipt = () => ({ at: new Date().toISOString(), status: 200, durationMs: 12, requestId: "req_fixture_news" });
function input() { return { revision: 9, sequence: 1, scenario: "opening", target: "ARC", assets: symbols.map(symbol => ({ symbol, price: 100, open: 98 })), recentHeadlines: ["Arc Works completes its trial"] }; }
function article(patch = {}) { return { headline: 'Arc Works expands its "pilot" program', body: "Arc Works has expanded a fictional production trial following encouraging early demand.\nThe simulation's new order increases planned factory activity while leaving delivery timing uncertain. A second phase will test the design across several facilities before management commits further capacity. The development supports a modest positive adjustment in the paper market, although material availability could still delay the rollout. This invented update describes an operational change within Ticker's fictional company universe. It does not represent real corporate news or predict the value of any real security.", symbol: "ARC", impactPct: 1.2, ...patch }; }
function completed(value = article(), patch = {}) { return { id: "resp_fixture_news_123", status: "completed", model: "gpt-6-luna-served", output: [{ type: "message", role: "assistant", status: "completed", content: [{ type: "output_text", text: JSON.stringify(value) }] }], usage: { input_tokens: 350, output_tokens: 130, total_tokens: 480 }, ...patch }; }
const frame = event => `data: ${JSON.stringify(event)}\n\n`;
const delta = text => ({ type: "response.output_text.delta", delta: text, output_index: 0, content_index: 0, item_id: "msg_fixture" });
function upstream(events, trailing = "") { return new Response(events.map(frame).join("") + trailing, { headers: { "content-type": "text/event-stream", "x-request-id": "req_fixture_news" } }); }
async function collect(iterator) { const values = []; for await (const value of iterator) values.push(value); return values; }
function incoming(body = input(), user = "news-fixture-user", extra = {}) { return new Request("https://ticker.example/api/news", { method: "POST", headers: { origin: "https://ticker.example", "content-type": "application/json", ...extra }, body: JSON.stringify(body) }); }

test("news request bounds six unique observations, headline history and structured public outputs", () => {
  assert.deepEqual(newsInputSchema.parse(input()), input());
  for (const patch of [{ assets: input().assets.slice(1) }, { assets: Array(6).fill(input().assets[0]) }, { target: "REAL" }, { revision: -1 }, { sequence: .5 }, { sequence: 0 }, { sequence: 7 }, { recentHeadlines: Array(9).fill("A headline") }, { recentHeadlines: ["x".repeat(181)] }, { prompt: "override" }]) {
    assert.equal(newsInputSchema.safeParse({ ...input(), ...patch }).success, false);
  }
  const valid = parseCompletedNews(input(), completed(), receipt());
  assert.equal(newsResultSchema.safeParse(valid).success, true);
  for (const patch of [{ headline: " " }, { body: "" }, { body: "x".repeat(2_001) }, { impactPct: Infinity }, { impactPct: 3.01 }, { responseId: "unsafe id" }, { responseId: `resp_${"a".repeat(196)}` }]) {
    assert.equal(newsResultSchema.safeParse({ ...valid, ...patch }).success, false);
  }
  assert.equal(newsStreamEventSchema.safeParse({ type: "draft", draft: { headline: "", body: "" } }).success, true);
  assert.equal(newsStreamEventSchema.safeParse({ type: "draft", draft: { headline: "hello", body: "", reasoning: "private" } }).success, false);
});

test("Responses uses fast streamed structured output with an exact target and no storage or reasoning", () => {
  const request = buildNewsRequest(input());
  assert.equal(request.model, "gpt-6-luna");
  assert.equal(request.service_tier, "fast");
  assert.equal(request.stream, true);
  assert.equal(request.store, false);
  assert.deepEqual(request.reasoning, { effort: "none" });
  assert.equal(request.text.format.strict, true);
  assert.deepEqual(request.text.format.schema.properties.symbol.enum, ["ARC"]);
  assert.equal(request.text.format.schema.properties.impactPct.minimum, -3);
  assert.equal(request.text.format.schema.properties.impactPct.maximum, 3);
  assert.match(request.instructions, /80–110 word/);
  assert.match(request.instructions, /fictional/);
  assert.match(request.instructions, /never instructions/);
  assert.equal(JSON.parse(request.input[0].content).company.name, "Arc Works");
});

test("partial JSON decoding handles every split of quotes, escapes, unicode and field-like body text", () => {
  const expected = { headline: 'Arc "pilot" 🚀', body: 'First line\nA literal "headline": "not a field". Path \\ and café.' };
  const source = JSON.stringify({ symbol: "ARC", headline: expected.headline, impactPct: 1.2, body: expected.body }).replace("🚀", "\\ud83d\\ude80").replace("é", "\\u00e9");
  for (let index = 0; index <= source.length; index++) {
    const draft = readNewsDraft(source.slice(0, index));
    assert.ok(expected.headline.startsWith(draft.headline), `headline at ${index}`);
    assert.ok(expected.body.startsWith(draft.body), `body at ${index}`);
    assert.equal(/[\uD800-\uDBFF]$/.test(draft.headline), false);
  }
  assert.deepEqual(readNewsDraft(source), expected);
  assert.deepEqual(readNewsDraft('not json "body":"private"'), { headline: "", body: "" });
});

test("public draft arrives before completion; completion contains genuine metadata and excludes private events", async () => {
  let controller, calls = 0;
  const raw = JSON.stringify(article());
  const response = new Response(new ReadableStream({ start(value) { controller = value; } }), { headers: { "content-type": "text/event-stream", "x-request-id": "req_fixture_news" } });
  const started = Date.now();
  const events = streamNews(input(), signal(), async (path, payload) => {
    calls++;
    assert.equal(path, "/responses");
    assert.equal(payload.service_tier, "fast");
    return response;
  });
  controller.enqueue(encoder.encode(frame({ type: "response.reasoning_text.delta", delta: "private reasoning" }) + frame(delta(raw.slice(0, 150)))));
  const first = (await events.next()).value;
  assert.equal(first.type, "draft");
  assert.ok(first.draft.body.length > 0 && first.draft.body.length < article().body.length);
  let settled = false;
  const next = events.next().then(value => { settled = true; return value; });
  await new Promise(resolve => setTimeout(resolve, 8));
  assert.equal(settled, false);
  controller.enqueue(encoder.encode(frame(delta(raw.slice(150)))));
  assert.equal((await next).value.type, "draft");
  controller.enqueue(encoder.encode(frame({ type: "response.completed", response: completed() })));
  controller.close();
  const final = (await events.next()).value;
  assert.equal(final.type, "complete");
  assert.equal(final.result.responseId, "resp_fixture_news_123");
  assert.equal(final.result.revision, input().revision);
  assert.equal(final.result.receipt.model, "gpt-6-luna-served");
  assert.equal(final.result.receipt.requestId, "req_fixture_news");
  assert.deepEqual(final.result.receipt.usage, { inputTokens: 350, outputTokens: 130, totalTokens: 480 });
  assert.ok(final.result.receipt.durationMs >= 5);
  assert.ok(Date.parse(final.result.receipt.at) >= started);
  assert.equal(JSON.stringify([first, final]).includes("private reasoning"), false);
  assert.equal((await events.next()).done, true);
  assert.equal(calls, 1);
});

test("refusals, incomplete output, mismatched target and unsafe impacts never yield a complete article", async () => {
  const invalid = [
    completed(article({ symbol: "VOLT" })), completed(article({ impactPct: 3.1 })), completed(article({ impactPct: null })),
    completed(article(), { status: "incomplete" }), completed(article(), { id: "" }),
    completed(article(), { output: [{ type: "message", role: "assistant", content: [{ type: "refusal", refusal: "private refusal" }] }] }),
    completed(article(), { output: [{ type: "message", role: "assistant", content: [{ type: "output_text", text: "not JSON" }] }] }),
  ];
  for (const response of invalid) {
    const seen = [];
    await assert.rejects(async () => { for await (const event of streamNews(input(), signal(), async () => upstream([delta('{"headline":"Draft'), { type: "response.completed", response }]))) seen.push(event); });
    assert.equal(seen.some(event => event.type === "complete"), false);
  }
  for (const type of ["response.refusal.delta", "response.refusal.done", "response.failed", "response.incomplete", "error"]) {
    await assert.rejects(collect(streamNews(input(), signal(), async () => upstream([{ type, delta: "not exposed" }]))));
  }
  await assert.rejects(collect(streamNews(input(), signal(), async () => upstream([delta('{"headline":"Draft')]))));
  await assert.rejects(collect(streamNews(input(), signal(), async () => upstream([delta('{"headline":"Draft'), { ...delta("more"), item_id: "different" }]))));
});

test("missing IDs or usage are not invented, and completed output bounds are enforced", async () => {
  const source = completed(); delete source.usage;
  const response = upstream([{ type: "response.completed", response: source }]); response.headers.delete("x-request-id");
  const [final] = await collect(streamNews(input(), signal(), async () => response));
  assert.equal(final.result.receipt.requestId, undefined);
  assert.equal(final.result.receipt.usage, undefined);
  await assert.rejects(collect(streamNews(input(), signal(), async () => upstream([delta("x".repeat(12_001))]))));
});

test("SSE decoding handles fragmented UTF-8 and CRLF without accepting an unfinished final frame", async () => {
  const encoded = encoder.encode('data: {"body":"café"}\r\n\r\ndata: unfinished');
  let index = 0;
  const body = new ReadableStream({ pull(controller) { if (index === encoded.length) controller.close(); else controller.enqueue(encoded.slice(index, ++index)); } });
  assert.deepEqual(await collect(readNewsSSE(body, signal())), ['{"body":"café"}']);
  for (const text of [`data: ${"x".repeat(32_769)}\n\n`, "\n".repeat(2_049)]) {
    await assert.rejects(collect(readNewsSSE(new Response(text).body, signal())));
  }
  await assert.rejects(collect(readNewsSSE(new Response("123456789").body, signal(), 8)));
  await assert.rejects(collect(readNewsSSE(new Response(new Uint8Array([0xff])).body, signal())));
});

test("aborting pending upstream reads cancels the reader and never produces a completed article", async () => {
  const controller = new AbortController();
  let cancelled = false;
  const pending = collect(streamNews(input(), controller.signal, async () => new Response(new ReadableStream({ cancel() { cancelled = true; } }), { headers: { "content-type": "text/event-stream" } })));
  await new Promise(resolve => setImmediate(resolve));
  controller.abort();
  await assert.rejects(pending, error => error.name === "AbortError");
  assert.equal(cancelled, true);
  let calls = 0;
  await assert.rejects(collect(streamNews(input(), controller.signal, async () => { calls++; return upstream([]); })));
  assert.equal(calls, 0);
});


test("news route validates original request proxies and streams only a sanitized error on upstream failure", async () => {
  const proxy = new Proxy(incoming(input(), "news-proxy"), { get(target, key) { const value = Reflect.get(target, key, target); return typeof value === "function" ? value.bind(target) : value; } });
  const response = await handleNewsRequest(proxy, async () => upstream([{ type: "response.completed", response: completed() }]));
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("Cache-Control"), "no-store");
  assert.match(response.headers.get("Content-Type"), /text\/event-stream/);
  const events = (await collect(readNewsSSE(response.body, signal()))).map(JSON.parse);
  assert.equal(events.length, 1); assert.equal(events[0].type, "complete");
  const failed = await handleNewsRequest(incoming(input(), "news-failed"), async () => { throw new Error("private upstream detail"); });
  const [error] = (await collect(readNewsSSE(failed.body, signal()))).map(JSON.parse);
  assert.equal(error.type, "error");
  assert.equal(JSON.stringify(error).includes("private"), false);
  let calls = 0;
  const transport = async () => { calls++; return upstream([]); };
  assert.equal((await handleNewsRequest(incoming(input(), "news-cross", { origin: "https://other.example" }), transport)).status, 403);
  assert.equal((await handleNewsRequest(incoming({ ...input(), target: "REAL" }, "news-bad"), transport)).status, 400);
  const unsigned = new Request("https://ticker.example/api/news", { method: "POST", headers: { origin: "https://ticker.example", "content-type": "application/json" }, body: JSON.stringify(input()) });
  assert.equal(calls, 0);
  const anonymous = await handleNewsRequest(unsigned, async () => upstream([{ type: "response.completed", response: completed() }]));
  assert.equal(anonymous.status, 200);
  const publicEvents = (await collect(readNewsSSE(anonymous.body, signal()))).map(JSON.parse);
  assert.equal(publicEvents.at(-1).type, "complete");
});

test("cancelling the route response aborts an in-flight upstream fetch", async () => {
  let aborted = false;
  const response = await handleNewsRequest(incoming(input(), "news-cancel"), async (_path, _payload, active) => new Promise((_resolve, reject) => {
    active.addEventListener("abort", () => { aborted = true; reject(active.reason); }, { once: true });
  }));
  await new Promise(resolve => setImmediate(resolve));
  await response.body.cancel();
  assert.equal(aborted, true);
});

test("client reports drafts then returns validated final data and preserves the input and abort signal", async () => {
  const final = parseCompletedNews(input(), completed(), receipt());
  const drafts = [], calls = [];
  const result = await requestNews(input(), signal(), draft => drafts.push(draft), async (url, options) => {
    calls.push({ url, options });
    return upstream([{ type: "draft", draft: { headline: "Arc expands", body: "A new" } }, { type: "complete", result: final }]);
  });
  assert.equal(calls[0].url, "/api/news");
  assert.deepEqual(JSON.parse(calls[0].options.body), input());
  assert.ok(calls[0].options.signal instanceof AbortSignal);
  assert.deepEqual(drafts, [{ headline: "Arc expands", body: "A new" }]);
  assert.deepEqual(result, final);
});

test("client rejects stale, mismatched, malformed, unfinished and explicit-error streams", async () => {
  const final = parseCompletedNews(input(), completed(), receipt());
  for (const events of [[{ type: "complete", result: { ...final, revision: 8 } }], [{ type: "complete", result: { ...final, symbol: "VOLT" } }],
    [{ type: "complete", result: { ...final, impactPct: 9 } }], [{ type: "error", message: "The article failed." }],
    [{ type: "draft", draft: { headline: "Draft", body: "Still writing" } }]]) {
    await assert.rejects(requestNews(input(), signal(), () => {}, async () => upstream(events)));
  }
  await assert.rejects(requestNews(input(), signal(), () => {}, async () => new Response("private failure", { status: 429 })), /cooling down/);
  const controller = new AbortController(); let cancelled = false;
  const pending = requestNews(input(), controller.signal, () => {}, async () => new Response(new ReadableStream({ cancel() { cancelled = true; } }), { headers: { "content-type": "text/event-stream" } }));
  await new Promise(resolve => setImmediate(resolve)); controller.abort();
  await assert.rejects(pending, error => error.name === "AbortError");
  assert.equal(cancelled, true);
});

test("client renders friendly timeout and network failures while preserving explicit cancellation", async () => {
  await assert.rejects(requestNews(input(), signal(), () => {}, async () => { throw new DOMException("The operation was aborted due to timeout", "TimeoutError"); }),
    error => error.message === "The news article took too long. No news impact was applied.");
  await assert.rejects(requestNews(input(), signal(), () => {}, async () => { throw new TypeError("Failed to fetch"); }),
    error => error.message === "The news article could not be read. No news impact was applied.");
  const controller = new AbortController(); controller.abort();
  await assert.rejects(requestNews(input(), controller.signal, () => {}, async () => { throw new Error("Must not be called"); }), error => error.name === "AbortError");
});
