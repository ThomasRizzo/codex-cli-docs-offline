import assert from "node:assert/strict";
import test from "node:test";
import { advanceMarket, applyNews, buildDecisionInput, createMarket, createPortfolio, executeDecision } from "../app/lib/market.ts";
import { SYMBOLS, type NewsResult, type TradeDecision } from "../app/lib/types.ts";

const receipt = { at: "2026-10-19T00:00:00.000Z", model: "test-news-model", durationMs: 100, status: 200, requestId: "req_test_news" };
function story(revision = 1, patch: Partial<NewsResult> = {}): NewsResult {
  return {
    revision, responseId: `resp_test_${revision}`, headline: `Arc Works announces a new project ${revision}`,
    body: "Arc Works has announced a fictional fabrication contract in the simulated market.",
    symbol: "ARC", impactPct: 2, receipt, ...patch,
  };
}

test("a published story changes only its target and records the exact before/after quote", () => {
  const original = createMarket(42, "opening");
  const untouched = structuredClone(original);
  const article = story();
  const next = applyNews(original, article);
  assert.notEqual(next, original);
  assert.equal(next.tick, original.tick);
  assert.equal(next.newsVersion, 1);
  assert.equal(next.assets[0].price, 85.88);
  assert.equal(next.assets[0].open, original.assets[0].open);
  assert.equal(next.assets[0].volume, original.assets[0].volume);
  assert.deepEqual(next.assets[0].history.at(-1), { tick: 0, price: 85.88 });
  assert.equal(next.assets[0].history.length, original.assets[0].history.length);
  for (let index = 1; index < next.assets.length; index++) assert.equal(next.assets[index], original.assets[index]);
  assert.deepEqual(next.news[0], {
    id: "news-resp_test_1", tick: 0, title: article.headline, symbol: "ARC",
    article: { ...article, id: "news-resp_test_1", tick: 0, priceBefore: 84.2, priceAfter: 85.88 },
  });
  assert.deepEqual(original, untouched);
});

test("multiple stories at one tick replace the quote without inventing additional time", () => {
  let market = createMarket(42, "opening");
  for (let tick = 0; tick < 250; tick++) market = advanceMarket(market);
  const before = market.assets[0].price;
  market = applyNews(market, story(1));
  assert.equal(market.news[0].article?.priceBefore, before);
  const afterFirst = market.assets[0].price;
  market = applyNews(market, story(2, { impactPct: -3 }));
  assert.equal(market.news[0].article?.priceBefore, afterFirst);
  assert.equal(market.assets[0].price, Math.round(afterFirst * .97 * 100) / 100);
  assert.equal(market.tick, 250);
  assert.equal(market.assets[0].history.length, 180);
  assert.equal(new Set(market.assets[0].history.map(point => point.tick)).size, 180);
  assert.deepEqual(market.assets[0].history.at(-1), { tick: 250, price: market.assets[0].price });
  assert.equal(market.newsVersion, 2);
});

test("duplicate response IDs, repeated revisions and out-of-order stories are no-ops", () => {
  const accepted = applyNews(createMarket(42, "opening"), story(5));
  for (const result of [story(5), story(5, { responseId: "resp_another" }), story(4), story(6, { responseId: "resp_test_5" })]) {
    assert.equal(applyNews(accepted, result), accepted);
  }
  assert.equal(applyNews(accepted, story(8)).newsVersion, 2);
});

test("malformed stories and invalid effects cannot change market prices or the news version", () => {
  const market = createMarket(42, "opening");
  const patches = [
    { impactPct: NaN }, { impactPct: Infinity }, { impactPct: -Infinity }, { impactPct: 3.001 }, { impactPct: -3.001 },
    { symbol: "UNKNOWN" }, { revision: -1 }, { revision: .5 }, { revision: 10_000_001 },
    { headline: "" }, { headline: "   " }, { headline: "x".repeat(181) }, { headline: null },
    { body: "" }, { body: " \n " }, { body: "x".repeat(2_001) },
    { responseId: "" }, { responseId: "unsafe id" }, { responseId: "resp_" }, { responseId: `resp_${"x".repeat(196)}` },
  ];
  for (const patch of patches) {
    const result = { ...story(), ...patch } as NewsResult;
    assert.equal(applyNews(market, result), market);
  }
  assert.equal(applyNews(market, null as unknown as NewsResult), market);
});

test("accepted effects keep prices finite, positive and bounded at both price limits", () => {
  for (const [price, impactPct] of [[.01, -3], [1_000_000, 3]]) {
    const original = createMarket(42, "opening");
    const market = { ...original, assets: original.assets.map(asset => asset.symbol === "ARC" ? { ...asset, price } : asset) };
    const next = applyNews(market, story(1, { impactPct }));
    assert.equal(next.assets[0].price, price);
    assert.equal(next.news[0].article?.priceAfter, price);
    assert.equal(next.newsVersion, 1);
  }
  const market = createMarket(42, "opening");
  for (const price of [NaN, Infinity, 0, -1]) {
    const invalid = { ...market, assets: market.assets.map(asset => asset.symbol === "ARC" ? { ...asset, price } : asset) };
    assert.equal(applyNews(invalid, story()), invalid);
  }
});

test("neutral stories still publish new context without changing a quote", () => {
  const market = createMarket(42, "opening");
  const next = applyNews(market, story(1, { impactPct: 0 }));
  assert.equal(next.assets[0].price, market.assets[0].price);
  assert.equal(next.newsVersion, 1);
  assert.equal(next.news[0].article?.impactPct, 0);
});

test("news retention stays bounded and decision observations include only the newest three stories", () => {
  let market = createMarket(42, "opening");
  for (let revision = 1; revision <= 10; revision++) market = applyNews(market, story(revision, { symbol: SYMBOLS[revision % SYMBOLS.length] }));
  assert.equal(market.news.length, 8);
  assert.equal(market.newsVersion, 10);
  assert.deepEqual(market.news.map(item => item.article?.revision), [10, 9, 8, 7, 6, 5, 4, 3]);
  assert.equal(applyNews(market, story(1)), market);
  const observed = buildDecisionInput(market, createPortfolio(), "balanced", 77);
  assert.equal(observed.newsVersion, 10);
  assert.deepEqual(observed.news, [10, 9, 8].map(revision => ({ headline: story(revision).headline, symbol: SYMBOLS[revision % SYMBOLS.length], impactPct: 2 })));
  assert.equal(JSON.stringify(observed).includes("resp_test_"), false);
  assert.equal(JSON.stringify(observed).includes(story().body), false);
});

test("a pre-publication decision cannot trade even when its own asset quote did not move", () => {
  const market = createMarket(42, "opening");
  const portfolio = createPortfolio();
  const observed = buildDecisionInput(market, portfolio, "balanced", 4);
  const decision: TradeDecision = { revision: 4, action: { kind: "buy", symbol: "BLOOM", quantity: 1 }, context: "Test choice", refused: false, receipt };
  const changed = applyNews(market, story());
  const stale = executeDecision(portfolio, changed, decision, "balanced", observed);
  assert.equal(stale.state, "skipped");
  assert.equal(stale.portfolio, portfolio);
  assert.match(stale.detail, /new story/);
  assert.equal(executeDecision(portfolio, changed, decision, "balanced", { ...observed, newsVersion: undefined }).state, "skipped");
  const fresh = buildDecisionInput(changed, portfolio, "balanced", 4);
  assert.equal(executeDecision(portfolio, changed, decision, "balanced", fresh).state, "executed");
  assert.equal(executeDecision(portfolio, market, decision, "balanced", { ...observed, newsVersion: undefined }).state, "executed");
});

test("background drift remains deterministic and never produces a canned API story", () => {
  let first = createMarket(791, "turbulent");
  let second = createMarket(791, "turbulent");
  for (let tick = 0; tick < 120; tick++) {
    if (tick === 25) {
      first = applyNews(first, story(1));
      second = applyNews(second, story(1));
    }
    first = advanceMarket(first);
    second = advanceMarket(second);
  }
  assert.deepEqual(first, second);
  assert.equal(first.news.length, 2);
  assert.equal(first.newsVersion, 1);
  assert.equal(first.news[0].article?.responseId, "resp_test_1");
  assert.equal(first.news[1].article, undefined);
});
