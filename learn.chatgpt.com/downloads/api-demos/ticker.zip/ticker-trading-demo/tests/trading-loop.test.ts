import { test } from "node:test";
import assert from "node:assert/strict";
import { TradingDecisionLoop, TradingRequestError } from "../app/lib/trading-loop.ts";
import { ActiveRunBudget } from "../app/lib/run-budget.ts";
import type { DecisionInput, TradeDecision } from "../app/lib/types.ts";
import { RequestCooldown, retryAfterMs } from "../app/lib/request-cooldown.ts";
import { IP_LIMITS } from "../app/lib/rate-limit-policy.ts";

const flush = () => new Promise<void>(resolve => setImmediate(resolve));
const input = { revision: 1 } as DecisionInput;
const result = { revision: 1 } as TradeDecision;

test("active budget accumulates across pauses, counts request delays, and requires reset after expiry", () => {
  let time = 0;
  const budget = new ActiveRunBudget(120_000, () => time);
  assert.equal(budget.start(), true);
  time = 35_000; budget.pause();
  time = 95_000; assert.equal(budget.elapsedMs, 35_000);
  budget.start(); time = 180_000;
  assert.equal(budget.expired, true); assert.equal(budget.elapsedMs, 120_000);
  budget.pause(); assert.equal(budget.start(), false);
  budget.reset(); assert.equal(budget.remainingMs, 120_000); assert.equal(budget.start(), true);
});

test("a slow request never overlaps and responses are discarded after cancellation", async () => {
  let time = 0, calls = 0, completed = 0, stopped = 0;
  let respond!: (value: TradeDecision) => void;
  let signal!: AbortSignal;
  const loop = new TradingDecisionLoop({
    observe: () => input, nextId: () => ++calls, started: () => {},
    submit: async (_, value) => { signal = value; return await new Promise(resolve => { respond = resolve; }); },
    completed: () => completed++, failed: () => assert.fail("Unexpected failure"), stopped: () => stopped++, backoff: () => {},
  }, () => time);
  loop.tick(); time = 4_000; loop.tick(); time = 8_000; loop.tick();
  assert.equal(calls, 1);
  loop.stop(); assert.equal(signal.aborted, true); assert.equal(stopped, 1);
  respond(result); await flush(); loop.tick();
  assert.equal(completed, 0); assert.equal(calls, 1);
});

test("successful decisions respect the minimum interval and preserve their observation", async () => {
  let time = 0, calls = 0, completions = 0;
  const loop = new TradingDecisionLoop({
    observe: () => input, nextId: () => ++calls, started: () => {}, submit: async () => result,
    completed: (_, observed, decision) => { assert.equal(observed, input); assert.equal(decision, result); completions++; },
    failed: () => assert.fail("Unexpected failure"), stopped: () => {}, backoff: () => {},
  }, () => time);
  loop.tick(); await flush(); time = 2_999; loop.tick(); assert.equal(calls, 1);
  time = 3_000; loop.tick(); await flush(); assert.equal(completions, 2); loop.stop();
});

test("Retry-After is respected and repeated failures eventually stop the run", async () => {
  let time = 0, calls = 0;
  const fatal: boolean[] = [];
  const loop = new TradingDecisionLoop({
    observe: () => input, nextId: () => ++calls, started: () => {},
    submit: async () => { throw new TradingRequestError("Rate limited", 10_000); },
    completed: () => assert.fail("Unexpected success"), failed: () => {}, stopped: () => {}, backoff: value => fatal.push(value),
  }, () => time);
  loop.tick(); await flush(); time = 9_999; loop.tick(); assert.equal(calls, 1);
  time = 10_000; loop.tick(); await flush(); time = 20_000; loop.tick(); await flush();
  assert.deepEqual(fatal, [false, false, true]); time = 120_000; loop.tick(); assert.equal(calls, 3);
});

test("a daily limit pauses and survives a new run without shortening Retry-After", async () => {
  let time = 0, calls = 0;
  const cooldown = new RequestCooldown(() => time), fatal: boolean[] = [];
  const makeLoop = () => new TradingDecisionLoop({
    observe: () => input, nextId: () => ++calls, started() {},
    submit: async () => { throw new TradingRequestError("Daily network limit reached", 86_400_000); },
    completed: () => assert.fail("Unexpected success"), failed() {}, stopped() {}, backoff: value => fatal.push(value),
  }, () => time, cooldown);
  let loop = makeLoop(); loop.tick(); await flush();
  assert.deepEqual(fatal, [true]); assert.equal(cooldown.until, 86_400_000);
  loop.stop(); loop = makeLoop();
  for (const now of [60_000, 120_000, 43_200_000, 86_399_999]) { time = now; loop.tick(); }
  assert.equal(calls, 1);
  time = 86_400_000; loop.tick(); await flush(); assert.equal(calls, 2); loop.stop();
});

test("a full normal run stays within the decision quotas", async () => {
  let time = 0, calls = 0;
  const minutes = new Map<number, number>();
  const loop = new TradingDecisionLoop({
    observe: () => input, nextId: () => ++calls, started() {}, submit: async () => {
      const minute = Math.floor(time / 60_000);
      minutes.set(minute, (minutes.get(minute) ?? 0) + 1); return result;
    }, completed() {}, failed: () => assert.fail("Unexpected failure"), stopped() {}, backoff() {},
  }, () => time);
  for (; time < 120_000; time += 100) { loop.tick(); await flush(); }
  loop.stop(); assert.equal(calls, 40); assert.ok(calls <= IP_LIMITS.decisions.day);
  assert.ok([...minutes.values()].every(count => count <= IP_LIMITS.decisions.minute));
});

test("Retry-After accepts seconds and HTTP dates", () => {
  assert.equal(retryAfterMs("86400", 0), 86_400_000);
  assert.equal(retryAfterMs("Thu, 01 Jan 1970 01:00:00 GMT", 0), 3_600_000);
  assert.equal(retryAfterMs(null), 0); assert.equal(retryAfterMs("invalid"), 0);
});
