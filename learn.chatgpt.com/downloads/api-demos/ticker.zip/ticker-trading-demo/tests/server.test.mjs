import test, { after } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { build } from "esbuild";
import { providerBindings, connectionRequired } from "./fixtures/provider.mjs";

const dir = await mkdtemp(join(tmpdir(), "ticker-api-"));
after(() => rm(dir, { recursive: true, force: true }));
const bundled = await build({ stdin: { contents: 'export * from "./app/api/decision/route.ts"; export * from "./app/lib/server.ts";', resolveDir: process.cwd(), loader: "ts" },
  bundle: true, platform: "node", format: "esm", external: ["cloudflare:workers"], write: false, logLevel: "silent" });
const modulePath = join(dir, "api.mjs");
await writeFile(modulePath, bundled.outputFiles[0].text);
const { ApiError, guardRequest, openAIResponse, getTradingDecision, handleDecisionRequest: handleDecisionRequestWithLimit } = await import(pathToFileURL(modulePath).href);
const handleDecisionRequest = (request, transport) => handleDecisionRequestWithLimit(request, transport, async () => null);

test("decision quota rejects before parsing or upstream and preserves the real Retry-After", async () => {
  const incoming = request({}, "quota-test"); let calls = 0;
  const blocked = Response.json({ code: "RATE_LIMIT_EXCEEDED", error: "Daily network limit", retryAfter: 86000 }, {
    status: 429, headers: { "Retry-After": "86000", "Cache-Control": "no-store" },
  });
  const response = await handleDecisionRequestWithLimit(incoming, async () => { calls++; throw new Error("Must not run"); }, async (actual, bucket) => {
    assert.equal(actual, incoming); assert.equal(bucket, "decisions"); return blocked;
  });
  assert.equal(response, blocked); assert.equal(incoming.bodyUsed, false); assert.equal(calls, 0);
  assert.equal(response.headers.get("Retry-After"), "86000");
  const rejected = await handleDecisionRequestWithLimit(request({}, "quota-cross", { origin: "https://other.example" }), async () => {
    assert.fail("Must not call upstream");
  }, async () => { assert.fail("Invalid origin must not consume quota"); });
  assert.equal(rejected.status, 403);
});
const symbols = ["ARC", "BLOOM", "CIRR", "DRFT", "EMBER", "VOLT"];
function input() { return { revision: 7, tick: 23, strategy: "balanced", scenario: "opening", cash: 10_000,
  positions: Object.fromEntries(symbols.map(symbol => [symbol, 0])),
  assets: symbols.map(symbol => ({ symbol, price: 100, open: 100, mean: 98, momentumPct: 1, volatilityPct: .5 })) }; }
function result(choice = "buy_ARC") { return { model: "gpt-6-luna", answers: [{ type: "choice", name: "trade", choice }], usage: { input_tokens: 410, output_tokens: 0, total_tokens: 410 } }; }
function request(body = input(), user = "ticker-fixture-user", extra = {}) { return new Request("https://ticker.example/api/decision", {
  method: "POST", headers: { origin: "https://ticker.example", "content-type": "application/json", ...extra }, body: JSON.stringify(body) }); }
const signal = () => new AbortController().signal;

test("one Decisions call returns its actual model, timing, status, ID and usage with the submitted revision", async () => {
  const calls = [];
  const start = Date.now();
  const decision = await getTradingDecision(input(), signal(), async (path, payload) => {
    calls.push({ path, payload });
    await new Promise(resolve => setTimeout(resolve, 8));
    return Response.json({ ...result(), model: "gpt-6-luna-served", private: "not forwarded" }, { status: 201, headers: { "x-request-id": "req_actual_fixture_123" } });
  });
  assert.equal(calls.length, 1);
  assert.equal(calls[0].path, "/decisions");
  assert.equal(calls[0].payload.questions[0].name, "trade");
  assert.deepEqual(decision.action, { kind: "buy", symbol: "ARC", quantity: 8 });
  assert.equal(decision.revision, 7);
  assert.equal(decision.receipt.model, "gpt-6-luna-served");
  assert.equal(decision.receipt.status, 201);
  assert.equal(decision.receipt.requestId, "req_actual_fixture_123");
  assert.deepEqual(decision.receipt.usage, { inputTokens: 410, outputTokens: 0, totalTokens: 410 });
  assert.ok(decision.receipt.durationMs >= 5);
  assert.ok(Date.parse(decision.receipt.at) >= start && Date.parse(decision.receipt.at) <= Date.now());
  assert.equal(JSON.stringify(decision).includes("not forwarded"), false);
});

test("omitted or invalid request IDs and omitted usage remain omitted", async () => {
  for (const id of [undefined, "invalid id", "x".repeat(129)]) {
    const payload = { model: "gpt-6-luna", answers: [{ type: "refusal", name: "trade" }] };
    const decision = await getTradingDecision(input(), signal(), async () => Response.json(payload, { headers: id ? { "x-request-id": id } : undefined }));
    assert.equal(decision.refused, true);
    assert.equal(decision.receipt.requestId, undefined);
    assert.equal(decision.receipt.usage, undefined);
  }
});

test("cancellation before transport or while reading a response cannot produce a trade", async () => {
  const before = new AbortController();
  before.abort();
  let calls = 0;
  await assert.rejects(getTradingDecision(input(), before.signal, async () => { calls++; return Response.json(result()); }));
  assert.equal(calls, 0);
  const during = new AbortController();
  let cancelled = false;
  const pending = getTradingDecision(input(), during.signal, async () => new Response(new ReadableStream({ cancel() { cancelled = true; } })));
  await new Promise(resolve => setImmediate(resolve));
  during.abort();
  await assert.rejects(pending, error => error.name === "AbortError");
  assert.equal(cancelled, true);
});

test("route guards origin, metadata, actual bytes and schema before transport", async () => {
  let calls = 0;
  const transport = async () => { calls++; return Response.json(result()); };
  const unsigned = new Request("https://ticker.example/api/decision", { method: "POST", headers: { origin: "https://ticker.example", "content-type": "application/json" }, body: JSON.stringify(input()) });
  const cases = [
    [request(input(), "origin", { origin: "https://other.example" }), 403],
    [request(input(), "fetch-site", { "sec-fetch-site": "cross-site" }), 403],
    [request(input(), "mime", { "content-type": "text/plain" }), 415],
    [request(input(), "length", { "content-length": "16385" }), 413],
    [request("x".repeat(16_385), "actual-length"), 413],
    [request({ ...input(), positions: {} }, "invalid"), 400],
  ];
  for (const [incoming, status] of cases) assert.equal((await handleDecisionRequest(incoming, transport)).status, status);
  assert.equal(calls, 0);
  assert.equal((await handleDecisionRequest(unsigned, transport)).status, 200, "valid anonymous requests are admitted");
});

test("route reads the original property-forwarding request proxy and returns no-store JSON", async () => {
  const proxy = new Proxy(request(input(), "proxy"), { get(target, key) { const value = Reflect.get(target, key, target); return typeof value === "function" ? value.bind(target) : value; } });
  const response = await handleDecisionRequest(proxy, async () => Response.json(result()));
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("Cache-Control"), "no-store");
  assert.equal((await response.json()).action.kind, "buy");
});

test("cancelling a pending incoming body releases its reader without reaching the API", async () => {
  const controller = new AbortController();
  let cancelled = false, calls = 0;
  const incoming = new Request("https://ticker.example/api/decision", {
    method: "POST", headers: { origin: "https://ticker.example", "content-type": "application/json" },
    body: new ReadableStream({ cancel() { cancelled = true; } }), signal: controller.signal, duplex: "half",
  });
  const pending = handleDecisionRequest(incoming, async () => { calls++; return Response.json(result()); });
  await new Promise(resolve => setImmediate(resolve));
  controller.abort();
  const response = await pending;
  assert.equal(response.status, 408);
  assert.equal(cancelled, true);
  assert.equal(calls, 0);
});


test("route sanitizes malformed responses, upstream errors and timeout failures instead of fabricating trades", async () => {
  const fixtures = [
    [async () => { throw new Error("private upstream details"); }, 502],
    [async () => { throw new DOMException("private timeout", "TimeoutError"); }, 504],
    [async () => { throw new DOMException("private abort", "AbortError"); }, 408],
    [async () => new Response("private failure", { status: 429 }), 429],
    [async () => new Response("private failure", { status: 500 }), 502],
    [async () => new Response("not JSON"), 502],
    [async () => new Response("x".repeat(16_385)), 502],
    [async () => Response.json(result("sell_ARC")), 502],
  ];
  for (const [index, [transport, status]] of fixtures.entries()) {
    const response = await handleDecisionRequest(request(input(), `failure-${index}`), transport);
    assert.equal(response.status, status);
    assert.equal(response.headers.get("Retry-After"), status === 429 ? "60" : null);
    const body = await response.json();
    assert.equal(typeof body.error, "string");
    assert.equal("action" in body, false);
    assert.equal("receipt" in body, false);
    assert.equal(JSON.stringify(body).includes("private"), false);
  }
});

test("server transport fixes the API origin and credential and preserves cancellation", async () => {
  const observed = [], controller = new AbortController();
  const send = async (url, options) => { observed.push({url, options}); return Response.json(result()); };
  const dependencies = { key: "fixture-key-only", bindings: providerBindings(send), fetch: send };
  for (const path of ["/decisions", "/responses"]) await openAIResponse(path, {model: "gpt-6-luna"}, controller.signal, dependencies);
  assert.equal(observed.length, 2);
  for (const [index, call] of observed.entries()) {
    assert.equal(call.url, `https://api.openai.com/v1${index ? "/responses" : "/decisions"}`);
    assert.equal(call.options.headers.Authorization, "Bearer fixture-key-only");
    assert.equal(call.options.signal, controller.signal);
    assert.equal(call.options.method, "POST");
    assert.equal(call.options.redirect, "manual");
  }
  for (const path of ["https://other.test/decisions", "//other.test/decisions", "/files", "/responses/../files"]) {
    await assert.rejects(openAIResponse(path, {}, signal(), dependencies), error => error instanceof ApiError && error.status === 500);
  }
  assert.equal(observed.length, 2);
  await assert.rejects(openAIResponse("/decisions", {}, signal(), {key: "", bindings: null}), error => error.status === 503);
  if (connectionRequired) {
    const previous=process.env.NODE_ENV;process.env.NODE_ENV="production";
    try { await assert.rejects(openAIResponse("/decisions", {}, signal(), {key: "fixture-key-only", bindings: null, fetch: () => assert.fail("Missing configured connection must fail closed")}), error => error.status === 503); }
    finally { if(previous===undefined)delete process.env.NODE_ENV;else process.env.NODE_ENV=previous; }
  }
});

test("upstream redirects, credentials, quota and network failures expose no response details", async () => {
  for (const [status, expected] of [[300, 502], [301, 502], [302, 502], [303, 502], [304, 502], [307, 502], [308, 502], [399, 502], [401, 503], [403, 503], [404, 503], [429, 429], [500, 502]]) {
    let calls = 0;
    const send = async (_url, init) => { calls++; assert.equal(init.redirect, "manual"); return new Response(null, {status, headers: {Location: "https://other.test/private-target"}}); };
    await assert.rejects(openAIResponse("/decisions", {}, signal(), {key: "fixture-key-only", bindings: providerBindings(send), fetch: send}), error => error instanceof ApiError && error.status === expected && !error.message.includes("private"));
    assert.equal(calls, 1);
  }
  const send = async () => { throw new Error("private network failure"); };
  await assert.rejects(openAIResponse("/decisions", {}, signal(), {key: "fixture-key-only", bindings: providerBindings(send), fetch: send}), error => error instanceof ApiError && error.status === 502 && !error.message.includes("private"));
});
