import assert from "node:assert/strict";
import test from "node:test";
import {
  ASSETS, SCENARIOS, advanceMarket, benchmarkReturn, buildDecisionInput,
  createMarket, createPortfolio, executeDecision, portfolioPnl, portfolioValue,
} from "../app/lib/market.ts";
import { POSITION_LIMIT, SYMBOLS, type MarketState, type Portfolio, type Strategy, type Symbol, type TradeAction, type TradeDecision } from "../app/lib/types.ts";

const receipt = { at: "2026-10-18T00:00:00.000Z", model: "test", durationMs: 1, status: 200 };
const decision = (action: TradeAction, revision = 1): TradeDecision => ({ revision, action, context: "Test decision", refused: false, receipt });
const buy = (quantity: number, symbol: Symbol = "ARC") => decision({ kind: "buy", symbol, quantity });
const sell = (quantity: number, symbol: Symbol = "ARC") => decision({ kind: "sell", symbol, quantity });
const hold = () => decision({ kind: "hold", symbol: null, quantity: 0 });
const close = (actual: number, expected: number) => assert.ok(Math.abs(actual - expected) < 1e-7, `${actual} should equal ${expected}`);

function atPrice(market: MarketState, price: number, symbol: Symbol = "ARC"): MarketState {
  return { ...market, assets: market.assets.map(asset => asset.symbol === symbol ? { ...asset, price } : asset) };
}

function execute(portfolio: Portfolio, market: MarketState, action: TradeDecision, strategy: Strategy = "balanced") {
  return executeDecision(portfolio, market, action, strategy, buildDecisionInput(market, portfolio, strategy, 1));
}

test("starts with six distinct fictional assets, forty quotes and an opening benchmark", () => {
  const market = createMarket(42, "opening");
  assert.equal(market.tick, 0);
  assert.equal(market.newsVersion, 0);
  assert.equal(new Set(ASSETS.map(asset => asset.name)).size, 6);
  assert.deepEqual(market.assets.map(asset => asset.symbol), [...SYMBOLS]);
  for (const asset of market.assets) {
    assert.equal(asset.history.length, 40);
    assert.equal(asset.history[0].tick, -39);
    assert.deepEqual(asset.history.at(-1), { tick: 0, price: asset.open });
    assert.equal(asset.price, asset.open);
  }
  assert.equal(benchmarkReturn(market), 0);
  const portfolio = createPortfolio();
  assert.equal(portfolio.cash, 10_000);
  assert.equal(portfolioValue(portfolio, market), 10_000);
  assert.deepEqual(portfolioPnl(portfolio, market), { amount: 0, percent: 0 });
});

test("identical seeds and scenarios reproduce the entire market without mutating prior snapshots", () => {
  let first = createMarket(1701, "rally");
  let second = createMarket(1701, "rally");
  const initial = structuredClone(first);
  const untouched = first;
  for (let tick = 0; tick < 150; tick++) {
    first = advanceMarket(first);
    second = advanceMarket(second);
  }
  assert.deepEqual(first, second);
  assert.deepEqual(untouched, initial);
  assert.notDeepEqual(createMarket(1702, "rally"), initial);
  assert.notDeepEqual(createMarket(1701, "turbulent"), initial);
});

test("all regimes retain positive cent prices, bounded histories/news and monotonically increasing volume", () => {
  for (const scenario of SCENARIOS) {
    let market = createMarket(834, scenario.id);
    for (let tick = 0; tick < 800; tick++) {
      const next = advanceMarket(market);
      assert.equal(next.tick, market.tick + 1);
      assert.ok(next.news.length <= 8);
      for (let index = 0; index < next.assets.length; index++) {
        const asset = next.assets[index];
        assert.ok(Number.isFinite(asset.price) && asset.price > 0);
        close(asset.price * 100, Math.round(asset.price * 100));
        assert.ok(asset.history.length <= 180);
        assert.equal(asset.history.at(-1)?.price, asset.price);
        assert.equal(asset.history.at(-1)?.tick, next.tick);
        assert.ok(asset.volume > market.assets[index].volume);
      }
      market = next;
    }
    assert.equal(market.newsVersion, 0);
    assert.equal(market.news.length, 1);
    assert.match(market.news[0].title, /Fictional market open/);
    assert.equal(market.news[0].article, undefined);
  }
});

test("rally and turbulence have distinct aggregate drift and volatility across seeds", () => {
  let rallyReturn = 0;
  let openingReturn = 0;
  let turbulentMovement = 0;
  let openingMovement = 0;
  for (let seed = 1; seed <= 20; seed++) {
    let rally = createMarket(seed, "rally");
    let opening = createMarket(seed, "opening");
    let turbulent = createMarket(seed, "turbulent");
    for (let tick = 0; tick < 120; tick++) {
      const nextOpening = advanceMarket(opening);
      const nextTurbulent = advanceMarket(turbulent);
      for (let index = 0; index < ASSETS.length; index++) {
        openingMovement += Math.abs(nextOpening.assets[index].price / opening.assets[index].price - 1);
        turbulentMovement += Math.abs(nextTurbulent.assets[index].price / turbulent.assets[index].price - 1);
      }
      rally = advanceMarket(rally);
      opening = nextOpening;
      turbulent = nextTurbulent;
    }
    rallyReturn += benchmarkReturn(rally);
    openingReturn += benchmarkReturn(opening);
  }
  assert.ok(rallyReturn / 20 > openingReturn / 20 + 3);
  assert.ok(turbulentMovement > openingMovement * 1.8);
});

test("decision observations contain finite recent statistics and independent holdings", () => {
  const market = createMarket(12, "opening");
  const portfolio = createPortfolio();
  const observed = buildDecisionInput(market, portfolio, "defensive", 19);
  assert.equal(observed.revision, 19);
  assert.equal(observed.strategy, "defensive");
  assert.equal(observed.cash, 10_000);
  assert.equal(observed.assets.length, 6);
  for (const asset of observed.assets) {
    for (const number of [asset.price, asset.open, asset.mean, asset.momentumPct, asset.volatilityPct]) assert.ok(Number.isFinite(number));
    assert.ok(asset.volatilityPct >= 0);
  }
  observed.positions.ARC = 2;
  assert.equal(portfolio.positions.ARC.quantity, 0);
});

test("buying and selling conserve equity at a fixed quote and do not mutate inputs", () => {
  const market = atPrice(createMarket(1, "opening"), 100);
  const original = createPortfolio();
  const bought = execute(original, market, buy(20));
  assert.equal(bought.state, "executed");
  assert.equal(bought.portfolio.cash, 8_000);
  assert.deepEqual(bought.portfolio.positions.ARC, { quantity: 20, averageCost: 100 });
  assert.equal(portfolioValue(bought.portfolio, market), 10_000);
  const sold = execute(bought.portfolio, market, sell(20));
  assert.equal(sold.state, "executed");
  assert.equal(sold.portfolio.cash, 10_000);
  assert.equal(sold.portfolio.realizedPnl, 0);
  assert.deepEqual(sold.portfolio.positions.ARC, { quantity: 0, averageCost: 0 });
  assert.equal(sold.portfolio.trades, 2);
  assert.deepEqual(original, createPortfolio());
  assert.equal(bought.portfolio.positions.ARC.quantity, 20);
});

test("weighted cost basis, partial sales and realized/unrealized profit reconcile", () => {
  let market = atPrice(createMarket(1, "opening"), 100);
  let portfolio = execute(createPortfolio(), market, buy(10)).portfolio;
  market = atPrice(market, 120);
  portfolio = execute(portfolio, market, buy(5)).portfolio;
  close(portfolio.positions.ARC.averageCost, 1_600 / 15);
  market = atPrice(market, 130);
  portfolio = execute(portfolio, market, sell(6)).portfolio;
  assert.equal(portfolio.cash, 9_180);
  assert.equal(portfolio.positions.ARC.quantity, 9);
  close(portfolio.realizedPnl, 140);
  close(portfolioValue(portfolio, market), 10_350);
  close(portfolio.realizedPnl + 9 * (130 - portfolio.positions.ARC.averageCost), 350);
  assert.equal(portfolioPnl(portfolio, market).amount, 350);
  close(portfolioPnl(portfolio, market).percent, 3.5);
  portfolio = execute(portfolio, market, sell(9)).portfolio;
  close(portfolio.realizedPnl, 350);
  assert.equal(portfolio.cash, 10_350);
  assert.equal(portfolio.positions.ARC.averageCost, 0);
});

test("fractional-cent cost basis survives repeated partial sales without money drift", () => {
  let market = atPrice(createMarket(1, "opening"), 10.01);
  let portfolio = execute(createPortfolio(), market, buy(3)).portfolio;
  market = atPrice(market, 10.03);
  portfolio = execute(portfolio, market, buy(4)).portfolio;
  market = atPrice(market, 10.07);
  for (let count = 0; count < 7; count++) portfolio = execute(portfolio, market, sell(1)).portfolio;
  assert.equal(portfolio.cash, 10_000.34);
  close(portfolio.realizedPnl, .34);
});

test("position limits include existing holdings and allow exact boundaries", () => {
  const market = atPrice(createMarket(1, "opening"), 100);
  for (const strategy of ["balanced", "momentum", "defensive"] as const) {
    const limit = 100 * POSITION_LIMIT[strategy];
    const first = execute(createPortfolio(), market, buy(limit - 1), strategy);
    assert.equal(first.state, "executed");
    const boundary = execute(first.portfolio, market, buy(1), strategy);
    assert.equal(boundary.state, "executed");
    const beyond = execute(boundary.portfolio, market, buy(1), strategy);
    assert.equal(beyond.state, "skipped");
    assert.equal(beyond.portfolio, boundary.portfolio);
    const trim = execute(boundary.portfolio, market, sell(1), strategy);
    assert.equal(trim.state, "executed");
  }
});

test("cash and share availability prohibit leverage and shorting", () => {
  const market = atPrice(createMarket(1, "opening"), 100);
  let portfolio = createPortfolio();
  portfolio = { ...portfolio, cash: 50 };
  const noCash = execute(portfolio, market, buy(1));
  assert.equal(noCash.state, "skipped");
  assert.match(noCash.detail, /cash/);
  assert.equal(noCash.portfolio, portfolio);
  const short = execute(createPortfolio(), market, sell(1));
  assert.equal(short.state, "skipped");
  assert.match(short.detail, /short selling/);
});

test("hold and refusal preserve the exact portfolio object", () => {
  const market = createMarket(1, "opening");
  const portfolio = createPortfolio();
  const held = execute(portfolio, market, hold());
  assert.equal(held.state, "held");
  assert.equal(held.portfolio, portfolio);
  const refused = execute(portfolio, market, { ...buy(1), refused: true });
  assert.equal(refused.state, "skipped");
  assert.equal(refused.portfolio, portfolio);
});

test("invalid orders are skipped without modifying the portfolio", () => {
  const market = createMarket(1, "opening");
  const portfolio = createPortfolio();
  const invalid = [
    buy(0), buy(-1), buy(.5), buy(NaN), buy(Infinity), buy(Number.MAX_SAFE_INTEGER + 1),
    decision({ kind: "hold", symbol: "ARC", quantity: 0 }),
    decision({ kind: "hold", symbol: null, quantity: 2 }),
    decision({ kind: "buy", symbol: "NOPE", quantity: 1 } as unknown as TradeAction),
    decision({ kind: "borrow", symbol: "ARC", quantity: 1 } as unknown as TradeAction),
    decision(null as unknown as TradeAction),
  ];
  for (const action of invalid) {
    const result = execute(portfolio, market, action);
    assert.equal(result.state, "skipped");
    assert.equal(result.portfolio, portfolio);
  }
});

test("quote ages, revisions, scenario changes and portfolio races reject stale decisions", () => {
  const market = createMarket(1, "opening");
  const portfolio = createPortfolio();
  const observed = buildDecisionInput(market, portfolio, "balanced", 1);
  const staleCases = [
    executeDecision(portfolio, { ...market, tick: 7 }, buy(1), "balanced", observed),
    executeDecision(portfolio, market, { ...buy(1), revision: 2 }, "balanced", observed),
    executeDecision(portfolio, market, buy(1), "momentum", observed),
    executeDecision(portfolio, { ...market, scenario: "rally" }, buy(1), "balanced", observed),
    executeDecision(portfolio, market, buy(1), "balanced", { ...observed, tick: 1 }),
    executeDecision({ ...portfolio, cash: 9_999 }, market, buy(1), "balanced", observed),
    executeDecision(portfolio, market, buy(1), "balanced", { ...observed, positions: { ...observed.positions, ARC: 1 } }),
  ];
  for (const result of staleCases) assert.equal(result.state, "skipped");
  assert.equal(executeDecision(portfolio, { ...market, tick: 6 }, buy(1), "balanced", observed).state, "executed");
});

test("slippage is rechecked against the quoted price in either direction", () => {
  const market = atPrice(createMarket(1, "opening"), 100);
  const portfolio = createPortfolio();
  const observed = buildDecisionInput(market, portfolio, "balanced", 1);
  for (const price of [103.01, 96.99]) {
    const result = executeDecision(portfolio, atPrice(market, price), buy(1), "balanced", observed);
    assert.equal(result.state, "skipped");
    assert.match(result.detail, /3%/);
    assert.equal(result.portfolio, portfolio);
  }
  assert.equal(executeDecision(portfolio, atPrice(market, 103), buy(1), "balanced", observed).state, "executed");
});

test("benchmark averages percentage returns rather than weighting by share price", () => {
  const market = createMarket(1, "opening");
  const changed = { ...market, assets: market.assets.map((asset, index) => ({ ...asset, price: asset.open * (index === 0 ? 1.12 : 1) })) };
  close(benchmarkReturn(changed), 2);
});

test("a changing portfolio reconciles cash, realized and unrealized results through many trades", () => {
  for (const strategy of ["balanced", "momentum", "defensive"] as const) {
    let market = createMarket(571, "turbulent");
    let portfolio = createPortfolio();
    let executed = 0;
    for (let tick = 0; tick < 300; tick++) {
      market = advanceMarket(market);
      const symbol = SYMBOLS[tick % SYMBOLS.length];
      const quantity = 1 + tick % 13;
      const action = tick % 5 < 3 ? buy(quantity, symbol) : sell(Math.min(quantity, portfolio.positions[symbol].quantity), symbol);
      const result = execute(portfolio, market, action, strategy);
      if (result.state === "executed") {
        executed++;
        close(portfolioValue(result.portfolio, market), portfolioValue(portfolio, market));
        if (action.action.kind === "buy") {
          const asset = market.assets.find(item => item.symbol === symbol)!;
          assert.ok(result.portfolio.positions[symbol].quantity * asset.price <= portfolioValue(result.portfolio, market) * POSITION_LIMIT[strategy] + 1e-8);
        }
      }
      portfolio = result.portfolio;
      assert.ok(portfolio.cash >= 0);
      close(portfolio.cash * 100, Math.round(portfolio.cash * 100));
      const unrealized = market.assets.reduce((sum, asset) => {
        const position = portfolio.positions[asset.symbol];
        assert.ok(Number.isSafeInteger(position.quantity) && position.quantity >= 0);
        return sum + position.quantity * (asset.price - position.averageCost);
      }, 0);
      close(portfolioPnl(portfolio, market).amount, portfolio.realizedPnl + unrealized);
    }
    assert.ok(executed > 100);
    assert.equal(portfolio.trades, executed);
  }
});
