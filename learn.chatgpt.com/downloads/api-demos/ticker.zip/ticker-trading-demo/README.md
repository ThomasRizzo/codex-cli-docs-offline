# Ticker

A paper-trading desk with six fictional stocks, generated market news, and real OpenAI Decisions API choices. The Responses API streams fictional articles that move prices; the Decisions API chooses a feasible buy, sell, or hold action using the latest quotes and news. Both feeds show actual API receipts.

## Run locally

Requires Node.js 22.13+ and Python 3.

```sh
npm ci
cp .env.example .env.local
# Set OPENAI_API_KEY in .env.local to your own dedicated project key.
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_fantastic_wolf_cub.sql
npm run dev
```

The server calls `/v1/decisions` and `/v1/responses` with `gpt-6-luna`. Responses uses Fast mode (`service_tier: "fast"`). The key must have access to both endpoints and the model. It stays on the server. Visitors do not need an account. The hosted Site uses its configured server-side API connection and `OPENAI_API_KEY` secret. Downloaded projects connect directly to `https://api.openai.com` in development and production. The downloadable project contains no credentials or original hosting identity. Configure your own server-side API secret before deploying the downloaded project.

## How it works

- Background prices advance locally once a second using seeded synthetic conditions. Opening, Rally, and Turbulent change that background; generated articles add non-deterministic price shocks. Switching conditions or strategy starts a fresh $10,000 portfolio.
- News generation starts with the run and repeats about every 20 active seconds, with one stream in flight and at most six requests per run (including failed or cancelled attempts). Public article text streams into News. Only a complete validated article changes its fictional stock's price, by at most 3% up or down. The article records the applied before/after quote and actual Responses receipt. An interrupted or rejected article never changes prices.
- Generated headlines appear in the top marquee; selecting one opens its article. Moving headlines pause on hover or focus and respect reduced-motion preferences. Branding lives in the sidebar, while download and help sit with the run controls.
- While running, the client requests one decision every three seconds, with at most one in flight. The server calculates legal candidates from the submitted market snapshot and portfolio, then asks the Decisions API to choose among them.
- Whole-share trades execute at the latest simulated quote. Execution rejects stale quotes, new articles published since the observation, price moves above 3%, revision mismatches, overspending, unavailable holdings, and strategy position limits. The next decision receives the latest three headlines and their price effects. There is no leverage or shorting. No real trades, news, or market data are involved.
- Balanced, Momentum, and Defensive use different instructions, trade sizes, and maximum position allocations. Net return includes cash and marked-to-market holdings. The market benchmark is the equally weighted price return of the six fictional stocks.
- A run allows two cumulative active minutes. Pause, tab hiding, and restart cancel pending requests and discard late replies. The timer continues through network delays and backoff. Returning to a hidden tab does not resume it automatically.
- Errors are visible. Retry-After is honored without shortening daily waits. Long decision cooldowns and repeated failures pause the run; news cooldowns independently prevent article requests. Both survive pause, reset, and Run again. Other news failures wait for the next scheduled slot. Same-origin checks, bounded payloads, request deadlines, and durable per-IP quotas protect anonymous requests.
- The simulation, portfolio, articles, and API receipts stay in the current tab. News requests use `store: false`; Ticker creates no saved user accounts or provider sessions. Closing or refreshing the tab discards the run.
- Soft synthesized sound starts after interaction and can be muted. Reduced-motion preferences are respected. No audio files or external chart services are required.

## Check and build

```sh
npm test
npm run typecheck
npm run build
npm run package:source
```

`app/lib/market.ts` owns market simulation, news shocks, and trade execution. `trading-contract.ts` and `/api/decision` own Decisions requests; `news-contract.ts`, `news-client.ts`, and `/api/news` own streamed Responses articles. `use-ticker.ts`, `trading-loop.ts`, and `news-loop.ts` own lifecycle, cadence, and cancellation. `app/components/ticker-app.tsx` owns the trading desk. The Sites/Vinext starter produces a Cloudflare Worker and static client assets.

## Usage limits

Both paid endpoints reserve an atomic D1 quota for the visitor's network before reading the body or contacting OpenAI. Decisions allow 30 requests per minute and 240 per UTC day; news allows 6 per minute and 24 per UTC day. A normal two-minute run makes at most 40 decisions and 6 news requests.

The counters are shared across Worker instances, tabs, and anonymous visitors on the same IP. The server uses only the edge-provided `CF-Connecting-IP`, never `X-Forwarded-For`. D1 stores hashed IP/bucket identifiers and expiring counters rather than raw IPs. Missing trusted client IPs or unavailable storage fail closed with HTTP 503. Exhausted quotas return HTTP 429 with the actual `Retry-After` and reset time; the client keeps the portfolio, news, and request history while waiting.

Bind D1 as `DB` and apply the included Drizzle migration before local use, as shown above. Sites applies migrations during publishing. The downloadable source retains the D1 binding declaration and migrations but excludes the original site's deployment identity and credentials.
