import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { Miniflare, Log, LogLevel } from "miniflare";
import { enforceIpRateLimitWithDb } from "../app/lib/ip-rate-limit.ts";
import { IP_LIMITS } from "../app/lib/rate-limit-policy.ts";

const root = fileURLToPath(new URL("../", import.meta.url));
const buckets = Object.keys(IP_LIMITS);

test("paid routes enforce the real D1 quota before body parsing or upstream work", { timeout: 60_000 }, async t => {
  const routes = buckets.map((bucket, i) => `import { POST as route${i} } from './app/api/${bucket}/route.ts';`).join("\n");
  const bundled = await build({
    absWorkingDir: root,
    stdin: { contents: `${routes}
      const routes = {${buckets.map((bucket, i) => `${JSON.stringify(`/api/${bucket}`)}: route${i}`).join(",")}};
      export default { async fetch(request) {
        const headers = new Headers(request.headers);
        if (headers.has('x-test-missing-ip')) headers.delete('cf-connecting-ip');
        const proxy = new Proxy(request, { get(target, key) {
          if (key === 'headers') return headers;
          const value = Reflect.get(target, key, target);
          return typeof value === 'function' ? value.bind(target) : value;
        }});
        return routes[new URL(request.url).pathname](proxy);
      }};`, resolveDir: root, loader: "ts" },
    bundle: true, write: false, platform: "neutral", format: "esm", target: "es2022",
    mainFields: ["module", "main"], conditions: ["workerd", "worker", "browser"], external: ["cloudflare:workers", "node:*"],
    define: { "process.env.NODE_ENV": '"production"' }, logLevel: "silent",
  });
  let outbound = 0;
  const options = {
    modules: true, script: bundled.outputFiles[0].text,
    compatibilityDate: "2026-05-15", compatibilityFlags: ["nodejs_compat"],
    host: "127.0.0.1", port: 0, cf: false, log: new Log(LogLevel.ERROR),
    outboundService: async () => { outbound++; return new Response("Unexpected upstream request", { status: 500 }); },
  };
  const worker = new Miniflare({ ...options, d1Databases: ["DB"] });
  const noDatabase = new Miniflare(options);
  t.after(async () => { await worker.dispose(); await noDatabase.dispose(); });
  const db = await worker.getD1Database("DB");
  for (const statement of readFileSync(new URL("../drizzle/0000_fantastic_wolf_cub.sql", import.meta.url), "utf8").split("--> statement-breakpoint")) {
    if (statement.trim()) await db.prepare(statement.trim()).run();
  }

  function request(bucket, patch = {}) {
    const headers = new Headers({
      origin: "https://demo.test", "content-type": "application/json",
      "cf-connecting-ip": "192.0.2.10",
    });
    for (const [key, value] of Object.entries(patch)) {
      if (value === null) { headers.delete(key); if (key === "cf-connecting-ip") headers.set("x-test-missing-ip", "1"); } else headers.set(key, value);
    }
    return new Request(`https://demo.test/api/${bucket}`, { method: "POST", headers, body: "{}" });
  }
  async function send(target, incoming) {
    return target.dispatchFetch(incoming.url, { method: "POST", headers: incoming.headers, body: await incoming.text() });
  }
  const countRows = async () => (await db.prepare("SELECT COUNT(*) AS count FROM demo_ip_rate_limits").first()).count;

  for (const bucket of buckets) await t.test(bucket, async () => {
    await db.prepare("DELETE FROM demo_ip_rate_limits").run();
    const policy = IP_LIMITS[bucket];
    for (const [patch, status] of [
      [{ origin: "https://other.test" }, 403],
      [{ "sec-fetch-site": "cross-site" }, 403],
      [{ "cf-connecting-ip": null, "x-forwarded-for": "192.0.2.99" }, 503],
      [{ "cf-connecting-ip": "garbage" }, 503],
    ]) {
      const response = await send(worker, request(bucket, patch));
      assert.equal(response.status, status, await response.clone().text());
      assert.equal(await countRows(), 0, "cross-origin requests and missing trusted IP must not reserve quota");
    }
    const unavailable = await send(noDatabase, request(bucket));
    assert.equal(unavailable.status, 503);
    assert.equal((await unavailable.json()).code, "RATE_LIMIT_UNAVAILABLE");

    assert.equal(await enforceIpRateLimitWithDb(db, request(bucket), bucket, policy), null);
    await db.prepare("UPDATE demo_ip_rate_limits SET minute_count = ?, day_count = ?").bind(policy.minute, policy.day).run();
    for (const spoofed of ["198.51.100.1", "198.51.100.2"]) {
      const response = await send(worker, request(bucket, { "x-forwarded-for": spoofed, "x-real-ip": spoofed, "oai-authenticated-user-id": crypto.randomUUID() }));
      assert.equal(response.status, 429, await response.clone().text());
      assert.equal(response.headers.get("cache-control"), "no-store");
      const payload = await response.json();
      assert.equal(payload.code, "RATE_LIMIT_EXCEEDED");
      assert.equal(Number(response.headers.get("retry-after")), payload.retryAfter);
      assert.ok(payload.retryAfter > 0);
    }
    const exhausted = await db.prepare("SELECT minute_count, day_count FROM demo_ip_rate_limits").first();
    assert.deepEqual(exhausted, { minute_count: policy.minute, day_count: policy.day });

    const independent = await send(worker, request(bucket, { "cf-connecting-ip": "192.0.2.11" }));
    assert.equal(independent.status, 400, "a different IP reaches schema validation");
    assert.equal(await countRows(), 2);
    await db.prepare("UPDATE demo_ip_rate_limits SET expires_at = 0").run();
    const afterExpiry = await send(worker, request(bucket));
    assert.equal(afterExpiry.status, 400, "expired quota allows validation again");
  });
  assert.equal(outbound, 0, "these regressions must never contact OpenAI");
});
