# Tempo — Chess coach

A compact chess practice app with 18 curated tactical positions: six each for Beginner, Intermediate, and Advanced. Click a piece and a highlighted destination, ask for a hint, or ask the coach a question.

The Decisions API selects a coaching action. The Responses API writes a short explanation using the selected action, verified exercise facts, and deterministic move feedback. Chess.js checks legality and replays the curated line; the model does not judge whether a move is correct. A different legal move stays on the original position so you can try again, and any actual immediate checkmate is accepted.

Comparison questions check every legal move from the position before the learner's last accepted move for immediate checkmate. The coach can distinguish an immediate win and equally good mates; it does not claim to rank longer continuations or earlier moves in the sequence.

Unclear questions get a short request to rephrase; unrelated requests get a friendly return to chess. Decisions selects these conversational actions before any puzzle hints reach the writer. The app returns a fixed reply without a Responses call, revealing clues, or advancing the hint level.

## Run locally

Requires Node.js 22.13 or newer.

```sh
npm ci
cp .env.example .env.local
```

Set `OPENAI_API_KEY` in `.env.local` to your own project key with access to `gpt-6-luna` and the Decisions and Responses APIs. Keep that file private.

```sh
npm run build
for migration in drizzle/*.sql; do
  node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file "$migration" || exit 1
done
npm run dev
```

Run database initialization once for a fresh database. For an existing database, apply only migrations that have not already run, in filename order.

Open the printed local URL. Both API requests run on the server; the key is never sent to the browser. This project uses the Sites Vinext starter with React, Tailwind CSS, and Cloudflare Workers.

## Exercises

Positions are authored for this demo and focus on a particular teaching line. They are not unrestricted engine analysis: a legal move outside that line is an invitation to retry, not a claim that the move is bad. The opponent follows the supplied continuation automatically. Use the difficulty selector to find other positions. Flip changes only the board view; reset restores the original exercise.

Pieces glide between squares, with a brief pause before the opponent replies. Reduced-motion preferences skip the movement and pause. Quiet interaction sounds are synthesized locally with Web Audio after your first interaction; the speaker button in the coach header remembers your sound preference. No audio files or extra requests are needed.

## Hosting

Configure your own `OPENAI_API_KEY` as a runtime secret and retain the logical `DB` binding. The server calls only `https://api.openai.com/v1/decisions` and `/v1/responses`, rejects redirects, and keeps the key out of browser responses. Keep the starter's Sites build integration. Missing key or database configuration fails closed with a message for the site owner.

No sign-in is required. The board and coaching conversation live in browser memory and reset on refresh; only the optional sound preference is saved locally. Responses requests use `store: false`. The app stores no coaching content or history in D1; its durable records contain only IP quota counters and expiry.

## Build and download

```sh
npm run build
```

The build regenerates `public/downloads/tempo-chess-coach.zip`. It includes runnable source, package manifest and lockfile, local assets, and blank configuration examples. Portable templates in `scripts/public-source/` keep the adapter and README reproducible. It excludes credentials, deployment identity, installed dependencies, build products, and local QA state. The app's Download project button serves this ZIP.

## Verification

The tests under `app/lib/` validate puzzle continuations, move handling, anonymous request validation, coaching decisions, and transport failure behavior. API tests mock external calls; live requests are separate checks. The server's durable per-IP quotas do not replace project-level API usage limits.

## IP usage limits

Each coaching request reserves a durable D1 quota before validation or upstream Decisions/Responses calls: **20 requests per minute and 100 per UTC day per IP**. The policy is in `app/lib/rate-limit-policy.ts`. Same-origin checks reject cross-site requests before quota reservation.

Sites supplies `CF-Connecting-IP`; client forwarding headers are ignored and equivalent IPv6 spellings are normalized. The database stores a SHA-256 digest rather than the raw IP. Both windows update atomically across Worker instances, so changing accounts or reloading does not reset the IP allowance. Attempts still consume quota if later validation or generation fails. People sharing an IP share its allowance.

A limit returns HTTP 429 with a readable cooldown, `Retry-After`, `retryAfter`, and `resetAt`. Missing trusted IP/database information or a storage error returns 503 without calling OpenAI. Expired records are removed in bounded batches on subsequent requests. These controls do not replace project-wide spend limits.

### Local quota database

The source download retains the logical `DB` binding and its schema migration, but no existing project or database identity. Sites provisions and migrates the hosted database during publication. For a fresh local checkout, build once and apply the included migration before starting the development server:

```sh
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_fantastic_wolf_cub.sql
npm run dev
```

Apply each migration only once to that local database. Local development uses a loopback IP only when `NODE_ENV=development` and the URL is localhost; it still enforces database quotas. Run `node --experimental-strip-types --test tests/*.test.mjs` for the persistent-limit and Worker route regressions.
