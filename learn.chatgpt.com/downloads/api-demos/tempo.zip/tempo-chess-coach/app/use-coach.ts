"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { Square } from "chess.js";
import { PUZZLES, type Difficulty, type Puzzle } from "./lib/puzzles";
import { evaluateAttempt, legalMoves, replayPuzzle } from "./lib/chess";
import { coachResponseSchema, type CoachRequest } from "./lib/coach-contracts";
import { useSoundEffects } from "./use-sound-effects";

interface CoachMessage { id: string; role: "user" | "assistant"; title?: string; text: string }
const greeting = (puzzle: Puzzle): CoachMessage[] => [{ id: "welcome", role: "assistant", title: puzzle.title, text: `${puzzle.brief}\n\nSelect a piece to see its legal moves.` }];
const MOVE_SETTLE_MS = 260;

export function useCoach() {
  const { soundEnabled, toggleSound, playSound, cancelSounds } = useSoundEffects();
  const [difficulty, setDifficultyValue] = useState<Difficulty>("beginner");
  const [puzzleId, setPuzzleId] = useState(PUZZLES[0].id);
  const [acceptedMoves, setAcceptedMoves] = useState<string[]>([]);
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [orientation, setOrientation] = useState<"w" | "b">("w");
  const [messages, setMessages] = useState<CoachMessage[]>(() => greeting(PUZZLES[0]));
  const [draft, setDraft] = useState("");
  const [hintCount, setHintCount] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [coachLoading, setCoachLoading] = useState(false);
  const [hintLoading, setHintLoading] = useState(false);
  const [isMoving, setIsMoving] = useState(false);
  const moving = useRef(false);
  const moveTimers = useRef(new Set<ReturnType<typeof setTimeout>>());
  const activeRequest = useRef<AbortController | null>(null);
  const requestId = useRef(0);
  const lastRequest = useRef<CoachRequest | null>(null);
  const puzzle = PUZZLES.find(item => item.id === puzzleId) ?? PUZZLES[0];
  const game = useMemo(() => replayPuzzle(puzzle, acceptedMoves), [puzzle, acceptedMoves]);
  const status = game.isCheckmate() || acceptedMoves.length >= puzzle.solution.length ? "solved" as const : "playing" as const;
  const history = game.history({ verbose: true });
  const finalMove = history.at(-1);
  const board = game.board().flatMap(rank => rank.flatMap(piece => piece ? [piece] : []));
  const legalTargets = selectedSquare && status === "playing"
    ? [...new Set(legalMoves(puzzle, acceptedMoves, selectedSquare).map(move => move.to as Square))]
    : [];

  function cancelRequest() {
    requestId.current += 1;
    activeRequest.current?.abort();
    activeRequest.current = null;
    setCoachLoading(false);
    setHintLoading(false);
  }

  useEffect(() => {
    const timers = moveTimers.current;
    return () => {
      requestId.current += 1;
      activeRequest.current?.abort();
      for (const timer of timers) clearTimeout(timer);
      timers.clear();
      cancelSounds();
    };
  }, [cancelSounds]);

  function cancelMovement() {
    for (const timer of moveTimers.current) clearTimeout(timer);
    moveTimers.current.clear();
    moving.current = false;
    setIsMoving(false);
    cancelSounds();
  }

  function afterLanding(callback: () => void) {
    const timer = setTimeout(() => {
      moveTimers.current.delete(timer);
      callback();
    }, MOVE_SETTLE_MS);
    moveTimers.current.add(timer);
  }

  function startPuzzle(next: Puzzle) {
    cancelRequest();
    cancelMovement();
    setPuzzleId(next.id);
    setDifficultyValue(next.difficulty);
    setAcceptedMoves([]);
    setSelectedSquare(null);
    setOrientation(next.orientation === "black" ? "b" : "w");
    setMessages(greeting(next));
    setDraft("");
    setHintCount(0);
    setFeedback(null);
    setError(null);
    lastRequest.current = null;
    playSound("tap");
  }

  async function askCoach(body: CoachRequest) {
    activeRequest.current?.abort();
    const controller = new AbortController();
    activeRequest.current = controller;
    const currentRequest = ++requestId.current;
    lastRequest.current = body;
    setError(null);
    setCoachLoading(true);
    setHintLoading(body.event === "hint");
    try {
      const response = await fetch("/api/coach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.any([controller.signal, AbortSignal.timeout(65_000)]),
      });
      const raw: unknown = await response.json().catch(() => null);
      if (!response.ok) {
        const message = raw && typeof raw === "object" && "error" in raw && typeof raw.error === "string"
          ? raw.error : "The coach couldn't reply. Your position is saved; try again.";
        throw new Error(message);
      }
      const parsed = coachResponseSchema.safeParse(raw);
      if (!parsed.success) throw new Error("The coach returned an incomplete reply. Your position is saved; try again.");
      const result = parsed.data;
      if (currentRequest !== requestId.current) return;
      setMessages(previous => [...previous, { id: crypto.randomUUID(), role: "assistant", title: result.title, text: result.text }]);
      playSound("notice");
    } catch (cause) {
      if (controller.signal.aborted || currentRequest !== requestId.current) return;
      setError(cause instanceof Error && cause.name !== "TimeoutError" ? cause.message : "The coach took too long. Your position is saved; try again.");
    } finally {
      if (currentRequest === requestId.current) {
        setCoachLoading(false);
        setHintLoading(false);
        activeRequest.current = null;
      }
    }
  }

  function selectSquare(square: Square) {
    if (moving.current || status === "solved") return;
    if (selectedSquare === square) { setSelectedSquare(null); return; }
    const piece = game.get(square);
    if (piece?.color === game.turn()) { setSelectedSquare(square); playSound("select"); return; }
    if (!selectedSquare) return;
    const options = legalMoves(puzzle, acceptedMoves, selectedSquare).filter(move => move.to === square);
    if (!options.length) { setFeedback("Choose a highlighted square for that piece."); playSound("tap"); return; }
    const move = options.find(option => option.promotion === "q") ?? options[0];
    const before = [...acceptedMoves];
    const result = evaluateAttempt(puzzle, before, move.uci);
    setSelectedSquare(null);
    setFeedback(result.feedback);
    if (result.verdict === "illegal") { playSound("tap"); return; }
    if (result.verdict === "legal-other") {
      playSound("tap");
    } else {
      const learnerMoves = [...before, move.uci];
      const learnerMove = replayPuzzle(puzzle, learnerMoves).history({ verbose: true }).at(-1)!;
      const replyMove = result.reply ? replayPuzzle(puzzle, result.moves).history({ verbose: true }).at(-1) : null;
      const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (reducedMotion) {
        setAcceptedMoves(result.moves);
        // With no staged visual movement, one landing cue avoids stacked clicks.
        playSound(learnerMove.captured || replyMove?.captured ? "capture" : "move");
        if (result.solved) playSound("success");
      } else {
        moving.current = true;
        setIsMoving(true);
        setAcceptedMoves(learnerMoves);
        playSound(learnerMove.captured ? "capture" : "move");
        const finish = () => {
          moving.current = false;
          setIsMoving(false);
          if (result.solved) playSound("success");
        };
        if (result.reply) {
          setFeedback(`${result.san ?? move.san}. ${puzzle.orientation === "white" ? "Black" : "White"} to move…`);
          afterLanding(() => {
            setAcceptedMoves(result.moves);
            setFeedback(result.feedback);
            playSound(replyMove?.captured ? "capture" : "move");
            afterLanding(finish);
          });
        } else {
          afterLanding(finish);
        }
      }
    }
    setMessages(previous => [...previous, { id: crypto.randomUUID(), role: "user", text: `I played ${result.san ?? move.san}.` }]);
    void askCoach({ puzzleId: puzzle.id, moves: before, event: "move", attemptedMove: move.uci, hintCount });
  }

  function hint() {
    if (moving.current || coachLoading || status === "solved") return;
    playSound("tap");
    const nextHint = Math.min(hintCount + 1, 20);
    setHintCount(nextHint);
    setMessages(previous => [...previous, { id: crypto.randomUUID(), role: "user", text: nextHint === 1 ? "Give me a hint." : "A little more help, please." }]);
    void askCoach({ puzzleId: puzzle.id, moves: acceptedMoves, event: "hint", hintCount: nextHint });
  }

  function send() {
    const message = draft.trim();
    if (moving.current || !message || coachLoading) return;
    playSound("tap");
    setDraft("");
    setMessages(previous => [...previous, { id: crypto.randomUUID(), role: "user", text: message }]);
    void askCoach({ puzzleId: puzzle.id, moves: acceptedMoves, event: "question", message, hintCount });
  }

  function nextPuzzle() {
    const pool = PUZZLES.filter(item => item.difficulty === difficulty);
    const index = pool.findIndex(item => item.id === puzzle.id);
    startPuzzle(pool[(index + 1) % pool.length]);
  }

  return {
    puzzles: PUZZLES, puzzle, difficulty,
    setDifficulty(value: Difficulty) { const next = PUZZLES.find(item => item.difficulty === value); if (next) startPuzzle(next); },
    selectPuzzle(id: string) { const next = PUZZLES.find(item => item.id === id); if (next) startPuzzle(next); },
    board, selectedSquare, legalTargets, selectSquare, orientation,
    flip() { if (moving.current) return; setOrientation(value => value === "w" ? "b" : "w"); playSound("tap"); },
    lastMove: finalMove ? { from: finalMove.from, to: finalMove.to } : null,
    status, feedback, moves: history.map(move => move.san),
    reset() { startPuzzle(puzzle); }, nextPuzzle,
    messages, draft, setDraft, send, hint, hintLoading, coachLoading, error,
    soundEnabled, toggleSound, isMoving,
    retryCoach() { if (lastRequest.current && !coachLoading && !moving.current) { playSound("tap"); void askCoach(lastRequest.current); } },
  };
}
