import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tempo — Chess coach",
  description: "Practice chess tactics with an AI coach.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
