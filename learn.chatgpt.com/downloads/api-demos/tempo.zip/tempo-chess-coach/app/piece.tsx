import type { Color, PieceSymbol } from "chess.js";

/** Original vector chess illustrations for Tempo. */
export function ChessPiece({ type, color }: { type: PieceSymbol; color: Color }) {
  return <svg viewBox="0 0 64 64" aria-hidden="true" focusable="false" className="chess-piece" data-color={color}>
    <g className="piece-body" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round">
      {type === "p" && <>
        <circle cx="32" cy="17" r="8" />
        <path d="M25 27h14l-2 7c0 7 4 11 8 15H19c4-4 8-8 8-15z" />
        <path d="M21 48h22l5 8H16z" />
      </>}
      {type === "r" && <>
        <path d="M17 10h7v7h5v-7h6v7h5v-7h7v17l-5 5 2 17H20l2-17-5-5z" />
        <path d="M20 47h24l5 9H15z" />
        <path className="piece-detail" d="M20 26h24M23 33h18" />
      </>}
      {type === "n" && <>
        <path d="m23 12 3-6 8 8c12 3 16 13 14 24l-3 11H22c0-7 3-12 10-17l-9-4-8 6-5-6 8-15z" />
        <path d="M22 47h23l5 9H17z" />
        <path className="piece-detail" d="M34 20c7 6 9 13 6 21M12 28l8 1" />
        <circle className="piece-eye" cx="25" cy="20" r="1.8" stroke="none" />
      </>}
      {type === "b" && <>
        <circle cx="32" cy="9" r="3" />
        <path d="M32 12c-5 5-12 10-12 16 0 5 5 8 12 8s12-3 12-8c0-6-7-11-12-16z" />
        <path d="M26 35h12c-1 5 0 9 6 14H20c6-5 7-9 6-14z" />
        <path d="M20 48h24l5 8H15z" />
        <path className="piece-detail" d="m35 19-7 10" />
      </>}
      {type === "q" && <>
        <path d="m14 19 8 9 3-13 7 12 7-12 3 13 8-9-7 22H21z" />
        <circle cx="13" cy="16" r="3" /><circle cx="24" cy="11" r="3" /><circle cx="40" cy="11" r="3" /><circle cx="51" cy="16" r="3" />
        <path d="M23 40h18l2 9H21zM20 48h24l5 8H15z" />
        <path className="piece-detail" d="M22 35h20" />
      </>}
      {type === "k" && <>
        <path d="M29 5h6v6h6v6h-6v7h-6v-7h-6v-6h6z" />
        <path d="M32 28c-9-12-21-8-18 1 1 4 6 7 8 12h20c2-5 7-8 8-12 3-9-9-13-18-1z" />
        <path d="M23 40h18l2 9H21zM20 48h24l5 8H15z" />
        <path className="piece-detail" d="M22 35h20" />
      </>}
    </g>
  </svg>;
}
