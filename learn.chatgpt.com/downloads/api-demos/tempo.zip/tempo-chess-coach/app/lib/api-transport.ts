export type OpenAIPath = "/decisions" | "/responses";
export type WorkerBindings = { OPENAI_API_KEY?: string };

/** The source download uses the owner's own API key at the public API origin. */
export async function apiTransport(path: OpenAIPath, directFetch: typeof fetch, _bindings?: WorkerBindings | null) {
  return { url: `https://api.openai.com/v1${path}`, fetch: directFetch };
}
