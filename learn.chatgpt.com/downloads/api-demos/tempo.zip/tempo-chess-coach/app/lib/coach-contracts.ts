import { z } from "zod";

export const COACH_MODEL = "gpt-6-luna";
export const uciSchema = z.string().regex(/^[a-h][1-8][a-h][1-8][qrbn]?$/);
export const coachRequestSchema = z.object({
  puzzleId: z.string().min(1).max(80).regex(/^[a-z0-9-]+$/),
  moves: z.array(uciSchema).max(20),
  event: z.enum(["hint", "move", "question"]),
  attemptedMove: uciSchema.optional(),
  message: z.string().trim().min(1).max(500).optional(),
  hintCount: z.number().int().min(0).max(20),
}).strict().superRefine((value, context) => {
  if (value.event === "move" && !value.attemptedMove) context.addIssue({ code: z.ZodIssueCode.custom, path: ["attemptedMove"], message: "A move is required." });
  if (value.event !== "move" && value.attemptedMove) context.addIssue({ code: z.ZodIssueCode.custom, path: ["attemptedMove"], message: "A move belongs to a move event." });
  if (value.event === "question" && !value.message) context.addIssue({ code: z.ZodIssueCode.custom, path: ["message"], message: "A question is required." });
});
export type CoachRequest = z.infer<typeof coachRequestSchema>;

export const coachActionSchema = z.enum(["piece_hint", "plan_hint", "review_move", "compare_moves", "explain_tactic", "suggest_next", "clarify_question", "redirect_to_chess"]);
export type CoachAction = z.infer<typeof coachActionSchema>;
export const coachTitles: Record<CoachAction, string> = {
  piece_hint: "Find the piece",
  plan_hint: "See the plan",
  review_move: "Review your move",
  compare_moves: "Compare your move",
  explain_tactic: "Understand the tactic",
  suggest_next: "Keep your momentum",
  clarify_question: "Could you rephrase?",
  redirect_to_chess: "Let's talk chess",
};

// Match Structured Outputs and local validation, including astral characters.
const textPattern = "^[\\s\\S]{1,600}$";
export const coachTextSchema = z.object({ text: z.string().regex(new RegExp(textPattern, "u")) }).strict();
export const coachTextJsonSchema = {
  type: "object",
  properties: { text: { type: "string", pattern: textPattern } },
  required: ["text"], additionalProperties: false,
};
export const coachResponseSchema = z.object({
  action: coachActionSchema,
  title: z.string().min(1).max(80),
  text: coachTextSchema.shape.text,
}).strict();
export type CoachResponse = z.infer<typeof coachResponseSchema>;
