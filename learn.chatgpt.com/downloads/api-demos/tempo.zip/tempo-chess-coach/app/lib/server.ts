import { z } from "zod";
import { apiTransport, type OpenAIPath, type WorkerBindings } from "./api-transport.ts";

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export const privateHeaders = {
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
};

export function guardRequest(request: Request): void {
  const url = new URL(request.url);
  if (request.headers.get("origin") !== url.origin || request.headers.get("sec-fetch-site") === "cross-site") {
    throw new ApiError(403, "Open the app in its own tab and try again.");
  }
  // Public visitors need no account. The route reserves its durable, trusted-IP
  // quota before validation or either paid API call.
}

async function boundedText(body: ReadableStream<Uint8Array> | null, maxBytes: number, timeoutMs?: number): Promise<string> {
  if (!body) return "";
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let size = 0;
  let text = "";
  let timedOut = false;
  const timer = timeoutMs === undefined ? undefined : setTimeout(() => {
    timedOut = true;
    void reader.cancel().catch(() => undefined);
  }, timeoutMs);
  try {
    while (true) {
      const chunk = await reader.read();
      if (timedOut) throw new ApiError(408, "The request took too long to arrive. Please try again.");
      if (chunk.done) break;
      size += chunk.value.byteLength;
      if (size > maxBytes) {
        await reader.cancel();
        throw new ApiError(413, "This request is too large. Try a shorter question.");
      }
      text += decoder.decode(chunk.value, { stream: true });
    }
    return text + decoder.decode();
  } finally {
    clearTimeout(timer);
    reader.releaseLock();
  }
}

export async function parseBody<S extends z.ZodTypeAny>(request: Request, schema: S): Promise<z.output<S>> {
  if (request.headers.get("content-type")?.split(";")[0].trim() !== "application/json") {
    throw new ApiError(415, "Send this request as JSON.");
  }
  const declaredLength = Number(request.headers.get("content-length") ?? 0);
  if (declaredLength > 32_000) throw new ApiError(413, "This request is too large. Try a shorter question.");
  let body: unknown;
  try {
    body = JSON.parse(await boundedText(request.body, 32_000, 10_000));
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(400, "The request could not be read. Please try again.");
  }
  const result = schema.safeParse(body);
  if (!result.success) throw new ApiError(400, "Check your puzzle and question, then try again.");
  return result.data;
}

export async function getOpenAIKey(workerBindings?: WorkerBindings | null): Promise<string> {
  let bindings = workerBindings;
  if (bindings === undefined) {
    try {
      const { env } = await import("cloudflare:workers");
      bindings = env as unknown as WorkerBindings;
    } catch {
      // The Cloudflare binding is unavailable in a plain Node development runner.
      bindings = null;
    }
  }
  const key = bindings?.OPENAI_API_KEY || (process.env.NODE_ENV === "development" ? process.env.OPENAI_API_KEY : undefined);
  if (!key) throw new ApiError(503, "The coach is not configured yet. The site owner needs to connect its OpenAI API key.");
  return key;
}

async function logOpenAIError(response: Response, path: string, key: string): Promise<void> {
  // Only bounded identifiers are useful here. Never log raw upstream text: an
  // authentication error can include a credential, and other errors may echo input.
  const identifier = (value: unknown, pattern: RegExp, maxLength: number): string | null => {
    if (typeof value !== "string" || value.length > maxLength || value.includes(key)
      || /sk[-_]/i.test(value) || !pattern.test(value)) return null;
    return value;
  };
  let error: Record<string, unknown> = {};
  try {
    const body: unknown = JSON.parse(await boundedText(response.body, 16_000, 2_000));
    if (body && typeof body === "object" && "error" in body
      && body.error && typeof body.error === "object" && !Array.isArray(body.error)) {
      error = body.error as Record<string, unknown>;
    }
  } catch {
    // HTML, oversized bodies, and failed reads must not hide the HTTP status.
  }
  console.error(JSON.stringify({
    event: "openai_request_failed",
    path,
    status: response.status,
    code: identifier(error.code, /^[a-z][a-z0-9_]*$/, 64),
    type: identifier(error.type, /^[a-z][a-z0-9_]*$/, 64),
    param: identifier(error.param, /^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*|\[\d{1,4}\])*$/, 128),
    requestId: identifier(response.headers.get("x-request-id"), /^req_[A-Za-z0-9]+$/, 96),
  }));
}

export async function postOpenAI(
  path: OpenAIPath,
  payload: unknown,
  signal: AbortSignal,
  dependencies: { key?: string; fetch?: typeof fetch; timeoutMs?: number; workerBindings?: WorkerBindings | null } = {},
): Promise<unknown> {
  if (path !== "/decisions" && path !== "/responses") throw new ApiError(500, "Unsupported coaching operation.");
  const key = dependencies.key ?? await getOpenAIKey(dependencies.workerBindings);
  if (!key) throw new ApiError(503, "The coach is not configured yet. The site owner needs to connect its OpenAI API key.");
  const timeout = AbortSignal.timeout(dependencies.timeoutMs ?? 30_000);
  try {
    const transport = await apiTransport(path, dependencies.fetch ?? fetch, dependencies.workerBindings);
    if (!transport) throw new ApiError(503, "The coach is not connected yet. The site owner needs to configure its API connection.");
    // Workerd's global fetch must be called without an adapter-object receiver.
    const { fetch: send, url } = transport;
    const response = await send(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify(payload),
      signal: AbortSignal.any([signal, timeout]),
      redirect: "manual",
    });
    if (response.status >= 300 && response.status < 400) {
      await response.body?.cancel().catch(() => undefined);
      throw new ApiError(502, "The coach could not reach OpenAI. Please try again shortly.");
    }
    if (!response.ok) {
      await logOpenAIError(response, path, key);
      if (response.status === 429) throw new ApiError(429, "The coach has reached its API limit. Try again shortly, or ask the site owner to check the project's quota.");
      if (response.status === 401) throw new ApiError(503, "OpenAI rejected the coach's API credentials. The site owner should check the deployed API key.");
      if (response.status === 403) throw new ApiError(503, "OpenAI denied this request. The site owner should check the API key's project permissions and access restrictions.");
      if (response.status === 404) throw new ApiError(503, "This API is not available for the coach. The site owner should check the API connection and project access.");
      throw new ApiError(502, "The coach could not finish this request. Your board is still here; please try again.");
    }
    let text: string;
    try {
      text = await boundedText(response.body, 256_000);
    } catch (error) {
      if (error instanceof ApiError) throw new ApiError(502, "The coach returned an unexpected response. Please try again.");
      throw error;
    }
    try {
      return JSON.parse(text);
    } catch {
      throw new ApiError(502, "The coach returned an unreadable response. Please try again.");
    }
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (timeout.aborted) throw new ApiError(504, "The coach took too long to respond. Please try again.");
    if (signal.aborted) throw new ApiError(408, "The request was canceled. Start again when you're ready.");
    throw new ApiError(502, "The coach could not reach OpenAI. Please try again shortly.");
  }
}

const responseSchema = z.object({
  status: z.string(),
  output: z.array(z.object({
    type: z.string(),
    content: z.array(z.object({
      type: z.string(),
      text: z.string().optional(),
    })).optional(),
  })),
});

export function responseText(value: unknown): string {
  const parsed = responseSchema.safeParse(value);
  if (!parsed.success || parsed.data.status !== "completed") {
    throw new ApiError(502, "The coach's response was incomplete. Please try again.");
  }
  const content = parsed.data.output.filter((item) => item.type === "message").flatMap((item) => item.content ?? []);
  if (content.some((part) => part.type === "refusal")) {
    throw new ApiError(422, "Let's return to the chess puzzle. Try a different question.");
  }
  const text = content.filter((part) => part.type === "output_text").map((part) => part.text ?? "").join("").trim();
  if (!text) throw new ApiError(502, "The coach returned no reply. Please try again.");
  return text;
}

export function errorResponse(error: unknown): Response {
  const status = error instanceof ApiError ? error.status : 500;
  return Response.json({ error: error instanceof ApiError ? error.message : "Something went wrong. Please try again." }, {
    status,
    headers: { ...privateHeaders, ...(status === 429 ? { "Retry-After": "60" } : {}) },
  });
}
