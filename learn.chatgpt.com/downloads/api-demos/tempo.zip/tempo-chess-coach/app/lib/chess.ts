import { Chess, type Move, type Square } from "chess.js";
import type { Puzzle } from "./puzzles";

export interface LegalMove {
  from: string;
  to: string;
  promotion?: string;
  uci: string;
  san: string;
}

export interface MoveEvaluation {
  verdict: "correct" | "alternative-mate" | "legal-other" | "illegal";
  /** Accepted position and history; unsuccessful attempts leave both unchanged. */
  fen: string;
  moves: string[];
  solved: boolean;
  san?: string;
  reply?: { uci: string; san: string };
  feedback: string;
}

const UCI = /^[a-h][1-8][a-h][1-8][qrbn]?$/;
const SQUARE = /^[a-h][1-8]$/;

function moveInput(uci: string) {
  if (!UCI.test(uci)) throw new Error("Use a valid UCI move.");
  return {
    from: uci.slice(0, 2) as Square,
    to: uci.slice(2, 4) as Square,
    ...(uci.length === 5 ? { promotion: uci[4] } : {}),
  };
}

function summarize(move: Move): LegalMove {
  return {
    from: move.from,
    to: move.to,
    ...(move.promotion ? { promotion: move.promotion } : {}),
    uci: move.from + move.to + (move.promotion ?? ""),
    san: move.san,
  };
}

function applyUci(game: Chess, uci: string): Move {
  const move = game.move(moveInput(uci));
  // chess.js ignores an unnecessary promotion field on a non-pawn move. Keep
  // accepted history canonical instead of treating "e1e8q" as a distinct mate.
  if (move.from + move.to + (move.promotion ?? "") !== uci) {
    game.undo();
    throw new Error("The promotion choice does not match this move.");
  }
  return move;
}

/**
 * Reconstruct only accepted exercise history. A final learner move can differ
 * from the teaching line if chess.js verifies that it immediately checkmates.
 * Never trust client-supplied FEN or an arbitrary legal game as puzzle progress.
 */
export function replayPuzzle(puzzle: Puzzle, moves: readonly string[] = []): Chess {
  if (moves.length > puzzle.solution.length) {
    throw new Error("The move history extends past this exercise.");
  }
  const game = new Chess(puzzle.fen);
  if (game.turn() !== puzzle.orientation[0]) {
    throw new Error("The puzzle orientation must match the side to move.");
  }
  for (let index = 0; index < moves.length; index += 1) {
    const uci = moves[index];
    const followsLine = uci === puzzle.solution[index];
    applyUci(game, uci);
    if (
      !followsLine &&
      !(index % 2 === 0 && index === moves.length - 1 && game.isCheckmate())
    ) {
      throw new Error("The move history is not an accepted puzzle line.");
    }
  }
  return game;
}

export function legalMoves(
  puzzle: Puzzle,
  moves: readonly string[] = [],
  from?: string,
): LegalMove[] {
  const game = replayPuzzle(puzzle, moves);
  if (moves.length === puzzle.solution.length || game.isGameOver()) return [];
  if (from !== undefined && !SQUARE.test(from)) return [];
  const options = from ? { square: from as Square, verbose: true as const } : { verbose: true as const };
  return game.moves(options).map(summarize);
}

/** Compare the last accepted learner move using an exhaustive one-ply mate check. */
export function compareLastMove(puzzle: Puzzle, moves: readonly string[]) {
  const history = replayPuzzle(puzzle, moves).history({ verbose: true });
  const index = history.findLastIndex((move) => move.color === puzzle.orientation[0]);
  if (index < 0) return null;

  const played = history[index];
  const before = new Chess(played.before);
  const immediateMates: LegalMove[] = [];
  for (const candidate of before.moves({ verbose: true })) {
    const move = before.move(candidate);
    if (before.isCheckmate()) immediateMates.push(summarize(move));
    before.undo();
  }
  const checkmate = new Chess(played.after).isCheckmate();
  return {
    scope: "last-accepted-learner-move" as const,
    learnerMoveNumber: Math.floor(index / 2) + 1,
    playedMove: summarize(played),
    checkmate,
    immediateMates,
    verdict: checkmate ? "immediate-mate" as const
      : immediateMates.length ? "mate-available" as const : "not-ranked" as const,
  };
}

/** Apply a learner move, then the curated opponent reply, without mutating inputs. */
export function evaluateAttempt(
  puzzle: Puzzle,
  moves: readonly string[],
  uci: string,
): MoveEvaluation {
  const game = replayPuzzle(puzzle, moves);
  const unchanged = {
    fen: game.fen(),
    moves: [...moves],
    solved: moves.length === puzzle.solution.length || game.isCheckmate(),
  };
  if (unchanged.solved) {
    return { ...unchanged, verdict: "illegal", feedback: "This exercise is already complete." };
  }
  if (moves.length % 2 !== 0 || game.turn() !== puzzle.orientation[0]) {
    return { ...unchanged, verdict: "illegal", feedback: "It is the other side's turn." };
  }

  let attempted: Move;
  try {
    attempted = applyUci(game, uci);
  } catch {
    return {
      ...unchanged,
      verdict: "illegal",
      feedback: "That move is not legal here. Choose one of the highlighted squares.",
    };
  }

  const expected = puzzle.solution[moves.length];
  const mate = game.isCheckmate();
  if (uci !== expected && !mate) {
    return {
      ...unchanged,
      verdict: "legal-other",
      san: attempted.san,
      feedback: `${attempted.san} is legal, but it is not the line in this exercise. Try another move.`,
    };
  }

  const accepted = [...moves, uci];
  if (mate) {
    return {
      verdict: uci === expected ? "correct" : "alternative-mate",
      fen: game.fen(),
      moves: accepted,
      solved: true,
      san: attempted.san,
      feedback: `${attempted.san} is checkmate${uci === expected ? "." : " too. This finishes the puzzle."}`,
    };
  }

  let reply: MoveEvaluation["reply"];
  if (accepted.length < puzzle.solution.length) {
    const replyUci = puzzle.solution[accepted.length];
    const replyMove = applyUci(game, replyUci);
    accepted.push(replyUci);
    reply = { uci: replyUci, san: replyMove.san };
  }
  const solved = accepted.length === puzzle.solution.length;
  return {
    verdict: "correct",
    fen: game.fen(),
    moves: accepted,
    solved,
    san: attempted.san,
    ...(reply ? { reply } : {}),
    feedback: solved
      ? `${attempted.san} completes the tactic.`
      : `${attempted.san} follows the tactic.${reply ? ` ${puzzle.orientation === "white" ? "Black" : "White"} replies ${reply.san}.` : ""}`,
  };
}
