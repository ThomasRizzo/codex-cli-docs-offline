// Per-IP request allowances. Windows reset at UTC minute/day boundaries.
// Keep simulation allowances large enough for a complete normal run.
export const IP_LIMITS = {
  "coach": {
    "minute": 20,
    "day": 100
  }
} as const;
