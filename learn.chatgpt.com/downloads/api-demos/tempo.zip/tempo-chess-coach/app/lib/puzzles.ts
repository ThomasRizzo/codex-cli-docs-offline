export type Difficulty = "beginner" | "intermediate" | "advanced";

export interface Puzzle {
  id: string;
  title: string;
  theme: string;
  difficulty: Difficulty;
  fen: string;
  orientation: "white" | "black";
  solution: string[];
  brief: string;
  hints: string[];
  explanation: string;
}

// Small instructional compositions, not positions attributed to historical games.
// Every line is checked with chess.js in chess.test.mjs. The line is a teaching
// variation, not an engine's verdict on every other legal move.
export const PUZZLES: Puzzle[] = [
  {
    id: "back-rank",
    title: "The last rank",
    theme: "Back-rank mate",
    difficulty: "beginner",
    fen: "6k1/5ppp/8/8/8/8/5PPP/4R1K1 w - - 0 1",
    orientation: "white",
    solution: ["e1e8"],
    brief: "White to move. Find checkmate in one.",
    hints: [
      "Your rook can use the open e-file.",
      "Black's own pawns block the king's escape squares.",
      "Check along the eighth rank, where the king has no cover.",
    ],
    explanation:
      "Re8# checks along the eighth rank. The rook covers f8 and h8, while Black's pawns occupy f7, g7, and h7. The king has no legal escape.",
  },
  {
    id: "queen-support",
    title: "A little support",
    theme: "Queen and king",
    difficulty: "beginner",
    fen: "7k/8/5KQ1/8/8/8/8/8 w - - 0 1",
    orientation: "white",
    solution: ["g6g7"],
    brief: "White to move. Find checkmate in one.",
    hints: [
      "The queen can move next to the black king.",
      "Your king must protect the queen's landing square.",
      "Look for a queen check on a square covered by the king on f6.",
    ],
    explanation:
      "Qg7# covers g8 and h7 and checks the king on h8. The white king on f6 protects g7, so Black cannot capture the queen.",
  },
  {
    id: "loose-queen",
    title: "A clear target",
    theme: "Undefended pieces",
    difficulty: "beginner",
    fen: "6k1/5ppp/8/q7/8/8/5PPP/R5K1 w - - 0 1",
    orientation: "white",
    solution: ["a1a5"],
    brief: "White to move. Win the undefended queen.",
    hints: [
      "Look for an enemy piece that nothing protects.",
      "Your rook and Black's queen share the same file.",
      "The a-file is clear between a1 and a5. Capture the queen."
    ],
    explanation: "Rxa5 captures Black's undefended queen. The rook travels straight up the clear a-file, and no black piece can recapture it. This wins material and completes the exercise; it is not checkmate."
  },
  {
    id: "diagonal-capture",
    title: "Across the board",
    theme: "Bishop diagonals",
    difficulty: "beginner",
    fen: "6k1/5pbp/6p1/8/8/8/1R3PPP/6K1 b - - 0 1",
    orientation: "black",
    solution: ["g7b2"],
    brief: "Black to move. Win the undefended rook.",
    hints: [
      "Trace the bishop's diagonals and look for a valuable target.",
      "The rook on b2 has no defender.",
      "The diagonal from g7 to b2 is clear. Your bishop can capture the rook."
    ],
    explanation: "Bxb2 wins the undefended rook. The bishop follows the clear g7–b2 diagonal, and White has no piece that can recapture it. This completes the material-winning exercise; the game itself continues."
  },
  {
    id: "first-promotion",
    title: "One square away",
    theme: "Pawn promotion",
    difficulty: "beginner",
    fen: "8/P6k/5K2/8/8/8/8/8 w - - 0 1",
    orientation: "white",
    solution: ["a7a8q"],
    brief: "White to move. Promote your pawn.",
    hints: [
      "A pawn becomes another piece when it reaches the farthest rank.",
      "Your pawn on a7 is one step from the eighth rank.",
      "Move from a7 to a8. The demo promotes the pawn to a queen."
    ],
    explanation: "a8=Q promotes the pawn to a queen, the most powerful piece. Black's king is too far away to capture it. The promotion completes this exercise; there is still a game to finish."
  },
  {
    id: "rook-ladder",
    title: "Closing the ladder",
    theme: "Two-rook mate",
    difficulty: "beginner",
    fen: "r5k1/8/8/8/8/8/1r6/7K b - - 0 1",
    orientation: "black",
    solution: ["a8a1"],
    brief: "Black to move. Find checkmate in one.",
    hints: [
      "The rook on b2 already keeps the white king off the second rank.",
      "Use your other rook to check along the first rank.",
      "Move the rook from a8 to a1, leaving the b2 rook in place."
    ],
    explanation: "Ra1# checks along the first rank and covers g1. The rook on b2 covers g2 and h2, so the king cannot step onto the second rank. The two rooks close every escape."
  },
  {
    id: "royal-fork",
    title: "Two targets",
    theme: "Knight fork",
    difficulty: "intermediate",
    fen: "7k/4q3/8/4N3/8/8/8/6K1 w - - 0 1",
    orientation: "white",
    solution: ["e5g6", "h8g8", "g6e7"],
    brief: "White to move. Fork the king and queen.",
    hints: [
      "The knight can attack two valuable pieces at once.",
      "A check makes Black deal with the king before saving the queen.",
      "Find the knight square that attacks both h8 and e7.",
    ],
    explanation:
      "Ng6+ attacks the king on h8 and the queen on e7. Black must move the king; this line uses Kg8. Nxe7 then takes the queen. This completes the material-winning exercise, rather than ending the game in mate.",
  },
  {
    id: "rook-deflection",
    title: "Draw the defender",
    theme: "Deflection",
    difficulty: "intermediate",
    fen: "3r2k1/5ppp/8/8/4Q3/8/5PPP/4R1K1 w - - 0 1",
    orientation: "white",
    solution: ["e4e8", "d8e8", "e1e8"],
    brief: "White to move. Force checkmate in two.",
    hints: [
      "The queen can force the black rook onto a new square.",
      "Your rook is ready to follow the queen up the e-file.",
      "Offer the queen with check on the back rank; the rook must take it.",
    ],
    explanation:
      "Qe8+ forces Rxe8: the black king's own pawns prevent escape. The queen's move clears the e-file, so Rxe8# follows. The defending rook is drawn onto the square where White can capture it with mate.",
  },
  {
    id: "arabian-net",
    title: "A knight's reach",
    theme: "Arabian mate",
    difficulty: "intermediate",
    fen: "6kr/8/8/8/8/5n2/7P/7K b - - 0 1",
    orientation: "black",
    solution: ["h8h2"],
    brief: "Black to move. Find checkmate in one.",
    hints: [
      "Your rook and knight can finish the attack together.",
      "The knight protects h2 and takes away the king's g1 escape.",
      "Capture the pawn with the rook, using the knight's protection.",
    ],
    explanation:
      "Rxh2# places the rook beside the king. The knight on f3 protects h2 and covers g1, while the rook covers g2. White can neither capture the rook nor escape.",
  },
  {
    id: "bishop-skewer",
    title: "Behind the king",
    theme: "Bishop skewer",
    difficulty: "intermediate",
    fen: "7k/2b3pp/8/8/3K4/8/5Q2/8 b - - 0 1",
    orientation: "black",
    solution: ["c7b6", "d4c3", "b6f2"],
    brief: "Black to move. Skewer the king and queen.",
    hints: [
      "The white king and queen share a diagonal.",
      "Check the king from the other end of that diagonal.",
      "From b6, the bishop looks through d4 toward the queen on f2."
    ],
    explanation: "Bb6+ lines up the king on d4 and queen on f2. White must move the king; this line uses Kc3. Bxf2 then wins the queen. Every legal king reply leaves the queen exposed to the same capture."
  },
  {
    id: "double-check-gain",
    title: "Two checks at once",
    theme: "Double check",
    difficulty: "intermediate",
    fen: "4k3/8/8/1q6/4B3/8/8/4R1K1 w - - 0 1",
    orientation: "white",
    solution: ["e4c6", "e8f8", "c6b5"],
    brief: "White to move. Use double check to win the queen.",
    hints: [
      "Your bishop is blocking the rook's path to the king.",
      "Move the bishop so it also checks the king and attacks the queen.",
      "On c6, the bishop checks along c6–d7–e8 and attacks b5."
    ],
    explanation: "Bc6+ gives double check: the bishop attacks e8 and uncovers the rook on e1. Black must move the king, so the queen cannot capture the bishop or block the rook. After Kf8, Bxb5 wins the queen; the same capture works after either other legal king reply."
  },
  {
    id: "pinned-defender",
    title: "Hold the defender",
    theme: "Absolute pin",
    difficulty: "intermediate",
    fen: "5k2/4bp2/5r1P/6B1/8/8/8/R5K1 w - - 0 1",
    orientation: "white",
    solution: ["a1a8", "e7d8", "g5f6"],
    brief: "White to move. Win the rook and keep your bishop.",
    hints: [
      "The bishop on e7 is defending the rook on f6.",
      "A back-rank check can force that defender into a pin.",
      "Ra8+ forces Bd8. Then ask whether that bishop can still capture on f6."
    ],
    explanation: "Ra8+ forces Bd8: the king has no safe move, with White's h6 pawn covering g7. Bxf6 then wins the rook. Black's bishop cannot recapture because leaving d8 would expose its king to the rook on a8."
  },
  {
    id: "smothered-mate",
    title: "No room to move",
    theme: "Smothered mate",
    difficulty: "advanced",
    fen: "5rk1/5Npp/4Q3/8/8/8/8/6K1 w - - 0 1",
    orientation: "white",
    solution: ["f7h6", "g8h8", "e6g8", "f8g8", "h6f7"],
    brief: "White to move. Force checkmate in three.",
    hints: [
      "Moving the knight can uncover the queen's diagonal to the king.",
      "A double check forces a king move. Then look for a queen sacrifice.",
      "Use the knight to protect g8, then draw Black's rook onto that square.",
    ],
    explanation:
      "Nh6+ gives double check: the knight attacks g8 and opens the queen's e6–g8 diagonal. After the forced Kh8, Qg8+ forces Rxg8. Nf7# then traps the king behind its own rook and pawns.",
  },
  {
    id: "minor-piece-net",
    title: "Pieces over points",
    theme: "Légal mating pattern",
    difficulty: "advanced",
    fen: "r2qkbnr/ppp2ppp/2np4/4N3/2B1P3/2N5/PPPP1PPP/R1BbK2R w KQkq - 0 1",
    orientation: "white",
    solution: ["c4f7", "e8e7", "c3d5"],
    brief: "White to move. Force checkmate in two.",
    hints: [
      "The bishop can check while protected by the knight on e5.",
      "Force the king forward, then bring the other knight into the attack.",
      "The knight on c3 can check the king from d5 after the bishop moves.",
    ],
    explanation:
      "Bxf7+ is protected by the knight on e5. Black's only legal reply is Ke7. Nd5# completes the net: the two knights and bishop cover the king's exits, and Black's own pieces block the remaining squares.",
  },
  {
    id: "anastasia-net",
    title: "Open the h-file",
    theme: "Anastasia's mate",
    difficulty: "advanced",
    fen: "5r1k/4N1pp/8/7Q/8/8/1K6/R7 w - - 0 1",
    orientation: "white",
    solution: ["h5h7", "h8h7", "a1h1"],
    brief: "White to move. Force checkmate in two.",
    hints: [
      "The knight on e7 already covers g8 and g6.",
      "Draw the king onto the h-file, where the rook can give check.",
      "A queen capture can remove h7's pawn and lure the king away from h8.",
    ],
    explanation:
      "Qxh7+ forces Kxh7. Rh1# then checks up the open h-file. The knight covers g8 and g6, Black's pawn occupies g7, and the rook covers every h-file escape.",
  },
  {
    id: "crossed-diagonals",
    title: "Crossed diagonals",
    theme: "Boden's mate",
    difficulty: "advanced",
    fen: "rk1r4/pp1R4/2b1K3/6B1/Q3P3/8/4B3/8 w - - 0 1",
    orientation: "white",
    solution: ["g5f4", "b8c8", "a4c6", "b7c6", "e2a6"],
    brief: "White to move. Force checkmate in three.",
    hints: [
      "The two bishops can control crossing diagonals around the king.",
      "Force the king onto c8, where the b7-pawn blocks the other bishop's route.",
      "Sacrifice the queen on c6 to remove the b7-pawn, then check with the other bishop from a6."
    ],
    explanation: "Bf4+ forces Kc8. Qxc6+ removes the bishop and forces bxc6, opening the a6–c8 diagonal. Ba6# follows: the bishop on f4 covers b8 and c7, Black's rook occupies d8, and the rook on d7 is protected by White's king."
  },
  {
    id: "pawn-assisted-mate",
    title: "Pawn power",
    theme: "Damiano's mate",
    difficulty: "advanced",
    fen: "2k5/8/8/4q3/3pp3/6pr/5PP1/5RK1 b - - 0 1",
    orientation: "black",
    solution: ["h3h1", "g1h1", "e5h5", "h1g1", "h5h2"],
    brief: "Black to move. Force checkmate in three.",
    hints: [
      "The pawn on g3 protects h2 and takes away an important escape square.",
      "A rook sacrifice can lure the king into the corner and clear a file for the queen.",
      "After the king takes the rook, bring the queen to h5 with check, then use h2."
    ],
    explanation: "Rh1+ forces Kxh1, clearing the h-file. Qh5+ forces Kg1, then Qh2# finishes. The pawn on g3 protects the queen on h2, the queen covers h1, and White's own rook and pawns block f1, f2, and g2."
  },
  {
    id: "clear-the-diagonal",
    title: "Clear the diagonal",
    theme: "Clearance sacrifice",
    difficulty: "advanced",
    fen: "r5k1/5ppp/8/4N2Q/8/2B5/8/1K6 w - - 0 1",
    orientation: "white",
    solution: ["h5f7", "g8h8", "e5g6", "h7g6", "f7g7"],
    brief: "White to move. Force checkmate in three.",
    hints: [
      "The knight on e5 blocks the bishop on c3 from protecting g7.",
      "Force the king into the corner, then find a knight check that opens the bishop’s diagonal.",
      "Ng6+ opens the bishop's diagonal. After the forced pawn capture, the queen can take g7 safely."
    ],
    explanation: "Qxf7+ forces Kh8. Ng6+ clears the c3–g7 diagonal and forces hxg6. Qxg7# is now protected by the bishop on c3, so the king cannot capture the queen. The queen also covers g8 and h7."
  },
];

export function getPuzzle(id: string): Puzzle | undefined {
  return PUZZLES.find((puzzle) => puzzle.id === id);
}
