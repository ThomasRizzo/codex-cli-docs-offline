"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export type SoundCue = "select" | "move" | "capture" | "success" | "notice" | "tap";

type Tone = {
  frequency: number;
  endFrequency?: number;
  duration: number;
  volume: number;
  delay?: number;
  waveform?: OscillatorType;
};

const PREFERENCE_KEY = "tempo-sound-enabled";
const TONES: Record<SoundCue, Tone[]> = {
  select: [{ frequency: 440, endFrequency: 350, duration: 0.045, volume: 0.018, waveform: "triangle" }],
  tap: [{ frequency: 620, endFrequency: 480, duration: 0.04, volume: 0.012 }],
  move: [
    { frequency: 255, endFrequency: 150, duration: 0.09, volume: 0.05 },
    { frequency: 780, endFrequency: 280, duration: 0.03, volume: 0.014, waveform: "triangle" },
  ],
  capture: [
    { frequency: 180, endFrequency: 85, duration: 0.12, volume: 0.055 },
    { frequency: 480, endFrequency: 230, duration: 0.05, volume: 0.012, waveform: "triangle" },
  ],
  success: [
    { frequency: 523.25, duration: 0.18, volume: 0.025 },
    { frequency: 659.25, duration: 0.2, volume: 0.022, delay: 0.09 },
    { frequency: 783.99, duration: 0.26, volume: 0.018, delay: 0.18 },
  ],
  notice: [{ frequency: 210, endFrequency: 185, duration: 0.075, volume: 0.018 }],
};

export function useSoundEffects() {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const enabled = useRef(true);
  const mounted = useRef(false);
  const context = useRef<AudioContext | null>(null);
  const voices = useRef(new Map<OscillatorNode, GainNode>());
  const generation = useRef(0);

  const cancelSounds = useCallback(() => {
    generation.current += 1;
    for (const [oscillator, gain] of voices.current) {
      oscillator.onended = null;
      try { oscillator.stop(); } catch { /* The voice may already have ended. */ }
      oscillator.disconnect();
      gain.disconnect();
    }
    voices.current.clear();
  }, []);

  useEffect(() => {
    mounted.current = true;
    try {
      enabled.current = localStorage.getItem(PREFERENCE_KEY) !== "false";
      setSoundEnabled(enabled.current);
    } catch { /* Sound remains optional when storage is unavailable. */ }

    function onVisibilityChange() {
      if (!document.hidden) return;
      cancelSounds();
      const audio = context.current;
      if (audio?.state === "running") void audio.suspend().catch(() => {});
    }
    document.addEventListener("visibilitychange", onVisibilityChange);
    return () => {
      mounted.current = false;
      document.removeEventListener("visibilitychange", onVisibilityChange);
      cancelSounds();
      const audio = context.current;
      context.current = null;
      if (audio && audio.state !== "closed") void audio.close().catch(() => {});
    };
  }, [cancelSounds]);

  const playSound = useCallback((cue: SoundCue) => {
    if (!mounted.current || !enabled.current || document.hidden) return;
    const userGesture = navigator.userActivation?.isActive === true;
    let audio = context.current;
    if (!audio || audio.state === "closed") {
      if (!userGesture) return;
      const Audio = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Audio) return;
      try {
        audio = new Audio();
        context.current = audio;
      } catch { return; }
    }

    const currentAudio = audio;
    const currentGeneration = generation.current;
    function play() {
      if (!mounted.current || !enabled.current || document.hidden
        || currentGeneration !== generation.current || context.current !== currentAudio
        || currentAudio.state !== "running") return;
      for (const tone of TONES[cue]) {
        const start = currentAudio.currentTime + (tone.delay ?? 0);
        const oscillator = currentAudio.createOscillator();
        const gain = currentAudio.createGain();
        oscillator.type = tone.waveform ?? "sine";
        oscillator.frequency.setValueAtTime(tone.frequency, start);
        oscillator.frequency.exponentialRampToValueAtTime(tone.endFrequency ?? tone.frequency, start + tone.duration);
        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(tone.volume, start + 0.004);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + tone.duration);
        oscillator.connect(gain);
        gain.connect(currentAudio.destination);
        voices.current.set(oscillator, gain);
        oscillator.onended = () => {
          voices.current.delete(oscillator);
          oscillator.disconnect();
          gain.disconnect();
        };
        oscillator.start(start);
        oscillator.stop(start + tone.duration + 0.015);
      }
    }

    if (audio.state === "running") play();
    else if (userGesture) void audio.resume().then(play).catch(() => {});
  }, []);

  const toggleSound = useCallback(() => {
    const next = !enabled.current;
    enabled.current = next;
    setSoundEnabled(next);
    try { localStorage.setItem(PREFERENCE_KEY, String(next)); } catch { /* Keep the in-memory preference. */ }
    cancelSounds();
    if (next) playSound("tap");
  }, [cancelSounds, playSound]);

  return { soundEnabled, toggleSound, playSound, cancelSounds };
}
