"use client";

import { useEffect, useLayoutEffect, useRef, useState, type KeyboardEvent } from "react";
import type { Color, PieceSymbol, Square } from "chess.js";
import { ArrowDownTrayIcon, ArrowPathIcon, ArrowRightIcon, ArrowUpIcon, ArrowsUpDownIcon, CheckIcon, ChevronDownIcon, LightBulbIcon, QuestionMarkCircleIcon, SparklesIcon, SpeakerWaveIcon, SpeakerXMarkIcon, XMarkIcon } from "@heroicons/react/16/solid";
import type { Difficulty, Puzzle } from "./lib/puzzles";
import { ChessPiece } from "./piece";

export type CoachProps = {
  puzzles: readonly Puzzle[];
  puzzle: Puzzle;
  difficulty: Difficulty;
  setDifficulty: (difficulty: Difficulty) => void;
  selectPuzzle: (id: string) => void;
  board: readonly { square: Square; type: PieceSymbol; color: Color }[];
  selectedSquare: Square | null;
  legalTargets: readonly Square[];
  selectSquare: (square: Square) => void;
  orientation: "w" | "b";
  flip: () => void;
  lastMove: { from: Square; to: Square } | null;
  status: "playing" | "solved";
  isMoving: boolean;
  soundEnabled: boolean;
  toggleSound: () => void;
  feedback: string | null;
  moves: readonly string[];
  reset: () => void;
  nextPuzzle: () => void;
  messages: readonly { id: string; role: "user" | "assistant"; text: string; title?: string }[];
  draft: string;
  setDraft: (draft: string) => void;
  send: () => void;
  hint: () => void;
  hintLoading: boolean;
  coachLoading: boolean;
  error: string | null;
  retryCoach: () => void;
};

const ICON = "size-4 shrink-0";
const DIFFICULTIES = [
  { value: "beginner", label: "Beginner" },
  { value: "intermediate", label: "Intermediate" },
  { value: "advanced", label: "Advanced" },
] as const;
const PIECE_NAMES: Record<PieceSymbol, string> = { p: "pawn", n: "knight", b: "bishop", r: "rook", q: "queen", k: "king" };
function TouchTarget() { return <span aria-hidden="true" className="pointer-fine:hidden absolute top-1/2 left-1/2 size-[max(100%,3rem)] -translate-1/2" />; }

function Board({ board, selectedSquare, legalTargets, selectSquare, orientation, lastMove, status, isMoving, puzzle, moves }: Pick<CoachProps, "board" | "selectedSquare" | "legalTargets" | "selectSquare" | "orientation" | "lastMove" | "status" | "isMoving" | "puzzle" | "moves">) {
  const [focusedSquare, setFocusedSquare] = useState<Square>("e2");
  const buttons = useRef<Partial<Record<Square, HTMLButtonElement | null>>>({});
  const previousPosition = useRef({ puzzleId: puzzle.id, orientation, moveCount: moves.length });
  const files = orientation === "w" ? "abcdefgh" : "hgfedcba";
  const ranks = orientation === "w" ? "87654321" : "12345678";
  const squares = [...ranks].flatMap((rank) => [...files].map((file) => `${file}${rank}` as Square));
  const pieces = new Map(board.map((piece) => [piece.square, piece]));

  useLayoutEffect(() => {
    const previous = previousPosition.current;
    previousPosition.current = { puzzleId: puzzle.id, orientation, moveCount: moves.length };
    const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (motion.matches || previous.puzzleId !== puzzle.id || previous.orientation !== orientation || moves.length !== previous.moveCount + 1 || !lastMove) return;
    const origin = buttons.current[lastMove.from];
    const destination = buttons.current[lastMove.to];
    const piece = destination?.querySelector<HTMLElement>(".piece-motion");
    if (!origin || !destination || !piece?.animate) return;
    const from = origin.getBoundingClientRect();
    const to = destination.getBoundingClientRect();
    piece.style.zIndex = "4";
    const animation = piece.animate([
      { transform: `translate(${from.x - to.x}px, ${from.y - to.y}px)` },
      { transform: "translate(0, 0)" },
    ], { duration: 220, easing: "cubic-bezier(0.2, 0.8, 0.2, 1)" });
    const stop = () => { animation.cancel(); piece.style.zIndex = ""; };
    animation.onfinish = () => { piece.style.zIndex = ""; };
    motion.addEventListener("change", stop);
    return () => { motion.removeEventListener("change", stop); stop(); };
  }, [puzzle.id, orientation, moves.length, lastMove?.from, lastMove?.to]);

  function moveFocus(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    const column = index % 8;
    if (event.key === "ArrowRight") next = column < 7 ? index + 1 : index;
    else if (event.key === "ArrowLeft") next = column > 0 ? index - 1 : index;
    else if (event.key === "ArrowDown") next = index < 56 ? index + 8 : index;
    else if (event.key === "ArrowUp") next = index >= 8 ? index - 8 : index;
    else if (event.key === "Home") next = event.ctrlKey ? 0 : index - column;
    else if (event.key === "End") next = event.ctrlKey ? 63 : index - column + 7;
    else if (event.key === "Escape" && selectedSquare) {
      event.preventDefault();
      selectSquare(selectedSquare);
      return;
    } else return;
    event.preventDefault();
    const square = squares[next];
    setFocusedSquare(square);
    buttons.current[square]?.focus();
  }

  return <div className="board-area grid min-h-0 min-w-0 flex-1 place-items-center">
    <p id="board-keyboard-help" className="sr-only">Use arrow keys to navigate. Press Enter or Space to select a piece, then a legal destination. Escape clears your selection.</p>
    <div role="grid" aria-label="Chessboard" aria-describedby="board-keyboard-help" aria-rowcount={8} aria-colcount={8} aria-busy={isMoving} className="chess-board">
      {[...ranks].map((rank, row) => <div key={rank} role="row" className="contents">
        {[...files].map((file, column) => {
          const square = `${file}${rank}` as Square;
          const piece = pieces.get(square);
          const legal = legalTargets.includes(square);
          const dark = (file.charCodeAt(0) - 97 + Number(rank)) % 2 === 1;
          return <button key={square} ref={(element) => { buttons.current[square] = element; }} type="button" role="gridcell" aria-rowindex={row + 1} aria-colindex={column + 1} aria-selected={selectedSquare === square} aria-disabled={status === "solved" || isMoving} aria-label={`${square}, ${piece ? `${piece.color === "w" ? "white" : "black"} ${PIECE_NAMES[piece.type]}` : "empty"}${legal ? ", legal destination" : ""}`} tabIndex={focusedSquare === square ? 0 : -1} onFocus={() => setFocusedSquare(square)} onKeyDown={(event) => moveFocus(event, row * 8 + column)} onClick={() => { if (status === "playing" && !isMoving) selectSquare(square); }} className="board-square" data-dark={dark} data-last={lastMove?.from === square || lastMove?.to === square}>
            {piece && <span className="piece-motion"><ChessPiece type={piece.type} color={piece.color} /></span>}
            {legal && <span aria-hidden="true" className="legal-dot" data-capture={Boolean(piece)} />}
            {column === 0 && <span aria-hidden="true" className="board-coordinate top-1 left-1">{rank}</span>}
            {row === 7 && <span aria-hidden="true" className="board-coordinate right-1 bottom-1">{file}</span>}
          </button>;
        })}
      </div>)}
    </div>
  </div>;
}

export default function Coach(props: CoachProps) {
  const { puzzles, puzzle, difficulty, setDifficulty, selectPuzzle, selectedSquare, orientation, flip, status, isMoving, soundEnabled, toggleSound, feedback, moves, reset, nextPuzzle, messages, draft, setDraft, send, hint, hintLoading, coachLoading, error, retryCoach } = props;
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [howOpen, setHowOpen] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  const history = useRef<HTMLDivElement>(null);
  const puzzleList = useRef<HTMLDivElement>(null);
  const historyPinned = useRef(true);
  const busy = hintLoading || coachLoading || isMoving;
  const availablePuzzles = puzzles.filter((item) => item.difficulty === difficulty);
  const initialMoveNumber = Number(puzzle.fen.split(" ")[5]) || 1;
  const startsBlack = puzzle.orientation === "black";

  useEffect(() => {
    if (howOpen && !dialog.current?.open) dialog.current?.showModal();
    if (!howOpen && dialog.current?.open) dialog.current?.close();
  }, [howOpen]);
  useEffect(() => {
    const list = puzzleList.current;
    const selected = list?.querySelector<HTMLButtonElement>('[aria-pressed="true"]');
    if (!list || !selected || list.scrollHeight <= list.clientHeight) return;
    const bounds = list.getBoundingClientRect();
    const option = selected.getBoundingClientRect();
    if (option.top < bounds.top) list.scrollTop += option.top - bounds.top;
    else if (option.bottom > bounds.bottom) list.scrollTop += option.bottom - bounds.bottom;
  }, [puzzle.id]);
  useEffect(() => {
    if (!messages.length || (messages.length === 1 && messages[0].id === "welcome")) historyPinned.current = true;
    const element = history.current;
    if (element && historyPinned.current) element.scrollTop = element.scrollHeight;
  }, [messages]);

  return <>
    <div className="isolate min-h-dvh lg:h-dvh lg:overflow-hidden">
      <main className="mx-auto grid max-w-440 gap-4 p-4 sm:p-6 lg:h-full lg:min-h-0 lg:grid-cols-[192px_minmax(0,1fr)] xl:grid-cols-[208px_minmax(0,1fr)]">
        <aside aria-label="Puzzle settings" className="flex min-h-0 min-w-0 flex-col gap-6 lg:overflow-hidden lg:pr-1">
          <div className="flex h-10 shrink-0 items-center justify-between gap-3">
            <a href="/" aria-label="Tempo homepage" className="flex size-10 shrink-0 items-center justify-center rounded-lg focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-cobalt"><img src="/favicon.svg" alt="" width="32" height="32" className="size-8" /></a>
            <h1 className="sr-only">Tempo chess coach</h1>
            <a href="/downloads/tempo-chess-coach.zip" download="tempo-chess-coach.zip" aria-label="Download project" title="Download project" className="button-ghost button-square lg:hidden"><ArrowDownTrayIcon className={`${ICON} fill-ink/70`} /><TouchTarget /></a>
          </div>
          <button type="button" onClick={() => setSettingsOpen((open) => !open)} aria-controls="puzzle-settings" aria-expanded={settingsOpen} className="flex items-center justify-between gap-3 rounded-xl border border-ink/10 bg-white p-3 text-left focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-cobalt lg:hidden"><div className="flex min-w-0 flex-col gap-1 text-base"><p className="font-medium">{puzzle.title}</p><p className="text-pretty text-ink/65">{puzzle.brief}</p></div><ChevronDownIcon className={`${ICON} fill-ink/55 ${settingsOpen ? "rotate-180" : ""}`} /></button>
          <div id="puzzle-settings" className={`flex min-h-0 flex-col gap-6 lg:flex-1 ${settingsOpen ? "" : "max-lg:hidden"}`}>
            <div className="flex shrink-0 flex-col gap-2">
              <label htmlFor="difficulty" className="text-base font-medium sm:text-sm">Difficulty</label>
              <div className="inline-grid grid-cols-[1fr_--spacing(8)]"><select id="difficulty" name="difficulty" value={difficulty} onChange={(event) => setDifficulty(event.target.value as Difficulty)} className="form-select col-span-full row-start-1 appearance-none pr-8">{DIFFICULTIES.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select><ChevronDownIcon className={`${ICON} pointer-events-none col-start-2 row-start-1 place-self-center fill-ink/50`} /></div>
            </div>
            <div className="flex min-h-0 flex-col gap-3 lg:flex-1">
              <h2 className="shrink-0 text-balance text-base font-medium sm:text-sm">Puzzles</h2>
              <div ref={puzzleList} role="group" aria-label="Choose a puzzle" className="scrollbar-thin grid min-h-0 auto-rows-max gap-2 sm:grid-cols-2 lg:grid-cols-1 lg:overflow-y-auto">
                {availablePuzzles.map((item, index) => <button key={item.id} type="button" onClick={() => selectPuzzle(item.id)} aria-pressed={puzzle.id === item.id} className="group relative grid grid-cols-[1.25rem_minmax(0,1fr)_16px] items-start gap-2 rounded-xl border border-transparent p-3 text-left hover:bg-white focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-cobalt aria-pressed:border-cobalt/10 aria-pressed:bg-mist">
                  <p className="text-base tabular-nums text-ink/65 sm:text-sm">{String(index + 1).padStart(2, "0")}</p>
                  <div className="flex min-w-0 flex-col gap-1 text-base sm:text-sm"><p className="text-pretty font-medium text-ink/75 group-aria-pressed:text-cobalt">{item.title}</p><p className="text-pretty text-ink/65">{item.theme}</p></div>
                  <CheckIcon className={`${ICON} h-lh fill-cobalt group-not-aria-pressed:invisible`} />
                </button>)}
              </div>
            </div>
          </div>
          <div className="shrink-0 max-lg:hidden"><a href="/downloads/tempo-chess-coach.zip" download="tempo-chess-coach.zip" className="button-secondary button-icon-left"><ArrowDownTrayIcon className={`${ICON} fill-ink/65`} />Download project<TouchTarget /></a></div>
        </aside>

        <div className="grid min-h-0 min-w-0 gap-4 lg:grid-cols-[minmax(0,1fr)_280px] xl:grid-cols-[minmax(0,1fr)_304px]">
          <section aria-label="Puzzle board" className="flex min-h-0 min-w-0 flex-col gap-4">
            <Board {...props} />
            <div role="group" aria-label="Puzzle actions" className="flex shrink-0 items-center gap-4 self-center rounded-2xl bg-white p-2 shadow-sm ring-1 ring-ink/10 max-[360px]:gap-2 max-[360px]:p-1.5">
              <div className="flex w-36 shrink-0 max-[360px]:w-32">
                {status === "solved" ? <button type="button" onClick={nextPuzzle} className="button-primary button-icon-right w-full">Next puzzle<ArrowRightIcon className={`${ICON} fill-white`} /><TouchTarget /></button> : <button type="button" onClick={hint} disabled={busy} aria-label={hintLoading ? "Finding a hint" : undefined} className="button-primary button-icon-left w-full whitespace-nowrap"><LightBulbIcon className={`${ICON} fill-white`} />{hintLoading ? "Finding…" : "Get a hint"}<TouchTarget /></button>}
              </div>
              <div className="flex items-center gap-4 border-l border-ink/10 pl-3 max-[360px]:pl-2">
                <button type="button" onClick={reset} aria-label="Reset puzzle" title="Reset puzzle" className="button-ghost button-square"><ArrowPathIcon className={`${ICON} fill-ink/65`} /><TouchTarget /></button>
                <button type="button" onClick={flip} disabled={isMoving} aria-label={`Flip board, ${orientation === "w" ? "black" : "white"} at bottom`} title="Flip board" className="button-ghost button-square"><ArrowsUpDownIcon className={`${ICON} fill-ink/65`} /><TouchTarget /></button>
                <button type="button" onClick={() => setHowOpen(true)} aria-label="How it works" title="How it works" className="button-ghost button-square"><QuestionMarkCircleIcon className={`${ICON} fill-ink/65`} /><TouchTarget /></button>
              </div>
            </div>
          </section>

          <section aria-label="Chess coach" className="flex min-h-0 min-w-0 flex-col overflow-hidden rounded-2xl border border-ink/8 bg-white">
            <div className="flex shrink-0 items-center gap-2 border-b border-ink/7 px-5 py-3">
              <SparklesIcon className={`${ICON} fill-cobalt`} /><h2 className="flex-1 text-balance text-base font-medium">Coach</h2>
              <button type="button" onClick={toggleSound} aria-label="Sound effects" aria-pressed={soundEnabled} title={soundEnabled ? "Mute sound effects" : "Enable sound effects"} className="button-ghost button-square">
                {soundEnabled ? <SpeakerWaveIcon className={`${ICON} fill-cobalt`} /> : <SpeakerXMarkIcon className={`${ICON} fill-ink/65`} />}<TouchTarget />
              </button>
            </div>
            <div ref={history} onScroll={(event) => { const element = event.currentTarget; historyPinned.current = element.scrollHeight - element.clientHeight - element.scrollTop < 80; }} role="log" aria-label="Coaching conversation" aria-live="polite" aria-relevant="additions text" tabIndex={0} className="scrollbar-thin flex min-h-0 flex-1 flex-col gap-5 overflow-y-auto p-5 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-cobalt max-lg:max-h-112 max-lg:min-h-52">
              {messages.length ? messages.map((message) => <div key={message.id} className={`flex shrink-0 flex-col gap-2 ${message.id === "welcome" ? "" : "tempo-message"}`}><p className={`text-base font-medium sm:text-sm ${message.role === "assistant" ? "text-cobalt" : "text-ink/65"}`}>{message.role === "assistant" ? "Tempo" : "You"}</p>{message.title && <h3 className="text-balance text-base font-medium sm:text-sm">{message.title}</h3>}<p className="whitespace-pre-wrap text-pretty text-base text-ink/75 sm:text-sm">{message.text}</p></div>) : <div className="flex flex-1 items-center"><p className="max-w-[32ch] text-pretty text-base text-ink/65 sm:text-sm">Try a move, ask for a hint, or talk through an idea.</p></div>}
              {busy && <div role="status" className="flex shrink-0 items-center gap-2 text-base text-ink/65 sm:text-sm"><SparklesIcon className={`${ICON} animate-pulse fill-cobalt`} /><p>{hintLoading ? "Looking for a useful hint…" : "Considering the position…"}</p></div>}
            </div>
            <div className={`scrollbar-thin flex max-h-28 shrink-0 flex-col gap-2 overflow-y-auto ${moves.length || feedback || selectedSquare ? "border-t border-ink/7 px-5 py-3" : ""}`}>
              {moves.length > 0 && <div aria-label="Move history" className="scrollbar-thin flex min-h-6 shrink-0 items-center gap-2 overflow-x-auto text-base tabular-nums text-ink/70 sm:text-sm">
                {moves.map((move, index) => {
                  const halfMove = index + (startsBlack ? 1 : 0);
                  const number = initialMoveNumber + Math.floor(halfMove / 2);
                  return <p key={`${index}-${move}`} className="shrink-0 font-medium"><span className="font-normal text-ink/65">{halfMove % 2 === 0 ? `${number}. ` : index === 0 ? `${number}… ` : ""}</span>{move}</p>;
                })}
              </div>}
              <div role="status" aria-live="polite" className="flex shrink-0 items-start gap-2 text-base text-ink/65 sm:text-sm">
                {status === "solved" && <CheckIcon className={`${ICON} h-lh fill-cobalt`} />}
                {(feedback || selectedSquare) && <p key={`${puzzle.id}:${moves.length}:${feedback}`} className="tempo-feedback min-w-0 text-pretty">{feedback || `Choose a destination for ${selectedSquare}.`}</p>}
              </div>
            </div>
            {error && <div role="alert" className="scrollbar-thin flex max-h-32 shrink-0 flex-col items-start gap-3 overflow-y-auto border-t border-coral/20 bg-coral/5 p-4"><p className="text-pretty text-base text-ink/75 sm:text-sm">{error}</p><button type="button" onClick={retryCoach} disabled={busy} className="button-secondary button-icon-left"><ArrowPathIcon className={`${ICON} fill-ink/65`} />Retry coaching<TouchTarget /></button></div>}
            <form onSubmit={(event) => { event.preventDefault(); if (draft.trim() && !busy) send(); }} className="shrink-0 border-t border-ink/7 p-4">
              <div className="flex min-w-0 flex-col rounded-xl border border-ink/12 bg-canvas/60 has-[textarea:focus-visible]:outline-2 has-[textarea:focus-visible]:-outline-offset-1 has-[textarea:focus-visible]:outline-cobalt">
                <textarea id="coach-question" name="question" aria-label="Ask your chess coach" aria-describedby="composer-keyboard-hint" enterKeyHint="send" value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => {
                  if (event.key !== "Enter" || event.shiftKey || event.nativeEvent.isComposing || event.nativeEvent.keyCode === 229) return;
                  event.preventDefault();
                  if (!event.repeat) event.currentTarget.form?.requestSubmit();
                }} rows={2} maxLength={500} disabled={busy} placeholder="Ask about this position…" className="h-18 min-w-0 w-full resize-none rounded-t-xl bg-transparent px-3 py-3 text-base text-ink placeholder:text-ink/65 focus-visible:outline-hidden disabled:opacity-60 sm:h-16 sm:text-sm" />
                <div className="flex items-center justify-between gap-2 p-2"><p id="composer-keyboard-hint" className="pl-1 text-base text-ink/65 sm:text-sm">Enter to send<span className="sr-only">. Shift+Enter for a new line.</span></p><button type="submit" disabled={busy || !draft.trim()} aria-label="Send question" title="Send question" className="button-secondary button-square"><ArrowUpIcon className={`${ICON} fill-ink/70`} /><TouchTarget /></button></div>
              </div>
            </form>
          </section>
        </div>
      </main>
    </div>

    <dialog ref={dialog} onClose={() => setHowOpen(false)} onClick={(event) => { if (event.target === event.currentTarget) setHowOpen(false); }} aria-labelledby="how-title" className="how-dialog w-[min(36rem,calc(100%-2rem))] rounded-2xl bg-white p-0 text-ink shadow-xl ring-1 ring-ink/10">
      <div className="flex flex-col gap-6 p-6 sm:p-8">
        <div className="flex items-start justify-between gap-4"><h2 id="how-title" className="text-balance text-2xl font-medium tracking-tight">How Tempo works</h2><button type="button" onClick={() => setHowOpen(false)} aria-label="Close how it works" className="button-ghost button-square"><XMarkIcon className={`${ICON} fill-ink/65`} /><TouchTarget /></button></div>
        <dl className="flex flex-col gap-5 text-base sm:text-sm"><div className="flex flex-col gap-1"><dt className="font-medium">Play the position</dt><dd className="text-pretty text-ink/65">Choose a difficulty and puzzle. Select a piece, then a highlighted destination. The opponent’s reply plays automatically.</dd></div><div className="flex flex-col gap-1"><dt className="font-medium">Think with your coach</dt><dd className="text-pretty text-ink/65">Ask for a hint or discuss a move. OpenAI’s Decisions and Responses APIs choose a coaching approach and explain the position.</dd></div><div className="flex flex-col gap-1"><dt className="font-medium">Use the keyboard</dt><dd className="text-pretty text-ink/65">Tab to the board. Move between squares with arrow keys, and press Enter or Space to select. Escape clears a selection.</dd></div></dl>
        <p className="text-pretty text-base text-ink/65 sm:text-sm">Legal moves and puzzle solutions are checked locally. AI coaching can make mistakes. Your position and questions are sent to OpenAI.</p>
        <button type="button" onClick={() => setHowOpen(false)} className="button-primary self-start">Back to the board<TouchTarget /></button>
      </div>
    </dialog>
  </>;
}
