"use client";

import Coach from "./coach";
import { useCoach } from "./use-coach";

export default function Home() {
  const coach = useCoach();
  return <Coach {...coach} />;
}
