import assert from "node:assert/strict";
import test from "node:test";
import { cleanupMcp } from "../app/lib/cleanup-mcp.ts";

const owner = "owner@example.test";
function request(method, params, headers = {}) {
  return new Request("https://demo.test/mcp", { method: "POST", headers: { "content-type": "application/json", ...headers },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params: { _meta: { "io.modelcontextprotocol/protocolVersion": "2026-07-28", "io.modelcontextprotocol/clientInfo": { name: "fixture-client", version: "1" }, "io.modelcontextprotocol/clientCapabilities": {} }, ...params } }) });
}
const identity = { "oai-authenticated-user-id": "synthetic-site-user", "oai-authenticated-user-email": owner };
const alert = crypto.randomUUID(), token = crypto.randomUUID();
const toolNames = ["cleanup_run", "cleanup_status", "cleanup_claim_alert", "cleanup_retry_alert", "cleanup_ack_alert", "cleanup_test_alert"];
const receipt = { issue_id: crypto.randomUUID(), identifier: "DEMO-42", url: "https://linear.app/example/issue/DEMO-42/cleanup",
  assignee_email: owner, priority: 1 };
test("discovery and schemas are public, static and do not access runtime bindings", async () => {
  const injected = { bindings: null, runtime: async () => assert.fail("Discovery must not load credentials or D1") };
  const discover = await cleanupMcp(request("server/discover"), injected);
  assert.equal(discover.headers.get("cache-control"), "no-store");
  assert.deepEqual((await discover.json()).result, { supportedVersions: ["2026-07-28"], capabilities: { tools: {} } });
  const list = (await (await cleanupMcp(request("tools/list"), injected)).json()).result.tools;
  assert.deepEqual(list.map(tool => tool.name), toolNames);
  assert.doesNotMatch(JSON.stringify(list), /owner@example|synthetic-site-user/);
});
test("every call requires configured owner plus both trusted Sites identity headers", async () => {
  for (const name of toolNames) {
    for (const headers of [{}, { ...identity, "oai-authenticated-user-email": "other@example.test" },
      { "oai-authenticated-user-email": owner }, { "oai-authenticated-user-id": "id" }, { authorization: "Bearer fixture", email: owner }]) {
      const response = await cleanupMcp(request("tools/call", { name, arguments: {} }, headers), {
        bindings: { CLEANUP_OWNER_EMAIL: owner, CLEANUP_IDENTITY_PROVIDER: "sites" }, runtime: async () => assert.fail("Unauthorized call reached runtime"),
      });
      assert.equal(response.status, 403);
    }
    const unconfigured = await cleanupMcp(request("tools/call", { name }, identity), { bindings: {}, runtime: async () => assert.fail() });
    assert.equal(unconfigured.status, 403);
    const untrusted = await cleanupMcp(request("tools/call", { name }, identity), {
      bindings: { CLEANUP_OWNER_EMAIL: owner }, runtime: async () => assert.fail("Identity-header trust must be opt-in"),
    });
    assert.equal(untrusted.status, 403);
  }
});
test("authorized tools reject arbitrary inputs and require owner-assigned ticket receipts", async () => {
  const calls = [];
  const injected = { bindings: { CLEANUP_OWNER_EMAIL: owner.toUpperCase(), CLEANUP_IDENTITY_PROVIDER: "sites" }, runtime: async () => ({ cleanup: async () => ({
    run: async () => { calls.push("run"); return { pending: 1 }; },
    status: async () => { calls.push("status"); return { alert: { id: alert } }; },
    claimAlert: async () => { calls.push("claim"); return { id: alert, lease_token: token }; },
    retryAlert: async (id, lease, category, seconds) => { assert.deepEqual([id, lease, category, seconds], [alert, token, "create_ambiguous", 90]); calls.push("retry"); return true; },
    testAlert: async id => { assert.equal(id, alert); calls.push("test"); return { id, synthetic: true }; },
    acknowledge: async (id, lease, proof, configuredOwner) => { assert.deepEqual([id, lease, proof, configuredOwner], [alert, token, receipt, owner]); calls.push("ack"); return true; },
  }) }) };
  for (const [name, args] of [["cleanup_run", { session_id: "arbitrary" }], ["cleanup_status", { scope: "different" }],
    ["cleanup_claim_alert", { alert_id: alert }], ["cleanup_test_alert", { test_id: alert, session_id: "arbitrary" }],
    ["cleanup_retry_alert", { alert_id: alert, lease_token: token, category: "raw credential-bearing error" }],
    ["cleanup_retry_alert", { alert_id: alert, lease_token: token, category: "rate_limited", retry_after_seconds: 901 }],
    ["cleanup_ack_alert", { alert_id: alert, notification_succeeded: true }],
    ["cleanup_ack_alert", { alert_id: alert, lease_token: token, receipt: { ...receipt, assignee_email: "other@example.test" } }],
    ["cleanup_ack_alert", { alert_id: alert, lease_token: token, receipt: { ...receipt, priority: 2 } }],
    ["cleanup_ack_alert", { alert_id: alert, lease_token: token, receipt: { ...receipt, url: "https://evil.example/issue/DEMO-42" } }]]) {
    const result = await (await cleanupMcp(request("tools/call", { name, arguments: args }, identity), injected)).json();
    assert.equal(result.error.code, -32602, JSON.stringify(args));
  }
  assert.deepEqual(calls, []);
  for (const [name, args] of [["cleanup_run", {}], ["cleanup_status", {}], ["cleanup_claim_alert", {}],
    ["cleanup_retry_alert", { alert_id: alert, lease_token: token, category: "create_ambiguous", retry_after_seconds: 90 }],
    ["cleanup_test_alert", { test_id: alert }], ["cleanup_ack_alert", { alert_id: alert, lease_token: token, receipt }]]) {
    const result = await (await cleanupMcp(request("tools/call", { name, arguments: args }, identity), injected)).json();
    assert.equal(result.result.isError, undefined);
    assert.ok(result.result.content[0].text);
  }
  assert.deepEqual(calls, ["run", "status", "claim", "retry", "test", "ack"]);
});
test("maintenance failure is sanitized and never acknowledged implicitly", async () => {
  const result = await (await cleanupMcp(request("tools/call", { name: "cleanup_run" }, identity), {
    bindings: { CLEANUP_OWNER_EMAIL: owner, CLEANUP_IDENTITY_PROVIDER: "sites" }, runtime: async () => { throw new Error("private fixture detail"); },
  })).json();
  assert.equal(result.result.isError, true);
  assert.doesNotMatch(JSON.stringify(result), /private fixture detail/);
});
