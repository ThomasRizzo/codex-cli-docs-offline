import assert from "node:assert/strict";
import test from "node:test";
import { readFile, readdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { Log, LogLevel, Miniflare } from "miniflare";

const root = fileURLToPath(new URL("../", import.meta.url));
const epoch = Date.UTC(2026, 9, 19);
const scope = "fixture-project";
const fingerprint = "a".repeat(64);
const bundled = await build({
  absWorkingDir: root, stdin: { resolveDir: root, loader: "ts", contents: `
    import {CleanupStore,cleanupFingerprint} from './app/lib/cleanup.ts';
    import {CleanupIncidents} from './app/lib/cleanup-incidents.ts';
    import {resolveApiTransport} from './source-download/openai-fetch.ts';
    export default {async fetch(request,env) {
      const input=await request.json();
      const network=resolveApiTransport(null);
      const transport=(path,init)=>network.fetch(network.origin+path,{...init,redirect:"manual"});
      const store=new CleanupStore(env.DB,{scope:input.scope??"${scope}",fingerprint:input.fingerprint??"${fingerprint}"},transport,()=>input.now??${epoch},()=>0.5);
      try {
        let result;
        if(input.op==="begin") result=await store.begin();
        if(input.op==="track") result=await store.track(input.intent,input.id);
        if(input.op==="reject") result=await store.rejected(input.intent,input.status);
        if(input.op==="emergency") result=await store.emergencyDelete(input.intent,input.id);
        if(input.op==="release") result=await store.release(input.id);
        if(input.op==="run") result=await store.run();
        if(input.op==="status") result=await store.status();
        if(input.op==="ack") result=await store.acknowledge(input.id,input.token,input.receipt,input.owner??"owner@example.test");
        if(input.op==="claimAlert") result=await store.claimAlert();
        if(input.op==="retryAlert") result=await store.retryAlert(input.id,input.token,input.category,input.retryAfter);
        if(input.op==="testAlert") result=await store.testAlert(input.id);
        if(input.op==="observeIncident") result=await new CleanupIncidents(env.DB,"loupe",()=>input.now??${epoch}).observe(input.problem,input.summary??{},input.observedAt);
        if(input.op==="assert") result=await store.assertSession(input.id);
        if(input.op==="fingerprint") result=await cleanupFingerprint(input.key,input.origin);
        return Response.json({result:result??null});
      }catch(error){return Response.json({error:error.message},{status:500});}
    }};` },
  bundle: true, format: "esm", platform: "neutral", target: "es2022", external: ["cloudflare:workers"], write: false, logLevel: "silent",
});

test("durable cleanup uses real D1 and native Worker global fetch", { timeout: 90_000 }, async t => {
  let provider = async request => {
    assert.equal(request.method, "DELETE");
    const id = new URL(request.url).pathname.split("/").at(-1);
    return Response.json({ id, deleted: true, object: "agent.session.deleted" });
  };
  const calls = [];
  const options = {
    modules: true, script: bundled.outputFiles[0].text, d1Databases: { DB: "durable-cleanup-test" },
    compatibilityDate: "2026-05-15", compatibilityFlags: ["nodejs_compat"],
    host: "127.0.0.1", port: 0, cf: false, log: new Log(LogLevel.ERROR),
    outboundService: async request => {
      assert.equal(new URL(request.url).origin, "https://api.openai.com");
      calls.push({ method: request.method, path: new URL(request.url).pathname, search: new URL(request.url).search });
      return provider(request);
    },
  };
  const worker = new Miniflare(options);
  t.after(() => worker.dispose());
  await worker.ready;
  let db = await worker.getD1Database("DB");
  for (const filename of (await readdir(new URL("../drizzle", import.meta.url))).filter(name => name.endsWith(".sql")).sort()) {
    for (const statement of (await readFile(new URL(`../drizzle/${filename}`, import.meta.url), "utf8")).split("--> statement-breakpoint").filter(part => part.trim())) {
      await db.prepare(statement).run();
    }
  }
  const call = async input => {
    const response = await worker.dispatchFetch("https://fixture.test", { method: "POST", body: JSON.stringify(input) });
    const body = await response.json();
    assert.equal(response.status, 200, JSON.stringify(body));
    return body.result;
  };
  const fail = async input => {
    const response = await worker.dispatchFetch("https://fixture.test", { method: "POST", body: JSON.stringify(input) });
    assert.equal(response.status, 500);
    return response.json();
  };
  const row = id => db.prepare("SELECT * FROM cleanup_jobs WHERE session_id = ?").bind(id).first();
  const intentRow = id => db.prepare("SELECT * FROM cleanup_intents WHERE id = ?").bind(id).first();
  const seed = async (id, extra = {}) => {
    const intent = await call({ op: "begin", ...extra });
    await call({ op: "track", intent, id, ...extra });
    return intent;
  };
  const clear = async () => {
    await db.batch(["cleanup_jobs", "cleanup_intents", "cleanup_maintenance", "cleanup_incidents"].map(table => db.prepare(`DELETE FROM ${table}`)));
    calls.length = 0;
  };
  const confirmed = request => Response.json({ id: new URL(request.url).pathname.split("/").at(-1), deleted: true, object: "agent.session.deleted" });

  await t.test("intent precedes attachment; tracking is idempotent and never reopens a resolved session", async () => {
    const intent = await call({ op: "begin" });
    assert.equal((await intentRow(intent)).observed, 0);
    assert.equal(calls.length, 0);
    await call({ op: "track", intent, id: "sess_one" });
    assert.equal((await row("sess_one")).due_at, epoch + 210_000);
    assert.equal(await call({ op: "release", id: "sess_one" }), "confirmed");
    await call({ op: "track", intent, id: "sess_one" });
    assert.equal((await row("sess_one")).resolved_at, epoch);
    await call({ op: "release", id: "sess_one" });
    assert.equal(calls.length, 1);
    await fail({ op: "track", intent: crypto.randomUUID(), id: "sess_untracked" });
    assert.equal(await row("sess_untracked"), null);
  });

  await t.test("provider failures retain work; retries back off and browser requests cannot bypass the delay", async () => {
    await clear();
    await seed("sess_retry");
    provider = async () => new Response(null, { status: 429, headers: { "Retry-After": "45" } });
    assert.equal(await call({ op: "release", id: "sess_retry" }), "queued");
    let job = await row("sess_retry");
    assert.equal(job.attempts, 1); assert.equal(job.due_at, epoch + 45_000); assert.equal(job.last_error, "provider_429");
    await call({ op: "release", id: "sess_retry", now: epoch + 1_000 });
    assert.equal(calls.length, 1);
    provider = async () => new Response(null, { status: 503 });
    await call({ op: "run", now: epoch + 45_000 });
    job = await row("sess_retry");
    assert.equal(job.attempts, 2); assert.equal(job.due_at, epoch + 75_000);
    provider = confirmed;
    await call({ op: "run", now: epoch + 75_000 });
    assert.equal((await row("sess_retry")).resolved_at, epoch + 75_000);
  });

  await t.test("definitive rejection and confirmed emergency deletion resolve only proven outcomes", async () => {
    await clear();
    const rejected = await call({ op: "begin" });
    await fail({ op: "reject", intent: rejected, status: 503 });
    assert.equal((await intentRow(rejected)).observed, 0);
    await call({ op: "reject", intent: rejected, status: 401 });
    assert.equal((await intentRow(rejected)).observed, 1);
    assert.equal((await intentRow(rejected)).last_error, "create_rejected_401");
    assert.equal(calls.length, 0);
    const lost = await call({ op: "begin" });
    provider = confirmed;
    await call({ op: "emergency", intent: lost, id: "sess_emergency" });
    assert.equal((await row("sess_emergency")).resolved_at, epoch);
    assert.equal((await intentRow(lost)).observed, 1);
  });

  await t.test("409 requests cancellation but requires a later confirmed delete", async () => {
    await clear(); await seed("sess_busy");
    provider = async request => {
      if (request.method === "POST") { assert.deepEqual(await request.json(), { events: [{ type: "agent.session.input.cancel" }] }); return Response.json({}); }
      return new Response(null, { status: 409 });
    };
    assert.equal(await call({ op: "release", id: "sess_busy" }), "queued");
    assert.deepEqual(calls.map(c => c.method), ["DELETE", "POST"]);
    assert.equal((await row("sess_busy")).resolved_at, null);
  });

  await t.test("malformed success is retried; correct-scope 404 confirms deletion", async () => {
    await clear(); await seed("sess_confirmation");
    for (const body of [{ id: "sess_other", deleted: true, object: "agent.session.deleted" }, { id: "sess_confirmation", deleted: false, object: "agent.session.deleted" }]) {
      provider = async () => Response.json(body);
      const current = await row("sess_confirmation");
      await call({ op: "run", now: current.due_at });
      assert.equal((await row("sess_confirmation")).resolved_at, null);
    }
    provider = async () => new Response(null, { status: 404 });
    await call({ op: "run", now: (await row("sess_confirmation")).due_at });
    assert.notEqual((await row("sess_confirmation")).resolved_at, null);
  });

  await t.test("leases prevent concurrent deletion and recover across an isolate restart", async () => {
    await clear(); await seed("sess_concurrent");
    let unblock, started;
    const gate = new Promise(resolve => { unblock = resolve; });
    const waiting = new Promise(resolve => { started = resolve; });
    provider = async request => { started(); await gate; return confirmed(request); };
    const first = call({ op: "release", id: "sess_concurrent" });
    await waiting;
    await call({ op: "run", now: epoch + 1 });
    assert.equal(calls.length, 1);
    unblock(); await first;
    await seed("sess_restart");
    await db.prepare("UPDATE cleanup_jobs SET lease_token = 'crashed', lease_until = ?, attempts = 1 WHERE session_id = 'sess_restart'").bind(epoch + 300_000).run();
    await worker.setOptions({ ...options, script: `${bundled.outputFiles[0].text}\n// restart` });
    db = await worker.getD1Database("DB");
    provider = confirmed;
    await call({ op: "run", now: epoch + 299_999 });
    assert.equal((await row("sess_restart")).resolved_at, null);
    await call({ op: "run", now: epoch + 300_001 });
    assert.equal((await row("sess_restart")).attempts, 2);
    assert.equal((await row("sess_restart")).resolved_at, epoch + 300_001);
  });

  await t.test("stale lease outcomes are fenced; a crash after DELETE recovers through 404", async () => {
    await clear(); await seed("sess_fenced");
    let unblock, started;
    const gate = new Promise(resolve => { unblock = resolve; });
    const waiting = new Promise(resolve => { started = resolve; });
    provider = async request => { started(); await gate; return confirmed(request); };
    const pending = call({ op: "release", id: "sess_fenced" });
    await waiting;
    await db.prepare("UPDATE cleanup_jobs SET lease_token = 'replacement', lease_until = ? WHERE session_id = 'sess_fenced'").bind(epoch + 60_000).run();
    unblock(); assert.equal(await pending, "queued");
    assert.equal((await row("sess_fenced")).resolved_at, null);
    provider = async () => new Response(null, { status: 404 });
    await call({ op: "run", now: epoch + 60_001 });
    assert.equal((await row("sess_fenced")).resolved_at, epoch + 60_001);
  });

  await t.test("changed keys, origins or labels strand old records without provider calls", async () => {
    await clear(); await seed("sess_old");
    provider = async () => assert.fail("Wrong credential scope must not reach the provider");
    for (const changed of [{ scope: "new-project" }, { fingerprint: "b".repeat(64) }]) {
      await fail({ op: "release", id: "sess_old", ...changed });
      const health = await call({ op: "run", now: epoch + 300_000, ...changed });
      assert.equal(health.stranded, 1); assert.ok(health.alert);
      assert.equal((await row("sess_old")).resolved_at, null);
    }
    const first = await call({ op: "fingerprint", key: "test-only-key-a", origin: "https://api.openai.com" });
    assert.match(first, /^[a-f0-9]{64}$/);
    assert.notEqual(first, await call({ op: "fingerprint", key: "test-only-key-b", origin: "https://api.openai.com" }));
    assert.notEqual(first, await call({ op: "fingerprint", key: "test-only-key-a", origin: "https://different.example" }));
    assert.equal(calls.length, 0);
  });

  await t.test("reconciliation honors numeric and date Retry-After without retrying early", async () => {
    for (const header of ["900", new Date(epoch + 210_000 + 900_000).toUTCString()]) {
      await clear();
      const intent = await call({ op: "begin" });
      provider = async () => new Response(null, { status: 429, headers: { "Retry-After": header } });
      await call({ op: "run", now: epoch + 210_000 });
      assert.equal((await intentRow(intent)).next_scan_at, epoch + 1_110_000);
      assert.equal((await intentRow(intent)).last_error, "reconcile_429");
      await call({ op: "run", now: epoch + 270_000 });
      assert.equal(calls.length, 1);
      await call({ op: "run", now: epoch + 1_110_000 });
      assert.equal(calls.length, 2);
      assert.equal((await intentRow(intent)).observed, 0);
    }
  });

  await t.test("ambiguous creation persists across empty scans and paginated metadata reconciliation", async () => {
    await clear();
    const intent = await call({ op: "begin" });
    const metadata = { cleanup_app: "lumen", cleanup_run: intent, cleanup_scope: scope };
    provider = async () => Response.json({ data: [], has_more: false });
    await call({ op: "run", now: epoch + 210_000 });
    assert.equal((await intentRow(intent)).observed, 0);
    provider = async request => {
      if (request.method === "DELETE") return confirmed(request);
      const after = new URL(request.url).searchParams.get("after");
      if (!after) return Response.json({ data: [
        { id: "sess_unrelated", metadata: null },
        { id: "sess_wrong_app", metadata: { ...metadata, cleanup_app: "other" } },
        { id: "sess_lost_a", metadata },
        { id: "sess_cursor", metadata: {} },
      ], has_more: true, last_id: "sess_cursor" });
      assert.equal(after, "sess_cursor");
      return Response.json({ data: [{ id: "sess_lost_b", metadata }], has_more: false });
    };
    await call({ op: "run", now: epoch + 270_000 });
    assert.equal((await intentRow(intent)).scan_after, "sess_cursor");
    assert.equal((await intentRow(intent)).observed, 0);
    await worker.setOptions({ ...options, script: `${bundled.outputFiles[0].text}\n// reconciliation restart` });
    db = await worker.getD1Database("DB");
    await call({ op: "run", now: epoch + 330_000 });
    assert.equal((await intentRow(intent)).observed, 1);
    assert.equal((await row("sess_lost_a")).resolved_at, epoch + 270_000);
    assert.equal((await row("sess_lost_b")).resolved_at, epoch + 330_000);
    assert.equal(await row("sess_unrelated"), null);
    assert.equal(await row("sess_wrong_app"), null);
  });

  await t.test("invalid cursors restart discovery and unknown sessions never expire silently", async () => {
    await clear(); const intent = await call({ op: "begin" });
    await db.prepare("UPDATE cleanup_intents SET scan_after = 'deleted_cursor' WHERE id = ?").bind(intent).run();
    provider = async () => new Response(null, { status: 400 });
    await call({ op: "run", now: epoch + 1_000_000 });
    assert.equal((await intentRow(intent)).scan_after, null);
    assert.equal((await intentRow(intent)).observed, 0);
    provider = async () => Response.json({ data: [], has_more: false });
    const health = await call({ op: "run", now: epoch + 10 * 24 * 60 * 60_000 });
    assert.equal(health.unknown, 1); assert.ok(health.alert);
  });

  const receipt = (extra = {}) => ({ issue_id: "da9c1479-ff40-4234-8ca4-24f7d3659ff5", identifier: "DEMO-1",
    url: "https://linear.app/example/issue/DEMO-1/cleanup-drill", assignee_email: "owner@example.test", priority: 1, ...extra });
  const incidentRow = id => db.prepare("SELECT * FROM cleanup_incidents WHERE id = ?").bind(id).first();

  await t.test("failure episodes survive changing counts, categories, recovery and later episodes", async () => {
    await clear(); await seed("sess_alert");
    provider = async () => new Response(null, { status: 401 });
    assert.equal(await call({ op: "release", id: "sess_alert" }), "queued");
    const initial = await call({ op: "status" });
    assert.equal(initial.blocked, 1); assert.ok(initial.alert);
    const id = initial.alert.id;
    assert.equal(initial.alert.marker, `api-showcase-cleanup:lumen:${id}`);
    await seed("sess_alert_new");
    const changed = await call({ op: "status", now: epoch + 1_000_000 });
    assert.equal(changed.alert.id, id);
    assert.equal(changed.alert.firstSummary.pending, 1);
    assert.equal(changed.alert.summary.pending, 2);
    assert.equal(changed.alert.summary.overdue, 2);
    assert.deepEqual(changed.alert.summary.categories, ["provider_auth"]);
    provider = confirmed;
    const recovered = await call({ op: "run", now: epoch + 1_000_001 });
    assert.equal(recovered.pending, 0);
    assert.equal(recovered.alert.id, id);
    assert.equal(recovered.alert.recoveredAt, null);
    assert.equal((await call({ op: "status", now: epoch + 1_000_002 })).alert.recoveredAt, epoch + 1_000_002);
    const lease = await call({ op: "claimAlert", now: epoch + 1_000_002 });
    assert.equal(await call({ op: "ack", id, token: lease.lease_token, receipt: receipt(), now: epoch + 1_000_003 }), true);
    assert.equal((await call({ op: "status", now: epoch + 1_000_004 })).alert, null);
    await seed("sess_later", { now: epoch + 1_000_005 });
    provider = async () => new Response(null, { status: 403 });
    await call({ op: "release", id: "sess_later", now: epoch + 1_000_006 });
    const later = await call({ op: "status", now: epoch + 1_000_007 });
    assert.notEqual(later.alert.id, id);
    assert.equal(later.latestTicket.id, id);
    assert.deepEqual(later.latestTicket.ticket, receipt());
  });

  await t.test("overdue work is recorded before a successful maintenance retry", async () => {
    await clear(); await seed("sess_overdue"); provider = confirmed;
    const result = await call({ op: "run", now: epoch + 900_001 });
    assert.equal(result.pending, 0);
    assert.equal(result.alert.firstSummary.overdue, 1);
    assert.equal(result.alert.recoveredAt, null);
    assert.equal((await call({ op: "status", now: epoch + 900_002 })).alert.recoveredAt, epoch + 900_002);
  });

  await t.test("delayed or same-millisecond healthy snapshots cannot recover a newer failure", async () => {
    await clear();
    await call({ op: "observeIncident", problem: true, summary: { blocked: 1 }, observedAt: epoch + 20, now: epoch + 20 });
    const active = await db.prepare("SELECT * FROM cleanup_incidents WHERE active_key = 'provider'").first();
    for (const observedAt of [epoch + 10, epoch + 20]) {
      await call({ op: "observeIncident", problem: false, observedAt, now: epoch + 30 });
      const unchanged = await incidentRow(active.id);
      assert.equal(unchanged.active_key, "provider");
      assert.equal(unchanged.recovered_at, null);
      assert.equal(unchanged.last_seen_at, epoch + 20);
      assert.deepEqual(JSON.parse(unchanged.latest_snapshot), { app: "loupe", blocked: 1 });
    }
    await call({ op: "observeIncident", problem: false, observedAt: epoch + 21, now: epoch + 40 });
    const recovered = await incidentRow(active.id);
    assert.equal(recovered.active_key, null);
    assert.equal(recovered.recovered_at, epoch + 21);
    assert.equal(recovered.ticket_receipt, null);
    assert.equal((await db.prepare("SELECT COUNT(*) AS n FROM cleanup_incidents").first()).n, 1);
  });

  await t.test("incident leases fence concurrent consumers, stale ack and stale retries", async () => {
    await clear(); const id = crypto.randomUUID(); await call({ op: "testAlert", id });
    const leases = await Promise.all([call({ op: "claimAlert" }), call({ op: "claimAlert" })]);
    assert.equal(leases.filter(Boolean).length, 1);
    const first = leases.find(Boolean);
    assert.equal(first.leaseUntil, epoch + 300_000);
    assert.equal(await call({ op: "claimAlert", now: epoch + 299_999 }), null);
    const second = await call({ op: "claimAlert", now: epoch + 300_001 });
    assert.notEqual(second.lease_token, first.lease_token);
    assert.equal(await call({ op: "ack", id, token: first.lease_token, receipt: receipt(), now: epoch + 300_002 }), false);
    assert.equal(await call({ op: "retryAlert", id, token: first.lease_token, category: "lookup_failed", now: epoch + 300_002 }), false);
    assert.equal(await call({ op: "ack", id, token: second.lease_token, receipt: receipt(), now: epoch + 300_003 }), true);
  });

  await t.test("ticket failures persist across restart and successful receipts are idempotent", async () => {
    await clear(); const id = crypto.randomUUID(); await call({ op: "testAlert", id });
    const lease = await call({ op: "claimAlert" });
    assert.equal(await call({ op: "retryAlert", id, token: lease.lease_token, category: "create_ambiguous", retryAfter: 90 }), true);
    assert.equal((await incidentRow(id)).next_attempt_at, epoch + 90_000);
    await worker.setOptions({ ...options, script: `${bundled.outputFiles[0].text}\n// ticket failure restart` });
    db = await worker.getD1Database("DB");
    const status = await call({ op: "status", now: epoch + 89_999 });
    assert.equal(status.alert.lastError, "create_ambiguous"); assert.equal(status.dueIncidents, 0);
    assert.equal(await call({ op: "claimAlert", now: epoch + 89_999 }), null);
    const retry = await call({ op: "claimAlert", now: epoch + 90_000 });
    assert.equal(retry.id, id); assert.equal(retry.marker, lease.marker); assert.equal(retry.attempts, 2);
    const ack = { op: "ack", id, token: retry.lease_token, receipt: receipt(), now: epoch + 90_001 };
    assert.equal(await call(ack), true);
    assert.equal(await call({ ...ack, now: epoch + 500_000 }), true);
    assert.equal(await call({ ...ack, receipt: receipt({ identifier: "DEMO-2", url: "https://linear.app/example/issue/DEMO-2" }) }), false);
    assert.equal(await call({ op: "claimAlert", now: epoch + 500_001 }), null);
    const saved = await call({ op: "status", now: epoch + 500_002 });
    assert.equal(saved.pendingIncidents, 0); assert.deepEqual(saved.latestTicket.ticket, receipt());
  });

  await t.test("invalid tickets, wrong assignment and notification-only ack never complete an incident", async () => {
    await clear(); const id = crypto.randomUUID(); await call({ op: "testAlert", id });
    const lease = await call({ op: "claimAlert" });
    for (const value of [undefined, true, receipt({ priority: 2 }), receipt({ assignee_email: "other@example.test" }),
      receipt({ issue_id: "invalid" }), receipt({ url: "https://linear.app/other/issue/DEMO-2" }),
      receipt({ url: "https://linear.app.example.test/example/issue/DEMO-1" }),
      receipt({ url: "https://linear.app/example/issue/DEMO-1?token=private" }),
      receipt({ url: "https://user:password@linear.app/example/issue/DEMO-1" })]) {
      assert.equal(await call({ op: "ack", id, token: lease.lease_token, receipt: value }), false);
    }
    assert.equal(await call({ op: "ack", id, sent: true }), false);
    assert.equal((await call({ op: "status" })).pendingIncidents, 1);
    assert.equal((await incidentRow(id)).ticket_receipt, null);
  });

  await t.test("synthetic drills use the same durable path without provider calls or repetition", async () => {
    await clear(); provider = async () => assert.fail("Drill must not call the provider");
    const id = crypto.randomUUID();
    const first = await call({ op: "testAlert", id });
    assert.equal(first.synthetic, true); assert.equal(first.summary.category, "simulated_delete_failure");
    assert.equal((await call({ op: "testAlert", id })).id, id);
    const health = await call({ op: "run" });
    assert.equal(health.pending, 0); assert.equal(health.unknown, 0); assert.equal(health.pendingIncidents, 1);
    const lease = await call({ op: "claimAlert" });
    assert.equal(await call({ op: "ack", id, token: lease.lease_token, receipt: receipt() }), true);
    const repeated = await call({ op: "testAlert", id, now: epoch + 900_000 });
    assert.deepEqual(repeated.ticket, receipt());
    assert.equal((await call({ op: "status", now: epoch + 900_000 })).alert, null);
    assert.equal((await db.prepare("SELECT COUNT(*) AS n FROM cleanup_incidents").first()).n, 1);
    assert.equal(calls.length, 0);
  });

  await t.test("a drain is bounded and only confirmed records age out", async () => {
    await clear(); provider = confirmed;
    for (let i = 0; i < 22; i++) await seed(`sess_bound_${i}`);
    const first = await call({ op: "run", now: epoch + 210_000 });
    assert.equal(first.pending, 2);
    assert.equal(calls.length, 20);
    assert.equal(first.dueJobs, 2);
    await call({ op: "run", now: epoch + 210_001 });
    const unknown = await call({ op: "begin" });
    provider = async () => Response.json({ data: [], has_more: false });
    await call({ op: "run", now: epoch + 2 * 24 * 60 * 60_000 });
    assert.equal((await db.prepare("SELECT COUNT(*) AS n FROM cleanup_jobs").first()).n, 0);
    assert.equal((await intentRow(unknown)).observed, 0);
    const columns = await db.prepare("PRAGMA table_info(cleanup_intents)").all();
    assert.ok(columns.results.every(c => !/content|prompt|document|nonce|secret|api_key/.test(c.name)));
  });
});
