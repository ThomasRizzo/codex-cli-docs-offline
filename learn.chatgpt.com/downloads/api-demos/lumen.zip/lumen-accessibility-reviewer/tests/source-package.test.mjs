import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, readdir, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";
import { fileURLToPath, pathToFileURL } from "node:url";
import { unzipSync } from "fflate";
import { buildSourceArchive } from "../scripts/package-source.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const archiveRoot = "lumen-accessibility-reviewer";
const privateMarkers = new RegExp([
  "CUSTOMER" + "_HTTP_", "tunnel" + "_[A-Za-z0-9]+", "appgprj" + "_[A-Za-z0-9]+",
  "http://localhost" + "/v1", "openai" + "[.]internal",
].join("|"));
const credentialMarkers = /\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}|-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----/;
const environmentNames = [
  "OPENAI_API_KEY", "LUMEN_SESSION_SECRET", "CLEANUP_PROVIDER_SCOPE",
  "CLEANUP_OWNER_EMAIL", "CLEANUP_IDENTITY_PROVIDER",
];

function archiveFiles(projectRoot = root, options) {
  const result = buildSourceArchive(projectRoot, options);
  const entries = unzipSync(result.bytes);
  assert.equal(Object.keys(entries).length, result.files.length);
  return new Map(Object.entries(entries).map(([filename, bytes]) => {
    assert.ok(filename.startsWith(`${archiveRoot}/`), filename);
    const relative = filename.slice(archiveRoot.length + 1);
    assert.ok(relative && !path.posix.isAbsolute(relative), filename);
    assert.ok(!relative.split("/").some(part => part === ".." || part === "."), filename);
    assert.doesNotMatch(relative, /[\\\x00-\x1f\x7f]/, filename);
    return [relative, Buffer.from(bytes)];
  }));
}

test("the source download includes durable cleanup and neutral, opt-in hosting configuration", async () => {
  const files = archiveFiles();
  for (const [filename, bytes] of files) {
    assert.doesNotMatch(bytes.toString("utf8"), credentialMarkers, filename);
    assert.doesNotMatch(bytes.toString("utf8"), privateMarkers, filename);
    assert.ok(!filename.split("/").some(part => [".git", "work", "node_modules", ".wrangler"].includes(part)), filename);
    assert.ok(!/(?:^|\/)\.env(?:\.|$)/.test(filename) || filename === ".env.example", filename);
  }
  assert.deepEqual(JSON.parse(files.get(".openai/hosting.json")), {
    d1: "DB", r2: null, capabilities: ["mcp"],
  });
  const env = Object.fromEntries(files.get(".env.example").toString("utf8").trim().split("\n").map(line => line.split("=")));
  assert.deepEqual(Object.keys(env), environmentNames);
  assert.ok(Object.values(env).every(value => value === ""), "Every downloadable setting must be blank.");
  assert.equal(env.CLEANUP_IDENTITY_PROVIDER, "", "Self-hosted maintenance must not trust identity headers by default.");
  assert.deepEqual(files.get(".env.example"), await readFile(path.join(root, ".env.example")));
  assert.deepEqual(files.get("app/lib/openai-fetch.ts"), await readFile(path.join(root, "source-download/openai-fetch.ts")));
  assert.deepEqual(files.get("tests/fixtures/provider.mjs"), await readFile(path.join(root, "source-download/provider.mjs")));

  for (const filename of [
    "app/lib/cleanup.ts", "app/lib/cleanup-mcp.ts", "app/mcp/route.ts", "db/schema.ts",
    "app/lib/agents.ts", "app/lib/generation-stream.ts", "app/lib/server.ts",
  ]) {
    assert.ok(files.has(filename), `${filename} must be in the downloadable project.`);
    assert.deepEqual(files.get(filename), await readFile(path.join(root, filename)));
  }
  const migrations = (await readdir(path.join(root, "drizzle"))).filter(name => name.endsWith(".sql")).sort();
  assert.ok(migrations.length >= 2, "Include the rate-limit and durable-cleanup migrations.");
  for (const filename of migrations) {
    assert.deepEqual(files.get(`drizzle/${filename}`), await readFile(path.join(root, "drizzle", filename)));
  }
  const migrationSql = migrations.map(filename => files.get(`drizzle/${filename}`).toString("utf8")).join("\n");
  for (const table of ["cleanup_intents", "cleanup_jobs", "cleanup_maintenance"]) {
    assert.match(migrationSql, new RegExp("CREATE TABLE [`\"]?" + table + "[`\"]?\\s*\\("));
  }
  const journal = JSON.parse(files.get("drizzle/meta/_journal.json"));
  for (const migration of journal.entries) {
    assert.ok(files.has(`drizzle/${migration.tag}.sql`), migration.tag);
    assert.ok(files.has(`drizzle/meta/${String(migration.idx).padStart(4, "0")}_snapshot.json`));
  }
});

test("the extracted project uses the public API and keeps self-hosted maintenance disabled", async () => {
  const folder = await mkdtemp(path.join(tmpdir(), "lumen-source-"));
  try {
    const files = archiveFiles();
    for (const [filename, bytes] of files) {
      const destination = path.join(folder, filename);
      await mkdir(path.dirname(destination), { recursive: true });
      await writeFile(destination, bytes);
    }
    await symlink(path.join(root, "node_modules"), path.join(folder, "node_modules"), "dir");
    const { getRuntime, ApiError } = await import(pathToFileURL(path.join(folder, "app/lib/server.ts")).href);
    const calls = [];
    const bindings = {
      OPENAI_API_KEY: "synthetic-provider-key",
      LUMEN_SESSION_SECRET: "synthetic-signing-key-at-least-32-characters",
      CLEANUP_PROVIDER_SCOPE: "download-test",
      DB: {},
    };
    const runtime = await getRuntime({
      bindings,
      fetch: async (url, init) => {
        calls.push({ url, init });
        return Response.json({ id: "sess_download", deleted: true, object: "agent.session.deleted" });
      },
    });
    for (const [method, endpoint] of [
      ["POST", "/v1/agents/sessions"],
      ["GET", "/v1/agents/sessions?limit=10&after=sess_cursor"],
      ["DELETE", "/v1/agents/sessions/sess_download"],
    ]) {
      await runtime.transport(endpoint, { method, headers: { "OpenAI-Beta": "agents=v1" }, redirect: "follow" });
      const { url, init } = calls.at(-1);
      assert.equal(url, `https://api.openai.com${endpoint}`);
      assert.equal(init.method, method);
      assert.equal(init.headers.get("authorization"), `Bearer ${bindings.OPENAI_API_KEY}`);
      assert.equal(init.headers.get("OpenAI-Beta"), "agents=v1");
      assert.equal(init.redirect, "manual");
    }
    await assert.rejects(runtime.transport("/v1/files", {}), error => error instanceof ApiError && error.status === 500);
    assert.equal(calls.length, 3);
    const redirected = await getRuntime({
      bindings,
      fetch: async (_url, init) => {
        assert.equal(init.redirect, "manual");
        return new Response(null, { status: 302, headers: { location: "https://other.example.test" } });
      },
    });
    await assert.rejects(redirected.transport("/v1/agents/sessions", {}), error => error instanceof ApiError && error.status === 502);
    const cleanup = await runtime.cleanup();
    assert.deepEqual(cleanup.metadata("synthetic-intent"), {
      cleanup_app: "lumen", cleanup_run: "synthetic-intent", cleanup_scope: "download-test",
    });
    const expectedFingerprint = Buffer.from(await crypto.subtle.digest(
      "SHA-256", new TextEncoder().encode(JSON.stringify([bindings.OPENAI_API_KEY, "https://api.openai.com"])),
    )).toString("hex");
    assert.equal(cleanup.scope.fingerprint, expectedFingerprint);

    const { cleanupMcp } = await import(pathToFileURL(path.join(folder, "app/lib/cleanup-mcp.ts")).href);
    const response = await cleanupMcp(new Request("https://example.test/mcp", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "oai-authenticated-user-id": "caller-supplied-id",
        "oai-authenticated-user-email": "owner@example.test",
      },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "cleanup_run", arguments: {} } }),
    }), {
      bindings: { CLEANUP_OWNER_EMAIL: "owner@example.test", CLEANUP_IDENTITY_PROVIDER: "" },
      runtime: async () => assert.fail("Blank opt-in must reject caller-supplied identity before runtime access."),
    });
    assert.equal(response.status, 403);
    const fixture = await import(pathToFileURL(path.join(folder, "tests/fixtures/provider.mjs")).href);
    const send = () => assert.fail("Fixture configuration must not make a request.");
    assert.equal(fixture.connectionRequired, false);
    assert.deepEqual(fixture.providerBindings(send), {});
    assert.deepEqual(fixture.providerConfiguration(send), { outboundService: send });
  } finally {
    await rm(folder, { recursive: true, force: true });
  }
});

test("packaging omits local secrets and identities and rejects credentials or private bindings in included source", async () => {
  const folder = await mkdtemp(path.join(tmpdir(), "lumen-package-guard-"));
  try {
    const credential = "sk-" + "syntheticCredential".repeat(3);
    await writeFile(path.join(folder, ".env.local"), `OPENAI_API_KEY=${credential}\n`);
    await mkdir(path.join(folder, ".openai"));
    await writeFile(path.join(folder, ".openai/hosting.json"), JSON.stringify({ projectId: "synthetic-private-project" }));
    await writeFile(path.join(folder, "README.md"), "Synthetic fixture.\n");
    const files = archiveFiles(folder);
    assert.ok(!files.has(".env.local"));
    assert.ok(!files.get(".openai/hosting.json").toString("utf8").includes("synthetic-private-project"));
    assert.ok(!Array.from(files.values()).some(bytes => bytes.includes(Buffer.from(credential))));

    await writeFile(path.join(folder, "README.md"), credential);
    assert.throws(() => archiveFiles(folder), /Potential credential/);
    const signingSecret = "synthetic-signing-secret-that-is-not-an-api-key";
    await writeFile(path.join(folder, "README.md"), signingSecret);
    assert.throws(() => archiveFiles(folder, { secretValues: [signingSecret] }), /Potential credential/);
    await writeFile(path.join(folder, "README.md"), "CUSTOMER" + "_HTTP_SYNTHETIC");
    assert.throws(() => archiveFiles(folder), /Private hosting configuration/);
  } finally {
    await rm(folder, { recursive: true, force: true });
  }
});
