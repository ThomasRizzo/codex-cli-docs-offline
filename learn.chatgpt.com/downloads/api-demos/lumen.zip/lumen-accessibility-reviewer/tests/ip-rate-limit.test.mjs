import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
import { test } from "node:test";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { Log, LogLevel, Miniflare } from "miniflare";
import { enforceIpRateLimit, enforceIpRateLimitWithDb, normalizeClientIp, resolveTrustedClientIp } from "../app/lib/ip-rate-limit.ts";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));
const instant = Date.parse("2026-10-19T12:34:50.250Z");
const request = (ip = "192.0.2.1", headers = {}, url = "https://demo.test/api/test") => new Request(url, {
  headers: { ...(ip === null ? {} : { "cf-connecting-ip": ip }), ...headers },
});

test("IP normalization preserves identity across IPv6 and mapped IPv4 spellings", () => {
  for (const ip of ["2001:DB8:0:0:0:0:0:1", "2001:db8::1", " 2001:db8::1 "]) {
    assert.equal(normalizeClientIp(ip), "2001:db8::1");
  }
  for (const ip of ["192.0.2.1", "::ffff:192.0.2.1", "0:0:0:0:0:FFFF:C000:201"]) {
    assert.equal(normalizeClientIp(ip), "192.0.2.1");
  }
  for (const ip of [null, "", "unknown", "192.0.2.1, 192.0.2.2", "192.0.2.1:443", "[::1]", "fe80::1%eth0", "192.168.001.1", "256.1.1.1", "2001:::1", "1".repeat(46)]) {
    assert.equal(normalizeClientIp(ip), null, String(ip));
  }
});

test("only the trusted edge IP identifies a hosted client; local development still gets an IP bucket", async () => {
  const original = process.env.NODE_ENV;
  try {
    for (const environment of ["production", "test", undefined]) {
      if (environment === undefined) delete process.env.NODE_ENV;
      else process.env.NODE_ENV = environment;
      assert.equal(resolveTrustedClientIp(request(null, {
        "x-forwarded-for": "192.0.2.2", "x-real-ip": "192.0.2.3", "true-client-ip": "192.0.2.4",
      })), null);
      assert.equal(resolveTrustedClientIp(request("192.0.2.1", { "x-forwarded-for": "192.0.2.2" })), "192.0.2.1");
      assert.equal(resolveTrustedClientIp(request(null, {}, "http://localhost/api/test")), null);
    }
    process.env.NODE_ENV = "development";
    for (const hostname of ["localhost", "127.0.0.1", "[::1]"]) {
      assert.equal(resolveTrustedClientIp(request(null, {}, `http://${hostname}/api/test`)), "127.0.0.1");
    }
    assert.equal(resolveTrustedClientIp(request(null)), null);
    assert.equal(resolveTrustedClientIp(request(null, {}, "https://localhost.attacker.test/api/test")), null);
    assert.equal(resolveTrustedClientIp(request("invalid", {}, "http://localhost/api/test")), null);
    assert.equal((await enforceIpRateLimitWithDb(undefined, request(null, {}, "http://localhost/api/test"), "test", { minute: 1 })).status, 503);
  } finally {
    if (original === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = original;
  }
});

test("unavailable identity or storage fails closed without leaking its error", async () => {
  for (const db of [undefined, { batch: async () => { throw new Error("private database detail"); }, prepare: () => ({ bind() { return this; } }) }]) {
    const response = await enforceIpRateLimitWithDb(db, request(), "test", { minute: 1 }, instant);
    assert.equal(response.status, 503);
    assert.equal(response.headers.get("cache-control"), "no-store");
    assert.equal(response.headers.get("retry-after"), "60");
    assert.equal(response.headers.get("x-content-type-options"), "nosniff");
    const body = await response.json();
    assert.equal(body.code, "RATE_LIMIT_UNAVAILABLE");
    assert.equal(body.retryAfter, 60);
    assert.ok(Number.isFinite(Date.parse(body.resetAt)));
    assert.doesNotMatch(JSON.stringify(body), /192\.0\.2\.1|private database detail/);
  }
  assert.equal((await enforceIpRateLimit(request(), "test", { minute: 1 })).status, 503, "Node has no Worker DB binding");
});

test("D1 reservations enforce both windows across concurrent calls and Worker restarts", { timeout: 90_000 }, async t => {
  const bundled = await build({
    absWorkingDir: projectRoot,
    stdin: { contents: `import { enforceIpRateLimit } from './app/lib/ip-rate-limit.ts';
      export default { async fetch(request) {
        const proxy = new Proxy(request, { get(target, property) {
          const value = Reflect.get(target, property, target);
          return typeof value === 'function' ? value.bind(target) : value;
        }});
        const response = await enforceIpRateLimit(proxy, 'worker', { minute: 1, day: 2 });
        return response || new Response('allowed');
      }};`, resolveDir: projectRoot },
    bundle: true, format: "esm", platform: "neutral", target: "es2022",
    external: ["cloudflare:workers", "node:*"],
    define: { "process.env.NODE_ENV": '"production"' }, write: false, logLevel: "silent",
  });
  let outbound = 0;
  const workerOptions = {
    modules: true, script: bundled.outputFiles[0].text,
    compatibilityDate: "2026-05-15", compatibilityFlags: ["nodejs_compat"],
    d1Databases: { DB: "rate-limit-test" },
    host: "127.0.0.1", port: 0, cf: false, log: new Log(LogLevel.ERROR),
    outboundService: async () => { outbound++; return new Response("No outbound calls allowed", { status: 503 }); },
  };
  const worker = new Miniflare(workerOptions);
  t.after(() => worker.dispose());
  await worker.ready;
  const db = await worker.getD1Database("DB");
  const migrationFiles = (await readdir(new URL("../drizzle/", import.meta.url))).filter(name => name.endsWith(".sql")).sort();
  for (const file of migrationFiles) {
    const sql = await readFile(new URL(`../drizzle/${file}`, import.meta.url), "utf8");
    for (const statement of sql.split("--> statement-breakpoint").filter(part => part.trim())) await db.prepare(statement).run();
  }
  const reserve = (bucket, policy, now = instant, ip = "192.0.2.1", headers = {}) => enforceIpRateLimitWithDb(db, request(ip, headers), bucket, policy, now);
  const rows = async () => (await db.prepare("SELECT * FROM demo_ip_rate_limits").all()).results;
  const clear = () => db.prepare("DELETE FROM demo_ip_rate_limits").run();

  await t.test("burst concurrency admits exactly the quota and denials do not consume the daily budget", async () => {
    const results = await Promise.all(Array.from({ length: 25 }, () => reserve("concurrent", { minute: 5, day: 9 })));
    assert.equal(results.filter(result => result === null).length, 5);
    assert.equal(results.filter(result => result?.status === 429).length, 20);
    const [row] = await rows();
    assert.equal(row.minute_count, 5);
    assert.equal(row.day_count, 5);
    assert.match(row.key, /^[\da-f]{64}$/);
    assert.doesNotMatch(JSON.stringify(row), /192\.0\.2\.1|concurrent/);
    const denial = results.find(Boolean);
    assert.equal(denial.headers.get("retry-after"), "10");
    assert.equal(denial.headers.get("cache-control"), "no-store");
    assert.deepEqual(await denial.json(), {
      code: "RATE_LIMIT_EXCEEDED",
      error: "You've reached this demo's usage limit for your network. Please try again in 10 seconds.",
      retryAfter: 10, resetAt: "2026-10-19T12:35:00.000Z",
    });
  });

  await t.test("a new minute preserves daily usage, daily denials do not consume a minute, and UTC midnight resets both", async () => {
    await clear();
    const policy = { minute: 2, day: 3 };
    assert.equal(await reserve("windows", policy), null);
    assert.equal(await reserve("windows", policy), null);
    assert.equal(await reserve("windows", policy, instant + 60_000), null);
    const denial = await reserve("windows", policy, instant + 60_000);
    assert.equal(denial.status, 429);
    const body = await denial.json();
    assert.equal(body.resetAt, "2026-10-20T00:00:00.000Z");
    assert.equal(body.retryAfter, Math.ceil((Date.parse(body.resetAt) - instant - 60_000) / 1000));
    assert.equal((await rows())[0].minute_count, 1);
    assert.equal((await rows())[0].day_count, 3);
    assert.equal(await reserve("windows", policy, Date.parse(body.resetAt)), null);
    assert.equal((await rows()).length, 1);
    assert.equal((await rows())[0].day_count, 1);
  });

  await t.test("when both limits are exhausted Retry-After uses the later daily reset", async () => {
    await clear();
    assert.equal(await reserve("both", { minute: 1, day: 1 }), null);
    const denial = await reserve("both", { minute: 1, day: 1 });
    const body = await denial.json();
    assert.equal(body.resetAt, "2026-10-20T00:00:00.000Z");
    assert.equal(Number(denial.headers.get("retry-after")), body.retryAfter);
  });

  await t.test("forwarded headers and user rotation cannot bypass the same-IP quota; distinct IPs and buckets remain isolated", async () => {
    await clear();
    assert.equal(await reserve("identity", { minute: 1 }), null);
    assert.equal((await reserve("identity", { minute: 1 }, instant, "192.0.2.1", {
      "x-forwarded-for": "203.0.113.9", "x-real-ip": "203.0.113.8", "true-client-ip": "203.0.113.7",
      "oai-authenticated-user-id": "different-user",
    })).status, 429);
    assert.equal((await reserve("identity", { minute: 1 }, instant, "::ffff:192.0.2.1")).status, 429);
    assert.equal(await reserve("other-bucket", { minute: 1 }), null);
    assert.equal(await reserve("identity", { minute: 1 }, instant, "192.0.2.2"), null);
    assert.equal(await reserve("identity", { minute: 1 }, instant, "2001:db8::1"), null);
    assert.equal((await reserve("identity", { minute: 1 }, instant, "2001:DB8:0:0:0:0:0:1")).status, 429);
    assert.equal(await reserve("identity", { minute: 1 }, instant, "2001:db8::2"), null);
    assert.equal((await rows()).length, 5);
  });

  await t.test("late requests cannot roll the active window backward", async () => {
    await clear();
    const policy = { minute: 1, day: 10 };
    assert.equal(await reserve("late", policy, instant + 60_000), null);
    assert.equal((await reserve("late", policy, instant)).status, 429);
    assert.equal((await reserve("late", policy, instant + 60_000)).status, 429);
    assert.equal((await rows())[0].day_count, 1);
  });

  await t.test("expiry cleanup uses an index and deletes no more than 100 old keys per request", async () => {
    await clear();
    await db.batch(Array.from({ length: 205 }, (_, i) => db.prepare(`INSERT INTO demo_ip_rate_limits
      (key, minute_window, minute_count, day_window, day_count, expires_at) VALUES (?, 0, 1, 0, 1, ?)`)
      .bind(`expired-${i}`, instant - 1)));
    assert.equal(await reserve("cleanup", { minute: 5, day: 20 }), null);
    assert.equal((await db.prepare("SELECT count(*) AS total FROM demo_ip_rate_limits WHERE expires_at < ?").bind(instant).first()).total, 105);
    const queryPlan = await db.prepare("EXPLAIN QUERY PLAN SELECT key FROM demo_ip_rate_limits WHERE expires_at <= ? ORDER BY expires_at LIMIT 100").bind(instant).all();
    assert.ok(queryPlan.results.some(row => row.detail.includes("demo_ip_rate_limits_expiry_idx")));
    assert.equal(await reserve("cleanup", { minute: 5, day: 20 }), null);
    assert.equal((await db.prepare("SELECT count(*) AS total FROM demo_ip_rate_limits WHERE expires_at < ?").bind(instant).first()).total, 5);
  });

  await t.test("the production wrapper accepts native proxied requests and uses the persisted Worker binding", async () => {
    await clear();
    const call = headers => worker.dispatchFetch("https://demo.test/api/test", { headers });
    assert.equal((await call({ "cf-connecting-ip": "2001:DB8:0:0:0:0:0:1" })).status, 200);
    assert.equal((await call({ "cf-connecting-ip": "2001:db8::1" })).status, 429);
    // Replace the Worker isolate while retaining the same D1 backing database.
    await worker.setOptions({ ...workerOptions, script: `${bundled.outputFiles[0].text}\n// restarted` });
    assert.equal((await call({ "cf-connecting-ip": "2001:db8::1" })).status, 429);
    assert.equal((await call({ "cf-connecting-ip": "garbage", "x-forwarded-for": "192.0.2.2" })).status, 503);
  });

  assert.equal(outbound, 0, "Rate-limit tests must never call a real external service");
});
