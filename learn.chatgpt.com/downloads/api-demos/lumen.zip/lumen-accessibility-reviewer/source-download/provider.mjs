export const connectionRequired = false;
export function providerBindings(_send) { return {}; }
export function providerConfiguration(send) { return { outboundService: send }; }

export const providerOrigin = "https://api.openai.com";
