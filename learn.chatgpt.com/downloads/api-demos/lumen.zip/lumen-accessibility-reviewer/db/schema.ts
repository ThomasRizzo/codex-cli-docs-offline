import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

// Only a digest of the canonical IP and route bucket is stored. Keys expire at UTC midnight;
// subsequent requests remove expired keys in bounded batches.
export const demoIpRateLimits = sqliteTable("demo_ip_rate_limits", {
  key: text("key").primaryKey(),
  minuteWindow: integer("minute_window").notNull(),
  minuteCount: integer("minute_count").notNull(),
  dayWindow: integer("day_window").notNull(),
  dayCount: integer("day_count").notNull(),
  expiresAt: integer("expires_at").notNull(),
}, table => [index("demo_ip_rate_limits_expiry_idx").on(table.expiresAt)]);

// Cleanup records contain resource identities and operational state, never user content.
export const cleanupIntents = sqliteTable("cleanup_intents", {
  id: text("id").primaryKey(),
  scope: text("scope").notNull(),
  fingerprint: text("fingerprint").notNull(),
  createdAt: integer("created_at").notNull(),
  cleanupAfter: integer("cleanup_after").notNull(),
  observed: integer("observed").notNull().default(0),
  nextScanAt: integer("next_scan_at").notNull(),
  scanAfter: text("scan_after"),
  scanAttempts: integer("scan_attempts").notNull().default(0),
  leaseToken: text("lease_token"),
  leaseUntil: integer("lease_until"),
  lastError: text("last_error"),
}, table => [index("cleanup_intents_due_idx").on(table.observed, table.nextScanAt)]);

export const cleanupJobs = sqliteTable("cleanup_jobs", {
  sessionId: text("session_id").primaryKey(),
  intentId: text("intent_id").notNull(),
  scope: text("scope").notNull(),
  fingerprint: text("fingerprint").notNull(),
  createdAt: integer("created_at").notNull(),
  dueAt: integer("due_at").notNull(),
  attempts: integer("attempts").notNull().default(0),
  leaseToken: text("lease_token"),
  leaseUntil: integer("lease_until"),
  lastError: text("last_error"),
  resolvedAt: integer("resolved_at"),
}, table => [index("cleanup_jobs_due_idx").on(table.resolvedAt, table.dueAt), index("cleanup_jobs_intent_idx").on(table.intentId)]);

export const cleanupMaintenance = sqliteTable("cleanup_maintenance", {
  id: text("id").primaryKey(),
  lastRunAt: integer("last_run_at"),
  alertFingerprint: text("alert_fingerprint"),
  alertId: text("alert_id"),
  alertPayload: text("alert_payload"),
  alertAckAt: integer("alert_ack_at"),
});

// Failure episodes survive changing counts, recovery, restarts and ticket API errors.
// Only a verified owner-scheduler ticket receipt completes the escalation outbox.
export const cleanupIncidents = sqliteTable("cleanup_incidents", {
  id: text("id").primaryKey(),
  kind: text("kind").notNull(),
  activeKey: text("active_key"),
  openedAt: integer("opened_at").notNull(),
  lastSeenAt: integer("last_seen_at").notNull(),
  recoveredAt: integer("recovered_at"),
  firstSnapshot: text("first_snapshot").notNull(),
  latestSnapshot: text("latest_snapshot").notNull(),
  attempts: integer("attempts").notNull().default(0),
  nextAttemptAt: integer("next_attempt_at").notNull(),
  leaseToken: text("lease_token"),
  leaseUntil: integer("lease_until"),
  lastError: text("last_error"),
  ticketReceipt: text("ticket_receipt"),
  ticketRecordedAt: integer("ticket_recorded_at"),
  acknowledgedToken: text("acknowledged_token"),
}, table => [
  uniqueIndex("cleanup_incidents_active_idx").on(table.activeKey),
  index("cleanup_incidents_due_idx").on(table.ticketRecordedAt, table.nextAttemptAt),
]);
