# Lumen — Accessibility reviewer

An interactive OpenAI API demo for reviewing and improving static HTML/CSS pages. Start with one of three sample pages, import an HTML file with its saved-page folder, or edit the source. Select findings to fix, ask follow-up questions, compare revisions, and undo changes.

## Run locally

Use Node.js 22.13 or later.

```sh
npm ci
cp .env.example .env.local
```

Set `OPENAI_API_KEY` to your own project key with Agents API access and `LUMEN_SESSION_SECRET` to a random string of at least 32 characters. Set `CLEANUP_PROVIDER_SCOPE` to a stable label for that provider project (1–80 letters, digits, underscores or hyphens, starting with a letter or digit). Keep `.env.local` private and untracked. Initialize a fresh local D1 database before starting the development server:

```sh
npm run build
for migration in drizzle/*.sql; do
  node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file "$migration" || exit 1
done
npm run dev
```

Run database initialization once for a fresh database. For an existing database, apply only migrations that have not already run, in filename order.

The downloaded project contains no API credentials or Sites identity. The API key is used on the server only. Visitors do not need an account. The hosted Site uses its configured server-side API connection. The downloadable project connects directly to `https://api.openai.com` with your own key in development and production.

```sh
npm run typecheck
npm test
npm run build
```

## How it works

- A sandboxed iframe renders sanitized HTML and CSS. Scripts, embedded frames, navigation, forms, and remote resource loading are disabled. Imported local stylesheets, raster images, and fonts are supported; this is a static page preview, not a running application.
- For a browser “Save As” page, upload the HTML first, then select its companion folder when prompted. Lumen resolves local stylesheets and their imports, preserves document-level theme classes, and embeds supported local images and fonts. Missing dependencies are reported; no external URLs are fetched. Imported binary assets stay in the browser and are excluded from AI requests.
- axe-core checks the actual rendered page at the selected viewport. Findings distinguish detected issues from checks that need human review. Each finding includes its rule, selector, impact, and evidence.
- The OpenAI Agents API uses `gpt-6-astra` with `service_tier: "fast"` and low reasoning effort. Its initial prompt contains a bounded page/audit summary, selected and high-priority finding excerpts, and recent conversation (at most 24,000 serialized characters). Complete HTML/CSS, findings, selection, and history stay in workspace files for targeted inspection; they are not repeated in the initial prompt. Exact overview questions (including the two chat suggestions) use `environment.type: "none"` without a sandbox. Detailed questions and revisions retain full file access. Answers never apply source edits.
- A hosted sandbox validates exact source patches. The server verifies the patch receipt against the submitted request and document before applying edits. Browser checks then run again on the changed page. A valid patch receipt does not establish accessibility compliance.
- Answers and progress stream into chat. Stop cancels the current run. Signed session handles are tied to a random nonce held only in the current tab. The server requests deletion of temporary provider sessions on completion, failure, timeout, and disconnect. D1 records creation intent and deletion jobs so an owner-operated maintenance task can retry after the browser or Worker exits. Sessions cannot be resumed after the browser disconnects; upstream stream interruptions can be reconciled while the browser remains connected. Provider processing and retention policies still apply; an API deletion confirmation does not guarantee immediate physical deletion or deletion of provider logs.
- Source edits and AI revisions remain in the current browser session. Undo restores the previous source and conversation. Export page downloads a standalone sanitized page with its imported assets; Download project downloads this runnable source.

## Scope and limits

Automated checks cover only part of accessibility. Keyboard interaction, screen-reader behavior, content meaning, and real user experience still need human review. Lumen does not issue a compliance score or certification.

Documents support up to 150,000 HTML characters and 300,000 CSS characters after sanitization. Uploaded and exported HTML can contain up to 16 MB, including embedded assets, before extraction. Local assets are limited to 2 MB each and 8 MB total (up to 100 assets); supported formats are PNG, JPEG, GIF, WebP, AVIF, WOFF, WOFF2, TTF, and OTF. Interactive JavaScript and unsupported asset formats are removed from the static preview. Reports show up to 50 element findings and identify when more results were omitted. Every revision is checked at the same chosen viewport; results at one width do not establish behavior at every width.

## IP rate limits

Starting an analysis or generation is limited to **6 requests per UTC minute and 20 per UTC day, per IP address**. Both windows are reserved atomically in the Sites D1 `DB` binding and persist across Worker instances. Visitors on the same network share this allowance. Signed-session burst limits apply to status and cleanup requests after handle verification.

The server trusts only the edge-provided `CF-Connecting-IP`, ignores caller-supplied forwarding headers, and stores a SHA-256 hash with usage counters rather than the raw IP address. Exhausted requests receive HTTP 429 with `Retry-After` and a reset time. If the trusted IP or D1 store is unavailable, new work fails closed with HTTP 503 before contacting OpenAI.

Status and Stop/session cleanup do not consume this IP generation allowance. They require the same-origin browser nonce, its correctly signed session handle, and an available cleanup ledger. During a D1 outage these operations fail closed; existing durable jobs remain pending for recovery.

The Run locally commands build the Worker configuration and apply every D1 migration before starting the development server.

The source download preserves the logical `DB` binding and all migrations, without a hosted project or database ID. Hosted deployment must provision D1 and apply all migrations before serving API requests. These per-IP limits are usage safeguards, not a project-wide monetary budget.

## Durable cleanup and owner operation

The cleanup ledger stores only random run IDs, provider session IDs, logical scope, a SHA-256 fingerprint of the actual server API key and effective API origin, timestamps, leases, retry categories, sanitized incident summaries and ticket receipts. It never stores page source, prompts, uploads, model output, browser nonce values, signing capabilities or the key itself.

- A creation intent commits before the single provider creation POST. Server-generated provider metadata carries the app name, random intent ID and logical scope. The known session ID and fallback deletion job commit before a browser handle or result is exposed.
- Completion, failure, timeout and disconnect make the job eligible immediately. The fallback deadline is 210 seconds after intent creation, allowing the 180-second generation deadline and a short grace period. If recording the ID fails, output stops and an emergency deletion is attempted. A confirmed emergency deletion is recorded if D1 has recovered; otherwise the intent remains unresolved.
- Each deletion attempt has an eight-second network deadline. HTTP 409 requests cancellation and leaves deletion pending. Network errors, malformed success responses, 429, 5xx and authentication failures retain the job. Retries use persisted exponential backoff from roughly 15 seconds to 15 minutes, with jitter and bounded `Retry-After`. The ledger never discards a job because of its retry count.
- Atomic 60-second leases and fenced updates prevent concurrent workers from completing each other's jobs. A maintenance call has a 20-second network budget, at most 20 deletion attempts, and one reconciliation page of up to 10 sessions. `dueJobs` and `dueReconciliations` let the owner task repeat bounded calls when work remains.
- A definitive creation HTTP 400/401/403/404/422 rejection received before any session ID closes the intent without claiming a session was deleted. Other ambiguous creation outcomes remain pending. Reconciliation lists sessions in the current provider project, matches only metadata belonging to an existing same-scope intent, and persists pagination progress. It never retries creation. Empty scans do not prove absence. Failed or empty scans back off from one to 15 minutes; invalid cursors restart the scan.
- Only an exact documented deletion confirmation (`id`, `deleted: true`, `object: agent.session.deleted`) or HTTP 404 under the recorded key/origin/scope confirms cleanup. Confirmed records and proven rejected intents are eligible for bounded pruning after 24 hours. Unconfirmed jobs and unidentified intents do not expire.

Use a separate provider project/workload and key for each demo. Before changing the key, API origin or `CLEANUP_PROVIDER_SCOPE`, stop new work and drain until both `pending` and `unknown` are zero. Even a same-project key rotation changes the fingerprint and conservatively strands old records. Restore the original credential/origin/scope to drain those records; never relabel them or accept a new project's 404 as deletion proof.

Configure these server-only bindings on a Sites deployment:

| Binding | Purpose |
| --- | --- |
| `DB` | Existing D1 storage, with all checked-in migrations applied. |
| `OPENAI_API_KEY` | That demo's provider credential. |
| `LUMEN_SESSION_SECRET` | At least 32 random characters for anonymous browser handles. |
| `CLEANUP_PROVIDER_SCOPE` | Explicit stable provider-project label. Missing scope prevents generation. |
| `CLEANUP_OWNER_EMAIL` | The verified Sites account allowed to operate maintenance. |
| `CLEANUP_IDENTITY_PROVIDER` | Set to `sites` only behind Sites' verified identity ingress. Blank disables maintenance calls. |

The manifest enables the Sites MCP capability. `POST /mcp` implements protocol `2026-07-28`: `server/discover` and `tools/list` return static public metadata; every `tools/call` requires the configured identity-provider opt-in, a Sites-verified user ID, and an exact normalized match to the configured owner email. No maintenance tool accepts arbitrary provider session IDs, provider URLs, credentials or scopes. Ticket receipt URLs are validated as Linear issue links and are never fetched by the Site. Visitors remain anonymous and need no login.

**Do not set `CLEANUP_IDENTITY_PROVIDER=sites` on a raw Worker or other public server that accepts caller-supplied `oai-authenticated-user-*` headers.** A non-Sites deployment must supply its own verified maintenance identity integration and trusted scheduler before enabling equivalent operations. The downloadable example leaves this opt-in blank.

After deploying and verifying the owner can call the Site's tools, configure an owner-linked cloud task every 15 minutes with a connected Linear account and an explicit ticket team and owner:

1. Call `cleanup_run` and read `cleanup_status`. Repeat a bounded number of batches while cleanup work is due; leave future backoff queued. A failed maintenance, authentication or storage call must itself create or reuse a P0 outage ticket assigned to the configured owner, using a stable Site-specific marker in Linear.
2. Claim pending incidents with `cleanup_claim_alert`. The claim returns an incident ID, stable ticket marker and a fenced five-minute lease. Search Linear for that exact marker before creating a ticket. Create a `[P0]` issue with the highest priority in Linear (`1`, Urgent), assign the configured owner, and include only the sanitized incident summary, timestamps and recovery context. A synthetic incident must be marked `[DRILL]`.
3. Read the issue back and verify its marker, priority and assignee. Call `cleanup_ack_alert` with the exact incident ID, current lease token and verified receipt (`issue_id`, `identifier`, canonical Linear `url`, `assignee_email`, `priority: 1`). Notification success alone cannot acknowledge an incident. Read `cleanup_status` to confirm that the receipt persisted.
4. If looking up, creating or reading back a ticket fails, call `cleanup_retry_alert` with the incident ID, lease token and sanitized category. Respect provider retry delays. Pending incidents survive process restarts and recovery; a lost call or expired lease is retried on a later run. After an ambiguous create, search and recover the marker before attempting another create. Notify the owner of escalation failures, but leave the incident pending.

Unresolved jobs or unidentified intents older than 15 minutes, stranded scopes and provider-authentication failures open a durable incident. One active failure episode per Site retains its identity as counts change. Recovery is recorded separately and does not erase a pending ticket obligation. Ticket receipts and incident history are not pruned with confirmed session metadata. Ticketed failures continue cleanup retries; the task does not automatically close real tickets.

The server validates the authenticated owner's receipt and stores it durably; it relies on that trusted task to read Linear independently. Leases and stable-marker recovery reduce duplicate creation, but Linear search-before-create is not an atomic idempotency guarantee. A crash after issue creation can require reconciliation. The task must never silently acknowledge a failed or unverified ticket.

`cleanup_test_alert({test_id})` is an owner-only, idempotent failure drill. It inserts a synthetic incident through the same escalation outbox without creating a provider session, changing credentials or processing user content. Test the real ticket path with this tool, read back the assigned P0 and persisted receipt, then explicitly resolve the drill ticket. Provider deletion failure-to-incident behavior is also covered by real-D1 tests with mocked provider responses.

Source deployment does not itself create a schedule or connect Linear. Verify the actual unattended owner task after deployment. This app provides no Worker cron, independent missed-run monitor or scheduling/ticket-service SLA. If the task stops, durable records remain but cleanup and escalation wait for another invocation. A Site/D1 outage is escalated externally by the task, since unavailable storage cannot record its own incident. Project listing can be delayed or unable to identify an ambiguous creation; those intents remain visible rather than being discarded. No provider TTL is assumed. This session cleanup does not claim to remove unrelated provider resources or logs.

The lifecycle uses the documented Agents API [creation metadata](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/create), [project session listing and pagination](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/list), and [session deletion confirmation](https://developers.openai.com/api/reference/resources/beta/subresources/agents/subresources/sessions/methods/delete).

## Hosting with Sites

Configure the server-only bindings above and the Site’s supported server-side API connection. Downloaded projects use the public OpenAI API adapter and require their own API project credential and outbound access to `api.openai.com`. The Sites helper scripts build and publish a source-linked site version. Sharing is configured in Sites independently of the source version.

`npm run package:source` rebuilds `public/downloads/lumen-accessibility-reviewer.zip`. Packaging excludes credentials, site identity, dependencies, build output, and verification artifacts. The archive includes a blank `.env.example`.

Inter is distributed under the SIL Open Font License in `public/fonts/Inter-LICENSE.txt`. Third-party dependency licenses remain with their respective packages.
