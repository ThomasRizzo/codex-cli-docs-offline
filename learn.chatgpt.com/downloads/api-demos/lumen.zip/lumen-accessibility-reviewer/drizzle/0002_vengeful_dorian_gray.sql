CREATE TABLE `cleanup_incidents` (
	`id` text PRIMARY KEY NOT NULL,
	`kind` text NOT NULL,
	`active_key` text,
	`opened_at` integer NOT NULL,
	`last_seen_at` integer NOT NULL,
	`recovered_at` integer,
	`first_snapshot` text NOT NULL,
	`latest_snapshot` text NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`next_attempt_at` integer NOT NULL,
	`lease_token` text,
	`lease_until` integer,
	`last_error` text,
	`ticket_receipt` text,
	`ticket_recorded_at` integer,
	`acknowledged_token` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `cleanup_incidents_active_idx` ON `cleanup_incidents` (`active_key`);--> statement-breakpoint
CREATE INDEX `cleanup_incidents_due_idx` ON `cleanup_incidents` (`ticket_recorded_at`,`next_attempt_at`);
--> statement-breakpoint
-- A prior push acknowledgment is not evidence of a P0 ticket. Preserve any existing
-- failure snapshot as an unacknowledged episode when upgrading the cleanup protocol.
INSERT INTO cleanup_incidents
  (id, kind, active_key, opened_at, last_seen_at, first_snapshot, latest_snapshot, next_attempt_at)
SELECT alert_id, 'provider', 'provider', COALESCE(last_run_at, unixepoch() * 1000),
  COALESCE(last_run_at, unixepoch() * 1000), alert_payload, alert_payload, 0
FROM cleanup_maintenance WHERE alert_id IS NOT NULL AND alert_payload IS NOT NULL
ON CONFLICT(id) DO NOTHING;
