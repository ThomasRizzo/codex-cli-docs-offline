CREATE TABLE `cleanup_intents` (
	`id` text PRIMARY KEY NOT NULL,
	`scope` text NOT NULL,
	`fingerprint` text NOT NULL,
	`created_at` integer NOT NULL,
	`cleanup_after` integer NOT NULL,
	`observed` integer DEFAULT 0 NOT NULL,
	`next_scan_at` integer NOT NULL,
	`scan_after` text,
	`scan_attempts` integer DEFAULT 0 NOT NULL,
	`lease_token` text,
	`lease_until` integer,
	`last_error` text
);
--> statement-breakpoint
CREATE INDEX `cleanup_intents_due_idx` ON `cleanup_intents` (`observed`,`next_scan_at`);--> statement-breakpoint
CREATE TABLE `cleanup_jobs` (
	`session_id` text PRIMARY KEY NOT NULL,
	`intent_id` text NOT NULL,
	`scope` text NOT NULL,
	`fingerprint` text NOT NULL,
	`created_at` integer NOT NULL,
	`due_at` integer NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`lease_token` text,
	`lease_until` integer,
	`last_error` text,
	`resolved_at` integer
);
--> statement-breakpoint
CREATE INDEX `cleanup_jobs_due_idx` ON `cleanup_jobs` (`resolved_at`,`due_at`);--> statement-breakpoint
CREATE INDEX `cleanup_jobs_intent_idx` ON `cleanup_jobs` (`intent_id`);--> statement-breakpoint
CREATE TABLE `cleanup_maintenance` (
	`id` text PRIMARY KEY NOT NULL,
	`last_run_at` integer,
	`alert_fingerprint` text,
	`alert_id` text,
	`alert_payload` text,
	`alert_ack_at` integer
);
