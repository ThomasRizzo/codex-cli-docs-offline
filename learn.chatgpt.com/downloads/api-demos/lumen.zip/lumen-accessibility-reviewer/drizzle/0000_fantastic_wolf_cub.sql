CREATE TABLE `demo_ip_rate_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`minute_window` integer NOT NULL,
	`minute_count` integer NOT NULL,
	`day_window` integer NOT NULL,
	`day_count` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `demo_ip_rate_limits_expiry_idx` ON `demo_ip_rate_limits` (`expires_at`);