import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Lumen — Accessibility review",
  description: "Inspect accessibility findings, make focused changes, and review the result.",
  icons: {
    icon: { url: "/lumen-icon.svg", type: "image/svg+xml", sizes: "any" },
    shortcut: "/lumen-icon.svg",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><head><link rel="preload" href="/fonts/InterVariable.woff2" as="font" type="font/woff2" crossOrigin="anonymous" /></head><body className="antialiased">{children}</body></html>;
}
