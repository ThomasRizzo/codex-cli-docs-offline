import { cleanupMcp } from "../lib/cleanup-mcp";

export async function POST(request: Request) { return cleanupMcp(request); }
