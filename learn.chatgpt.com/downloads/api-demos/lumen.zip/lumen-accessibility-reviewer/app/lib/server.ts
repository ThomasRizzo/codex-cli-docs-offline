import { z } from "zod";
import { AgentsError, type AgentsTransport } from "./agents.ts";
import { documentSchema } from "./contracts.ts";
import type { ReviewBinding } from "./generation-result.ts";
import { resolveApiTransport, type TransportBindings } from "./openai-fetch.ts";
import { CleanupStore, cleanupFingerprint } from "./cleanup.ts";

export class ApiError extends Error {
  readonly status: number;
  constructor(status: number, message: string) { super(message); this.status = status; }
}
export const privateHeaders = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
const windows = new Map<string, { count: number; expires: number }>();
const limits = { status: 90, cancel: 30 };
export const GENERATION_DEADLINE_MS = 180_000;

export function guardRequest(request: Request): string {
  const url = new URL(request.url);
  if (request.headers.get("origin") !== url.origin || request.headers.get("sec-fetch-site") === "cross-site") {
    throw new ApiError(403, "Open Lumen in its own tab and try again.");
  }
  // An unguessable, per-tab capability replaces account identity. It is kept
  // only in browser memory and is never used as a paid-usage quota key.
  const owner = request.headers.get("x-lumen-session");
  if (!owner || !/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(owner)) {
    throw new ApiError(400, "Refresh Lumen to start a new temporary review session.");
  }
  return owner;
}

/** Call only after verifying the signed handle, so arbitrary nonces cannot fill this map. */
export function limitSessionRequests(owner: string, operation: keyof typeof limits): void {
  const now = Date.now();
  for (const [key, value] of windows) if (value.expires <= now) windows.delete(key);
  const key = `${owner}:${operation}`;
  const current = windows.get(key);
  if (current && current.count >= limits[operation]) throw new ApiError(429, "A few too many requests. Wait a minute and try again.");
  if (current) current.count++;
  else {
    if (windows.size >= 2000) throw new ApiError(503, "Lumen is busy. Please try again shortly.");
    windows.set(key, { count: 1, expires: now + 60_000 });
  }
}

export async function parseBody<S extends z.ZodTypeAny>(request: Request, schema: S, maxBytes = 4096): Promise<z.output<S>> {
  if (request.headers.get("content-type")?.split(";")[0].trim() !== "application/json") throw new ApiError(415, "Send this request as JSON.");
  if (Number(request.headers.get("content-length") ?? 0) > maxBytes) throw new ApiError(413, "This file is too large. Use a smaller page and try again.");
  if (!request.body) throw new ApiError(400, "The request is empty.");
  const reader = request.body.getReader();
  let text = "", bytes = 0, timedOut = false;
  const decoder = new TextDecoder();
  const timer = setTimeout(() => { timedOut = true; void reader.cancel().catch(() => undefined); }, 10_000);
  try {
    while (true) {
      const chunk = await reader.read();
      if (timedOut) throw new ApiError(408, "The file took too long to arrive. Please try again.");
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > maxBytes) throw new ApiError(413, "This file is too large. Use a smaller page and try again.");
      text += decoder.decode(chunk.value, { stream: true });
    }
    text += decoder.decode();
  } finally { clearTimeout(timer); await reader.cancel().catch(() => undefined); reader.releaseLock(); }
  let value: unknown;
  try { value = JSON.parse(text); } catch { throw new ApiError(400, "The request could not be read. Please try again."); }
  const parsed = schema.safeParse(value);
  if (!parsed.success) throw new ApiError(400, "Check your page and request, then try again.");
  return parsed.data;
}

export type Bindings = {
  OPENAI_API_KEY?: string; LUMEN_SESSION_SECRET?: string; DB?: D1Database;
  CLEANUP_PROVIDER_SCOPE?: string; CLEANUP_OWNER_EMAIL?: string; CLEANUP_IDENTITY_PROVIDER?: string;
} & TransportBindings;
export async function runtimeBindings(): Promise<Bindings | null> {
  try { const { env } = await import("cloudflare:workers"); return env as unknown as Bindings; }
  catch { return null; }
}
let localSecret: string | undefined;
export async function getRuntime(options: { bindings?: Bindings | null; fetch?: typeof fetch } = {}) {
  let bindings = options.bindings;
  if (bindings === undefined) bindings = await runtimeBindings();
  const dev = process.env.NODE_ENV === "development";
  const key = bindings?.OPENAI_API_KEY || (dev ? process.env.OPENAI_API_KEY : undefined);
  if (!key) throw new ApiError(503, "The site owner needs to connect Lumen’s OpenAI API key.");
  let secret = bindings?.LUMEN_SESSION_SECRET || (dev ? process.env.LUMEN_SESSION_SECRET : undefined);
  if (!secret && dev) {
    localSecret ??= bytes64(crypto.getRandomValues(new Uint8Array(32)));
    secret = localSecret;
  }
  if (!secret || secret.length < 32) throw new ApiError(503, "Lumen’s session configuration is incomplete.");
  let network;
  try { network = resolveApiTransport(bindings, options.fetch); }
  catch { throw new ApiError(503, "Lumen’s server connection is not configured."); }
  const transport: AgentsTransport = async (path, init) => {
    if (!/^\/v1\/agents\/sessions(?:\/[A-Za-z0-9_-]+(?:\/(?:turns|items|events))?)?(?:\?[^#]*)?$/.test(path)) throw new ApiError(500, "Unsupported generation operation.");
    const headers = new Headers(init.headers);
    headers.set("Authorization", `Bearer ${key}`);
    try {
      const response = await network.fetch(`${network.origin}${path}`, { ...init, headers, redirect: "manual" });
      if (response.status >= 300 && response.status < 400) throw new Error("Unexpected API redirect");
      if (!response.ok) {
        // Never log upstream bodies: they can contain uploaded data or a credential.
        const requestId = response.headers.get("x-request-id");
        console.error(JSON.stringify({ event: "agents_request_failed", status: response.status, requestId: requestId && /^req_[A-Za-z0-9]{1,100}$/.test(requestId) ? requestId : undefined }));
      }
      return response;
    } catch {
      if (init.signal?.aborted) throw new ApiError(504, "The generation service took too long to respond. Please try again.");
      throw new ApiError(502, "Lumen could not reach the generation service. Please try again.");
    }
  };
  const cleanup = async () => {
    const scope = bindings?.CLEANUP_PROVIDER_SCOPE || (dev ? process.env.CLEANUP_PROVIDER_SCOPE : undefined);
    if (!scope || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$/.test(scope) || !bindings?.DB) {
      throw new ApiError(503, "The site owner needs to configure Lumen’s durable cleanup storage and provider scope.");
    }
    return new CleanupStore(bindings.DB, { scope, fingerprint: await cleanupFingerprint(key, network.origin) }, transport);
  };
  return { transport, secret, cleanup };
}

function bytes64(bytes: Uint8Array): string { return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
function from64(text: string): Uint8Array { return Uint8Array.from(atob(text.replace(/-/g, "+").replace(/_/g, "/")), c => c.charCodeAt(0)); }
async function hashOwner(owner: string): Promise<string> { return bytes64(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(owner)))); }
async function hmacKey(secret: string) { return crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]); }
const digestSchema = z.string().regex(/^[a-f0-9]{64}$/);
const handleSchema = z.object({ id: z.string().regex(/^[A-Za-z0-9_-]{1,200}$/), owner: z.string(), created: z.number().int(), expires: z.number().int(), audience: z.literal("lumen"), requestHash: digestSchema, sourceHash: digestSchema }).strict();
export const tokenRequestSchema = z.object({ token: z.string().max(2000).min(1) }).strict();
// Source travels only in the request body, never the readable signed handle.
export const statusRequestSchema = z.object({ token: tokenRequestSchema.shape.token, document: documentSchema }).strict();
export async function createHandle(id: string, owner: string, secret: string, binding: ReviewBinding, now = Date.now()): Promise<string> {
  const claims = handleSchema.parse({ id, owner: await hashOwner(owner), created: now, expires: now + 10 * 60_000, audience: "lumen", ...binding });
  const payload = bytes64(new TextEncoder().encode(JSON.stringify(claims)));
  const signature = await crypto.subtle.sign("HMAC", await hmacKey(secret), new TextEncoder().encode(payload));
  return `${payload}.${bytes64(new Uint8Array(signature))}`;
}
export async function verifyHandle(token: string, owner: string, secret: string, now = Date.now(), allowExpiredForCleanup = false): Promise<z.output<typeof handleSchema>> {
  try {
    if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(token) || token.length > 2000) throw new Error();
    const [payload, signature] = token.split(".");
    const valid = await crypto.subtle.verify("HMAC", await hmacKey(secret), from64(signature) as BufferSource, new TextEncoder().encode(payload));
    if (!valid) throw new Error();
    const claims = handleSchema.parse(JSON.parse(new TextDecoder().decode(from64(payload))));
    if (claims.owner !== await hashOwner(owner) || (!allowExpiredForCleanup && claims.expires <= now) || claims.created > now + 5000) throw new Error();
    return claims;
  } catch { throw new ApiError(403, "This review session has expired. Submit your brief again."); }
}

export function errorResponse(error: unknown): Response {
  const status = error instanceof ApiError || error instanceof AgentsError ? error.status : 500;
  const message = error instanceof ApiError || error instanceof AgentsError ? error.message : "Something interrupted the generation. Please try again.";
  const responseStatus = error instanceof AgentsError
    ? ([401, 403, 404, 409, 429].includes(status) ? 503 : status >= 500 && ![502, 503, 504].includes(status) ? 502 : status)
    : status;
  return Response.json({ error: message }, { status: responseStatus, headers: { ...privateHeaders, ...(responseStatus === 429 ? { "Retry-After": "60" } : {}) } });
}
