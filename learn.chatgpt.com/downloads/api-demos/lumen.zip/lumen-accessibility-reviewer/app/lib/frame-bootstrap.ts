import axe from "axe-core";
import { auditSchema, documentSchema, type AuditReport, type Finding } from "./contracts";
import { documentParts, normalizeDocument } from "./document-io";
import { assetReferenceRestorer, materializeAssetReferences, validatePreviewAssets } from "./preview-assets";

type BootstrapConfig = { token: string; parentOrigin: string };
declare global { interface Window { __LUMEN_AUDIT_CONFIG__?: BootstrapConfig } }

const config = window.__LUMEN_AUDIT_CONFIG__;
delete window.__LUMEN_AUDIT_CONFIG__;
if (!config || !/^[a-f0-9]{32}$/.test(config.token)) throw new Error("Missing preview configuration.");
const { token, parentOrigin } = config;
let activeRevision = "";
let generation = 0;
let initialized = false;
let auditing = false;
let pendingHighlight: string | null = null;
let highlightTimer: ReturnType<typeof setTimeout> | undefined;
let clearHighlight: (() => void) | undefined;
let restoreReferences: (text: string) => string = text => text;
const userStyle = document.createElement("style");
document.head.appendChild(userStyle);
const send = (type: string, payload: Record<string, unknown> = {}) => {
  window.parent.postMessage({ type, token, ...payload }, parentOrigin);
};

// The submitted page cannot navigate, submit forms, or change the outer document.
document.addEventListener("click", event => {
  if (event.target instanceof Element && event.target.closest("a, area")) event.preventDefault();
}, true);
document.addEventListener("submit", event => event.preventDefault(), true);
axe.configure({ allowedOrigins: [] });

function compact(text: unknown, limit: number): string {
  return typeof text === "string" ? restoreReferences(text).slice(0, limit) : "";
}

function safeSelector(target: axe.NodeResult["target"]): string {
  const selector = target.filter(item => typeof item === "string").join(" ");
  if (!/data:(?:image|font)\//i.test(selector)) return compact(selector, 500);
  // A positional selector still highlights the live element without exposing bytes.
  try {
    let element = document.querySelector(selector);
    const parts: string[] = [];
    while (element) {
      const tag = element.tagName.toLowerCase();
      const siblings = element.parentElement ? Array.from(element.parentElement.children).filter(sibling => sibling.tagName === element?.tagName) : [element];
      parts.unshift(`${tag}:nth-of-type(${siblings.indexOf(element) + 1})`);
      element = element.parentElement;
    }
    return compact(parts.join(" > "), 500);
  } catch { return ""; }
}

// A selector is repair evidence, but does not always identify something visible.
function previewTarget(selector: string, ruleId = ""): NonNullable<Finding["previewTarget"]> {
  let element: Element | null = null;
  try { element = selector ? document.querySelector(selector) : null; } catch { return "none"; }
  if (!element) return "none";
  if (element === document.documentElement || element === document.body || document.head.contains(element)) return "page";
  if (!(element instanceof HTMLElement || element instanceof SVGElement)) return "none";
  const rect = element.getBoundingClientRect();
  if (!rect.width || !rect.height || (rect.width <= 1 && rect.height <= 1)) return "none";
  if (rect.right + window.scrollX <= 0 || rect.bottom + window.scrollY <= 0) return "none";
  for (let ancestor: Element | null = element; ancestor; ancestor = ancestor.parentElement) {
    const style = getComputedStyle(ancestor);
    if (style.visibility !== "visible" || Number(style.opacity) === 0 || style.display === "none") return "none";
    if (/^rect\(0px[ ,]+0px[ ,]+0px[ ,]+0px\)$/.test(style.clip) || /^inset\(50%\)$/.test(style.clipPath)) return "none";
  }
  return ruleId === "region" ? "content" : "element";
}

function metadataFindings(): Finding[] {
  const found: Finding[] = [];
  const metadata = [
    { missing: !document.title.trim(), ruleId: "document-title", selector: "title", title: "Page needs a descriptive title", description: "A descriptive document title helps people identify the page.", html: "<title></title>" },
    { missing: !document.documentElement.lang.trim(), ruleId: "html-has-lang", selector: "html", title: "Page needs a language", description: "A document language helps assistive technology pronounce the content.", html: "<html>" },
  ];
  for (const item of metadata) if (item.missing) {
    found.push({ key: `${item.ruleId}:${item.selector}`, ruleId: item.ruleId, title: item.title, description: item.description, impact: "serious", kind: "violation", selector: item.selector, html: item.html, previewTarget: "page", failureSummary: item.description, helpUrl: `https://dequeuniversity.com/rules/axe/4.14/${item.ruleId}` });
  }
  return found;
}

function findingsFrom(results: axe.AxeResults): AuditReport {
  const findings = metadataFindings();
  const metadataRules = new Set(["document-title", "html-has-lang"]);
  const seen = new Set(findings.map(finding => finding.key));
  for (const kind of ["violation", "review"] as const) {
    for (const result of kind === "violation" ? results.violations : results.incomplete) {
      if (metadataRules.has(result.id)) continue;
      for (const node of result.nodes) {
        const selector = safeSelector(node.target);
        const key = compact(`${result.id}:${selector}`, 700);
        if (seen.has(key)) continue;
        seen.add(key);
        findings.push({
          key, ruleId: compact(result.id, 100), title: compact(result.help, 200), description: compact(result.description, 500),
          impact: node.impact || result.impact || "unknown", kind, selector, html: compact(restoreReferences(node.html), 1000),
          previewTarget: previewTarget(selector, result.id),
          failureSummary: compact(node.failureSummary || "This check needs human review.", 1600),
          helpUrl: compact(result.helpUrl, 300),
        });
      }
    }
  }
  const metadataPassed = 2 - metadataFindings().length;
  return auditSchema.parse({
    findings: findings.slice(0, 50),
    passed: Math.min(1000, results.passes.filter(result => !metadataRules.has(result.id)).length + metadataPassed),
    incomplete: Math.min(1000, findings.filter(finding => finding.kind === "review").length),
    viewport: { width: window.innerWidth, height: window.innerHeight },
    truncated: findings.length > 50,
  });
}

function highlight(selector: string | null) {
  clearHighlight?.();
  if (!selector) return;
  const kind = previewTarget(selector);
  if (kind === "none" || kind === "page") return;
  let target: Element | null = null;
  try { target = document.querySelector(selector); } catch { return; }
  if (!(target instanceof HTMLElement || target instanceof SVGElement)) return;
  const element = target;
  const inlineStyle = element.getAttribute("style");
  element.style.setProperty("outline", "3px solid #6152e8", "important");
  element.style.setProperty("outline-offset", "3px", "important");
  element.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
  clearHighlight = () => {
    clearTimeout(highlightTimer);
    if (inlineStyle === null) element.removeAttribute("style"); else element.setAttribute("style", inlineStyle);
    clearHighlight = undefined;
  };
  highlightTimer = setTimeout(() => clearHighlight?.(), 1800);
}

window.addEventListener("message", async event => {
  if (event.source !== window.parent || event.origin !== parentOrigin || !event.data || event.data.token !== token) return;
  const message = event.data;
  if (message.type === "lumen:highlight") {
    if (message.revision === activeRevision && (message.selector === null || (typeof message.selector === "string" && message.selector.length <= 500))) {
      if (auditing) pendingHighlight = message.selector;
      else highlight(message.selector);
    }
    return;
  }
  // One document per iframe: a revision change mounts a fresh isolated frame.
  if (message.type !== "lumen:render" || initialized || typeof message.revision !== "string" || message.revision.length > 200 || typeof message.audit !== "boolean") return;
  initialized = true;
  auditing = message.audit;
  const thisGeneration = ++generation;
  activeRevision = message.revision;
  try {
    const { document: normalized, removed } = normalizeDocument(documentSchema.parse(message.document));
    const assets = validatePreviewAssets(message.assets);
    const parts = documentParts(normalized.html);
    restoreReferences = assetReferenceRestorer(assets);
    for (const [name, value] of Object.entries(parts.htmlAttributes)) document.documentElement.setAttribute(name, materializeAssetReferences(value, assets));
    for (const [name, value] of Object.entries(parts.bodyAttributes)) document.body.setAttribute(name, materializeAssetReferences(value, assets));
    document.title = normalized.title;
    if (normalized.lang) document.documentElement.lang = normalized.lang; else document.documentElement.removeAttribute("lang");
    userStyle.textContent = materializeAssetReferences(normalized.css, assets);
    document.body.innerHTML = materializeAssetReferences(parts.bodyHtml, assets);
    // Establish layout so used font faces start loading before the readiness wait.
    void document.body.offsetWidth;
    await Promise.race([
      Promise.all([document.fonts.ready, ...Array.from(document.images).map(image => image.decode().catch(() => undefined))]),
      new Promise(resolve => setTimeout(resolve, 2500)),
    ]);
    await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
    if (thisGeneration !== generation) return;
    send("lumen:rendered", { revision: activeRevision });
    if (!message.audit) return;
    const results = await axe.run(document, {
      runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa", "best-practice"] },
      iframes: false,
      resultTypes: ["violations", "incomplete", "passes"],
    });
    if (thisGeneration !== generation) return;
    const report = findingsFrom(results);
    auditing = false;
    send("lumen:result", { snapshot: { ...report, revision: activeRevision, document: normalized, removed } });
    if (pendingHighlight) highlight(pendingHighlight);
  } catch {
    auditing = false;
    send("lumen:error", { revision: activeRevision, message: "The page could not be checked. Try a smaller HTML/CSS document and run the check again." });
  }
});
send("lumen:ready");
