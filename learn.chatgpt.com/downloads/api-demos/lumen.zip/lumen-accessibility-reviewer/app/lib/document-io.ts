import DOMPurify from "dompurify";
import { documentSchema, MAX_IMPORT_HTML_BYTES, type PageDocument } from "./contracts";
import { isPreviewAssetReference, materializeAssetReferences, validatePreviewAssets, type PreviewAssets } from "./preview-assets";

const FORBIDDEN_TAGS = ["script", "iframe", "frame", "frameset", "object", "embed", "base", "meta", "link", "template", "noscript"];
const RASTER_DATA = /^data:image\/(?:png|jpeg|gif|webp|avif);base64,[a-z\d+/=\s]+$/i;

function browserOnly() {
  if (typeof window === "undefined" || !DOMPurify.isSupported) {
    throw new Error("Open this page in a current browser to import or export HTML.");
  }
}

/** Network resources and navigation are deliberately outside the static preview. */
function constrainResources(root: Element | DocumentFragment): number {
  let removed = 0;
  const elements = [...(root instanceof Element ? [root] : []), ...root.querySelectorAll("*")];
  for (const element of elements) {
    for (const attribute of Array.from(element.attributes)) {
      const name = attribute.name.toLowerCase();
      if (["srcset", "action", "formaction", "formtarget", "target", "ping", "poster", "background", "autofocus", "nonce", "is"].includes(name)) {
        element.removeAttribute(attribute.name); removed++;
      } else if (name === "src" && !(element.tagName === "IMG" && (RASTER_DATA.test(attribute.value) || isPreviewAssetReference(attribute.value)))) {
        element.removeAttribute(attribute.name); removed++;
      } else if (name === "href" && !attribute.value.startsWith("#")) {
        // Keep links keyboard reachable without permitting navigation or network work.
        element.setAttribute("href", "#"); removed++;
      }
    }
  }
  return removed;
}

export type DocumentParts = { htmlAttributes: Record<string, string>; bodyAttributes: Record<string, string>; bodyHtml: string };

function attributes(element: Element | null, omitLang = false): Record<string, string> {
  return Object.fromEntries(Array.from(element?.attributes || []).filter(attribute => !omitLang || attribute.name !== "lang").map(attribute => [attribute.name, attribute.value]));
}

function sanitizeHtml(html: string): DocumentParts & { html: string; removed: number } {
  browserOnly();
  const root = DOMPurify.sanitize(html, {
    WHOLE_DOCUMENT: true,
    USE_PROFILES: { html: true },
    FORBID_TAGS: [...FORBIDDEN_TAGS, "style"],
    // The detached result is immediately restricted to raster data/opaque refs.
    ADD_URI_SAFE_ATTR: ["src"],
    RETURN_DOM: true,
  }) as HTMLElement;
  const removed = DOMPurify.removed.length + constrainResources(root);
  const body = root.querySelector("body");
  const parts = { htmlAttributes: attributes(root, true), bodyAttributes: attributes(body), bodyHtml: body?.innerHTML || "" };
  const hasRoots = Object.keys(parts.htmlAttributes).length || Object.keys(parts.bodyAttributes).length;
  return { ...parts, removed, html: hasRoots ? `<html${serializeAttributes(parts.htmlAttributes)}><body${serializeAttributes(parts.bodyAttributes)}>${parts.bodyHtml}</body></html>` : parts.bodyHtml };
}

/** Root attributes are applied to the real iframe roots, never to wrapper elements. */
export function documentParts(html: string): DocumentParts {
  const { htmlAttributes, bodyAttributes, bodyHtml } = sanitizeHtml(html);
  return { htmlAttributes, bodyAttributes, bodyHtml };
}

/** Preserve CSS text; the preview and standalone export both deny external loads. */
export function normalizeDocument(input: PageDocument): { document: PageDocument; removed: number } {
  const parsed = documentSchema.parse(input);
  const body = sanitizeHtml(parsed.html);
  return { document: documentSchema.parse({ ...parsed, html: body.html }), removed: body.removed };
}

export function importHtml(text: string): { document: PageDocument; removed: number } {
  browserOnly();
  if (new TextEncoder().encode(text).byteLength > MAX_IMPORT_HTML_BYTES) throw new Error(`Keep the HTML file under ${MAX_IMPORT_HTML_BYTES / 1_000_000} MB.`);
  // DOMPurify parses an inert document. Never put the submitted document in the app DOM.
  const imported = DOMPurify.sanitize(text, {
    WHOLE_DOCUMENT: true,
    USE_PROFILES: { html: true },
    // DOMPurify's HTML-only profile omits title (it is in the SVG tag list).
    // Importing a full document still needs its inert text metadata.
    ADD_TAGS: ["title"],
    ADD_URI_SAFE_ATTR: ["src"],
    FORBID_TAGS: FORBIDDEN_TAGS,
    RETURN_DOM: true,
  }) as HTMLElement;
  let removed = DOMPurify.removed.length;
  const css = Array.from(imported.querySelectorAll("style")).map(style => {
    const source = style.textContent || "", media = style.getAttribute("media")?.trim();
    return media ? `@media ${media}{\n${source}\n}` : source;
  }).join("\n\n");
  for (const style of imported.querySelectorAll("style")) style.remove();
  removed += constrainResources(imported);
  const body = imported.querySelector("body");
  const result = normalizeDocument({
    title: imported.querySelector("title")?.textContent || "",
    lang: imported.getAttribute("lang") || "",
    html: `<html${serializeAttributes(attributes(imported, true))}><body${serializeAttributes(attributes(body))}>${body?.innerHTML || ""}</body></html>`,
    css,
  });
  return { document: result.document, removed: removed + result.removed };
}

function escapeHtml(text: string): string {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function serializeAttributes(values: Record<string, string>): string {
  return Object.entries(values).map(([name, value]) => ` ${name}="${escapeHtml(value)}"`).join("");
}

export function exportDocumentHtml(input: PageDocument, assetInput?: PreviewAssets): string {
  const { document } = normalizeDocument(input);
  const assets = validatePreviewAssets(assetInput);
  const parts = documentParts(document.html);
  const htmlAttributes = { ...parts.htmlAttributes, ...(document.lang ? { lang: document.lang } : {}) };
  // CSS escapes preserve literal '<' without allowing an HTML raw-text closing tag.
  const css = materializeAssetReferences(document.css, assets).replace(/</g, "\\3c ");
  const rootAttrs = materializeAssetReferences(serializeAttributes(htmlAttributes), assets);
  const bodyAttrs = materializeAssetReferences(serializeAttributes(parts.bodyAttributes), assets);
  const bodyHtml = materializeAssetReferences(parts.bodyHtml, assets);
  const output = `<!doctype html>\n<html${rootAttrs}>\n<head>\n<meta charset="utf-8">\n<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; font-src data:; base-uri 'none'; form-action 'none'">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>${escapeHtml(document.title)}</title>\n<style>${css}</style>\n</head>\n<body${bodyAttrs}>${bodyHtml}</body>\n</html>\n`;
  if (new TextEncoder().encode(output).byteLength > MAX_IMPORT_HTML_BYTES) throw new Error(`This HTML export exceeds ${MAX_IMPORT_HTML_BYTES / 1_000_000} MB. Remove repeated or large images/fonts and try again.`);
  return output;
}
