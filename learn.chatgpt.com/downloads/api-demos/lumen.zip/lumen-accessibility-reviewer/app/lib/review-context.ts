import type { CreateRequest, Finding } from "./contracts.ts";

// These are deliberately exact overview requests, not a general intent classifier.
// Ambiguous follow-ups, source-specific questions and edit requests keep file access.
const overviewQuestions = new Set([
  "what is this", "what is this page", "what does this page do",
  "explain the main issues", "explain the most important issues on this page",
  "what should i check manually", "what should i check manually on this page",
]);
export function isOverviewQuestion(brief: string): boolean {
  return overviewQuestions.has(brief.trim().toLowerCase().replace(/[?.!]+$/, "").replace(/\s+/g, " "));
}

export const MAX_CONTEXT_CHARS = 24_000;
const priority: Record<Finding["impact"], number> = { critical: 0, serious: 1, moderate: 2, minor: 3, unknown: 4 };

/** A bounded introduction; authoritative source and complete history remain in files. */
export function makeReviewContext(request: CreateRequest) {
  const selected = new Set(request.selectedFindingKeys);
  const indexed = request.audit.findings.map((finding, index) => ({ finding, index }));
  const ordered = [...indexed].sort((a, b) => Number(selected.has(b.finding.key)) - Number(selected.has(a.finding.key))
    || Number(a.finding.kind === "review") - Number(b.finding.kind === "review")
    || priority[a.finding.impact] - priority[b.finding.impact]);
  const groups = new Map<string, { ruleId: string; title: string; kind: Finding["kind"]; impact: Finding["impact"]; count: number }>();
  for (const { finding } of ordered) {
    const key = JSON.stringify([finding.ruleId, finding.kind, finding.impact]);
    const group = groups.get(key);
    if (group) group.count++;
    else groups.set(key, { ruleId: finding.ruleId, title: finding.title, kind: finding.kind, impact: finding.impact, count: 1 });
  }
  const context = {
    brief: request.brief,
    source_in_workspace: !isOverviewQuestion(request.brief),
    page: {
      title: request.document.title, lang: request.document.lang,
      html_characters: request.document.html.length, css_characters: request.document.css.length,
      // A source-text excerpt, not a claim about visibility or the complete page.
      text_excerpt: request.document.html.replace(/<!--[\s\S]*?-->/g, " ")
        .replace(/<(script|style|template|head)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, " ")
        .replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim().slice(0, 800),
    },
    audit: {
      passed: request.audit.passed, incomplete: request.audit.incomplete, viewport: request.audit.viewport,
      truncated: request.audit.truncated,
      confirmed_findings: indexed.filter(({ finding }) => finding.kind === "violation").length,
      review_findings: indexed.filter(({ finding }) => finding.kind === "review").length,
      selected_indexes: indexed.filter(({ finding }) => selected.has(finding.key)).map(({ index }) => index),
      rules: [] as Array<{ ruleId: string; title: string; kind: Finding["kind"]; impact: Finding["impact"]; count: number }>,
      omitted_rules: groups.size,
      details: [] as Array<{ index: number; selected: boolean; ruleId: string; title: string; kind: Finding["kind"]; impact: Finding["impact"]; selector: string; html: string; failureSummary: string }>,
      omitted_details: indexed.length,
    },
    history: [] as Array<{ role: "user" | "assistant"; content: string; truncated: boolean }>,
    omitted_history: request.history.length,
  };

  function append<T>(list: T[], candidate: T, budget: number, prepend = false): boolean {
    prepend ? list.unshift(candidate) : list.push(candidate);
    if (JSON.stringify(list).length <= budget && JSON.stringify(context).length <= MAX_CONTEXT_CHARS) return true;
    prepend ? list.shift() : list.pop();
    return false;
  }
  // Prioritize recent turns; complete, unabridged history stays in the manifest.
  for (const turn of [...request.history].reverse()) {
    if (!append(context.history, { ...turn, content: turn.content.slice(0, 800), truncated: turn.content.length > 800 }, 6_000, true)) break;
    context.omitted_history--;
  }
  for (const group of groups.values()) {
    if (append(context.audit.rules, group, 4_000)) context.audit.omitted_rules--;
  }
  for (const { finding, index } of ordered) {
    const { ruleId, title, kind, impact, selector, html, failureSummary } = finding;
    if (append(context.audit.details, { index, selected: selected.has(finding.key), ruleId, title, kind, impact, selector, html, failureSummary }, 8_000)) context.audit.omitted_details--;
  }
  return context;
}
