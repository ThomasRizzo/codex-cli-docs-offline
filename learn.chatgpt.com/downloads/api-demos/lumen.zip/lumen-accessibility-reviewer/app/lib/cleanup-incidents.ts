import { z } from "zod";

const uuid = z.string().uuid();
const identifier = /^[A-Z][A-Z0-9]{0,15}-[1-9][0-9]{0,11}$/;
const LEASE_MS = 5 * 60_000;
export const ticketFailureSchema = z.enum(["lookup_failed", "create_failed", "create_ambiguous", "readback_failed", "receipt_mismatch", "rate_limited"]);
export type TicketFailure = z.infer<typeof ticketFailureSchema>;
export const ticketReceiptSchema = z.object({
  issue_id: uuid,
  identifier: z.string().regex(identifier),
  url: z.string().max(500),
  assignee_email: z.string().email().max(254),
  priority: z.literal(1),
}).strict().refine(receipt => {
  try {
    const url = new URL(receipt.url);
    const parts = url.pathname.split("/");
    return url.protocol === "https:" && url.hostname === "linear.app" && !url.port && !url.username && !url.password
      && !url.search && !url.hash && parts.length >= 4 && parts.length <= 5
      && /^[a-zA-Z0-9_-]+$/.test(parts[1]) && parts[2] === "issue" && parts[3] === receipt.identifier
      && (parts.length === 4 || /^[a-zA-Z0-9_-]+$/.test(parts[4]));
  } catch { return false; }
}, "Expected the canonical Linear URL for this issue identifier");
export type TicketReceipt = z.infer<typeof ticketReceiptSchema>;
type Incident = {
  id: string; kind: "provider" | "drill"; opened_at: number; last_seen_at: number; recovered_at: number | null;
  first_snapshot: string; latest_snapshot: string; attempts: number; next_attempt_at: number;
  lease_token: string | null; lease_until: number | null; last_error: string | null;
  ticket_receipt: string | null; ticket_recorded_at: number | null; acknowledged_token: string | null;
};

/** An escalation outbox independent of the changing cleanup backlog. No user content. */
export class CleanupIncidents {
  private readonly db: D1Database;
  private readonly app: string;
  private readonly now: () => number;
  constructor(db: D1Database, app: string, now: () => number) { this.db = db; this.app = app; this.now = now; }

  private describe(row: Incident) {
    return {
      id: row.id, marker: `api-showcase-cleanup:${this.app}:${row.id}`, synthetic: row.kind === "drill",
      openedAt: row.opened_at, lastSeenAt: row.last_seen_at, recoveredAt: row.recovered_at,
      firstSummary: JSON.parse(row.first_snapshot), summary: JSON.parse(row.latest_snapshot),
      attempts: row.attempts, nextAttemptAt: row.next_attempt_at, leaseUntil: row.lease_until,
      lastError: row.last_error, ticket: row.ticket_receipt ? JSON.parse(row.ticket_receipt) as TicketReceipt : null,
      ticketRecordedAt: row.ticket_recorded_at,
    };
  }

  async observe(problem: boolean, summary: object, observedAt: number): Promise<void> {
    const now = observedAt, snapshot = JSON.stringify({ app: this.app, ...summary });
    if (problem) {
      await this.db.prepare(`INSERT INTO cleanup_incidents
        (id, kind, active_key, opened_at, last_seen_at, first_snapshot, latest_snapshot, next_attempt_at)
        VALUES (?, 'provider', 'provider', ?, ?, ?, ?, ?)
        ON CONFLICT(active_key) DO UPDATE SET last_seen_at = MAX(last_seen_at, excluded.last_seen_at),
          latest_snapshot = CASE WHEN last_seen_at <= excluded.last_seen_at THEN excluded.latest_snapshot ELSE latest_snapshot END`)
        .bind(crypto.randomUUID(), now, now, snapshot, snapshot, now).run();
    } else {
      // Use the snapshot's start time, not the later write time. A delayed healthy
      // snapshot (including a same-millisecond tie) must not resolve a newer failure.
      // This fences stale recovery, not a total ordering of concurrent observations.
      // Recovery never erases the obligation to file a ticket for an observed breach.
      await this.db.prepare(`UPDATE cleanup_incidents SET active_key = NULL, recovered_at = ?, last_seen_at = ?,
        latest_snapshot = ? WHERE active_key = 'provider' AND last_seen_at < ?`).bind(now, now, snapshot, now).run();
    }
  }

  async status() {
    const results = await this.db.batch([
      this.db.prepare("SELECT * FROM cleanup_incidents WHERE ticket_receipt IS NULL ORDER BY opened_at, id LIMIT 1"),
      this.db.prepare(`SELECT COUNT(*) AS pending, COALESCE(SUM(next_attempt_at <= ? AND (lease_until IS NULL OR lease_until <= ?)), 0) AS due
        FROM cleanup_incidents WHERE ticket_receipt IS NULL`).bind(this.now(), this.now()),
      this.db.prepare("SELECT * FROM cleanup_incidents WHERE ticket_receipt IS NOT NULL ORDER BY ticket_recorded_at DESC, id DESC LIMIT 1"),
    ]);
    const alert = results[0].results[0] as Incident | undefined;
    const counts = results[1].results[0] as { pending: number; due: number };
    const latest = results[2].results[0] as Incident | undefined;
    return { alert: alert ? this.describe(alert) : null, pendingIncidents: counts.pending, dueIncidents: counts.due,
      latestTicket: latest ? this.describe(latest) : null };
  }

  async claim() {
    const now = this.now(), token = crypto.randomUUID();
    const row = await this.db.prepare(`UPDATE cleanup_incidents SET lease_token = ?, lease_until = ?, attempts = attempts + 1
      WHERE id = (SELECT id FROM cleanup_incidents WHERE ticket_receipt IS NULL AND next_attempt_at <= ?
        AND (lease_until IS NULL OR lease_until <= ?) ORDER BY opened_at, id LIMIT 1) RETURNING *`)
      .bind(token, now + LEASE_MS, now, now).first<Incident>();
    return row ? { ...this.describe(row), lease_token: token } : null;
  }

  async retry(id: string, token: string, category: TicketFailure, retryAfterSeconds = 0): Promise<boolean> {
    if (!uuid.safeParse(id).success || !uuid.safeParse(token).success || !ticketFailureSchema.safeParse(category).success
      || !Number.isInteger(retryAfterSeconds) || retryAfterSeconds < 0 || retryAfterSeconds > 900) return false;
    const now = this.now();
    const row = await this.db.prepare(`SELECT * FROM cleanup_incidents WHERE id = ? AND lease_token = ?
      AND lease_until > ? AND ticket_receipt IS NULL`).bind(id, token, now).first<Incident>();
    if (!row) return false;
    const delay = Math.max(retryAfterSeconds * 1000, Math.min(900_000, 30_000 * 2 ** Math.min(row.attempts - 1, 5)));
    const saved = await this.db.prepare(`UPDATE cleanup_incidents SET next_attempt_at = ?, last_error = ?,
      lease_token = NULL, lease_until = NULL WHERE id = ? AND lease_token = ? AND lease_until > ?
      AND ticket_receipt IS NULL RETURNING id`).bind(now + delay, category, id, token, now).first();
    return !!saved;
  }

  /** The authenticated owner scheduler attests that it read back this Linear receipt.
   * The Site validates its shape and owner, but has no Linear credential to verify it independently. */
  async acknowledge(id: string, token: string, value: unknown, owner: string): Promise<boolean> {
    const parsed = ticketReceiptSchema.safeParse(value);
    if (!uuid.safeParse(id).success || !uuid.safeParse(token).success || !parsed.success
      || !z.string().email().safeParse(owner).success || parsed.data.assignee_email.toLowerCase() !== owner.toLowerCase()) return false;
    const receipt = JSON.stringify({ ...parsed.data, assignee_email: parsed.data.assignee_email.toLowerCase() });
    const now = this.now();
    const saved = await this.db.prepare(`UPDATE cleanup_incidents SET ticket_receipt = ?, ticket_recorded_at = ?,
      acknowledged_token = ?, lease_token = NULL, lease_until = NULL, last_error = NULL
      WHERE id = ? AND lease_token = ? AND lease_until > ? AND ticket_receipt IS NULL RETURNING id`)
      .bind(receipt, now, token, id, token, now).first();
    if (saved) return true;
    // A response lost after commit can be retried, but a stale or different receipt cannot replace proof.
    const existing = await this.db.prepare(`SELECT id FROM cleanup_incidents
      WHERE id = ? AND acknowledged_token = ? AND ticket_receipt = ?`).bind(id, token, receipt).first();
    return !!existing;
  }

  async testAlert(testId: string) {
    if (!uuid.safeParse(testId).success) throw new Error("invalid_cleanup_test_id");
    const now = this.now(), snapshot = JSON.stringify({ app: this.app, synthetic: true, category: "simulated_delete_failure",
      description: "Owner-requested escalation drill. No provider session, customer data or provider request exists." });
    await this.db.prepare(`INSERT INTO cleanup_incidents
      (id, kind, opened_at, last_seen_at, first_snapshot, latest_snapshot, next_attempt_at)
      VALUES (?, 'drill', ?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING`).bind(testId, now, now, snapshot, snapshot, now).run();
    const row = await this.db.prepare("SELECT * FROM cleanup_incidents WHERE id = ?").bind(testId).first<Incident>();
    if (!row || row.kind !== "drill") throw new Error("cleanup_test_identity_conflict");
    return this.describe(row);
  }
}
