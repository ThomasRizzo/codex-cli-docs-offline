import { z } from "zod";
import { ticketFailureSchema, ticketReceiptSchema, type TicketFailure } from "./cleanup-incidents.ts";
import { getRuntime, parseBody, privateHeaders, runtimeBindings, type Bindings } from "./server.ts";

const empty = { type: "object", properties: {}, additionalProperties: false };
const leaseProperties = { alert_id: { type: "string", format: "uuid" }, lease_token: { type: "string", format: "uuid" } };
const tools = [
  { name: "cleanup_run", description: "Run a bounded cleanup/reconciliation batch and durably preserve failure episodes, including recovered incidents awaiting P0 tickets.", inputSchema: empty },
  { name: "cleanup_status", description: "Read cleanup health, pending durable incidents and the latest recorded Linear ticket receipt. Does not acknowledge incidents.", inputSchema: empty },
  { name: "cleanup_claim_alert", description: "Lease one due incident for five minutes. Before creating a P0, find its exact marker in Linear; use provider idempotency where available. Read back priority 1 and owner assignment before acknowledgment. A null result means none is currently claimable.", inputSchema: empty },
  { name: "cleanup_retry_alert", description: "Persist a failed or ambiguous ticket attempt and release its lease with backoff. A create timeout requires lookup of the same marker before retrying creation. No raw error or customer content is accepted.", inputSchema: {
    type: "object", properties: { ...leaseProperties, category: { type: "string", enum: ticketFailureSchema.options }, retry_after_seconds: { type: "integer", minimum: 0, maximum: 900 } },
    required: ["alert_id", "lease_token", "category"], additionalProperties: false,
  } },
  { name: "cleanup_ack_alert", description: "Record a Linear P0 ticket receipt only after the owner scheduler has read back the issue's exact marker, priority 1, and configured owner assignment. The Site trusts that authenticated readback attestation; it has no Linear credential. Notification-only acknowledgments are rejected.", inputSchema: {
    type: "object", properties: { ...leaseProperties, receipt: { type: "object", properties: {
      issue_id: { type: "string", format: "uuid" }, identifier: { type: "string" }, url: { type: "string" },
      assignee_email: { type: "string", format: "email" }, priority: { type: "integer", const: 1 },
    }, required: ["issue_id", "identifier", "url", "assignee_email", "priority"], additionalProperties: false } },
    required: ["alert_id", "lease_token", "receipt"], additionalProperties: false,
  } },
  { name: "cleanup_test_alert", description: "Owner-authorized escalation drill: idempotently enqueue a clearly synthetic simulated deletion failure through the same durable incident/ticket path. Creates no provider session, customer data, or provider API request. Reusing test_id returns the same incident, including its existing receipt; it never reopens it.", inputSchema: {
    type: "object", properties: { test_id: { type: "string", format: "uuid" } }, required: ["test_id"], additionalProperties: false,
  } },
];
const leaseShape = { alert_id: z.string().uuid(), lease_token: z.string().uuid() };
const argumentSchemas = {
  cleanup_run: z.object({}).strict(), cleanup_status: z.object({}).strict(), cleanup_claim_alert: z.object({}).strict(),
  cleanup_retry_alert: z.object({ ...leaseShape, category: ticketFailureSchema, retry_after_seconds: z.number().int().min(0).max(900).optional() }).strict(),
  cleanup_ack_alert: z.object({ ...leaseShape, receipt: ticketReceiptSchema }).strict(),
  cleanup_test_alert: z.object({ test_id: z.string().uuid() }).strict(),
};
const rpcSchema = z.object({ jsonrpc: z.literal("2.0"), id: z.union([z.string().max(200), z.number().finite(), z.null()]), method: z.string().max(100), params: z.unknown().optional() }).strict();
const callSchema = z.object({ name: z.enum(["cleanup_run", "cleanup_status", "cleanup_claim_alert", "cleanup_retry_alert", "cleanup_ack_alert", "cleanup_test_alert"]), arguments: z.record(z.unknown()).optional(), _meta: z.record(z.unknown()).optional() }).strict();

export async function cleanupMcp(request: Request, injected?: { bindings: Bindings | null; runtime?: typeof getRuntime }): Promise<Response> {
  let id: string | number | null = null;
  const response = (body: unknown, status = 200) => Response.json(body, { status, headers: privateHeaders });
  const failure = (code: number, message: string, status = 200) => response({ jsonrpc: "2.0", id, error: { code, message } }, status);
  try {
    const rpc = await parseBody(request, rpcSchema, 4096); id = rpc.id;
    if (rpc.method === "server/discover") return response({ jsonrpc: "2.0", id, result: { supportedVersions: ["2026-07-28"], capabilities: { tools: {} } } });
    if (rpc.method === "tools/list") return response({ jsonrpc: "2.0", id, result: { tools } });
    if (rpc.method !== "tools/call") return failure(-32601, "Method not found");
    const bindings = injected ? injected.bindings : await runtimeBindings();
    const owner = bindings?.CLEANUP_OWNER_EMAIL?.trim().toLowerCase();
    const email = request.headers.get("oai-authenticated-user-email")?.trim().toLowerCase();
    const userId = request.headers.get("oai-authenticated-user-id");
    // Trust these headers only behind Sites' authenticated ingress. A public
    // self-hosted deployment must strip them and supply its own verified identity.
    if (bindings?.CLEANUP_IDENTITY_PROVIDER !== "sites" || !owner || !/^[^\s@]+@[^\s@]+$/.test(owner) || !userId?.trim() || !email || email !== owner) return failure(-32001, "Owner authentication required", 403);
    const parsed = callSchema.safeParse(rpc.params);
    if (!parsed.success) return failure(-32602, "Invalid tool arguments");
    const { name, arguments: args = {} } = parsed.data;
    const validated = argumentSchemas[name].safeParse(args);
    if (!validated.success) return failure(-32602, "Invalid tool arguments");
    if (name === "cleanup_ack_alert" && (args.receipt as { assignee_email: string }).assignee_email.toLowerCase() !== owner) return failure(-32602, "Ticket must be assigned to the configured cleanup owner");
    try {
      const runtime = await (injected?.runtime ?? getRuntime)({ bindings });
      const store = await runtime.cleanup();
      const result = name === "cleanup_run" ? await store.run()
        : name === "cleanup_status" ? await store.status()
        : name === "cleanup_claim_alert" ? await store.claimAlert()
        : name === "cleanup_retry_alert" ? { retry_queued: await store.retryAlert(args.alert_id as string, args.lease_token as string, args.category as TicketFailure, args.retry_after_seconds as number | undefined) }
        : name === "cleanup_test_alert" ? await store.testAlert(args.test_id as string)
        : { acknowledged: await store.acknowledge(args.alert_id as string, args.lease_token as string, args.receipt, owner) };
      return response({ jsonrpc: "2.0", id, result: { content: [{ type: "text", text: JSON.stringify(result) }] } });
    } catch {
      return response({ jsonrpc: "2.0", id, result: { isError: true, content: [{ type: "text", text: "Cleanup maintenance failed. Check storage, provider scope and credentials; unresolved records have not been discarded." }] } });
    }
  } catch { return failure(-32600, "Invalid JSON-RPC request", 400); }
}
