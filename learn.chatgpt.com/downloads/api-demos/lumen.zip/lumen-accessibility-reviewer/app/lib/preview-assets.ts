/** Asset bytes never belong in the editable source or an API request. */
export type PreviewAssets = Record<string, string>;

export const MAX_PREVIEW_ASSET_BYTES = 2_000_000;
export const MAX_PREVIEW_ASSETS_BYTES = 8_000_000;
export const MAX_PREVIEW_ASSETS = 100;
const ID = /^[a-f0-9]{64}$/;
const REFERENCE = /^lumen-asset:[a-f0-9]{64}$/;
const DATA = /^data:(image\/(?:png|jpeg|gif|webp|avif)|font\/(?:woff2?|ttf|otf));base64,((?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?)$/;

export function isPreviewAssetReference(value: string): boolean { return REFERENCE.test(value); }

function matchesType(bytes: Uint8Array, mime: string): boolean {
  const ascii = (offset: number, value: string) => [...value].every((character, index) => bytes[offset + index] === character.charCodeAt(0));
  switch (mime) {
    case "image/png": return [137, 80, 78, 71, 13, 10, 26, 10].every((byte, index) => bytes[index] === byte);
    case "image/jpeg": return bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
    case "image/gif": return ascii(0, "GIF87a") || ascii(0, "GIF89a");
    case "image/webp": return ascii(0, "RIFF") && ascii(8, "WEBP");
    case "image/avif": return ascii(4, "ftyp") && [8, 16, 20, 24, 28].some(offset => ascii(offset, "avif") || ascii(offset, "avis"));
    case "font/woff": return ascii(0, "wOFF");
    case "font/woff2": return ascii(0, "wOF2");
    case "font/ttf": return (bytes[0] === 0 && bytes[1] === 1 && bytes[2] === 0 && bytes[3] === 0) || ascii(0, "true");
    case "font/otf": return ascii(0, "OTTO");
    default: return false;
  }
}

function assetSize(value: unknown): number {
  if (typeof value !== "string" || value.length > Math.ceil(MAX_PREVIEW_ASSET_BYTES / 3) * 4 + 80) throw Error("Keep each preview image or font under 2 MB.");
  const match = DATA.exec(value);
  if (!match || !match[2]) throw Error("Preview assets must be embedded raster images or fonts.");
  const size = match[2].length / 4 * 3 - (match[2].endsWith("==") ? 2 : match[2].endsWith("=") ? 1 : 0);
  if (size > MAX_PREVIEW_ASSET_BYTES) throw Error("Keep each preview image or font under 2 MB.");
  // Checking the declared format prevents an SVG/HTML file masquerading as a raster.
  const prefix = Uint8Array.from(atob(match[2].slice(0, 48)), character => character.charCodeAt(0));
  if (!matchesType(prefix, match[1])) throw Error("A preview asset does not match its image or font format.");
  return size;
}

export function validatePreviewAssets(value: unknown = {}): PreviewAssets {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw Error("The saved page has invalid preview assets.");
  const entries = Object.entries(value);
  if (entries.length > MAX_PREVIEW_ASSETS) throw Error("Keep the saved page to 100 preview images and fonts.");
  const assets: PreviewAssets = {};
  let size = 0;
  for (const [id, data] of entries) {
    if (!ID.test(id)) throw Error("The saved page has an invalid asset reference.");
    size += assetSize(data);
    if (size > MAX_PREVIEW_ASSETS_BYTES) throw Error("Keep preview images and fonts under 8 MB in total.");
    assets[id] = data as string;
  }
  return assets;
}

export async function createPreviewAsset(bytes: Uint8Array, mime: string): Promise<{ id: string; reference: string; dataUrl: string }> {
  if (!bytes.length || bytes.length > MAX_PREVIEW_ASSET_BYTES) throw Error("Keep each preview image or font under 2 MB.");
  if (!matchesType(bytes, mime)) throw Error("This file is not a supported raster image or font.");
  const hash = await crypto.subtle.digest("SHA-256", Uint8Array.from(bytes));
  const id = [...new Uint8Array(hash)].map(byte => byte.toString(16).padStart(2, "0")).join("");
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 16_384) binary += String.fromCharCode(...bytes.subarray(offset, offset + 16_384));
  return { id, reference: `lumen-asset:${id}`, dataUrl: `data:${mime};base64,${btoa(binary)}` };
}

/** Call only at the isolated rendering/export boundary, after validating the map. */
export function materializeAssetReferences(text: string, assets: PreviewAssets): string {
  let expandedLength = text.length;
  return text.replace(/lumen-asset:[^\s"'()<>{};,]+/g, reference => {
    if (!isPreviewAssetReference(reference)) throw Error("The page contains an invalid preview asset reference.");
    const data = assets[reference.slice("lumen-asset:".length)];
    if (!data) throw Error("A preview image or font is missing. Import the saved page again.");
    expandedLength += data.length - reference.length;
    if (expandedLength > 16_000_000) throw Error("This page repeats too much image or font data to preview. Use a smaller saved page.");
    return data;
  });
}

/** Keep asset bytes out of axe evidence sent back to the app and API. */
export function assetReferenceRestorer(assets: PreviewAssets): (text: string) => string {
  const references = new Map(Object.entries(assets).map(([id, data]) => [data, `lumen-asset:${id}`]));
  return text => text.replace(/data:(?:image|font)\/[a-z0-9.+-]+;base64,[a-zA-Z0-9+/=]+/gi, data => references.get(data) || "[embedded resource]");
}
