import { z } from "zod";

export const MAX_REQUEST_BYTES = 4_000_000;
export const MAX_RESULT_BYTES = 192 * 1024;
export const MAX_HTML_CHARS = 150_000;
export const MAX_CSS_CHARS = 300_000;
export const MAX_IMPORT_HTML_BYTES = 16_000_000;
export const documentSchema = z.object({
  title: z.string().max(120), lang: z.string().max(35),
  html: z.string().max(MAX_HTML_CHARS), css: z.string().max(MAX_CSS_CHARS),
}).strict();
export type PageDocument = z.infer<typeof documentSchema>;
export const findingSchema = z.object({
  key: z.string().min(1).max(700), ruleId: z.string().min(1).max(100),
  title: z.string().max(200), description: z.string().max(500),
  impact: z.enum(["critical", "serious", "moderate", "minor", "unknown"]),
  kind: z.enum(["violation", "review"]),
  selector: z.string().max(500), html: z.string().max(1000),
  previewTarget: z.enum(["element", "content", "page", "none"]).optional(),
  failureSummary: z.string().max(1600), helpUrl: z.string().url().max(300),
}).strict();
export type Finding = z.infer<typeof findingSchema>;
export const auditSchema = z.object({
  findings: z.array(findingSchema).max(50),
  passed: z.number().int().min(0).max(1000),
  incomplete: z.number().int().min(0).max(1000),
  viewport: z.object({width:z.number().int().min(280).max(2400),height:z.number().int().min(200).max(1600)}).strict(),
  truncated: z.boolean(),
}).strict();
export type AuditReport = z.infer<typeof auditSchema>;
export type AuditSnapshot = AuditReport & { revision: string; document: PageDocument; removed: number };
export const historyEntrySchema = z.object({role:z.enum(["user","assistant"]),content:z.string().min(1).max(1500)}).strict();
export type HistoryEntry = z.infer<typeof historyEntrySchema>;
export const createRequestSchema = z.object({
  brief:z.string().trim().min(2).max(1500),
  document:documentSchema,
  audit:auditSchema,
  selectedFindingKeys:z.array(z.string().min(1).max(700)).max(50),
  history:z.array(historyEntrySchema).max(12).default([]),
}).strict().superRefine((value,ctx)=>{
  const keys=new Set(value.audit.findings.map(f=>f.key));
  if(keys.size!==value.audit.findings.length || new Set(value.selectedFindingKeys).size!==value.selectedFindingKeys.length || value.selectedFindingKeys.some(key=>!keys.has(key)))ctx.addIssue({code:z.ZodIssueCode.custom,path:["selectedFindingKeys"],message:"Review the current page before selecting fixes."});
});
export type CreateRequest = z.infer<typeof createRequestSchema>;
export const editSchema = z.object({
  field:z.enum(["title","lang","html","css"]),
  before:z.string().max(18_000),after:z.string().max(18_000),
}).strict();
export type SourceEdit = z.infer<typeof editSchema>;
export const resultSchema = z.object({
  status:z.enum(["complete","answer","clarification","off_topic"]),
  message:z.string().min(1).max(1500),
  edits:z.array(editSchema).max(16),
}).strict().superRefine((result,ctx)=>{
  if(result.status==="complete" ? !result.edits.length : result.edits.length)ctx.addIssue({code:z.ZodIssueCode.custom,path:["edits"],message:"Only a requested revision may contain edits."});
});
export type GenerationResult = z.infer<typeof resultSchema>;
export const resultJsonSchema = {
  type:"object",additionalProperties:false,required:["status","message","edits"],properties:{
    status:{type:"string",enum:["complete","answer","clarification","off_topic"]},
    message:{type:"string",minLength:1,maxLength:1500},
    edits:{type:"array",maxItems:16,items:{type:"object",additionalProperties:false,required:["field","before","after"],properties:{field:{type:"string",enum:["title","lang","html","css"]},before:{type:"string",maxLength:18000},after:{type:"string",maxLength:18000}}}},
  },
};
/** Apply exact, unique replacements in order; metadata edits replace the complete value. */
export function applyEdits(source:PageDocument,edits:SourceEdit[]):PageDocument {
  const next={...documentSchema.parse(source)};
  for(const edit of edits){
    const {field,before,after}=editSchema.parse(edit),value=next[field];
    if(before===after)throw Error("An edit did not change the page.");
    if(field==="title"||field==="lang"||(!before && !value)){
      if(value!==before)throw Error("The page changed while this edit was being prepared.");
      next[field]=after;
    }else{
      if(!before || value.split(before).length!==2)throw Error("An edit could not be matched uniquely. The current page is preserved.");
      next[field]=value.replace(before,()=>after);
    }
  }
  return documentSchema.parse(next);
}
