import { isIP } from "node:net";

export type IpRateLimitPolicy = { minute: number; day?: number };

const MINUTE_MS = 60_000;
const DAY_MS = 86_400_000;
const STORAGE_RETRY_SECONDS = 60;

type UsageRow = {
  minute_window: number;
  minute_count: number;
  day_window: number;
  day_count: number;
};

/** Reject lists, ports, zones, and malformed addresses; collapse equivalent IPv6 spellings. */
export function normalizeClientIp(value: string | null): string | null {
  if (value === null) return null;
  const ip = value.trim();
  if (!ip || ip.length > 45 || !/^[\da-f:.]+$/i.test(ip)) return null;
  const version = isIP(ip);
  if (version === 4) return ip;
  if (version !== 6) return null;

  const canonical = new URL(`http://[${ip}]/`).hostname.slice(1, -1);
  const mapped = /^::ffff:([\da-f]+):([\da-f]+)$/.exec(canonical);
  if (mapped) {
    const high = parseInt(mapped[1], 16);
    const low = parseInt(mapped[2], 16);
    return `${high >>> 8}.${high & 255}.${low >>> 8}.${low & 255}`;
  }
  return canonical;
}

/** Sites preserves the edge-supplied CF-Connecting-IP; caller-supplied forwarding headers are ignored. */
export function resolveTrustedClientIp(request: Request): string | null {
  const edgeIp = request.headers.get("cf-connecting-ip");
  if (edgeIp !== null) return normalizeClientIp(edgeIp);
  const hostname = new URL(request.url).hostname;
  if (process.env.NODE_ENV === "development"
    && ["localhost", "127.0.0.1", "[::1]"].includes(hostname)) {
    // Local preview still uses durable quotas; this is not a storage bypass.
    return "127.0.0.1";
  }
  return null;
}

function unavailable(now = Date.now()): Response {
  return Response.json({
    code: "RATE_LIMIT_UNAVAILABLE",
    error: "This demo's usage protection is temporarily unavailable. Please try again shortly.",
    retryAfter: STORAGE_RETRY_SECONDS,
    resetAt: new Date(now + STORAGE_RETRY_SECONDS * 1_000).toISOString(),
  }, {
    status: 503,
    headers: { "Cache-Control": "no-store", "Retry-After": String(STORAGE_RETRY_SECONDS), "X-Content-Type-Options": "nosniff" },
  });
}

function limited(resetAt: number, now: number): Response {
  const retryAfter = Math.max(1, Math.ceil((resetAt - now) / 1_000));
  const unit = retryAfter < 60 ? "second" : retryAfter < 3_600 ? "minute" : "hour";
  const amount = Math.ceil(retryAfter / (unit === "second" ? 1 : unit === "minute" ? 60 : 3_600));
  return Response.json({
    code: "RATE_LIMIT_EXCEEDED",
    error: `You've reached this demo's usage limit for your network. Please try again in ${amount} ${unit}${amount === 1 ? "" : "s"}.`,
    retryAfter,
    resetAt: new Date(resetAt).toISOString(),
  }, {
    status: 429,
    headers: { "Cache-Control": "no-store", "Retry-After": String(retryAfter), "X-Content-Type-Options": "nosniff" },
  });
}

/** One transaction reserves both quotas, so concurrent requests cannot overspend either window. */
export async function enforceIpRateLimitWithDb(
  db: D1Database | undefined,
  request: Request,
  bucket: string,
  policy: IpRateLimitPolicy,
  now = Date.now(),
): Promise<Response | null> {
  try {
    const ip = resolveTrustedClientIp(request);
    if (!db || !ip || !/^[a-z\d][a-z\d:_-]{0,63}$/i.test(bucket)
      || !Number.isSafeInteger(now) || now < 0
      || !Number.isSafeInteger(policy.minute) || policy.minute < 1
      || (policy.day !== undefined && (!Number.isSafeInteger(policy.day) || policy.day < 1))) {
      return unavailable();
    }

    // Store neither the IP nor its forwarding headers. Bucket is included to isolate route quotas.
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify([ip, bucket])));
    const key = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
    const minuteWindow = Math.floor(now / MINUTE_MS) * MINUTE_MS;
    const dayWindow = Math.floor(now / DAY_MS) * DAY_MS;
    const dayLimit = policy.day ?? Number.MAX_SAFE_INTEGER;

    const results = await db.batch([
      // The expiry index bounds both the scan and deletion work per request.
      db.prepare(`DELETE FROM demo_ip_rate_limits WHERE key IN (
        SELECT key FROM demo_ip_rate_limits WHERE expires_at <= ? ORDER BY expires_at LIMIT 100
      )`).bind(now),
      db.prepare(`INSERT INTO demo_ip_rate_limits
        (key, minute_window, minute_count, day_window, day_count, expires_at)
        VALUES (?, ?, 1, ?, 1, ?)
        ON CONFLICT(key) DO UPDATE SET
          minute_count = CASE WHEN excluded.minute_window > minute_window THEN 1 ELSE minute_count + 1 END,
          minute_window = MAX(minute_window, excluded.minute_window),
          day_count = CASE WHEN excluded.day_window > day_window THEN 1 ELSE day_count + 1 END,
          day_window = MAX(day_window, excluded.day_window),
          expires_at = MAX(expires_at, excluded.expires_at)
        WHERE (minute_window < excluded.minute_window OR minute_count < ?)
          AND (day_window < excluded.day_window OR day_count < ?)
        RETURNING key`).bind(key, minuteWindow, dayWindow, dayWindow + DAY_MS, policy.minute, dayLimit),
      // batch() executes transactionally on the primary: do not make a separate replica-prone read.
      db.prepare(`SELECT minute_window, minute_count, day_window, day_count
        FROM demo_ip_rate_limits WHERE key = ?`).bind(key),
    ]);

    if (results.some(result => !result.success)) return unavailable(now);
    if (results[1].results.length === 1) return null;
    const row = results[2].results[0] as UsageRow | undefined;
    if (!row) return unavailable(now);
    const exhaustedUntil = [
      row.minute_count >= policy.minute && row.minute_window >= minuteWindow ? row.minute_window + MINUTE_MS : 0,
      policy.day !== undefined && row.day_count >= policy.day && row.day_window >= dayWindow ? row.day_window + DAY_MS : 0,
    ];
    const resetAt = Math.max(...exhaustedUntil);
    return resetAt > now ? limited(resetAt, now) : unavailable(now);
  } catch {
    // Never expose database errors, IPs, or credentials, and never call a paid API without a reservation.
    return unavailable();
  }
}

export async function enforceIpRateLimit(
  request: Request,
  bucket: string,
  policy: IpRateLimitPolicy,
): Promise<Response | null> {
  try {
    const { env } = await import("cloudflare:workers");
    return await enforceIpRateLimitWithDb(env.DB, request, bucket, policy);
  } catch {
    return unavailable();
  }
}
