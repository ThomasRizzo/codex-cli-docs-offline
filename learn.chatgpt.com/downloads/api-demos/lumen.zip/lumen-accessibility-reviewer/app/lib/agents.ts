import { readSSE } from "./sse.ts";
import { MAX_RESULT_BYTES, type CreateRequest } from "./contracts.ts";
import { makeAgentInput } from "./generation-result.ts";
import { isOverviewQuestion } from "./review-context.ts";
import { OVERVIEW_INSTRUCTIONS } from "./instructions.ts";

/** The injected transport must keep authentication and API routing server-side. */
export type AgentsTransport = (path: string, init: RequestInit) => Promise<Response>;

export type CommandEvidence = {
  id: string;
  command: string;
  exitCode: number | null;
  output: string;
  status: "completed" | "failed" | "incomplete";
};

export type GenerationSessionState = {
  status: "preparing" | "running" | "complete" | "failed" | "cancelled" | "waiting";
  sessionId: string;
  turnId: string | null;
  progress: string;
  result: unknown | null;
  commands: CommandEvidence[];
  error: string | null;
};

export class AgentsError extends Error {
  readonly status: number;

  constructor(message: string, status = 502) {
    super(message);
    this.name = "AgentsError";
    this.status = status;
  }
}

type Options = { signal?: AbortSignal };
export type GenerationInput = Options & {
  request: CreateRequest; instructions: string; resultSchema: Record<string, unknown>;
  metadata?: { cleanup_app: string; cleanup_run: string; cleanup_scope: string };
};
export type GenerationStreamEvent =
  | { type: "session"; id: string }
  | { type: "progress"; progress: string }
  | { type: "text"; phase: "commentary" | "final_answer"; itemId: string; delta: string }
  | { type: "text_done"; phase: "commentary" | "final_answer"; itemId: string; text: string }
  | { type: "finished"; status: "completed" | "failed" | "cancelled" | "waiting"; sessionId: string; turnId: string | null };
type RecordValue = Record<string, unknown>;
const MAX_RESPONSE_BYTES = 4 * 1024 * 1024;
const PAGE_SIZE = 50;
const MAX_PAGES = 4;
const SESSION_STATUSES = new Set(["idle", "in_progress", "requires_action", "failed"]);
const TURN_STATUSES = new Set(["queued", "in_progress", "waiting", "completed", "failed", "cancelled"]);

function record(value: unknown): value is RecordValue {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function resourceId(value: unknown): string {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]{1,200}$/.test(value)) {
    throw new AgentsError("The generation service returned an invalid resource identifier.");
  }
  return value;
}

function sessionPath(sessionId: string): string {
  return `/v1/agents/sessions/${resourceId(sessionId)}`;
}

function httpError(status: number): AgentsError {
  const message = status === 401 ? "The generation service could not authenticate."
    : status === 403 ? "This project cannot access the generation service."
    : status === 404 ? "This generation session is no longer available."
    : status === 409 ? "The generation session is still busy."
    : status === 429 ? "The generation service is busy. Please try again shortly."
    : "The generation service could not complete the request. Please try again.";
  return new AgentsError(message, status);
}

async function request(
  transport: AgentsTransport,
  path: string,
  method: "GET" | "POST" | "DELETE",
  options: Options,
  body?: unknown,
): Promise<Response> {
  const timeout = AbortSignal.timeout(25_000);
  const response = await transport(path, {
    method,
    headers: { "OpenAI-Beta": "agents=v1", Accept: "application/json", ...(body === undefined ? {} : { "Content-Type": "application/json" }) },
    signal: options.signal ? AbortSignal.any([options.signal, timeout]) : timeout,
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  if (!response.ok) {
    await response.body?.cancel().catch(() => undefined);
    throw httpError(response.status);
  }
  return response;
}

async function json(response: Response): Promise<unknown> {
  if (!response.body) throw new AgentsError("The generation service returned an empty response.");
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let bytes = 0;
  try {
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > MAX_RESPONSE_BYTES) {
        throw new AgentsError("The generation result was too large. Try a shorter brief.");
      }
      chunks.push(chunk.value);
    }
  } finally {
    await reader.cancel().catch(() => undefined);
    reader.releaseLock();
  }
  const joined = new Uint8Array(bytes);
  let offset = 0;
  for (const chunk of chunks) { joined.set(chunk, offset); offset += chunk.byteLength; }
  try { return JSON.parse(new TextDecoder().decode(joined)); }
  catch { throw new AgentsError("The generation service returned an unreadable response."); }
}

async function list(transport: AgentsTransport, path: string, options: Options): Promise<RecordValue[]> {
  const items: RecordValue[] = [];
  let after: string | undefined;
  const cursors = new Set<string>();
  for (let page = 0; page < MAX_PAGES; page++) {
    const query = new URLSearchParams({ order: "asc", limit: String(PAGE_SIZE), ...(after ? { after } : {}) });
    const result = await json(await request(transport, `${path}?${query}`, "GET", options));
    if (!record(result) || !Array.isArray(result.data) || result.data.length > PAGE_SIZE || !result.data.every(record) || typeof result.has_more !== "boolean") {
      throw new AgentsError("The generation service returned an incomplete result list.");
    }
    items.push(...result.data);
    if (!result.has_more) return items;
    after = resourceId(result.last_id);
    if (cursors.has(after)) throw new AgentsError("The generation service repeated a result page.");
    cursors.add(after);
  }
  throw new AgentsError("The generation produced too many steps. Try a shorter brief.");
}

function creationBody(input: GenerationInput, stream: boolean): RecordValue {
  const payload = makeAgentInput(input.request);
  const overview = isOverviewQuestion(input.request.brief);
  return {
    agent: { model: "gpt-6-astra", service_tier: "fast", reasoning: { effort: "low" }, instructions: overview ? OVERVIEW_INSTRUCTIONS : input.instructions,
      text: { format: { type: "json_schema", schema: input.resultSchema } } },
    environment: overview ? { type: "none" } : { type: "openai_hosted", container_size: "small", network: { access: "disabled" }, files: payload.files },
    input: payload.input, stream, ...(input.metadata ? { metadata: input.metadata } : {}),
  };
}

/** Creates a one-shot hosted Python workspace. Never automatically retry creation. */
export async function createGenerationSession(transport: AgentsTransport, input: GenerationInput): Promise<{ id: string }> {
  const result = await json(await request(transport, "/v1/agents/sessions", "POST", input, creationBody(input, false)));
  if (!record(result)) throw new AgentsError("The generation service did not create a session.");
  return { id: resourceId(result.id) };
}

/**
 * Creates and observes one turn without the gap in a later GET subscription.
 * Only public root-agent messages leave this filter. Final results still need
 * pollGenerationSession validation; neither stream EOF nor session idle is success.
 * Keep reading until the session ID arrives if the browser disconnects during
 * creation, then explicitly cancel/delete it. Closing the stream does not cancel work.
 */
export async function* streamGenerationSession(transport: AgentsTransport, input: GenerationInput): AsyncGenerator<GenerationStreamEvent> {
  const body = creationBody(input, true);
  const controller = new AbortController();
  const signals = [controller.signal, AbortSignal.timeout(180_000), ...(input.signal ? [input.signal] : [])];
  const signal = AbortSignal.any(signals);
  // The handshake has its own deadline; receiving headers must not cut off a live response after 25 seconds.
  const connectTimer = setTimeout(() => controller.abort(new DOMException("The generation connection timed out.", "TimeoutError")), 25_000);
  let response: Response | undefined;
  let sessionId: string | null = null, turnId: string | null = null;
  const seen = new Set<string>();
  const messages = new Map<string, { phase: "commentary" | "final_answer"; parts: Map<number, string>; published: string }>();
  const publish = (itemId: string, replace: boolean): GenerationStreamEvent | null => {
    const message = messages.get(itemId)!;
    const text = [...message.parts].sort(([a], [b]) => a - b).map(([, text]) => text).join("");
    if (new TextEncoder().encode(text).length > MAX_RESULT_BYTES) throw new AgentsError("The streamed answer was too large. Try a shorter brief.");
    const previous = message.published;
    message.published = text;
    if (replace || !text.startsWith(previous)) return { type: "text_done", itemId, phase: message.phase, text };
    return text.length > previous.length ? { type: "text", itemId, phase: message.phase, delta: text.slice(previous.length) } : null;
  };
  try {
    response = await transport("/v1/agents/sessions", {
      method: "POST", signal,
      headers: { "OpenAI-Beta": "agents=v1", Accept: "text/event-stream", "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    clearTimeout(connectTimer);
    if (!response.ok) throw httpError(response.status);
    if (!response.body || !response.headers.get("content-type")?.toLowerCase().startsWith("text/event-stream")) {
      throw new AgentsError("The generation service did not open a live connection.");
    }
    for await (const frame of readSSE(response.body, { signal, maxBytes: 12 * 1024 * 1024, maxEventBytes: 3 * 1024 * 1024 })) {
      if (frame.data === "[DONE]") break;
      let event: unknown;
      try { event = JSON.parse(frame.data); }
      catch { throw new AgentsError("The generation service sent an unreadable event."); }
      if (!record(event) || typeof event.type !== "string") continue;
      if (typeof event.event_id === "string") {
        if (seen.has(event.event_id)) continue;
        if (seen.size >= 20_000) throw new AgentsError("The generation produced too many events.");
        seen.add(event.event_id);
      }
      if (event.type === "agent.session.created" && record(event.session)) {
        const id = resourceId(event.session.id);
        if (sessionId && sessionId !== id) throw new AgentsError("The generation stream changed sessions.");
        if (!sessionId) { sessionId = id; yield { type: "session", id }; yield { type: "progress", progress: "Preparing the workspace" }; }
        continue;
      }
      if (!sessionId) {
        if (event.type === "error") throw new AgentsError("The generation service could not start this task.");
        continue;
      }
      if (event.session_id !== undefined && event.session_id !== sessionId) throw new AgentsError("The generation stream changed sessions.");
      if (record(event.session) && event.session.id !== sessionId) throw new AgentsError("The generation stream changed sessions.");
      if (["error", "agent.session.failed", "agent.session.environment.failed"].includes(event.type)) {
        yield { type: "finished", status: "failed", sessionId, turnId }; return;
      }
      if (event.type === "agent.session.requires_action") {
        yield { type: "finished", status: "waiting", sessionId, turnId }; return;
      }
      if (["agent.session.environment.ready", "agent.session.environment.connected"].includes(event.type)) {
        yield { type: "progress", progress: "Workspace ready" }; continue;
      }
      if (["agent.session.turn.created", "agent.session.turn.in_progress", "agent.session.turn.completed", "agent.session.turn.failed", "agent.session.turn.cancelled"].includes(event.type)) {
        if (!record(event.turn) || event.turn.subagent_id !== null) continue;
        const id = resourceId(event.turn.id);
        if (event.turn.session_id !== sessionId || event.turn_id !== id || (turnId && turnId !== id)) {
          throw new AgentsError("The generation stream returned an unexpected task.");
        }
        turnId = id;
        const status = event.type.slice("agent.session.turn.".length);
        if (status === "completed" || status === "failed" || status === "cancelled") {
          yield { type: "finished", status, sessionId, turnId }; return;
        }
        if (status === "in_progress") yield { type: "progress", progress: "Reviewing your page" };
        continue;
      }
      // Root turn attribution is mandatory before exposing any item or output.
      if (!turnId || event.turn_id !== turnId) continue;
      if (["agent.session.turn.item.added", "agent.session.turn.item.done"].includes(event.type) && record(event.item)) {
        const item = event.item;
        if (item.turn_id !== turnId) continue;
        if (item.type === "command_execution") {
          yield { type: "progress", progress: event.type.endsWith("added") ? "Checking your review" : "Review checks complete" };
          continue;
        }
        if (item.type !== "message" || item.role !== "assistant" || (item.phase !== "commentary" && item.phase !== "final_answer")) continue;
        const id = resourceId(item.id);
        if (!Array.isArray(item.content) || item.content.length > 16 || !item.content.every((part) => record(part) && part.type === "output_text" && typeof part.text === "string")) continue;
        if (!messages.has(id) && messages.size >= 32) throw new AgentsError("The generation produced too many messages.");
        const message = messages.get(id) ?? { phase: item.phase, parts: new Map<number, string>(), published: "" };
        if (message.phase !== item.phase) throw new AgentsError("The generation message changed its output phase.");
        message.parts = new Map(item.content.map((part, index) => [index, (part as { text: string }).text]));
        messages.set(id, message);
        if (item.phase === "final_answer" && event.type.endsWith("added")) yield { type: "progress", progress: "Preparing the changes" };
        const output = publish(id, event.type.endsWith("done"));
        if (output) yield output;
        continue;
      }
      if (event.type === "agent.session.turn.output_text.delta" || event.type === "agent.session.turn.output_text.done") {
        if (typeof event.item_id !== "string" || !messages.has(event.item_id)) continue;
        if (typeof event.content_index !== "number" || !Number.isInteger(event.content_index) || event.content_index < 0 || event.content_index >= 16) {
          throw new AgentsError("The generation service returned an invalid text part.");
        }
        const done = event.type.endsWith("done");
        const text = done ? event.text : event.delta;
        if (typeof text !== "string") throw new AgentsError("The generation service returned an invalid text update.");
        const message = messages.get(event.item_id)!;
        message.parts.set(event.content_index, done ? text : (message.parts.get(event.content_index) ?? "") + text);
        const output = publish(event.item_id, done);
        if (output) yield output;
      }
    }
    throw new AgentsError("The live connection ended before the task finished. Retrieve its saved result.");
  } catch (error) {
    if (signal.aborted) throw signal.reason;
    if (error instanceof AgentsError) throw error;
    throw new AgentsError("The connection was interrupted. Your page is unchanged; please try again.");
  } finally {
    clearTimeout(connectTimer);
    controller.abort();
    await response?.body?.cancel().catch(() => undefined);
  }
}

/** Reads one snapshot; the caller owns polling cadence, deadline, and session ownership. */
export async function pollGenerationSession(transport: AgentsTransport, sessionId: string, options: Options = {}): Promise<GenerationSessionState> {
  const path = sessionPath(sessionId);
  const [session, turns] = await Promise.all([
    request(transport, path, "GET", options).then(json),
    list(transport, `${path}/turns`, options),
  ]);
  if (!record(session) || session.id !== sessionId || !SESSION_STATUSES.has(String(session.status))) {
    throw new AgentsError("The generation service returned an invalid session state.");
  }
  const state: GenerationSessionState = {
    status: "preparing", sessionId, turnId: null, progress: "Preparing the workspace", result: null, commands: [], error: null,
  };
  if (session.status === "failed") {
    return { ...state, status: "failed", progress: "Generation stopped", error: "The generation workspace could not finish. Please try again." };
  }
  const rootTurns = turns.filter((turn) => turn.subagent_id === null);
  if (rootTurns.length > 1) throw new AgentsError("This generation session contains more than one task.");
  const turn = rootTurns[0];
  if (!turn) return state;
  if (!TURN_STATUSES.has(String(turn.status)) || turn.session_id !== sessionId) {
    throw new AgentsError("The generation service returned an invalid task state.");
  }
  state.turnId = resourceId(turn.id);
  if (turn.status === "failed") {
    return { ...state, status: "failed", progress: "Generation stopped", error: "The accessibility reviewer could not finish this task. Please try again." };
  }
  if (turn.status === "cancelled") {
    return { ...state, status: "cancelled", progress: "Generation cancelled", error: "This generation was cancelled." };
  }
  if (turn.status === "waiting" || session.status === "requires_action") {
    return { ...state, status: "waiting", progress: "Generation needs attention", error: "The generation could not continue automatically. Please try again." };
  }
  if (turn.status === "queued") return state;
  if (turn.status !== "completed") return { ...state, status: "running", progress: "Reviewing your page" };

  const items = (await list(transport, `${path}/items`, options)).filter((item) => item.turn_id === turn.id);
  state.commands = items.filter((item) => item.type === "command_execution" && ["completed", "failed", "incomplete"].includes(String(item.status))).slice(-12).map((item) => ({
    id: resourceId(item.id),
    command: typeof item.command === "string" ? item.command.slice(0, 16_384) : "",
    exitCode: typeof item.exit_code === "number" && Number.isInteger(item.exit_code) ? item.exit_code : null,
    output: typeof item.output === "string" ? item.output.slice(0, 16_384) : "",
    status: item.status as CommandEvidence["status"],
  }));
  const finalMessages = items.filter((item) => item.type === "message" && item.role === "assistant" && item.phase === "final_answer" && item.status === "completed");
  const finalMessage = finalMessages.at(-1);
  // Persisted output can lag the completed-turn event; read again without submitting more work.
  if (!finalMessage) return { ...state, status: "running", progress: "Collecting the results" };
  if (!Array.isArray(finalMessage.content) || finalMessage.content.length > 16 || !finalMessage.content.every((part) => record(part) && part.type === "output_text" && typeof part.text === "string")) {
    throw new AgentsError("The accessibility reviewer returned an incomplete result. Please try again.");
  }
  const text = finalMessage.content.map((part) => (part as { text: string }).text).join("");
  if (new TextEncoder().encode(text).length > MAX_RESULT_BYTES) throw new AgentsError("The result was too large. Try a shorter brief.");
  try { state.result = JSON.parse(text); }
  catch { throw new AgentsError("The accessibility reviewer returned an incomplete result. Please try again."); }
  return { ...state, status: "complete", progress: "Generation ready" };
}

/** Cancellation stops active work; closing an observer request does not. */
export async function cancelGenerationSession(transport: AgentsTransport, sessionId: string, options: Options = {}): Promise<void> {
  const response = await request(transport, `${sessionPath(sessionId)}/events`, "POST", options, { events: [{ type: "agent.session.input.cancel" }] });
  await response.body?.cancel().catch(() => undefined);
}

/** Save the result before deletion. A 409 is exposed for bounded caller-owned retries. */
export async function deleteGenerationSession(transport: AgentsTransport, sessionId: string, options: Options = {}): Promise<void> {
  const response = await request(transport, sessionPath(sessionId), "DELETE", options);
  await response.body?.cancel().catch(() => undefined);
}
