import type { GenerationSessionState } from "./agents.ts";
import { applyEdits, createRequestSchema, documentSchema, resultSchema, MAX_HTML_CHARS, MAX_CSS_CHARS, type CreateRequest, type PageDocument } from "./contracts.ts";
import { isOverviewQuestion, makeReviewContext } from "./review-context.ts";

export type ReviewBinding = { requestHash: string; sourceHash: string };

/** Stable JSON shared with Python: object keys sort; array and patch order matter. */
export function canonicalJSON(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJSON).join(",")}]`;
  if (value && typeof value === "object") return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonicalJSON((value as Record<string, unknown>)[key])}`).join(",")}}`;
  return JSON.stringify(value);
}
export async function digest(value: unknown): Promise<string> {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalJSON(value)));
  return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, "0")).join("");
}
export function validateGenerationRequest(input: unknown): CreateRequest {
  const parsed = createRequestSchema.safeParse(input);
  if (!parsed.success) throw new Error("Check your current page, review, and request, then try again.");
  return parsed.data;
}
export async function reviewBinding(input: CreateRequest): Promise<ReviewBinding> {
  const request = validateGenerationRequest(input);
  const [requestHash, sourceHash] = await Promise.all([digest(request), digest(request.document)]);
  return { requestHash, sourceHash };
}

// This validator checks patch consistency and conservative content-preservation
// rules. It does NOT measure accessibility. Only the later browser audit does.
const VALIDATOR = String.raw`import collections, hashlib, json, pathlib, re
from html.parser import HTMLParser
root = pathlib.Path('/workspace')
manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
source = json.loads((root / 'document.json').read_text(encoding='utf-8'))
edits = json.loads((root / 'edits.json').read_text(encoding='utf-8'))
def keys(value, expected):
    assert isinstance(value, dict) and set(value) == set(expected), 'Unexpected object fields'
def text(value, maximum):
    assert isinstance(value, str) and len(value.encode('utf-16-le')) // 2 <= maximum, 'Text exceeds its limit'
def document(value):
    keys(value, ['title', 'lang', 'html', 'css'])
    for field, limit in [('title', 120), ('lang', 35), ('html', ${MAX_HTML_CHARS}), ('css', ${MAX_CSS_CHARS})]: text(value[field], limit)
def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')).hexdigest()
document(source)
assert source == manifest['document'], 'Source document no longer matches the request'
assert isinstance(edits, list) and 1 <= len(edits) <= 16, 'Return one to sixteen edits'
updated = dict(source)
seen = set()
for edit in edits:
    keys(edit, ['field', 'before', 'after'])
    field, before, after = edit['field'], edit['before'], edit['after']
    assert field in updated, 'Unknown source field'
    text(before, 18000); text(after, 18000)
    assert before != after, 'An edit must change its field'
    fingerprint = (field, before, after)
    assert fingerprint not in seen, 'Duplicate edit'
    seen.add(fingerprint)
    value = updated[field]
    if field in ['title', 'lang'] or (before == '' and value == ''):
        assert value == before, 'Metadata does not match the original value'
        updated[field] = after
    else:
        assert before and value.count(before) == 1, 'The replacement must match exactly once'
        updated[field] = value.replace(before, after, 1)
document(updated)
assert updated != source, 'The edits made no final change'

class Contents(HTMLParser):
    voids = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self, markup):
        super().__init__(convert_charrefs=True)
        self.stack = []; self.words = []; self.accessible_words = []; self.controls = 0; self.accessible_controls = 0; self.images = 0; self.styles = []
        self.feed(markup); self.close()
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        parent_ignored = any(entry[1] for entry in self.stack)
        parent_hidden = any(entry[2] for entry in self.stack)
        ignored = parent_ignored or tag in {'script','style','template','head'}
        hidden = parent_hidden or 'hidden' in attrs or 'inert' in attrs or str(attrs.get('aria-hidden','')).lower() == 'true'
        if attrs.get('style'): self.styles.append(attrs['style'])
        control = tag in {'button','select','textarea'} or (tag == 'input' and str(attrs.get('type','')).lower() != 'hidden') or (tag == 'a' and 'href' in attrs) or attrs.get('role') in {'button','link','checkbox','radio','switch','textbox','combobox','slider','spinbutton'}
        if control and not ignored:
            self.controls += 1
            if not hidden: self.accessible_controls += 1
        if tag == 'img' and not ignored: self.images += 1
        if tag not in self.voids: self.stack.append((tag, ignored, hidden))
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.voids: self.handle_endtag(tag)
    def handle_endtag(self, tag):
        for at in range(len(self.stack)-1, -1, -1):
            if self.stack[at][0] == tag:
                del self.stack[at:]; break
    def handle_data(self, data):
        if any(entry[1] for entry in self.stack): return
        words = re.findall(r'\w+', data.casefold())
        self.words.extend(words)
        if not any(entry[2] for entry in self.stack): self.accessible_words.extend(words)
old, new = Contents(source['html']), Contents(updated['html'])
for before_words, after_words in [(old.words,new.words),(old.accessible_words,new.accessible_words)]:
    assert not (collections.Counter(before_words) - collections.Counter(after_words)), 'Preserve the page text; do not remove or hide content to pass checks'
assert new.controls >= old.controls, 'Preserve the existing interactive controls'
assert new.accessible_controls >= old.accessible_controls, 'Do not hide existing interactive controls'
assert new.images >= old.images, 'Preserve the page images'
def hiding_declarations(css):
    css = re.sub(r'/\*.*?\*/', '', css, flags=re.S).lower()
    declarations = []
    for match in re.finditer(r'([a-z-]+)\s*:\s*([^;}]+)', css):
        prop, value = match.groups()
        value = re.sub(r'\s+|!important', '', value)
        if (prop == 'display' and value == 'none') or (prop == 'visibility' and value in {'hidden','collapse'}) or (prop == 'content-visibility' and value == 'hidden') or (prop in {'opacity','font-size'} and re.fullmatch(r'0(?:\.0+)?(?:px|em|rem|%)?', value)):
            declarations.append((prop,value))
    return collections.Counter(declarations)
assert not (hiding_declarations(updated['css'] + ';' + ';'.join(new.styles)) - hiding_declarations(source['css'] + ';' + ';'.join(old.styles))), 'Do not add rules that conceal page content'
(root / 'updated-document.json').write_text(json.dumps(updated, ensure_ascii=False), encoding='utf-8')
print(json.dumps({'lumen_validation': {'request_sha256': digest(manifest), 'source_sha256': digest(source), 'edits_sha256': digest(edits), 'result_sha256': digest(updated), 'edits': len(edits)}}))
`;

function base64(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let binary = "";
  for (let at = 0; at < bytes.length; at += 8192) binary += String.fromCharCode(...bytes.subarray(at, at + 8192));
  return btoa(binary);
}
export function makeAgentInput(input: CreateRequest) {
  const request = validateGenerationRequest(input);
  return {
    files: isOverviewQuestion(request.brief) ? [] : [
      { type: "inline", path: "/workspace/manifest.json", data: base64(JSON.stringify(request)) },
      { type: "inline", path: "/workspace/document.json", data: base64(JSON.stringify(request.document)) },
      { type: "inline", path: "/workspace/apply_edits.py", data: base64(VALIDATOR) },
    ],
    input: [{ role: "user", content: [{ type: "input_text", text: JSON.stringify(makeReviewContext(request)) }] }],
  };
}

function invokesValidator(command: string): boolean {
  let script = command.trim();
  // Agents records the actual shell invocation, including its shell wrapper.
  const wrapped = script.match(/^(?:\/(?:usr\/)?bin\/)?(?:bash|sh|zsh|dash)\s+-(?:lc|cl|c)\s+(['"])([\s\S]*)\1$/);
  if (wrapped) script = wrapped[1] === '"' ? wrapped[2].replace(/\\(["\\$`])/g, "$1") : wrapped[2];
  return /(?:^|\n|&&|;)\s*python3?\s+(?:\/workspace\/apply_edits\.py|'\/workspace\/apply_edits\.py'|"\/workspace\/apply_edits\.py")\s*(?:$|\n|&&|;)/.test(script);
}

/** Reapply against the bound original document before checking actual command evidence. */
export async function generationResult(state: Pick<GenerationSessionState, "result" | "commands">, source: PageDocument, binding: ReviewBinding) {
  const parsed = resultSchema.safeParse(state.result);
  if (!parsed.success || !documentSchema.safeParse(source).success || await digest(source) !== binding.sourceHash) return null;
  let steps = 0;
  if (parsed.data.status === "complete") {
    let updated: PageDocument;
    try { updated = applyEdits(source, parsed.data.edits); } catch { return null; }
    const identities = parsed.data.edits.map(edit => canonicalJSON(edit));
    if (new Set(identities).size !== identities.length || canonicalJSON(updated) === canonicalJSON(source)) return null;
    const [editHash, resultHash] = await Promise.all([digest(parsed.data.edits), digest(updated)]);
    steps = state.commands.filter(command => {
      if (command.status !== "completed" || command.exitCode !== 0 || !invokesValidator(command.command)) return false;
      return command.output.split("\n").some(line => {
        if (line.length > 700) return false;
        try {
          const receipt = JSON.parse(line)?.lumen_validation;
          return receipt?.request_sha256 === binding.requestHash && receipt?.source_sha256 === binding.sourceHash
            && receipt?.edits_sha256 === editHash && receipt?.result_sha256 === resultHash && receipt?.edits === parsed.data.edits.length;
        } catch { return false; }
      });
    }).length;
    if (!steps) return null;
  } else if (state.commands.length && (parsed.data.status !== "answer" || state.commands.some(command => invokesValidator(command.command)))) {
    // Detailed answers may inspect source. They never authorize applying a patch;
    // clarification/off-topic replies must remain tool-free.
    return null;
  }
  return { result: parsed.data, execution: { steps, verified: parsed.data.status === "complete" && steps > 0 } };
}
