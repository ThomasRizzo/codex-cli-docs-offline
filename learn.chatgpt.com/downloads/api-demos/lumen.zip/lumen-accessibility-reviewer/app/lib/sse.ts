export type SSEMessage = { event: string; data: string };

/** Decode bounded SSE frames. Event IDs are metadata, not a promise of replay. */
export async function* readSSE(
  body: ReadableStream<Uint8Array>,
  options: { signal?: AbortSignal; maxBytes?: number; maxEventBytes?: number } = {},
): AsyncGenerator<SSEMessage> {
  const maxBytes = options.maxBytes ?? 8 * 1024 * 1024;
  const maxEventBytes = options.maxEventBytes ?? 1024 * 1024;
  const reader = body.getReader();
  const decoder = new TextDecoder("utf-8", { fatal: true });
  const encoder = new TextEncoder();
  let pending = "", event = "message", bytes = 0, eventBytes = 0;
  let data: string[] = [];
  const abort = () => { void reader.cancel().catch(() => undefined); };
  options.signal?.addEventListener("abort", abort, { once: true });
  try {
    while (true) {
      options.signal?.throwIfAborted();
      const chunk = await reader.read();
      options.signal?.throwIfAborted();
      bytes += chunk.value?.byteLength ?? 0;
      if (bytes > maxBytes) throw new Error("The event stream exceeded its size limit.");
      pending += chunk.done ? decoder.decode() : decoder.decode(chunk.value, { stream: true });
      while (true) {
        options.signal?.throwIfAborted();
        const end = pending.search(/[\r\n]/);
        if (end < 0 || (!chunk.done && pending[end] === "\r" && end === pending.length - 1)) break;
        const line = pending.slice(0, end);
        pending = pending.slice(end + (pending[end] === "\r" && pending[end + 1] === "\n" ? 2 : 1));
        eventBytes += encoder.encode(line).byteLength;
        if (eventBytes > maxEventBytes) throw new Error("An event exceeded its size limit.");
        if (line === "") {
          if (data.length) yield { event, data: data.join("\n") };
          data = []; event = "message"; eventBytes = 0;
          continue;
        }
        if (line.startsWith(":")) continue;
        const colon = line.indexOf(":");
        const field = colon < 0 ? line : line.slice(0, colon);
        const value = colon < 0 ? "" : line.slice(colon + 1).replace(/^ /, "");
        if (field === "data") data.push(value);
        if (field === "event") event = value || "message";
      }
      if (encoder.encode(pending).byteLength + eventBytes > maxEventBytes) throw new Error("An event exceeded its size limit.");
      // A truncated, unterminated frame is not a complete SSE event.
      if (chunk.done) return;
    }
  } finally {
    options.signal?.removeEventListener("abort", abort);
    await reader.cancel().catch(() => undefined);
    reader.releaseLock();
  }
}
