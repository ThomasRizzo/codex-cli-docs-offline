// Per-IP request allowances. Windows reset at UTC minute/day boundaries.
// Keep simulation allowances large enough for a complete normal run.
export const IP_LIMITS = {
  "start": {
    "minute": 6,
    "day": 20
  }
} as const;
