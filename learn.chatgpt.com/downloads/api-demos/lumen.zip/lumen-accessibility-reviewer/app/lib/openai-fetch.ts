export type TransportBindings = object;

/** The downloadable project uses the public API with the deployer's own key. */
export function resolveApiTransport(_bindings: TransportBindings | null | undefined, publicFetch: typeof fetch = fetch) {
  return { origin: "https://api.openai.com", fetch: (input: RequestInfo | URL, init?: RequestInit) => publicFetch(input, init) };
}
