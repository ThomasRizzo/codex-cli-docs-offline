"use client";

import { useCallback, useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import { ArrowDownTrayIcon, ArrowPathIcon, ArrowUpIcon, ArrowUturnLeftIcon, Bars3Icon, CheckIcon, ChevronDownIcon, CodeBracketIcon, ComputerDesktopIcon, DevicePhoneMobileIcon, DocumentArrowUpIcon, QuestionMarkCircleIcon, StopIcon, SunIcon, XMarkIcon } from "@heroicons/react/16/solid";
import AuditFrame from "./components/audit-frame";
import FindingsPanel from "./components/findings-panel";
import SourceEditor from "./components/source-editor";
import ReviewChat, { type ChatTurn } from "./components/review-chat";
import { useReviewGeneration } from "./components/use-review-generation";
import { applyEdits, MAX_IMPORT_HTML_BYTES, type AuditSnapshot, type Finding, type PageDocument } from "./lib/contracts";
import { normalizeDocument, exportDocumentHtml } from "./lib/document-io";
import { SAMPLE_PAGES } from "./lib/samples";
import { importSavedPage } from "./lib/saved-page-import";
import type { PreviewAssets } from "./lib/preview-assets";

type SavedPageImport = Awaited<ReturnType<typeof importSavedPage>>;
interface PendingImport { filename: string; result: SavedPageImport }

interface Revision {
  document: PageDocument;
  assets: PreviewAssets;
  draft: PageDocument;
  audit: AuditSnapshot | null;
  turns: ChatTurn[];
  selected: string[];
  activeKey: string | null;
}
const sameDocument = (a: PageDocument, b: PageDocument) => a.title === b.title && a.lang === b.lang && a.html === b.html && a.css === b.css;
const issueCount = (audit: AuditSnapshot | null) => audit?.findings.filter(finding => finding.kind === "violation").length;

export default function Home() {
  const initial = SAMPLE_PAGES[0];
  const [pageDocument, setPageDocument] = useState<PageDocument>(initial.document);
  const [draft, setDraft] = useState<PageDocument>(initial.document);
  const [assets, setAssets] = useState<PreviewAssets>({});
  const [importFilename, setImportFilename] = useState("");
  const [importWarnings, setImportWarnings] = useState<string[]>([]);
  const [sampleId, setSampleId] = useState(initial.id);
  const [revision, setRevision] = useState("page-0");
  const [audit, setAudit] = useState<AuditSnapshot | null>(null);
  const [auditError, setAuditError] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [activeKey, setActiveKey] = useState<string | null>(null);
  const [highlightRequest, setHighlightRequest] = useState(0);
  const [canvasTab, setCanvasTab] = useState<"preview" | "source" | "compare">("preview");
  const [railTab, setRailTab] = useState<"findings" | "chat">("findings");
  const [mobilePanel, setMobilePanel] = useState<"page" | "review">("page");
  const [viewportMode, setViewportMode] = useState<"desktop" | "mobile">("desktop");
  const [turns, setTurns] = useState<ChatTurn[]>([]);
  const [prompt, setPrompt] = useState("");
  const [revisions, setRevisions] = useState<Revision[]>([]);
  const [notice, setNotice] = useState("");
  const [localError, setLocalError] = useState("");
  const [importing, setImporting] = useState(false);
  const [pendingImport, setPendingImport] = useState<PendingImport | null>(null);
  const [importError, setImportError] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [compact, setCompact] = useState(false);
  const revisionCounter = useRef(0);
  const revisionRef = useRef(revision);
  const documentRef = useRef(pageDocument);
  const runVersion = useRef(0);
  const activeRequest = useRef<number | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const folderRef = useRef<HTMLInputElement>(null);
  const uploadButtonRef = useRef<HTMLButtonElement>(null);
  const importDialogRef = useRef<HTMLDialogElement>(null);
  const pendingHtmlRef = useRef<File | null>(null);
  const importVersion = useRef(0);
  const menuRef = useRef<HTMLButtonElement>(null);
  const pagePanelRef = useRef<HTMLButtonElement>(null);
  const composerRef = useRef<HTMLTextAreaElement>(null);
  const helpRef = useRef<HTMLDialogElement>(null);
  const generation = useReviewGeneration();
  useEffect(() => {
    const query = window.matchMedia("(max-width: 900px)");
    const update = () => setCompact(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  useEffect(() => {
    if (!menuOpen) return;
    const escape = (event: globalThis.KeyboardEvent) => {
      if (event.key === "Escape") { setMenuOpen(false); menuRef.current?.focus(); }
    };
    const outside = (event: PointerEvent) => {
      const target = event.target;
      if (target instanceof Element && !target.closest("#header-actions") && !menuRef.current?.contains(target)) setMenuOpen(false);
    };
    document.addEventListener("keydown", escape);
    document.addEventListener("pointerdown", outside);
    return () => { document.removeEventListener("keydown", escape); document.removeEventListener("pointerdown", outside); };
  }, [menuOpen]);
  useEffect(() => {
    const dialog = importDialogRef.current;
    if (pendingImport && dialog && !dialog.open) dialog.showModal();
  }, [pendingImport]);
  useEffect(() => () => { ++importVersion.current; }, []);
  const viewport = viewportMode === "desktop" ? { width: 960, height: 720 } : { width: 390, height: 780 };
  const checking = !audit && !auditError;
  const dirty = !sameDocument(draft, pageDocument);
  const before = revisions.at(-1);
  const activeFinding = audit?.findings.find(finding => finding.key === activeKey);
  const error = localError || generation.error;
  const canSend = !importing && !dirty && Boolean(audit) && (prompt.trim().length >= 2 || selected.length > 0);

  function newRevision(nextDocument: PageDocument) {
    const id = `page-${++revisionCounter.current}`;
    revisionRef.current = id;
    documentRef.current = nextDocument;
    setPageDocument(nextDocument);
    setRevision(id);
    setAudit(null);
    setAuditError("");
  }

  const receiveAudit = useCallback((snapshot: AuditSnapshot) => {
    if (snapshot.revision !== revisionRef.current) return;
    const previousDocument = documentRef.current;
    documentRef.current = snapshot.document;
    setPageDocument(snapshot.document);
    setDraft(current => sameDocument(current, previousDocument) ? snapshot.document : current);
    setAudit(snapshot);
    setAuditError("");
    setSelected(current => current.filter(key => snapshot.findings.some(finding => finding.key === key)));
    setActiveKey(current => snapshot.findings.some(finding => finding.key === current) ? current : null);
    if (snapshot.removed) setNotice(`Removed ${snapshot.removed} unsupported ${snapshot.removed === 1 ? "item" : "items"} from the preview.`);
  }, []);

  function snapshot(): Revision {
    return { document: pageDocument, assets, draft, audit, turns, selected, activeKey };
  }

  function resetWorkspace(nextDocument: PageDocument, nextSampleId: string, removed = 0, imported?: { assets: PreviewAssets; filename: string; notice: string; warnings: string[] }) {
    ++importVersion.current;
    pendingHtmlRef.current = null;
    setPendingImport(null);
    setImportError("");
    importDialogRef.current?.close();
    setAssets(imported?.assets ?? {});
    setImportFilename(imported?.filename ?? "");
    setImportWarnings(imported?.warnings ?? []);
    ++runVersion.current;
    activeRequest.current = null;
    generation.stop(true);
    generation.clearFeedback();
    newRevision(nextDocument);
    setDraft(nextDocument);
    setSampleId(nextSampleId);
    setMenuOpen(false);
    setSelected([]);
    setActiveKey(null);
    setTurns([]);
    setPrompt("");
    setRevisions([]);
    setCanvasTab("preview");
    setRailTab("findings");
    setMobilePanel("page");
    setLocalError("");
    setNotice(imported?.notice ?? (removed ? `Removed ${removed} unsupported ${removed === 1 ? "item" : "items"} to keep the preview isolated.` : ""));
    setImporting(false);
  }

  function chooseSample(id: string) {
    const sample = SAMPLE_PAGES.find(item => item.id === id);
    if (!sample) return;
    try {
      const normalized = normalizeDocument(sample.document);
      resetWorkspace(normalized.document, id, normalized.removed);
    } catch (cause) { setLocalError(cause instanceof Error ? cause.message : "This sample could not be loaded."); }
  }

  function restoreImportFocus() {
    requestAnimationFrame(() => {
      if (window.matchMedia("(max-width: 900px)").matches) menuRef.current?.focus();
      else uploadButtonRef.current?.focus();
    });
  }

  function cancelImport() {
    ++importVersion.current;
    pendingHtmlRef.current = null;
    setPendingImport(null);
    setImportError("");
    setImporting(false);
    importDialogRef.current?.close();
    restoreImportFocus();
  }

  function acceptImport(file: File, result: SavedPageImport, withoutStyles = false) {
    const details = [withoutStyles ? `Opened ${file.name} without the missing stylesheets.` : `Opened ${file.name}.`];
    if (result.removed) details.push(`Removed ${result.removed} unsupported ${result.removed === 1 ? "item" : "items"}.`);
    resetWorkspace(result.document, "", result.removed, { assets: result.assets, filename: file.name, notice: details.join(" "), warnings: result.warnings });
    restoreImportFocus();
  }

  async function upload(file: File | undefined) {
    if (!file) return;
    const task = ++importVersion.current;
    ++runVersion.current;
    activeRequest.current = null;
    generation.stop(true);
    setTurns(current => current.map(turn => turn.status === "pending" ? { ...turn, status: "stopped" } : turn));
    generation.clearFeedback();
    pendingHtmlRef.current = file;
    setPendingImport(null);
    importDialogRef.current?.close();
    setImporting(true);
    setImportError("");
    setLocalError("");
    setMenuOpen(false);
    try {
      if (!/\.html?$/i.test(file.name)) throw new Error("Choose an .html or .htm file.");
      if (file.size > MAX_IMPORT_HTML_BYTES) throw new Error("Choose an HTML file smaller than 16 MB.");
      const result = await importSavedPage(file);
      if (task !== importVersion.current) return;
      if (result.missingStylesheets.length) setPendingImport({ filename: file.name, result });
      else acceptImport(file, result);
    } catch (cause) {
      if (task === importVersion.current) {
        pendingHtmlRef.current = null;
        setLocalError(cause instanceof Error ? cause.message : "The file could not be opened. Your current page is preserved.");
        setMobilePanel("review");
      }
    } finally { if (task === importVersion.current) setImporting(false); }
  }

  async function addCompanionFolder(files: File[]) {
    const file = pendingHtmlRef.current;
    if (!file || files.length === 0) return;
    const task = ++importVersion.current;
    setImporting(true);
    setImportError("");
    try {
      const result = await importSavedPage(file, files);
      if (task !== importVersion.current || pendingHtmlRef.current !== file) return;
      if (result.missingStylesheets.length) {
        setPendingImport({ filename: file.name, result });
        setImportError("Some stylesheets are still missing. Choose the folder saved with this HTML file, or open without them.");
      } else acceptImport(file, result);
    } catch (cause) {
      if (task === importVersion.current) setImportError(cause instanceof Error ? cause.message : "These files could not be read. Choose the companion folder again.");
    } finally { if (task === importVersion.current) setImporting(false); }
  }

  function openWithoutStyles() {
    const file = pendingHtmlRef.current;
    if (importing || !file || !pendingImport) return;
    acceptImport(file, pendingImport.result, true);
  }

  function applySource() {
    if (generation.busy || importing || !dirty) return;
    try {
      const normalized = normalizeDocument(draft);
      setRevisions(current => [...current.slice(-4), { ...snapshot(), draft: pageDocument }]);
      ++runVersion.current;
      generation.clearFeedback();
      newRevision(normalized.document);
      setDraft(normalized.document);
      setSelected([]);
      setActiveKey(null);
      setLocalError("");
      setNotice(normalized.removed ? `Removed ${normalized.removed} unsupported ${normalized.removed === 1 ? "item" : "items"} from the source.` : "Source applied.");
      setCanvasTab("preview");
    } catch (cause) { setLocalError(cause instanceof Error ? cause.message : "The source could not be applied. Your draft is preserved."); }
  }

  function undo() {
    if (!before || generation.busy || importing) return;
    ++runVersion.current;
    generation.clearFeedback();
    newRevision(before.document);
    setAssets(before.assets);
    setDraft(before.draft);
    setTurns(before.turns);
    setSelected(before.selected);
    setActiveKey(before.activeKey);
    setRevisions(current => current.slice(0, -1));
    setLocalError("");
    setNotice("Previous version restored.");
    if (revisions.length === 1 && canvasTab === "compare") setCanvasTab("preview");
  }

  function rerun() {
    newRevision(pageDocument);
  }

  function changeViewport(mode: "desktop" | "mobile") {
    if (mode === viewportMode) return;
    setViewportMode(mode);
    newRevision(pageDocument);
  }

  function highlight(finding: Finding, reveal = false) {
    setActiveKey(finding.key);
    setHighlightRequest(current => current + 1);
    if (reveal) {
      setCanvasTab("preview");
      setMobilePanel("page");
      if (compact) requestAnimationFrame(() => pagePanelRef.current?.focus({ preventScroll: true }));
    }
  }

  function preparePrompt(text: string) {
    setPrompt(text);
    setRailTab("chat");
    setMobilePanel("review");
    generation.clearFeedback();
    setLocalError("");
    requestAnimationFrame(() => composerRef.current?.focus());
  }

  function send(event?: FormEvent) {
    event?.preventDefault();
    if (generation.busy) { generation.stop(); return; }
    if (!canSend || !audit || activeRequest.current !== null) return;
    const brief = prompt.trim() || "Fix the selected findings while preserving this page’s design and meaning. If a fix needs more information, ask me first.";
    const task = ++runVersion.current;
    activeRequest.current = task;
    const previous = snapshot();
    const userId = `user-${task}`;
    const userTurn: ChatTurn = { id: userId, role: "user", content: brief, status: "pending" };
    const sentTurns = [...turns, userTurn];
    setTurns(sentTurns);
    setPrompt("");
    setRailTab("chat");
    setMobilePanel("review");
    setLocalError("");
    setNotice("");
    void generation.start({
      brief, document: pageDocument,
      audit: { findings: audit.findings, passed: audit.passed, incomplete: audit.incomplete, viewport: audit.viewport, truncated: audit.truncated },
      selectedFindingKeys: selected,
      history: turns.filter(turn => turn.status === "complete").slice(-12).map(({ role, content }) => ({ role, content: content.slice(0, 1500) })),
    }, {
      onComplete(result) {
        if (task !== runVersion.current) return;
        try {
          if (result.status === "complete") {
            const normalized = normalizeDocument(applyEdits(previous.document, result.edits));
            setRevisions(current => [...current.slice(-4), previous]);
            newRevision(normalized.document);
            setDraft(normalized.document);
            setSelected([]);
            setActiveKey(null);
            setNotice(normalized.removed ? `Updated the page and removed ${normalized.removed} unsupported ${normalized.removed === 1 ? "item" : "items"}.` : "Changes applied.");
          }
          setTurns([...sentTurns.map(turn => turn.id === userId ? { ...turn, status: "complete" as const } : turn), { id: `assistant-${task}`, role: "assistant", content: result.message, status: "complete" }]);
        } catch (cause) {
          setLocalError(cause instanceof Error ? cause.message : "The changes could not be applied. Your current page is preserved.");
          setTurns(sentTurns.map(turn => turn.id === userId ? { ...turn, status: "failed" } : turn));
        }
      },
      onError() { if (task === runVersion.current) setTurns(current => current.map(turn => turn.id === userId ? { ...turn, status: "failed" } : turn)); },
      onStop() { if (task === runVersion.current) { activeRequest.current = null; setTurns(current => current.map(turn => turn.id === userId ? { ...turn, status: "stopped" } : turn)); } },
    }).finally(() => { if (activeRequest.current === task) activeRequest.current = null; });
  }

  function composerKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing && event.nativeEvent.keyCode !== 229) { event.preventDefault(); if (!generation.busy) send(); }
  }

  function downloadPage() {
    try {
      const url = URL.createObjectURL(new Blob([exportDocumentHtml(pageDocument, assets)], { type: "text/html;charset=utf-8" }));
      const link = document.createElement("a");
      link.href = url;
      link.download = `${pageDocument.title.replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").slice(0, 60) || "lumen-page"}.html`;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setMenuOpen(false);
    } catch (cause) { setLocalError(cause instanceof Error ? cause.message : "The page could not be exported."); }
  }

  const beforeCount = issueCount(before?.audit ?? null);
  const afterCount = issueCount(audit);
  const comparable = before?.audit?.viewport.width === audit?.viewport.width && before?.audit?.viewport.height === audit?.viewport.height;

  return <>
    <div className="app-shell isolate">
      <header className="app-header">
        <a href="/" className="brand" aria-label="Lumen home"><SunIcon aria-hidden="true" /><span>Lumen</span></a>
        <div className="sample-control"><label className="sr-only" htmlFor="sample-select">Sample page</label><select id="sample-select" name="sample" value={sampleId} onChange={event => chooseSample(event.target.value)}>{!sampleId && <option value="">{importFilename || "Your HTML page"}</option>}{SAMPLE_PAGES.map(sample => <option value={sample.id} key={sample.id}>{sample.name}</option>)}</select><ChevronDownIcon aria-hidden="true" /></div>
        <button ref={menuRef} type="button" className="button icon-button mobile-menu-toggle" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen} aria-controls="header-actions" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <XMarkIcon aria-hidden="true" /> : <Bars3Icon aria-hidden="true" />}</button>
        <nav id="header-actions" className="header-actions" data-open={menuOpen} aria-label="Project actions">
          <button ref={uploadButtonRef} type="button" className="button ghost upload-button" aria-busy={importing} onClick={() => fileRef.current?.click()}><DocumentArrowUpIcon aria-hidden="true" />{importing ? "Opening…" : "Upload HTML"}</button>
          <button type="button" className="button secondary" onClick={downloadPage}><ArrowDownTrayIcon aria-hidden="true" />Export HTML</button>
          <a className="button ghost project-download" href="/downloads/lumen-accessibility-reviewer.zip" download><CodeBracketIcon aria-hidden="true" />Download project</a>
          <button type="button" className="button icon-button" aria-label="How Lumen works" onClick={() => { helpRef.current?.showModal(); setMenuOpen(false); }}><QuestionMarkCircleIcon aria-hidden="true" /></button>
        </nav>
        <input className="sr-only" ref={fileRef} name="html-upload" aria-label="Upload HTML file" type="file" accept=".html,.htm,text/html" onChange={event => { void upload(event.target.files?.[0]); event.target.value = ""; }} tabIndex={-1} />
      </header>
      <nav className="mobile-panel-switcher segmented" aria-label="Workspace panel"><button ref={pagePanelRef} type="button" aria-pressed={mobilePanel === "page"} onClick={() => setMobilePanel("page")}>Page</button><button type="button" aria-pressed={mobilePanel === "review"} onClick={() => setMobilePanel("review")}>Review{afterCount !== undefined && <span className="tab-count">{afterCount}</span>}</button></nav>
      <main className="workbench">
        <h1 className="sr-only">Lumen accessibility review</h1>
        <section className="canvas-panel" inert={compact && mobilePanel !== "page"} data-mobile-visible={mobilePanel === "page"} aria-label="Page workspace">
          <div className="canvas-toolbar">
            <div className="canvas-tabs segmented" aria-label="Page view"><button type="button" aria-pressed={canvasTab === "preview"} onClick={() => setCanvasTab("preview")}>Preview</button><button type="button" aria-pressed={canvasTab === "source"} onClick={() => setCanvasTab("source")}>Source</button><button type="button" aria-pressed={canvasTab === "compare"} disabled={!before} onClick={() => setCanvasTab("compare")}>Compare</button></div>
            <div className="canvas-tools"><div className="viewport-switcher segmented" aria-label="Preview size"><button type="button" aria-label="Desktop preview" aria-pressed={viewportMode === "desktop"} onClick={() => changeViewport("desktop")}><ComputerDesktopIcon aria-hidden="true" /></button><button type="button" aria-label="Mobile preview" aria-pressed={viewportMode === "mobile"} onClick={() => changeViewport("mobile")}><DevicePhoneMobileIcon aria-hidden="true" /></button></div><button type="button" className="button icon-button" disabled={!before || generation.busy || importing} aria-label="Undo last revision" title="Undo last revision" onClick={undo}><ArrowUturnLeftIcon aria-hidden="true" /></button></div>
          </div>
          <div className="page-caption"><h2>{pageDocument.title || "Untitled page"}</h2>{canvasTab === "compare" && beforeCount !== undefined && afterCount !== undefined && comparable ? <p className="comparison-count">{beforeCount} → {afterCount} confirmed {afterCount === 1 ? "issue" : "issues"}</p> : <p>{sampleId ? "Sample page" : "Your page"}<span aria-hidden="true"> · </span>{viewport.width} × {viewport.height}</p>}</div>
          <div className="canvas-body">
            <div className="frame-workspace" data-hidden={canvasTab === "source"} data-compare={canvasTab === "compare" && Boolean(before)}>
              {canvasTab === "compare" && before && <div className="preview-cell" key="before"><div className="preview-label"><span>Before</span>{beforeCount !== undefined && comparable ? <span>{beforeCount} {beforeCount === 1 ? "issue" : "issues"}</span> : <span>Not checked at this size</span>}</div><div className="frame-holder"><AuditFrame document={before.document} assets={before.assets} revision={`before-${revision}`} onAudit={() => {}} viewport={viewport} audit={false} title="Page before the last revision" /></div></div>}
              <div className="preview-cell current-preview" key="current">{canvasTab === "compare" && <div className="preview-label"><span>After</span><span>{checking ? "Checking…" : afterCount !== undefined ? `${afterCount} ${afterCount === 1 ? "issue" : "issues"}` : "Not checked"}</span></div>}<div className="frame-holder"><AuditFrame document={pageDocument} assets={assets} revision={revision} onAudit={receiveAudit} onError={message => { if (revisionRef.current === revision) setAuditError(message); }} highlight={activeFinding?.selector || null} highlightRequest={highlightRequest} viewport={viewport} title="Current page preview" /></div></div>
            </div>
            {canvasTab === "source" && <SourceEditor draft={draft} onChange={setDraft} dirty={dirty} busy={generation.busy || importing} onApply={applySource} onDiscard={() => setDraft(pageDocument)} />}
          </div>
          <div className="canvas-footer"><div className="audit-state" role="status"><span className="status-dot" data-checking={checking} />{auditError ? "Review unavailable" : checking ? "Checking the page…" : "Review up to date"}</div><button type="button" className="button ghost compact" disabled={checking || generation.busy} onClick={rerun}><ArrowPathIcon aria-hidden="true" />Recheck</button></div>
        </section>
        <aside className="review-rail" inert={compact && mobilePanel !== "review"} data-mobile-visible={mobilePanel === "review"} aria-label="Accessibility review">
          <div className="rail-header"><div className="rail-tabs segmented" aria-label="Review view"><button type="button" aria-pressed={railTab === "findings"} onClick={() => setRailTab("findings")}>Findings</button><button type="button" aria-pressed={railTab === "chat"} onClick={() => setRailTab("chat")}>Chat{turns.length > 0 && <span className="chat-dot" aria-label="Conversation started" />}</button></div><p>Accessibility review</p></div>
          <div className="rail-content">
            <div className="findings-scroll" hidden={railTab !== "findings"}><FindingsPanel audit={audit} checking={checking} selected={selected} activeKey={activeKey} onSelect={key => setSelected(current => current.includes(key) ? current.filter(item => item !== key) : [...current, key])} onSelectAll={setSelected} onHighlight={highlight} /></div>
            <div className="chat-pane" hidden={railTab !== "chat"}><ReviewChat turns={turns} busy={generation.busy} message={generation.message} onRetry={preparePrompt} onSuggest={preparePrompt} /></div>
          </div>
          <div className="composer-area">
            {selected.length > 0 && <div className="selection-context"><p>{selected.length} {selected.length === 1 ? "finding" : "findings"} selected</p><button type="button" className="text-button" onClick={() => setSelected([])}>Clear</button></div>}
            {generation.busy && <div className="generation-status" role="status"><span className="activity-dot" /><p title={generation.progress || "Reviewing your request…"}>{generation.progress || "Reviewing your request…"}</p><span className="elapsed">{Math.floor(generation.elapsed)}s</span></div>}
            {(error || auditError) && <p className="error-message" role="alert">{error || auditError}</p>}
            {notice && !error && <p className="composer-notice" role="status">{notice}</p>}
            {importWarnings.length > 0 && <details className="import-notes"><summary>{importWarnings.length} import {importWarnings.length === 1 ? "note" : "notes"}</summary><ul role="list">{importWarnings.map((warning, index) => <li key={`${index}-${warning}`}>{warning}</li>)}</ul></details>}
            {dirty && <p className="composer-notice">Apply or discard source changes before asking Lumen.</p>}
            <form className="composer" onSubmit={send}>
              <textarea ref={composerRef} name="message" aria-label="Message Lumen" placeholder={selected.length ? "Add instructions for these fixes…" : "Ask about this page…"} value={prompt} maxLength={1500} onChange={event => setPrompt(event.target.value)} onKeyDown={composerKeyDown} rows={3} />
              <div className="composer-bottom"><p className="composer-key-hint">Enter to send<span> · Shift + Enter for a new line</span></p><button type={generation.busy ? "button" : "submit"} className="button primary send-button" disabled={!generation.busy && !canSend} onClick={generation.busy ? event => { event.preventDefault(); generation.stop(); } : undefined}>{generation.busy ? <><StopIcon aria-hidden="true" />Stop</> : !prompt.trim() && selected.length > 0 ? <><CheckIcon aria-hidden="true" />Fix selected</> : <><ArrowUpIcon aria-hidden="true" />Send</>}</button></div>
            </form>
            <p className="review-scope">Automated checks are a starting point.</p>
          </div>
        </aside>
      </main>
    </div>
    <dialog ref={importDialogRef} className="help-dialog import-dialog" aria-labelledby="import-title" aria-describedby="import-description" onCancel={event => { event.preventDefault(); cancelImport(); }} onClick={event => { if (event.target === event.currentTarget) cancelImport(); }}>
      <div className="help-content import-content">
        <div className="dialog-heading"><h2 id="import-title">Add the page’s files</h2><button type="button" className="button icon-button" aria-label="Cancel import" onClick={cancelImport}><XMarkIcon aria-hidden="true" /></button></div>
        <p id="import-description"><strong>{pendingImport?.filename}</strong> refers to stylesheets saved in a companion folder. Choose the folder saved beside the HTML file to include its styles and local images.</p>
        <div className="missing-styles"><h3>Stylesheets to find</h3><ul role="list">{pendingImport?.result.missingStylesheets.map((path, index) => <li key={`${index}-${path}`}><code>{path}</code></li>)}</ul></div>
        <p className="import-privacy">Files are read locally in your browser. Your current page stays open until the import is ready.</p>
        {importError && <p className="error-message" role="alert">{importError}</p>}
        {importing && <p className="import-progress" role="status">Reading the page’s files…</p>}
        <input ref={element => { folderRef.current = element; if (element) element.setAttribute("webkitdirectory", ""); }} className="sr-only" name="page-files" aria-label="Choose companion folder" type="file" multiple tabIndex={-1} onChange={event => { void addCompanionFolder(Array.from(event.target.files || [])); event.target.value = ""; }} />
        <button type="button" className="button primary folder-button" disabled={importing} onClick={() => folderRef.current?.click()}><DocumentArrowUpIcon aria-hidden="true" />{importing ? "Reading files…" : "Choose companion folder"}</button>
        <div className="import-footer"><button type="button" className="button ghost" onClick={cancelImport}>Cancel</button><button type="button" className="button secondary" disabled={importing || !pendingImport} onClick={openWithoutStyles}>Open without styles</button></div>
      </div>
    </dialog>
    <dialog ref={helpRef} className="help-dialog" aria-labelledby="help-title" onClick={event => { if (event.target === event.currentTarget) helpRef.current?.close(); }}><div className="help-content"><div className="dialog-heading"><h2 id="help-title">How Lumen works</h2><button type="button" className="button icon-button" aria-label="Close help" onClick={() => helpRef.current?.close()}><XMarkIcon aria-hidden="true" /></button></div><p>Review a sample or upload a saved HTML page. If its styles are in a companion folder, Lumen will ask you to choose that folder. Automated checks run locally in an isolated preview.</p><ol><li><strong>Inspect the findings.</strong> Confirmed issues are separate from checks that need human review. Expand a finding to see the element and its evidence.</li><li><strong>Make a focused change.</strong> Select findings and choose Fix selected, or ask Lumen a question. Only sending a request shares the current source, findings, and recent conversation with OpenAI.</li><li><strong>Check the result.</strong> Changes trigger a fresh review. Compare the previous page, undo a revision, or export your current HTML.</li></ol><p>Automated checks do not establish accessibility compliance. Also test keyboard use, reading order, meaningful labels, and the experience with assistive technology.</p><p className="help-footnote">Unsupported content is removed for the isolated preview. Your work stays in this tab; export it before leaving.</p></div></dialog>
  </>;
}
