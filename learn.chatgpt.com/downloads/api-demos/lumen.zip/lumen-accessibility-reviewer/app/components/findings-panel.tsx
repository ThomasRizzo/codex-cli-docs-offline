"use client";

import { useState } from "react";
import { ArrowTopRightOnSquareIcon, CheckIcon, ChevronDownIcon, CursorArrowRaysIcon } from "@heroicons/react/16/solid";
import type { AuditSnapshot, Finding } from "../lib/contracts";

interface Props {
  audit: AuditSnapshot | null;
  checking: boolean;
  selected: string[];
  activeKey: string | null;
  onSelect: (key: string) => void;
  onSelectAll: (keys: string[]) => void;
  onHighlight: (finding: Finding, reveal?: boolean) => void;
}

function FailureSummary({ summary, description }: { summary: string; description: string }) {
  const normalize = (text: string) => text.replace(/\s+/g, " ").trim();
  if (!summary.trim() || normalize(summary) === normalize(description)) return null;
  return <div className="failure-summary">{summary.trim().split(/\r?\n\s*\r?\n/).map((section, sectionIndex) => {
    const [heading, ...lines] = section.split(/\r?\n/);
    if (!/^Fix (?:any|all) of the following:$/.test(heading.trim())) return <p key={sectionIndex}>{normalize(section)}</p>;
    const items: string[] = [];
    const firstLine = lines.find(line => line.trim());
    const indentation = firstLine?.match(/^\s*/)?.[0].length ?? 0;
    for (const line of lines) {
      if (!line.trim()) continue;
      if (items.length && (line.match(/^\s*/)?.[0].length ?? 0) > indentation) items[items.length - 1] += ` ${line.trim()}`;
      else items.push(line.trim());
    }
    return <div className="failure-summary-group" key={sectionIndex}>
      <p>{heading.trim()}</p>
      {items.length > 0 && <ul>{items.map((item, itemIndex) => <li key={itemIndex}>{item}</li>)}</ul>}
    </div>;
  })}</div>;
}

function FindingRow({ finding, selected, active, onSelect, onHighlight }: { finding: Finding; selected: boolean; active: boolean; onSelect: () => void; onHighlight: (reveal?: boolean) => void }) {
  const [expanded, setExpanded] = useState(false);
  const id = `finding-${encodeURIComponent(finding.key)}`;
  const canHighlight = Boolean(finding.selector) && (finding.previewTarget === "element" || finding.previewTarget === "content");
  const targetDescription = finding.previewTarget === "page" ? "Page-level check" : finding.ruleId === "region" ? "Page structure" : "No visible target";
  return <article className="finding" data-active={active}>
    <div className="finding-heading">
      <label className="finding-check" aria-label={`Select ${finding.title}`}>
        <input type="checkbox" name="finding" checked={selected} onChange={onSelect} />
        <CheckIcon aria-hidden="true" />
      </label>
      <button type="button" className="finding-toggle" aria-expanded={expanded} aria-controls={id} onClick={() => { setExpanded(!expanded); if (!expanded && canHighlight) onHighlight(); }}>
        <div className="finding-title">{finding.title}</div>
        <div className="finding-meta"><span className="impact" data-impact={finding.impact}>{finding.impact === "unknown" ? "Unrated" : finding.impact.charAt(0).toUpperCase() + finding.impact.slice(1)}</span><span>{finding.ruleId}</span></div>
        <ChevronDownIcon className="finding-chevron" aria-hidden="true" />
      </button>
    </div>
    <div id={id} className="finding-evidence" hidden={!expanded}>
      <p>{finding.description}</p>
      <FailureSummary summary={finding.failureSummary} description={finding.description} />
      <div className="evidence-code"><code>{finding.html || finding.selector}</code></div>
      <div className="evidence-actions">
        {canHighlight ? <button type="button" className="button ghost compact" onClick={() => onHighlight(true)}><CursorArrowRaysIcon aria-hidden="true" />{finding.previewTarget === "content" ? "Show affected content" : "Show element"}</button> : <span className="evidence-target-description">{targetDescription}</span>}
        <a href={finding.helpUrl} target="_blank" rel="noreferrer" className="button ghost compact">Rule details<ArrowTopRightOnSquareIcon aria-hidden="true" /></a>
      </div>
    </div>
  </article>;
}

export default function FindingsPanel({ audit, checking, selected, activeKey, onSelect, onSelectAll, onHighlight }: Props) {
  if (!audit) return <div className="findings-empty"><div className="audit-loader" aria-hidden="true" /><h2>{checking ? "Checking the page" : "Ready to review"}</h2><p>{checking ? "Measuring the page in its preview." : "Run a review to see measured findings."}</p></div>;
  const violations = audit.findings.filter(finding => finding.kind === "violation");
  const reviews = audit.findings.filter(finding => finding.kind === "review");
  return <div className="findings-content" aria-busy={checking}>
    <div className="review-summary">
      <div><p className="metric-value">{violations.length}</p><p>Confirmed issues</p></div>
      <div><p className="metric-value">{reviews.length}</p><p>Need human review</p></div>
    </div>
    <div className="checks-note"><span>{audit.passed} checks passed</span><span>{audit.viewport.width}px wide</span></div>
    {audit.truncated && <p className="inline-notice">Showing the first 50 findings. Recheck after fixes to uncover more.</p>}
    <section className="finding-group" aria-labelledby="violations-heading">
      <div className="finding-group-heading"><h2 id="violations-heading">Confirmed issues</h2>{violations.length > 0 && <button type="button" className="text-button" onClick={() => onSelectAll(violations.every(f => selected.includes(f.key)) ? selected.filter(key => !violations.some(f => f.key === key)) : [...new Set([...selected, ...violations.map(f => f.key)])])}>{violations.every(f => selected.includes(f.key)) ? "Clear" : "Select all"}</button>}</div>
      {violations.length ? violations.map(finding => <FindingRow key={finding.key} finding={finding} selected={selected.includes(finding.key)} active={activeKey === finding.key} onSelect={() => onSelect(finding.key)} onHighlight={reveal => onHighlight(finding, reveal)} />) : <p className="empty-group">No violations found in these automated checks. A human review is still needed.</p>}
    </section>
    <section className="finding-group human-review" aria-labelledby="human-heading">
      <div className="finding-group-heading"><h2 id="human-heading">Human review</h2></div>
      <p className="group-description">These checks could not be decided automatically.</p>
      {reviews.length ? reviews.map(finding => <FindingRow key={finding.key} finding={finding} selected={selected.includes(finding.key)} active={activeKey === finding.key} onSelect={() => onSelect(finding.key)} onHighlight={reveal => onHighlight(finding, reveal)} />) : <p className="empty-group">Also check keyboard navigation, reading order, and whether labels make sense in context.</p>}
    </section>
  </div>;
}
