"use client";

import { useEffect, useRef, useState } from "react";
import { applyEdits, resultSchema, type CreateRequest, type GenerationResult } from "../lib/contracts";
import { readSSE } from "../lib/sse";

type Run = { controller: AbortController; observer: AbortController; token: string | null; onStop?: () => void };

export function useReviewGeneration() {
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [elapsed, setElapsed] = useState(0);
  const active = useRef<Run | null>(null);
  const pendingCleanup = useRef(new Set<string>());
  const cleanupInFlight = useRef(new Set<string>());
  const session = useRef<string | null>(null);
  function requestHeaders() {
    session.current ??= crypto.randomUUID();
    return { "Content-Type": "application/json", "X-Lumen-Session": session.current };
  }

  useEffect(() => {
    if (!busy) return;
    const started = Date.now();
    const timer = window.setInterval(() => setElapsed(Math.floor((Date.now() - started) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, [busy]);
  useEffect(() => {
    const release = () => {
      if (active.current?.token) pendingCleanup.current.add(active.current.token);
      for (const token of pendingCleanup.current) void fetch("/api/review/cancel", {
        method: "POST", headers: requestHeaders(), body: JSON.stringify({ token }), keepalive: true,
      }).catch(() => undefined);
    };
    window.addEventListener("pagehide", release);
    return () => {
      window.removeEventListener("pagehide", release);
      release();
      const run = active.current; active.current = null;
      run?.controller.abort();
      if (run?.token) run.observer.abort();
    };
  }, []);

  function cleanup(token: string) {
    pendingCleanup.current.add(token);
    if (cleanupInFlight.current.has(token)) return;
    cleanupInFlight.current.add(token);
    void (async () => {
      try {
        for (let attempt = 0; attempt < 3; attempt += 1) {
          try {
            const response = await fetch("/api/review/cancel", { method: "POST", headers: requestHeaders(), body: JSON.stringify({ token }), keepalive: true, signal: AbortSignal.timeout(50000) });
            if (response.ok) { pendingCleanup.current.delete(token); return; }
          } catch { /* Keep the handle for retry and navigation cleanup. */ }
          if (attempt < 2) await new Promise(resolve => window.setTimeout(resolve, (attempt + 1) * 1000));
        }
      } finally { cleanupInFlight.current.delete(token); }
    })();
  }

  function stop(quiet = false) {
    const run = active.current; active.current = null;
    run?.controller.abort();
    if (run?.token) { cleanup(run.token); run.observer.abort(); }
    setBusy(false); setProgress("");
    if (!quiet) { run?.onStop?.(); setMessage("Stopped. Your current page is unchanged."); }
  }
  function clearFeedback() { setError(null); setMessage(""); }

  async function start(input: CreateRequest, callbacks: { onOpen?: () => void; onComplete: (result: GenerationResult) => void; onError?: (message: string) => void; onStop?: () => void }) {
    if (active.current) return;
    const run: Run = { controller: new AbortController(), observer: new AbortController(), token: null, onStop: callbacks.onStop };
    active.current = run;
    setBusy(true); setElapsed(0); setError(null); setMessage(""); setProgress("Reading your message…");
    const finish = (value: unknown) => {
      const parsed = resultSchema.safeParse(value);
      if (!parsed.success) throw new Error("The review was incomplete. Your current page is unchanged; please try again.");
      if (parsed.data.status === "complete") applyEdits(input.document, parsed.data.edits);
      callbacks.onComplete(parsed.data);
      setMessage(parsed.data.message);
      if (run.token) cleanup(run.token);
    };
    try {
      // During startup Stop keeps this observer alive until a handle can be cleaned up.
      const response = await fetch("/api/review/start", {
        method: "POST", headers: { ...requestHeaders(), Accept: "text/event-stream" },
        body: JSON.stringify(input), signal: AbortSignal.any([run.observer.signal, AbortSignal.timeout(185000)]),
      });
      if (!response.ok) {
        const problem: unknown = await response.json().catch(() => null);
        throw new Error(problem && typeof problem === "object" && "error" in problem && typeof problem.error === "string" ? problem.error : "The review could not start. Please try again.");
      }
      if (!response.body || !response.headers.get("content-type")?.includes("text/event-stream")) throw new Error("The live response could not be read. Please try again.");
      if (active.current === run) callbacks.onOpen?.();
      let streamError: string | null = null;
      try {
        for await (const event of readSSE(response.body, { signal: run.observer.signal })) {
          const data: unknown = JSON.parse(event.data);
          if (!data || typeof data !== "object") continue;
          if (event.event === "session") {
            if (!("token" in data) || typeof data.token !== "string" || !data.token) throw new Error("The generation session was incomplete.");
            run.token = data.token;
            if (active.current !== run) { cleanup(data.token); run.observer.abort(); return; }
          }
          if (active.current !== run) continue;
          if ((event.event === "start" || event.event === "progress") && "progress" in data && typeof data.progress === "string") setProgress(data.progress.slice(0, 500));
          else if (event.event === "message" && "message" in data && typeof data.message === "string") setMessage(data.message.slice(0, 1500));
          else if (event.event === "complete" && "result" in data) { finish(data.result); return; }
          else if (event.event === "error") { streamError = "error" in data && typeof data.error === "string" ? data.error : "The review could not finish. Please try again."; break; }
        }
      } catch (cause) {
        if (run.controller.signal.aborted) throw cause;
        throw new Error("The connection ended before the review finished. Your page is unchanged; please try again.");
      }
      if (streamError) throw new Error(streamError);
      if (active.current !== run) return;
      throw new Error("The connection ended before the review finished. Your page is unchanged; please try again.");
    } catch (cause) {
      if (active.current === run && !run.controller.signal.aborted) {
        const message = cause instanceof Error ? cause.message : "The review could not finish. Please try again.";
        setError(message); callbacks.onError?.(message);
        if (run.token) cleanup(run.token);
      }
    } finally {
      if (active.current === run) { active.current = null; setBusy(false); setProgress(""); }
    }
  }

  return { busy, progress, error, message, elapsed, start, stop, clearFeedback };
}
