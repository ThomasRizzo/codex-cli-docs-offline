"use client";

import { useEffect, useRef } from "react";
import { ArrowPathIcon } from "@heroicons/react/16/solid";

export interface ChatTurn { id: string; role: "user" | "assistant"; content: string; status: "complete" | "pending" | "failed" | "stopped" }
export default function ReviewChat({ turns, busy, message, onRetry, onSuggest }: { turns: ChatTurn[]; busy: boolean; message: string; onRetry: (text: string) => void; onSuggest: (text: string) => void }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const following = useRef(true);
  useEffect(() => {
    const node = scrollRef.current;
    if (node && following.current) node.scrollTop = node.scrollHeight;
  }, [turns, message, busy]);
  return <div className="review-chat" ref={scrollRef} onScroll={event => { const node = event.currentTarget; following.current = node.scrollHeight - node.scrollTop - node.clientHeight < 90; }}>
    {turns.length === 0 ? <div className="chat-empty"><h2>A second pair of eyes</h2><p>Ask about a finding, request a specific fix, or discuss what needs a human review.</p><div className="chat-suggestions"><button type="button" className="suggestion" onClick={() => onSuggest("Explain the most important issues on this page.")}>Explain the main issues</button><button type="button" className="suggestion" onClick={() => onSuggest("What should I check manually on this page?")}>What should I check manually?</button></div></div> : <div className="chat-turns" role="log" aria-label="Conversation with Lumen">
      {turns.map(turn => <article className="chat-turn" data-role={turn.role} key={turn.id}><h3>{turn.role === "user" ? "You" : "Lumen"}</h3><p>{turn.content}</p>{(turn.status === "failed" || turn.status === "stopped") && <button type="button" className="button ghost compact" disabled={busy} onClick={() => onRetry(turn.content)}><ArrowPathIcon aria-hidden="true" />{turn.status === "stopped" ? "Continue this request" : "Try again"}</button>}</article>)}
      {busy && message && <article className="chat-turn streaming" data-role="assistant"><h3>Lumen</h3><p>{message}</p></article>}
    </div>}
  </div>;
}
