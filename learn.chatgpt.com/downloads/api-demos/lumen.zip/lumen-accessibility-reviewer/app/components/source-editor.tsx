"use client";

import { useState } from "react";
import { CheckIcon } from "@heroicons/react/16/solid";
import { MAX_HTML_CHARS, MAX_CSS_CHARS, type PageDocument } from "../lib/contracts";

export default function SourceEditor({ draft, onChange, dirty, busy, onApply, onDiscard }: { draft: PageDocument; onChange: (document: PageDocument) => void; dirty: boolean; busy: boolean; onApply: () => void; onDiscard: () => void }) {
  const [field, setField] = useState<"html" | "css">("html");
  return <section className="source-editor" aria-label="Page source">
    <div className="source-metadata">
      <label className="field-label">Page title<input name="page-title" value={draft.title} maxLength={120} readOnly={busy} onChange={event => onChange({ ...draft, title: event.target.value })} /></label>
      <label className="field-label language-field">Language<input name="page-language" value={draft.lang} maxLength={35} readOnly={busy} placeholder="en" onChange={event => onChange({ ...draft, lang: event.target.value })} /></label>
    </div>
    <div className="source-toolbar"><div className="segmented" aria-label="Source language"><button type="button" aria-pressed={field === "html"} onClick={() => setField("html")}>HTML</button><button type="button" aria-pressed={field === "css"} onClick={() => setField("css")}>CSS</button></div><p>{dirty ? "Unsaved changes" : "Current page source"}</p></div>
    <textarea className="source-textarea" name={`${field}-source`} aria-label={field === "html" ? "HTML source" : "CSS source"} value={draft[field]} onChange={event => onChange({ ...draft, [field]: event.target.value })} readOnly={busy} spellCheck={false} autoCapitalize="off" autoComplete="off" wrap="off" maxLength={field === "html" ? MAX_HTML_CHARS : MAX_CSS_CHARS} />
    <div className="source-footer"><p>Paste HTML here, or upload an .html file.</p><div><button type="button" className="button ghost" disabled={!dirty || busy} onClick={onDiscard}>Discard</button><button type="button" className="button secondary" disabled={!dirty || busy} onClick={onApply}><CheckIcon aria-hidden="true" />Apply source</button></div></div>
  </section>;
}
