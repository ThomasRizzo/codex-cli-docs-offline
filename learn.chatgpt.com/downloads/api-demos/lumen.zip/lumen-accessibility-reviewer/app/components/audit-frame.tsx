"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { z } from "zod";
import { auditSchema, documentSchema, type AuditSnapshot, type PageDocument } from "../lib/contracts";
import { normalizeDocument } from "../lib/document-io";
import { validatePreviewAssets, type PreviewAssets } from "../lib/preview-assets";

const EMPTY_ASSETS: PreviewAssets = {};

const snapshotSchema = auditSchema.extend({ revision: z.string().max(200), document: documentSchema, removed: z.number().int().min(0).max(100_000) });
let runtimePromise: Promise<string> | undefined;
function loadRuntime() {
  runtimePromise ??= fetch("/audit-runtime.js", { cache: "no-cache", credentials: "same-origin" }).then(async response => {
    if (!response.ok) throw new Error("Could not load the accessibility checker.");
    const runtime = await response.text();
    if (!runtime.length || runtime.length > 2_000_000) throw new Error("Could not load the accessibility checker.");
    return runtime;
  }).catch(error => { runtimePromise = undefined; throw error; });
  return runtimePromise;
}

export function createFrameHtml(runtime: string, token: string, parentOrigin: string): string {
  if (!/^[a-f0-9]{32}$/.test(token)) throw new Error("Invalid frame token.");
  const config = JSON.stringify({ token, parentOrigin }).replace(/</g, "\\u003c");
  // Encode the trusted bundle so library strings such as '<!--' or '<script'
  // cannot change the HTML parser's script state. No eval or user source is used.
  const bytes = new TextEncoder().encode(runtime);
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 16_384) binary += String.fromCharCode(...bytes.subarray(offset, offset + 16_384));
  const code = JSON.stringify(btoa(binary));
  const csp = `default-src 'none'; script-src 'nonce-${token}'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; font-src data:; media-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'`;
  return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${csp}"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body><script nonce="${token}">window.__LUMEN_AUDIT_CONFIG__=${config};{const script=document.createElement('script');script.nonce='${token}';script.textContent=new TextDecoder().decode(Uint8Array.from(atob(${code}),c=>c.charCodeAt(0)));document.head.appendChild(script);}</script></body></html>`;
}

export function readAuditMessage(data: unknown, token: string, revision: string, viewport: { width: number; height: number }, expectedDocument?: PageDocument): AuditSnapshot | null {
  if (!data || typeof data !== "object") return null;
  const message = data as Record<string, unknown>;
  if (message.type !== "lumen:result" || message.token !== token) return null;
  const parsed = snapshotSchema.safeParse(message.snapshot);
  if (!parsed.success || parsed.data.revision !== revision || parsed.data.viewport.width !== viewport.width || parsed.data.viewport.height !== viewport.height) return null;
  if (new Set(parsed.data.findings.map(finding => finding.key)).size !== parsed.data.findings.length) return null;
  if (expectedDocument && JSON.stringify(parsed.data.document) !== JSON.stringify(expectedDocument)) return null;
  return parsed.data;
}

export type AuditFrameProps = {
  document: PageDocument; revision: string; onAudit: (snapshot: AuditSnapshot) => void;
  onError?: (message: string) => void; highlight?: string | null; highlightRequest?: number;
  viewport?: { width: number; height: number }; audit?: boolean; title?: string;
  assets?: PreviewAssets;
};

export default function AuditFrame({ document, revision, onAudit, onError, highlight = null, highlightRequest = 0, viewport = { width: 960, height: 720 }, audit = true, title = "Page preview", assets = EMPTY_ASSETS }: AuditFrameProps) {
  const frame = useRef<HTMLIFrameElement>(null);
  const container = useRef<HTMLDivElement>(null);
  const [source, setSource] = useState("");
  const [bounds, setBounds] = useState({ width: 0, height: 0 });
  const callbacks = useRef({ onAudit, onError });
  callbacks.current = { onAudit, onError };
  const frameState = useRef<{ token: string; revision: string; rendered: boolean } | null>(null);
  const selected = useRef(highlight);
  selected.current = highlight;
  const frameWidth = Math.min(2400, Math.max(280, Math.round(viewport.width)));
  const frameHeight = Math.min(1600, Math.max(200, Math.round(viewport.height)));
  const serialized = useMemo(() => JSON.stringify(document), [document]);
  const assetState = useMemo(() => {
    try { return { assets: validatePreviewAssets(assets), error: "" }; }
    catch (cause) { return { assets: EMPTY_ASSETS, error: cause instanceof Error ? cause.message : "The page assets could not be opened." }; }
  }, [assets]);

  useEffect(() => {
    const element = container.current;
    if (!element) return;
    const update = () => {
      const next = { width: element.clientWidth, height: element.clientHeight };
      setBounds(current => current.width === next.width && current.height === next.height ? current : next);
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    let active = true;
    let completed = false;
    const token = crypto.randomUUID().replace(/-/g, "");
    const state = { token, revision, rendered: false };
    frameState.current = state;
    if (assetState.error) { callbacks.current.onError?.(assetState.error); return; }
    let normalized: ReturnType<typeof normalizeDocument>;
    try { normalized = normalizeDocument(JSON.parse(serialized)); } catch {
      callbacks.current.onError?.("This page is too large or contains unsupported markup. Check the HTML/CSS and try again.");
      return;
    }
    const post = (message: Record<string, unknown>) => frame.current?.contentWindow?.postMessage({ ...message, token }, "*");
    const deadline = setTimeout(() => {
      if (active && !completed) { completed = true; callbacks.current.onError?.("The accessibility check took too long. Run the check again."); }
    }, 20_000);
    const listener = (event: MessageEvent) => {
      if (!active || event.source !== frame.current?.contentWindow || event.origin !== "null" || !event.data || event.data.token !== token) return;
      if (event.data.type === "lumen:ready") {
        post({ type: "lumen:render", revision, document: normalized.document, assets: assetState.assets, audit });
      } else if (event.data.type === "lumen:rendered" && event.data.revision === revision) {
        state.rendered = true;
        if (!audit) { completed = true; clearTimeout(deadline); }
      } else if (event.data.type === "lumen:error" && event.data.revision === revision) {
        completed = true; clearTimeout(deadline);
        callbacks.current.onError?.("The page could not be checked. Try a smaller HTML/CSS document and run the check again.");
      } else {
        const snapshot = readAuditMessage(event.data, token, revision, { width: frameWidth, height: frameHeight }, normalized.document);
        if (!snapshot || !audit || completed) return;
        completed = true; clearTimeout(deadline);
        callbacks.current.onAudit({ ...snapshot, removed: snapshot.removed + normalized.removed });
        if (selected.current) post({ type: "lumen:highlight", revision, selector: selected.current });
      }
    };
    window.addEventListener("message", listener);
    loadRuntime().then(runtime => {
      if (active) setSource(createFrameHtml(runtime, token, window.location.origin));
    }).catch(() => {
      if (active) { completed = true; clearTimeout(deadline); callbacks.current.onError?.("Could not load the accessibility checker. Reload the page to try again."); }
    });
    return () => { active = false; clearTimeout(deadline); window.removeEventListener("message", listener); if (frameState.current === state) frameState.current = null; };
  }, [serialized, revision, frameWidth, frameHeight, audit, assetState]);

  useEffect(() => {
    const state = frameState.current;
    if (state?.rendered) frame.current?.contentWindow?.postMessage({ type: "lumen:highlight", token: state.token, revision: state.revision, selector: highlight }, "*");
  }, [highlight, highlightRequest]);

  // Fit the measured viewport in its panel; only the page inside it should scroll.
  const scale = bounds.width && bounds.height ? Math.min(1, bounds.width / frameWidth, bounds.height / frameHeight) : 1;
  return <div ref={container} className="audit-frame" role="region" aria-label={`${title} viewport`} style={{ width: "100%", height: "100%", overflow: "clip", position: "relative" }}>
    <div style={{ width: frameWidth * scale, height: frameHeight * scale, margin: "0 auto", position: "relative", overflow: "clip" }}>
      {source && <iframe ref={frame} title={title} tabIndex={0} sandbox="allow-scripts" referrerPolicy="no-referrer" srcDoc={source} width={frameWidth} height={frameHeight} style={{ display: "block", position: "absolute", top: 0, left: 0, border: 0, background: "white", width: frameWidth, height: frameHeight, transform: `scale(${scale})`, transformOrigin: "top left" }} />}
    </div>
  </div>;
}
