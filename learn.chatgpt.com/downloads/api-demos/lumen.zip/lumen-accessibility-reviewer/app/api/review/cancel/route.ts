import { errorResponse, getRuntime, guardRequest, limitSessionRequests, parseBody, privateHeaders, tokenRequestSchema, verifyHandle } from "../../../lib/server";

export async function POST(request: Request) {
  try {
    const owner = guardRequest(request);
    const { token } = await parseBody(request, tokenRequestSchema);
    const runtime = await getRuntime();
    // A correctly signed owner handle remains valid for deletion after read access expires.
    const handle = await verifyHandle(token, owner, runtime.secret, Date.now(), true);
    limitSessionRequests(owner, "cancel");
    const cleanup = await runtime.cleanup();
    const outcome = await cleanup.release(handle.id);
    return Response.json({ ok: true, cleanup: outcome }, { headers: privateHeaders });
  } catch (error) { return errorResponse(error); }
}
