import { digest, generationResult } from "../../../lib/generation-result";
import { MAX_REQUEST_BYTES } from "../../../lib/contracts";
import { pollGenerationSession } from "../../../lib/agents";
import { GENERATION_DEADLINE_MS, ApiError, errorResponse, getRuntime, guardRequest, limitSessionRequests, parseBody, privateHeaders, statusRequestSchema, verifyHandle } from "../../../lib/server";

export async function POST(request: Request) {
  let cleanupOnError: (() => Promise<unknown>) | undefined;
  try {
    const owner = guardRequest(request);
    const { token, document } = await parseBody(request, statusRequestSchema, MAX_REQUEST_BYTES);
    const runtime = await getRuntime(), handle = await verifyHandle(token, owner, runtime.secret);
    limitSessionRequests(owner, "status");
    if (await digest(document) !== handle.sourceHash) throw new ApiError(409, "The page changed during this review. Start a new review of the current page.");
    const queue = await runtime.cleanup();
    try { await queue.assertSession(handle.id); }
    catch { throw new ApiError(503, "This generation session is no longer available."); }
    const cleanup = () => queue.release(handle.id).catch(() => console.error(JSON.stringify({ event: "generation_cleanup_failed", sessionId: handle.id })));
    cleanupOnError = cleanup;
    if (Date.now() - handle.created > GENERATION_DEADLINE_MS) {
      await cleanup(); throw new ApiError(408, "This review took too long. Try a shorter brief.");
    }
    const state = await pollGenerationSession(runtime.transport, handle.id);
    if (["failed", "cancelled", "waiting"].includes(state.status)) {
      await cleanup(); return Response.json({ status: state.status, progress: state.progress, error: state.error }, { headers: privateHeaders });
    }
    if (state.status !== "complete") return Response.json({ status: state.status, progress: state.progress }, { headers: privateHeaders });
    const result = await generationResult(state, document, handle);
    if (!result) {
      await cleanup();
      return Response.json({ status: "failed", progress: "Review incomplete", error: "The review did not pass its final checks. Your current page is unchanged; try again." }, { headers: privateHeaders });
    }
    await cleanup();
    return Response.json({ status: "complete", progress: "Review ready", ...result }, { headers: privateHeaders });
  } catch (error) { await cleanupOnError?.(); return errorResponse(error); }
}
