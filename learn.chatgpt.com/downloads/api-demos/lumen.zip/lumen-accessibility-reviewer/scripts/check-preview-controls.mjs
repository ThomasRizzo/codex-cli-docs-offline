/** Browser regressions for preview scrolling, repeat highlights, and header actions. */
export async function runPreviewControlChecks(page) {
  const checks = [];
  const check = (condition, label) => { if (!condition) throw Error(label); checks.push(label); };
  const fits = async () => {
    const boxes = await page.locator('.audit-frame').evaluateAll(elements => elements.filter(el => el.clientWidth && el.clientHeight).map(el => {
      const frame = el.querySelector('iframe'), wrapper = frame.parentElement;
      const outer = el.getBoundingClientRect(), inner = frame.getBoundingClientRect();
      return { fits: inner.left >= outer.left - 1 && inner.right <= outer.right + 1 && inner.top >= outer.top - 1 && inner.bottom <= outer.bottom + 1, clipped: getComputedStyle(el).overflow === 'clip' && getComputedStyle(wrapper).overflow === 'clip', offsets: [el.scrollTop, el.scrollLeft, wrapper.scrollTop, wrapper.scrollLeft] };
    }));
    check(boxes.length > 0 && boxes.every(box => box.fits && box.clipped && box.offsets.every(offset => offset === 0)), 'Visible previews fit their panels without outer scrolling');
  };
  await page.setViewportSize({ width: 1512, height: 900 });
  await page.getByText('Review up to date', { exact: true }).waitFor();
  const centered = await page.getByRole('button', { name: 'How Lumen works', exact: true }).evaluate(el => {
    const a = el.getBoundingClientRect(), b = el.querySelector('svg').getBoundingClientRect();
    return Math.abs(a.x + a.width / 2 - b.x - b.width / 2) < .5 && Math.abs(a.y + a.height / 2 - b.y - b.height / 2) < .5;
  });
  check(centered, 'Desktop help icon is centered');
  const html = '<html lang="en"><head><title>Preview controls check</title><style>body{font:18px Arial;color:#222;background:white;margin:24px}button{width:64px;height:44px;border:1px solid #333;background:white}</style></head><body><main><h1>Long page</h1><p>Scroll to the unnamed button.</p><div style="height:1100px" aria-hidden="true"></div><button id="target"></button><p>End of page</p></main></body></html>';
  await page.locator('input[name="html-upload"]').setInputFiles({ name: 'preview-controls.html', mimeType: 'text/html', buffer: Buffer.from(html) });
  await page.locator('.page-caption h2').filter({ hasText: 'Preview controls check' }).waitFor();
  await page.frameLocator('iframe[title="Current page preview"]').locator('button').waitFor();
  const finding = page.locator('.finding').filter({ has: page.locator('.finding-meta', { hasText: 'button-name' }) }).first();
  await finding.locator('.finding-toggle').waitFor();
  await page.getByText('Review up to date', { exact: true }).waitFor();
  const frame = await (await page.locator('iframe[title="Current page preview"]').elementHandle()).contentFrame();
  await frame.evaluate(() => { window.__previewCheckMarker = 'same-frame'; });
  await finding.locator('.finding-toggle').click();
  await frame.waitForFunction(() => document.querySelector('button')?.style.outlineStyle === 'solid');
  check(await frame.evaluate(() => scrollY > 0), 'Opening a finding scrolls the inner page to its target');
  await frame.waitForFunction(() => !document.querySelector('button')?.style.outlineStyle);
  for (let attempt = 0; attempt < 2; attempt++) {
    await finding.getByRole('button', { name: 'Show element', exact: true }).click();
    await frame.waitForFunction(() => document.querySelector('button')?.style.outlineStyle === 'solid');
    check(await frame.evaluate(() => window.__previewCheckMarker === 'same-frame'), 'Repeated Show element highlights without remounting or reauditing');
    await fits();
    await frame.waitForFunction(() => !document.querySelector('button')?.style.outlineStyle);
  }
  await page.getByRole('button', { name: 'Source', exact: true }).click();
  await finding.getByRole('button', { name: 'Show element', exact: true }).click();
  check(await page.getByRole('button', { name: 'Preview', exact: true }).getAttribute('aria-pressed') === 'true', 'Show element returns from Source to Preview');
  await frame.evaluate(() => scrollTo(0, 0));
  await page.locator('iframe[title="Current page preview"]').focus();
  await page.keyboard.press('PageDown');
  await frame.waitForFunction(() => scrollY > 0);
  check(true, 'Keyboard scrolling reaches the page inside the iframe');
  for (const size of [{ width: 1280, height: 720 }, { width: 1512, height: 900 }, { width: 390, height: 844 }]) {
    await page.setViewportSize(size);
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    await fits();
  }
  const menu = page.getByRole('button', { name: 'Open menu', exact: true });
  await menu.click();
  const aligned = await page.locator('#header-actions').evaluate(el => {
    const upload = el.querySelector('.upload-button').getBoundingClientRect(), help = el.querySelector('.icon-button').getBoundingClientRect();
    const icons = [...el.querySelectorAll('.upload-button svg,.icon-button svg')].map(icon => icon.getBoundingClientRect().left);
    return Math.abs(upload.width - help.width) < .5 && Math.abs(upload.x - help.x) < .5 && Math.abs(icons[0] - icons[1]) < .5;
  });
  check(aligned, 'Mobile help action aligns with the other menu rows');
  await page.getByRole('button', { name: 'Close menu', exact: true }).click();
  await page.getByRole('navigation', { name: 'Workspace panel' }).getByRole('button', { name: /^Review/ }).click();
  await finding.getByRole('button', { name: 'Show element', exact: true }).click();
  await frame.waitForFunction(() => document.querySelector('button')?.style.outlineStyle === 'solid');
  check(await page.locator(':focus').textContent() === 'Page', 'Mobile Show element reveals Page and moves focus to its visible control');
  await fits();
  await page.getByRole('button', { name: 'Mobile preview', exact: true }).click();
  await page.getByText('Review up to date', { exact: true }).waitFor();
  const mobileFrame = await (await page.locator('iframe[title="Current page preview"]').elementHandle()).contentFrame();
  check(await mobileFrame.evaluate(() => innerWidth === 390 && innerHeight === 780), 'Fitting preserves the actual audited mobile viewport');
  await fits();
  await page.getByRole('button', { name: 'Source', exact: true }).click();
  await page.getByRole('textbox', { name: 'Page title', exact: true }).fill('Updated preview controls');
  await page.getByRole('button', { name: 'Apply source', exact: true }).click();
  await page.getByText('Review up to date', { exact: true }).waitFor();
  await page.getByRole('button', { name: 'Compare', exact: true }).click();
  await page.frameLocator('iframe[title="Page before the last revision"]').getByRole('heading', { name: 'Long page' }).waitFor();
  await fits();
  await page.setViewportSize({ width: 1512, height: 900 });
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  await fits();
  return checks;
}
