import { build } from "esbuild";
import { fileURLToPath } from "node:url";

/** Run against an already-open local QA page; this never starts a host or calls an API. */
export async function runAuditEngineChecks(page) {
  const root = fileURLToPath(new URL("../", import.meta.url));
  const bundled = await build({
    absWorkingDir: root,
    stdin: { contents: 'export {createFrameHtml,readAuditMessage} from "./app/components/audit-frame.tsx"; export {normalizeDocument,importHtml,exportDocumentHtml} from "./app/lib/document-io.ts"; export {createPreviewAsset,validatePreviewAssets} from "./app/lib/preview-assets.ts"; export {importSavedPage} from "./app/lib/saved-page-import.ts";', resolveDir: root, loader: "ts" },
    bundle: true, write: false, platform: "browser", format: "iife", globalName: "LumenEngineChecks", minify: true,
  });
  await page.evaluate(`${bundled.outputFiles[0].text}\nglobalThis.__lumenChecks = LumenEngineChecks;`);
  const networkAttempts = [];
  const guard = async route => { networkAttempts.push(route.request().url()); await route.abort(); };
  await page.route("**/*lumen-forbidden*", guard);
  try {
    const checks = await page.evaluate(async () => {
      const api = globalThis.__lumenChecks;
      const runtime = await (await fetch("/audit-runtime.js", { cache: "no-cache" })).text();
      const passed = [];
      const assert = (condition, name) => { if (!condition) throw Error(name); passed.push(name); };
      const fixture = {
        title: "", lang: "",
        html: '<main><h1>Example page</h1><button id="icon"></button><label>Subscribe</label><input id="email" type="email"><img id="photo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII="><p class="faint">This paragraph needs readable contrast.</p></main>',
        css: 'body{background:#fff;color:#111;font:16px Arial;padding:24px}button{width:48px;height:48px}img{width:80px;height:80px}.faint{color:#bbb}',
      };
      const frames = [];
      const render = (source, { audit = true, width = 960, height = 720 } = {}) => new Promise((resolve, reject) => {
        const frame = document.createElement("iframe");
        frame.setAttribute("sandbox", "allow-scripts");
        frame.style.cssText = `position:fixed;left:0;top:0;width:${width}px;height:${height}px;border:0;z-index:2147483647;background:white`;
        frame.width = String(width); frame.height = String(height);
        const token = crypto.randomUUID().replace(/-/g, ""), revision = crypto.randomUUID();
        let seenResult = false;
        const cleanup = () => { clearTimeout(timeout); window.removeEventListener("message", listener); };
        const timeout = setTimeout(() => { cleanup(); reject(Error("Audit fixture timed out")); }, 20_000);
        const listener = event => {
          if (event.source !== frame.contentWindow || event.origin !== "null" || event.data?.token !== token) return;
          if (event.data.type === "lumen:ready") frame.contentWindow.postMessage({ type: "lumen:render", token, revision, document: source, audit }, "*");
          if (event.data.type === "lumen:error") { cleanup(); reject(Error("Audit fixture returned an error")); }
          if (event.data.type === "lumen:result") {
            seenResult = true;
            const snapshot = api.readAuditMessage(event.data, token, revision, { width, height });
            if (audit && snapshot) { cleanup(); resolve({ snapshot, frame, token, revision }); }
          }
          if (!audit && event.data.type === "lumen:rendered") setTimeout(() => { cleanup(); resolve({ frame, token, revision, seenResult }); }, 300);
        };
        window.addEventListener("message", listener);
        frame.srcdoc = api.createFrameHtml(runtime, token, window.location.origin);
        frames.push(frame); document.body.append(frame);
      });
      try {
        const before = await render(fixture);
        const ids = new Set(before.snapshot.findings.filter(item => item.kind === "violation").map(item => item.ruleId));
        for (const id of ["button-name", "label", "image-alt", "document-title", "html-has-lang", "color-contrast"]) assert(ids.has(id), `Detects real ${id} finding`);
        let isolated = false;
        try { void before.frame.contentWindow.document; } catch { isolated = true; }
        assert(isolated, "Preview has an opaque origin");
        before.frame.remove();

        const repaired = {
          ...fixture, title: "Newsletter signup", lang: "en",
          html: fixture.html.replace('id="icon"', 'id="icon" aria-label="Open menu"').replace('<label>', '<label for="email">').replace('id="photo"', 'id="photo" alt=""'),
          css: fixture.css.replace("color:#bbb", "color:#333"),
        };
        const after = await render(repaired);
        const remaining = new Set(after.snapshot.findings.filter(item => item.kind === "violation").map(item => item.ruleId));
        assert([...ids].filter(id => ["button-name", "label", "image-alt", "document-title", "html-has-lang", "color-contrast"].includes(id)).every(id => !remaining.has(id)), "Recheck verifies the targeted repairs");
        assert(JSON.stringify(after.snapshot.document) === JSON.stringify(api.normalizeDocument(repaired).document), "Report includes the exact normalized source");
        const message = { type: "lumen:result", token: after.token, snapshot: after.snapshot };
        const vp = after.snapshot.viewport;
        assert(!api.readAuditMessage(message, "0".repeat(32), after.revision, vp), "Rejects a foreign frame token");
        assert(!api.readAuditMessage(message, after.token, "stale-revision", vp), "Rejects a stale revision");
        assert(!api.readAuditMessage(message, after.token, after.revision, { width: 390, height: 780 }), "Rejects a mismatched viewport");
        assert(!api.readAuditMessage(message, after.token, after.revision, vp, fixture), "Rejects a different tested source");
        after.frame.remove();

        const imported = api.importHtml('<!doctype html><html lang="fr"><head><title>Import test</title><style>p{color:navy}</style></head><body><main><h1>Bonjour</h1><p>Texte</p></main></body></html>');
        if (!(imported.document.title === "Import test" && imported.document.lang === "fr" && imported.document.css.includes("color:navy") && imported.document.html.includes("Bonjour"))) throw Error(`Full HTML import mismatch: ${JSON.stringify(imported)}`);
        passed.push("Full HTML import preserves metadata, inline styles, and body");
        globalThis.__lumenAttacked = false;
        const hostile = {
          title: "Hostile fixture", lang: "en",
          html: '<main><h1>Safe content</h1><script>parent.__lumenAttacked=true</script><img src="/lumen-forbidden-image" onerror="parent.__lumenAttacked=true"><iframe src="/lumen-forbidden-frame"></iframe><object data="/lumen-forbidden-object"></object><base href="https://example.invalid/"><meta http-equiv="refresh" content="0;url=/lumen-forbidden-refresh"><a href="/lumen-forbidden-link">Link</a><form action="/lumen-forbidden-form"><input autofocus name="name"><button>Send</button></form></main>',
          css: '@import url("/lumen-forbidden-style");body{background-image:url("/lumen-forbidden-css")}h1{color:black}',
        };
        const normalized = api.normalizeDocument(hostile);
        assert(normalized.removed > 0 && !/<(?:script|iframe|object|meta|base)\b|onerror|autofocus|src="\//i.test(normalized.document.html), "Sanitizer removes executable and external markup");
        const hostileResult = await render(hostile);
        assert(!globalThis.__lumenAttacked, "Submitted script and event handlers cannot execute");
        assert(hostileResult.snapshot.removed > 0, "Audit reports removed unsupported markup");
        hostileResult.frame.remove();

        const escapeSource = { ...repaired, css: 'p:before{content:"</style><script>bad()</script>"}' };
        const exported = api.exportDocumentHtml(escapeSource);
        const parsed = new DOMParser().parseFromString(exported, "text/html");
        assert(parsed.querySelectorAll("script").length === 0 && parsed.querySelectorAll("style").length === 1, "HTML export prevents CSS raw-text breakout");
        assert(parsed.querySelector('meta[http-equiv="Content-Security-Policy"]')?.content.includes("default-src 'none'"), "Export retains a network-denying policy");

        const comparison = await render(repaired, { audit: false });
        assert(!comparison.seenResult, "Comparison preview skips auditing"); comparison.frame.remove();
        const narrow = await render(repaired, { width: 390, height: 780 });
        assert(narrow.snapshot.viewport.width === 390 && narrow.snapshot.viewport.height === 780, "Mobile audit uses the requested actual viewport"); narrow.frame.remove();
        const invalidLang = await render({ ...repaired, lang: "definitely-not-a-language" });
        assert(invalidLang.snapshot.findings.some(item => item.ruleId === "html-lang-valid"), "Invalid document language is checked"); invalidLang.frame.remove();
        const many = await render({ title: "Many controls", lang: "en", html: `<main><h1>Controls</h1>${Array.from({ length: 60 }, (_, index) => `<button id="button-${index}"></button>`).join("")}</main>`, css: "button{width:48px;height:48px}" });
        assert(many.snapshot.findings.length === 50 && many.snapshot.truncated, "Large reports are bounded and marked truncated"); many.frame.remove();
        return passed;
      } finally {
        for (const frame of frames) frame.remove();
        delete globalThis.__lumenAttacked;
      }
    });
    // Exercise genuine keyboard actions in the isolated browsing context.
    await page.evaluate(async () => {
      const api = globalThis.__lumenChecks;
      const runtime = await (await fetch("/audit-runtime.js", { cache: "no-cache" })).text();
      const frame = document.createElement("iframe");
      const token = crypto.randomUUID().replace(/-/g, "");
      const image = await api.createPreviewAsset(Uint8Array.from(atob("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII="), character => character.charCodeAt(0)), "image/png");
      const fontResponse = await fetch("/fonts/InterVariable.woff2");
      if (!fontResponse.ok) throw Error("Local font fixture is unavailable.");
      const font = await api.createPreviewAsset(new Uint8Array(await fontResponse.arrayBuffer()), "font/woff2");
      const assets = api.validatePreviewAssets({ [image.id]: image.dataUrl, [font.id]: font.dataUrl });
      const imported = api.importHtml(`<html class="theme-root" data-theme="saved" lang="fr" style="--copy-color:rgb(20,30,40)"><head><title>Saved roots</title><style>@font-face{font-family:SavedFixture;src:url("${font.reference}") format("woff2")}body{font:16px SavedFixture,sans-serif;background:#fff}html.theme-root[data-theme="saved"] body.body-root{color:var(--copy-color)}img{width:20px;height:20px}</style><style media="print">body{color:red}</style></head><body class="body-root" data-layout="saved"><main><h1>Keyboard</h1><img id="asset-image" src="${image.reference}"><a href="/lumen-forbidden-keyboard-link">Go somewhere</a><form action="/lumen-forbidden-keyboard-form"><label for="entry">Entry</label><input id="entry" name="entry"><button id="send" style="outline-color:navy;color:black">Send</button></form></main></body></html>`);
      if (!(imported.document.html.startsWith('<html class="theme-root"') && imported.document.html.includes('body class="body-root"') && !/<html[^>]* lang=/.test(imported.document.html) && imported.document.lang === "fr")) throw Error("Root attributes or canonical language were lost during import.");
      if (JSON.stringify(imported.document).includes("base64,")) throw Error("Imported canonical source contains asset bytes.");
      const exported = new DOMParser().parseFromString(api.exportDocumentHtml(imported.document, assets), "text/html");
      if (!(exported.documentElement.className === "theme-root" && exported.body.className === "body-root" && exported.documentElement.lang === "fr" && exported.querySelector("#asset-image")?.getAttribute("src") === image.dataUrl && exported.querySelector("style")?.textContent.includes(font.dataUrl))) throw Error("Export did not preserve roots and embed the referenced assets.");
      const largeImageBytes = new Uint8Array(1_600_000);
      largeImageBytes.set(Uint8Array.from(atob(image.dataUrl.split(",")[1]), character => character.charCodeAt(0)));
      const largeImage = await api.createPreviewAsset(largeImageBytes, "image/png");
      const largeSource = { ...imported.document, html: imported.document.html.replace(image.reference, largeImage.reference) };
      const largeExport = api.exportDocumentHtml(largeSource, { [largeImage.id]: largeImage.dataUrl, [font.id]: font.dataUrl });
      if (new TextEncoder().encode(largeExport).byteLength <= 2_000_000) throw Error("Large-export regression fixture is too small.");
      const roundTrip = await api.importSavedPage(new File([largeExport], "Exported page.html", { type: "text/html" }));
      if (!(roundTrip.document.html.includes(largeImage.reference) && roundTrip.document.css.includes(font.reference) && Object.keys(roundTrip.assets).length === 2 && !JSON.stringify(roundTrip.document).includes("base64,"))) throw Error("An exported page above 2 MB did not reimport with opaque references.");
      let boundedExport = false;
      try {
        api.exportDocumentHtml({ title: "Repeated assets", lang: "en", html: `<main>${`<img src="${largeImage.reference}">`.repeat(7)}</main>`, css: `.backdrop{background:url("${largeImage.reference}")}` }, { [largeImage.id]: largeImage.dataUrl });
      } catch (error) { boundedExport = error instanceof Error && error.message.startsWith("This HTML export exceeds"); }
      if (!boundedExport) throw Error("Oversized final HTML export was not bounded by the import capacity.");
      frame.dataset.lumenEngineKeyboard = "true"; frame.dataset.token = token;
      frame.setAttribute("sandbox", "allow-scripts");
      frame.width = "960"; frame.height = "720";
      frame.style.cssText = "position:fixed;left:0;top:0;width:960px;height:720px;z-index:2147483647;background:white;border:0";
      await new Promise((resolve, reject) => {
        const timer = setTimeout(() => { window.removeEventListener("message", listener); reject(Error("Keyboard fixture timed out")); }, 10_000);
        const listener = event => {
          if (event.source !== frame.contentWindow || event.origin !== "null" || event.data?.token !== token) return;
          if (event.data.type === "lumen:ready") frame.contentWindow.postMessage({ type: "lumen:render", token, revision: "keyboard-check", audit: true, document: imported.document, assets }, "*");
          if (event.data.type === "lumen:result") {
            clearTimeout(timer); window.removeEventListener("message", listener);
            const snapshot = api.readAuditMessage(event.data, token, "keyboard-check", { width: 960, height: 720 }, imported.document);
            if (!snapshot || !snapshot.findings.some(finding => finding.ruleId === "image-alt" && finding.html.includes(image.reference)) || JSON.stringify(snapshot).includes("base64,")) reject(Error("Audit evidence leaked asset bytes or lost the canonical image reference."));
            else resolve();
          }
          if (event.data.type === "lumen:error") { clearTimeout(timer); window.removeEventListener("message", listener); reject(Error("Asset preview returned an error.")); }
        };
        window.addEventListener("message", listener);
        frame.srcdoc = api.createFrameHtml(runtime, token, window.location.origin);
        document.body.append(frame);
      });
    });
    try {
      const frame = page.frameLocator('iframe[data-lumen-engine-keyboard="true"]');
      const rendered = await frame.locator("body").evaluate(element => ({
        color: getComputedStyle(element).color, bodyClass: element.className,
        htmlClass: document.documentElement.className, theme: document.documentElement.dataset.theme,
        loadedImage: document.querySelector("#asset-image").naturalWidth,
        loadedFont: document.fonts.check("16px SavedFixture"),
      }));
      if (rendered.htmlClass !== "theme-root" || rendered.bodyClass !== "body-root" || rendered.theme !== "saved" || rendered.color !== "rgb(20, 30, 40)") throw Error(`Root styling/media were changed: ${JSON.stringify(rendered)}`);
      if (rendered.loadedImage !== 1 || !rendered.loadedFont) throw Error("Embedded preview image/font did not load before the audit.");
      checks.push("Actual html/body attributes and stylesheet media survive import and rendering");
      checks.push("Local images and fonts load before the accessibility audit");
      checks.push("Canonical source and finding evidence contain references rather than asset bytes");
      checks.push("HTML export preserves true root attributes and embeds referenced assets");
      checks.push("Exports above 2 MB reimport with bounded assets and canonical opaque references");
      checks.push("Final exported HTML cannot exceed the raw import byte limit");
      await frame.getByRole("link").press("Enter");
      await frame.getByLabel("Entry").fill("example");
      await frame.getByLabel("Entry").press("Enter");
      await frame.getByRole("button", { name: "Send" }).click();
      if (!await frame.getByRole("heading", { name: "Keyboard" }).isVisible()) throw Error("Preview navigated after keyboard or form actions.");
      checks.push("Link keyboard activation and form submission cannot navigate");
      const originalStyle = await frame.locator("#send").getAttribute("style");
      await page.evaluate(() => {
        const frame = document.querySelector('iframe[data-lumen-engine-keyboard="true"]');
        frame.contentWindow.postMessage({ type: "lumen:highlight", token: frame.dataset.token, revision: "keyboard-check", selector: "#send" }, "*");
      });
      await frame.locator("#send").evaluate(element => new Promise(resolve => {
        const start = Date.now();
        const poll = () => {
          if (element.style.getPropertyPriority("outline") === "important") resolve(true);
          else if (Date.now() - start > 1000) resolve(false);
          else setTimeout(poll, 20);
        }; poll();
      })).then(highlighted => { if (!highlighted) throw Error("Finding highlight did not appear."); });
      await frame.locator("#send").evaluate(element => new Promise(resolve => setTimeout(resolve, 1900)));
      if (await frame.locator("#send").getAttribute("style") !== originalStyle) throw Error("Highlight changed the assessed inline styles.");
      checks.push("Transient finding highlight restores exact original inline styles");
    } finally {
      await page.evaluate(() => document.querySelector('iframe[data-lumen-engine-keyboard="true"]')?.remove());
    }
    if (networkAttempts.length) throw Error(`Preview attempted ${networkAttempts.length} blocked network request(s).`);
    return [...checks, "No untrusted markup or CSS issued a network request"];
  } finally {
    await page.unroute("**/*lumen-forbidden*", guard);
    await page.evaluate(() => { delete globalThis.__lumenChecks; });
  }
}
