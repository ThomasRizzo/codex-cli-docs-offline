import { build } from "esbuild";
import { mkdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
await mkdir(new URL("../public", import.meta.url), { recursive: true });
await build({
  absWorkingDir: root,
  entryPoints: ["app/lib/frame-bootstrap.ts"],
  outfile: "public/audit-runtime.js",
  bundle: true,
  platform: "browser",
  format: "iife",
  target: ["es2020"],
  minify: true,
  legalComments: "inline",
  sourcemap: false,
});
console.log("Built the local accessibility audit runtime.");
