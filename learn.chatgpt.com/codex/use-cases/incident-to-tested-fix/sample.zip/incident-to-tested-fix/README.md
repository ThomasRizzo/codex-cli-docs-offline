# Investigate an incident and test a fix

Reproduce a synthetic duplicate-order defect and test a transaction fix with real PostgreSQL connections. The sample also demonstrates the rollout gate for a legacy committed order that has no receipt and still has a pending retry.

## Run the fixture

Use Docker with Compose and run the commands sequentially from this directory. The images pin Node.js 24.19.0 and PostgreSQL 17.6 by digest. The npm lock pins `pg` 8.23.1 and its dependencies. Installation needs registry access; subsequent tests use only the disposable local database.

```bash
docker compose -p codex-incident-rehearsal up -d --wait postgres
docker compose -p codex-incident-rehearsal run --rm runner node main.mjs baseline
docker compose -p codex-incident-rehearsal run --rm runner node main.mjs regression
docker compose -p codex-incident-rehearsal run --rm runner
docker compose -p codex-incident-rehearsal down --volumes
```

Use `docker-compose` instead if your installation exposes that command. The baseline intentionally exits with code `1`; do not chain the commands with `&&`. It observes two orders and one receipt, but the assertion requires one of each. The corrected regression and full suite must exit with code `0`.

The database uses public synthetic credentials, SCRAM host authentication, an in-memory data volume, and loopback port `55432`. The runner shares only that database container's network.

Before mutating its schema, the program checks the database name, role, explicit fixture marker, and pinned PostgreSQL version. Do not change the connection to an application or production database. Tests reset `incident_rehearsal` between cases; this fixture is not suitable for parallel suite runs.

## Inspect the evidence

Read the fictional packet under `incidents/INC-DEMO-014/`, then inspect both handler functions in `main.mjs`. Baseline and fixed modes select named implementations in the same file. This is a seeded reproduction, not a historical application revision or an executed Codex task. Keep the final source hash with your logs.

The program emits structured records for commits, rollbacks, committed counts, and acknowledgment status/body. A successful acknowledgment is exactly status `200` with body `{"received":true}`. When an exception is injected, the handler does not return an acknowledgment. A separate observer connection reads committed state.

The concurrent tests use independent database backend IDs and a latch that holds the receipt claimant. A bounded loop checks `pg_stat_activity` and `pg_blocking_pids` until the competitor is actually waiting on the winner's transaction lock. Only then does the test release the claimant to commit or roll back. The tests use neither timing sleeps nor mocks of PostgreSQL uniqueness.

## Hold legacy retries before resuming

Run orphan identification only after ingestion is paused and all old consumers have drained. Existing committed orders without matching receipts must be held before retained deliveries resume. The fixture's durable `delivery_holds` table models an existing queue or quarantine mechanism; it is not a proposed application migration.

The seeded legacy test shows that a held retry returns no success and creates no additional order or receipt.

Reconciliation requires exactly one committed order with trusted immutable event identity and a matching canonical payload fingerprint. It writes the matching receipt without another order, then releases the hold. A subsequent retry receives the duplicate acknowledgment with one order and one receipt.

Missing fingerprints or conflicting payload evidence keep the key held. Do not invent a fingerprint from an unverified retry, delete receipts, or replay an unresolved legacy event. If historical records cannot identify every affected key, keep the affected delivery window paused or quarantined for the owner's reconciliation decision.

## Limits

The before-commit and after-commit hooks inject application exceptions. They prove rollback and retry behavior for those boundaries; they do not reproduce an abrupt host death, a lost database connection during `COMMIT`, or an unknown commit result. Mark the unknown-commit transport criterion as **not run**.

External email, payments, provider acknowledgment delivery, production load, retention settings, mixed-version deployment, and Cloud environment execution are outside this local run.

To rehearse in Codex Cloud, first publish an environment that supplies the same isolated PostgreSQL engine and dependencies, then validate a fresh task. Do not assume Docker or the local Compose network is available there. Keep unavailable environment prerequisites explicit in the handoff.
