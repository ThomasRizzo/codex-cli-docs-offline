# Synthetic incident investigation

The fictional packet proposes that retries explain duplicate orders. Source inspection and the isolated reproduction support a narrower cause: the seeded legacy handler commits an order before writing its processing receipt. A failure in that gap preserves the order but leaves the event unclaimed. The stable-key retry writes another order.

Read the `baseline` function in `main.mjs` and the packet under `incidents/INC-DEMO-014/`. The baseline command failed the required one-order assertion with two orders and one receipt. The corrected regression rolled back both writes on the injected pre-commit failure and processed the retry once. See `test-evidence.md` and the raw logs for exact tested source and results.

The corrected handler claims a receipt with PostgreSQL's unique constraint and writes the order on the same connection in the same transaction. Controlled competing connections demonstrate that the duplicate waits for the claimant. A committed claimant produces a verified duplicate acknowledgment; a rolled-back claimant allows the competitor to process the event.

Handling existing orders left by old workers requires a separate state transition. Before retries resume, the fixture identifies and holds legacy event keys with orders but no receipts. It reconciles only a single trusted order with matching identity and canonical payload, without repeating the business mutation. Missing or conflicting evidence keeps the retry held.

The experiment establishes synthetic database behavior under injected application exceptions and real transaction contention. It does not establish a historical customer root cause, an unknown commit outcome after transport loss, external-effect idempotency, production recovery, or Codex Cloud environment readiness.
