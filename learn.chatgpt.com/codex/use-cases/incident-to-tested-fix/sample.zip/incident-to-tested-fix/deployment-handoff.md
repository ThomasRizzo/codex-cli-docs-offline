# Deployment handoff template

This is a review template, not an authorization to deploy. The runnable fixture exercises synthetic state only. Record the application revision, deployment owner, approved runbook, observation window, and stop thresholds before an application rollout.

## Pre-resume gate

1. Confirm the provider's event identity, acknowledgment, retry, and retention contracts. Verify the actual unique receipt constraint, payload policy, isolation level, and external-effect boundary.
2. Pause ingestion using the approved lossless retention procedure. Drain every old consumer and prevent old versions from restarting. A mixed-version canary needs its own tested strategy.
3. Identify legacy committed business records without matching receipts. If available records cannot establish complete event keys, keep the affected delivery window paused or quarantined for owner review.
4. Hold each affected event key through the existing durable queue or quarantine mechanism. Verify every consumer enforces the hold across restarts. Deploy the corrected handler to all consumers.
5. Reconcile only from trusted immutable provider/account/event identity, canonical payload evidence, and a single committed business record. Record the matching receipt without another business mutation, then release that key's hold. Keep keys held for a separate remediation decision when evidence is missing or conflicting, or when multiple records exist.
6. Rehearse the seeded pending retry: while held, it produces no additional order or success acknowledgment; after trusted reconciliation, its duplicate acknowledgment leaves one order and one receipt. Rehearse an unresolved key that stays held without a fabricated receipt.
7. Resume only reconciled keys or unaffected deliveries when the remaining holds stay enforced. Observe the agreed duplicate-order, acknowledgment/error, latency, lock-wait, and retry-backlog thresholds. Preserve receipts across the entire replay window.

## Rollback

Name the containment step, safe revision, and owner who decides when processing resumes. Reverting to the legacy handler reopens the duplicate-order defect. Preserve receipts and unresolved holds; deleting receipts to unblock retries is unsafe. Review historical duplicate orders through a separate reconciliation/remediation process.

## Remaining verification

Exercise unknown commit results after actual connection loss, provider response delivery, production retention, external effects, restart persistence of the real hold mechanism, and the selected rollout sequence in the application's approved staging environment. A passing local fixture is evidence for code review, not evidence of production health.
