# Synthetic incident INC-DEMO-014

The `order.created` handler receives a retry for one stable provider/account/event key. The fictional packet describes two committed orders between 12:03 and 12:05 UTC on September 22, 2026. Expected behavior is one business order and one processing receipt for that key, including repeated and concurrent deliveries.

Read `release.json`, `logs.ndjson`, and `order-created.sanitized.json`. All identifiers, timestamps, and observations are synthetic. The release SHA is not a Git commit in this repository. The executable reproduction is the `baseline` function in `main.mjs`; record its source hash and mode when testing.

The affected implementation commits the order before it records the receipt. A failure between those writes leaves a committed order without a receipt. The retry then creates another order. Two deliveries alone do not establish a retry storm.

This investigation assumes the service has been stabilized. The fixture contains no customer data, monitoring connection, external charge, email, or production database. Its canonical payload is an explicit ordered tuple of type, external order ID, and amount in cents. Event identity is scoped by provider, account ID, and event ID.

Prepare a focused fix and observed red/green evidence. Include a pre-resume gate for orders left by the old handler: identify the keys after old consumers drain, hold pending retries, and reconcile only from trusted identity, payload, and committed-order evidence. Unresolved keys stay quarantined for owner review.
