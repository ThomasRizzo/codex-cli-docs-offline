COMMENT ON DATABASE codex_incident_test IS 'codex-synthetic-incident-fixture-v1';
