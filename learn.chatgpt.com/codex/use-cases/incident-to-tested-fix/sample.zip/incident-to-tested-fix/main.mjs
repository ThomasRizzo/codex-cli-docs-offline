import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { setImmediate as yieldTurn } from "node:timers/promises";
import { after, before, beforeEach, test } from "node:test";
import pg from "pg";

// These public credentials are exclusively for the disposable synthetic fixture.
// Do not replace this configuration with a production host or application DB.
const connection = {
  host: "127.0.0.1",
  port: 55432,
  user: "codex_incident_test",
  password: "synthetic-incident-fixture-only",
  database: "codex_incident_test",
  connectionTimeoutMillis: 5000,
  query_timeout: 10000,
};
const mode = process.argv[2] ?? "fixed";
assert.ok(["baseline", "regression", "fixed"].includes(mode));
const observer = new pg.Client({
  ...connection,
  application_name: "fixture-observer",
});
const clients = new Set();
const backendIds = new WeakMap();
const event = JSON.parse(
  readFileSync(
    new URL(
      "./incidents/INC-DEMO-014/order-created.sanitized.json",
      import.meta.url
    ),
    "utf8"
  )
);
const acknowledgment = { status: 200, body: { received: true } };

// The fixture's trusted payload has this explicit canonical field order.
// A real integration must use its provider's verified identity/canonicalization.
function fingerprint(input) {
  return createHash("sha256")
    .update(
      JSON.stringify([
        input.payload.type,
        input.payload.orderId,
        input.payload.amountCents,
      ])
    )
    .digest("hex");
}

function key(input) {
  return [input.provider, input.accountId, input.eventId];
}

function trace(action, client, input, detail = {}) {
  console.log(
    JSON.stringify({
      action,
      pid: backendIds.get(client),
      key: key(input),
      ...detail,
    })
  );
}

function failAt(point) {
  return async (boundary) => {
    if (boundary === point) throw new Error(`injected:${point}`);
  };
}

async function connect(name) {
  const client = new pg.Client({ ...connection, application_name: name });
  await client.connect();
  clients.add(client);
  const backend = await client.query("SELECT pg_backend_pid() AS pid");
  backendIds.set(client, backend.rows[0].pid);
  await client.query("SET search_path TO incident_rehearsal, public");
  await client.query("SET statement_timeout = '8s'");
  return client;
}

async function counts(input = event) {
  const result = await observer.query(
    `SELECT
       (SELECT count(*)::integer FROM orders WHERE provider=$1 AND account_id=$2 AND event_id=$3) AS orders,
       (SELECT count(*)::integer FROM event_receipts WHERE provider=$1 AND account_id=$2 AND event_id=$3) AS receipts`,
    key(input)
  );
  trace("committed-state", observer, input, result.rows[0]);
  return result.rows[0];
}

async function assertCounts(orders, receipts, input = event) {
  assert.deepEqual(await counts(input), { orders, receipts });
}

async function writeOrder(client, input) {
  await client.query(
    "INSERT INTO orders(provider, account_id, event_id, payload_fingerprint) VALUES ($1,$2,$3,$4)",
    [...key(input), fingerprint(input)]
  );
  trace("order-written", client, input);
}

async function checkReceipt(client, input) {
  const result = await client.query(
    "SELECT payload_fingerprint FROM event_receipts WHERE provider=$1 AND account_id=$2 AND event_id=$3",
    key(input)
  );
  if (result.rowCount !== 1)
    throw new Error("missing-receipt-after-skipped-claim");
  if (result.rows[0].payload_fingerprint !== fingerprint(input))
    throw new Error("payload-conflict");
}

// A deliberately defective legacy handler: the first commit survives its failure.
async function baseline(client, input, hook = async (_boundary) => {}) {
  const existing = await client.query(
    "SELECT 1 FROM event_receipts WHERE provider=$1 AND account_id=$2 AND event_id=$3",
    key(input)
  );
  if (existing.rowCount) {
    await checkReceipt(client, input);
    return acknowledgment;
  }
  await client.query("BEGIN ISOLATION LEVEL READ COMMITTED");
  await writeOrder(client, input);
  await client.query("COMMIT");
  trace("legacy-order-committed-without-receipt", client, input);
  await hook("afterOrder");
  await client.query(
    "INSERT INTO event_receipts(provider, account_id, event_id, payload_fingerprint) VALUES ($1,$2,$3,$4)",
    [...key(input), fingerprint(input)]
  );
  trace("legacy-receipt-committed", client, input);
  return acknowledgment;
}

// The durable hold represents an existing operator-controlled queue quarantine.
// It is fixture infrastructure, not a proposed migration or an in-memory lock.
async function assertNotHeld(client, input) {
  const hold = await client.query(
    "SELECT 1 FROM delivery_holds WHERE provider=$1 AND account_id=$2 AND event_id=$3",
    key(input)
  );
  if (hold.rowCount) {
    trace("legacy-retry-held-no-ack", client, input);
    throw new Error("legacy-retry-held");
  }
}

// docs:start node-example
async function fixed(client, input, hook = async (_boundary) => {}) {
  await assertNotHeld(client, input);
  await hook("beforeClaim");
  await client.query("BEGIN ISOLATION LEVEL READ COMMITTED");
  let committed = false;
  try {
    const claimed = await client.query(
      `INSERT INTO event_receipts(provider, account_id, event_id, payload_fingerprint)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (provider, account_id, event_id) DO NOTHING RETURNING event_id`,
      [...key(input), fingerprint(input)]
    );
    trace("receipt-claim-result", client, input, {
      inserted: claimed.rowCount === 1,
    });
    if (claimed.rowCount === 1) {
      await hook("afterClaim");
      await writeOrder(client, input);
      await hook("afterOrder");
    } else {
      // A new READ COMMITTED statement sees the winner after its commit.
      await checkReceipt(client, input);
    }
    await client.query("COMMIT");
    committed = true;
    trace("transaction-committed", client, input);
    await hook("afterCommit");
    trace("acknowledged", client, input, acknowledgment);
    return acknowledgment;
  } catch (error) {
    if (!committed) {
      await client.query("ROLLBACK");
      trace("transaction-rolled-back-no-ack", client, input);
    } else {
      trace("committed-response-lost-no-ack", client, input);
    }
    throw error;
  }
}
// docs:end node-example

// Run only while ingestion is paused and all old consumers have drained.
async function identifyAndHoldLegacyOrphans(client) {
  const result = await client.query(
    `INSERT INTO delivery_holds(provider, account_id, event_id)
     SELECT DISTINCT o.provider,o.account_id,o.event_id FROM orders o
     WHERE NOT EXISTS (SELECT 1 FROM event_receipts r
       WHERE r.provider=o.provider AND r.account_id=o.account_id AND r.event_id=o.event_id)
     ON CONFLICT DO NOTHING RETURNING event_id`
  );
  console.log(
    JSON.stringify({ action: "pre-resume-orphans-held", keys: result.rowCount })
  );
  return result.rowCount;
}

// This synthetic ledger retains trusted immutable identity and canonical payload.
// If real legacy evidence is missing or conflicting, keep the delivery quarantined.
async function reconcileHeldOrphan(client, input) {
  await client.query("BEGIN ISOLATION LEVEL READ COMMITTED");
  try {
    const hold = await client.query(
      "SELECT 1 FROM delivery_holds WHERE provider=$1 AND account_id=$2 AND event_id=$3 FOR UPDATE",
      key(input)
    );
    assert.equal(hold.rowCount, 1, "reconciliation requires an existing hold");
    const orders = await client.query(
      "SELECT payload_fingerprint FROM orders WHERE provider=$1 AND account_id=$2 AND event_id=$3 FOR UPDATE",
      key(input)
    );
    if (
      orders.rowCount !== 1 ||
      orders.rows[0].payload_fingerprint !== fingerprint(input)
    ) {
      throw new Error("legacy-evidence-insufficient-keep-held");
    }
    await client.query(
      "INSERT INTO event_receipts(provider, account_id, event_id, payload_fingerprint) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING",
      [...key(input), fingerprint(input)]
    );
    await checkReceipt(client, input);
    await client.query(
      "DELETE FROM delivery_holds WHERE provider=$1 AND account_id=$2 AND event_id=$3",
      key(input)
    );
    await client.query("COMMIT");
    trace("trusted-orphan-reconciled-hold-released", client, input);
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  }
}

function latch() {
  let release = () => {};
  const promise = new Promise((resolve) => {
    release = () => resolve(undefined);
  });
  return { promise, release };
}

async function waitForDatabaseContention(waiter, winner) {
  const deadline = performance.now() + 5000;
  while (performance.now() < deadline) {
    const result = await observer.query(
      `SELECT wait_event_type, wait_event, pg_blocking_pids(pid) AS blockers
       FROM pg_stat_activity WHERE pid=$1`,
      [backendIds.get(waiter)]
    );
    const state = result.rows[0];
    if (
      state?.wait_event_type === "Lock" &&
      state.blockers.includes(backendIds.get(winner))
    ) {
      trace("real-database-contention", waiter, event, {
        winner: backendIds.get(winner),
        ...state,
      });
      return;
    }
    await yieldTurn();
  }
  throw new Error("competitor-never-observed-blocking-on-winner");
}

before(async () => {
  await observer.connect();
  const backend = await observer.query("SELECT pg_backend_pid() AS pid");
  backendIds.set(observer, backend.rows[0].pid);
  const identity = await observer.query(
    `SELECT current_database() AS database, current_user AS username, version(),
       shobj_description(oid,'pg_database') AS marker FROM pg_database WHERE datname=current_database()`
  );
  assert.equal(identity.rows[0].database, "codex_incident_test");
  assert.equal(identity.rows[0].username, "codex_incident_test");
  assert.equal(
    identity.rows[0].marker,
    "codex-synthetic-incident-fixture-v1",
    "refuse to mutate an unmarked database"
  );
  const pgVersion = await observer.query("SHOW server_version");
  assert.equal(
    pgVersion.rows[0].server_version,
    "17.6 (Debian 17.6-2.pgdg12+1)"
  );
  console.log(
    JSON.stringify({
      action: "fixture-environment",
      node: process.version,
      pg: pgVersion.rows[0].server_version,
      mode,
    })
  );
  await observer.query("DROP SCHEMA IF EXISTS incident_rehearsal CASCADE");
  await observer.query("CREATE SCHEMA incident_rehearsal");
  await observer.query("SET search_path TO incident_rehearsal, public");
  await observer.query(`
    CREATE TABLE event_receipts (
      provider text NOT NULL, account_id text NOT NULL, event_id text NOT NULL,
      payload_fingerprint text NOT NULL,
      CONSTRAINT event_receipts_identity UNIQUE(provider,account_id,event_id) NOT DEFERRABLE
    );
    CREATE TABLE orders (
      id bigserial PRIMARY KEY, provider text NOT NULL, account_id text NOT NULL,
      event_id text NOT NULL, payload_fingerprint text
    );
    CREATE TABLE delivery_holds (
      provider text NOT NULL, account_id text NOT NULL, event_id text NOT NULL,
      PRIMARY KEY(provider,account_id,event_id)
    );
  `);
  const schema = await observer.query(
    "SELECT conname, condeferrable, pg_get_constraintdef(oid) AS definition FROM pg_constraint WHERE conname='event_receipts_identity'"
  );
  console.log(JSON.stringify({ action: "receipt-schema", ...schema.rows[0] }));
});

beforeEach(async () => {
  await observer.query(
    "TRUNCATE orders,event_receipts,delivery_holds RESTART IDENTITY"
  );
});

after(async () => {
  await Promise.allSettled([...clients].map((client) => client.end()));
  await observer.end();
});

test(
  "retry after the order boundary leaves exactly one order and one receipt",
  { timeout: 15000 },
  async () => {
    const client = await connect("regression");
    const handler = mode === "baseline" ? baseline : fixed;
    await assert.rejects(
      handler(client, event, failAt("afterOrder")),
      /injected:afterOrder/
    );
    await assertCounts(mode === "baseline" ? 1 : 0, 0);
    assert.deepEqual(await handler(client, event), acknowledgment);
    await assertCounts(1, 1);
  }
);

if (mode === "fixed") {
  test("first delivery and committed duplicate return the exact acknowledgment", async () => {
    const client = await connect("first-and-duplicate");
    assert.deepEqual(await fixed(client, event), acknowledgment);
    assert.deepEqual(await fixed(client, event), acknowledgment);
    await assertCounts(1, 1);
  });

  for (const boundary of ["beforeClaim", "afterClaim", "afterOrder"]) {
    test(`failure ${boundary} rolls back and remains retryable`, async () => {
      const client = await connect(`failure-${boundary}`);
      await assert.rejects(
        fixed(client, event, failAt(boundary)),
        new RegExp(`injected:${boundary}`)
      );
      await assertCounts(0, 0);
      assert.deepEqual(await fixed(client, event), acknowledgment);
      await assertCounts(1, 1);
    });
  }

  test("lost acknowledgment after commit does not duplicate the order", async () => {
    const client = await connect("lost-ack");
    await assert.rejects(
      fixed(client, event, failAt("afterCommit")),
      /injected:afterCommit/
    );
    await assertCounts(1, 1);
    assert.deepEqual(await fixed(client, event), acknowledgment);
    await assertCounts(1, 1);
  });

  for (const outcome of ["commit", "rollback"]) {
    test(
      `real overlapping duplicate contention: winner ${outcome}`,
      { timeout: 15000 },
      async (context) => {
        const winner = await connect(`winner-${outcome}`);
        const waiter = await connect(`waiter-${outcome}`);
        assert.notEqual(backendIds.get(winner), backendIds.get(waiter));
        const claimed = latch();
        const release = latch();
        context.after(() => release.release());
        const winnerResult = fixed(winner, event, async (boundary) => {
          if (boundary !== "afterClaim") return;
          claimed.release();
          await release.promise;
          if (outcome === "rollback")
            throw new Error("injected:winner-rollback");
        }).then(
          (value) => ({ value, error: null }),
          (error) => ({ value: null, error })
        );
        let waiterResult;
        try {
          await claimed.promise;
          await assertCounts(0, 0);
          waiterResult = fixed(waiter, event).then(
            (value) => ({ value, error: null }),
            (error) => ({ value: null, error })
          );
          await waitForDatabaseContention(waiter, winner);
        } finally {
          release.release();
          const first = await winnerResult;
          const second = await waiterResult;
          if (outcome === "rollback")
            assert.match(first.error?.message ?? "", /winner-rollback/);
          else assert.deepEqual(first.value, acknowledgment);
          assert.deepEqual(second?.value, acknowledgment);
        }
        await assertCounts(1, 1);
      }
    );
  }

  test("event, account, and provider scope remain independent; conflicting payload is rejected", async () => {
    const client = await connect("identity");
    const inputs = [
      event,
      { ...event, eventId: "evt_demo_043" },
      { ...event, accountId: "acct_demo_02" },
      { ...event, provider: "synthetic-other" },
    ];
    for (const input of inputs) {
      assert.deepEqual(await fixed(client, input), acknowledgment);
      await assertCounts(1, 1, input);
    }
    await assert.rejects(
      fixed(client, {
        ...event,
        payload: { ...event.payload, amountCents: 9999 },
      }),
      /payload-conflict/
    );
    await assertCounts(1, 1);
  });

  test("legacy orphan is held before retry and reconciled only from trusted evidence", async () => {
    const client = await connect("legacy-orphan");
    await writeOrder(client, event); // Autocommit models the old committed order.
    await assertCounts(1, 0);
    assert.equal(await identifyAndHoldLegacyOrphans(client), 1);
    await assert.rejects(fixed(client, event), /legacy-retry-held/);
    await assertCounts(1, 0);
    await assert.rejects(
      reconcileHeldOrphan(client, {
        ...event,
        payload: { ...event.payload, amountCents: 9999 },
      }),
      /evidence-insufficient/
    );
    await assert.rejects(fixed(client, event), /legacy-retry-held/);
    await reconcileHeldOrphan(client, event);
    assert.deepEqual(await fixed(client, event), acknowledgment);
    await assertCounts(1, 1);
  });

  test("missing legacy payload evidence stays quarantined without a fabricated receipt", async () => {
    const client = await connect("legacy-missing-evidence");
    await client.query(
      "INSERT INTO orders(provider,account_id,event_id) VALUES ($1,$2,$3)",
      key(event)
    );
    assert.equal(await identifyAndHoldLegacyOrphans(client), 1);
    await assert.rejects(
      reconcileHeldOrphan(client, event),
      /evidence-insufficient/
    );
    await assert.rejects(fixed(client, event), /legacy-retry-held/);
    await assertCounts(1, 0);
  });
}
