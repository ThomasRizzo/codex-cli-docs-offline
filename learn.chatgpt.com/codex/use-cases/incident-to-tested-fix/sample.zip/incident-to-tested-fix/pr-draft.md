# Draft application PR description

The webhook handler commits an order before recording its receipt. A worker failure between those writes leaves the event unclaimed, so its retry can create another order. Claim the receipt and write the order on one PostgreSQL connection in one transaction; verify duplicate payload identity before acknowledging a skipped claim.

The synthetic regression fails on the seeded legacy handler with two orders, then passes on the corrected handler. Eleven isolated PostgreSQL checks cover pre-commit rollback, the post-commit response boundary, independent-connection contention for commit and rollback, event-key scope, payload conflicts, and legacy-orphan quarantine/reconciliation.

Before retained deliveries resume, hold legacy keys with existing orders but no receipts. Reconcile only from trusted event identity, canonical payload, and committed-order evidence; keep unresolved keys quarantined. Actual database connection loss during `COMMIT`, provider acknowledgment delivery, external effects, Cloud execution, and the production rollout remain environment-specific verification work. See `test-evidence.md` and `deployment-handoff.md`.
