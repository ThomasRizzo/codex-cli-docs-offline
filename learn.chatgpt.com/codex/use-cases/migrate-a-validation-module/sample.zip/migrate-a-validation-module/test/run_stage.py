"""Run the identical frozen HTTP suite in one stage's interpreter."""

import hashlib
import importlib.util
import json
import platform
import sys
from importlib.metadata import version
from pathlib import Path

from fastapi.testclient import TestClient
import pydantic

ROOT = Path(__file__).resolve().parent.parent


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    stage = sys.argv[1]
    destination = Path(sys.argv[2])
    app_path = ROOT / "support" / stage / "app.py"
    spec = importlib.util.spec_from_file_location("stage_application", app_path)
    application = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(application)
    fixtures_path = ROOT / "test" / "http-cases.json"
    fixtures = json.loads(fixtures_path.read_text())
    observations = []
    with TestClient(application.app, raise_server_exceptions=True) as client:
        for case in fixtures:
            request = {
                key: case[key] for key in ("json", "content", "headers") if key in case
            }
            response = client.post(case.get("path", "/orders"), **request)
            observed = {
                "name": case["name"],
                "status": response.status_code,
                "headers": {"content-type": response.headers["content-type"]},
                "response": response.json(),
            }
            expected = {
                "name": case["name"],
                "status": case["status"],
                "headers": {"content-type": "application/json"},
                "response": case["response"],
            }
            assert observed == expected, (stage, observed, expected)
            observations.append(observed)
        response = client.get("/openapi.json")
        assert response.status_code == 200
        assert response.headers["content-type"] == "application/json"
        schema = response.json()
        expected_schema = json.loads(
            (ROOT / "test" / "expected-openapi.json").read_text()
        )
        assert schema == expected_schema, "Public OpenAPI contract changed"
    direct = application.serialize_order({"order_id": "ord_123"})
    assert direct == {"order_id": "ord_123", "customer_note": None}
    assert type(direct["order_id"]) is str
    if stage != "legacy":
        import pydantic.v1

        bundled_v1 = pydantic.v1.VERSION
    else:
        bundled_v1 = None
    report = {
        "stage": stage,
        "python": platform.python_version(),
        "fastapi": version("fastapi"),
        "pydantic": version("pydantic"),
        "bundled_v1": bundled_v1,
        "http_cases": len(observations),
        "fixture_sha256": sha256(fixtures_path),
        "schema_fixture_sha256": sha256(ROOT / "test" / "expected-openapi.json"),
        "lock_sha256": sha256(ROOT / "support" / stage / "uv.lock"),
        "app_sha256": sha256(app_path),
        "observations": observations,
        "public_openapi": schema,
        "direct_call": direct,
        "native_model_schema": application.native_schema(),
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(
        f"{stage}: {len(observations)} HTTP cases + public schema + direct caller passed"
    )
    print(
        f"Python {report['python']}; FastAPI {report['fastapi']}; "
        f"Pydantic {report['pydantic']}; bundled v1 {bundled_v1}"
    )


if __name__ == "__main__":
    main()
