"""Application-owned HTTP and OpenAPI contracts, present before the migration."""

import json
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

ERROR_CODES = {
    "value_error.missing": "required",
    "missing": "required",
    "type_error.str": "invalid_type",
    "type_error.none.not_allowed": "invalid_type",
    "string_type": "invalid_type",
    "value_error.extra": "extra_forbidden",
    "extra_forbidden": "extra_forbidden",
    "type_error.dict": "invalid_body",
    "model_attributes_type": "invalid_body",
    "model_type": "invalid_body",
    "value_error.jsondecode": "invalid_json",
    "json_invalid": "invalid_json",
}


def create_app(
    order_model,
    legacy_model,
    order_response=None,
    legacy_response=None,
    error_fields=None,
):
    app = FastAPI(title="Orders contract", version="1.0.0")

    @app.exception_handler(RequestValidationError)
    async def invalid_order(_request: Request, error: RequestValidationError):
        fields = []
        for item in error.errors():
            code = ERROR_CODES[item["type"]]
            path = list(item["loc"])
            if code == "invalid_json":
                path = ["body"]
            fields.append({"path": path, "code": code})
        if error_fields:
            fields = error_fields(fields)
        return JSONResponse(
            status_code=422,
            content={"error": {"code": "INVALID_ORDER", "fields": fields}},
        )

    @app.post("/orders", response_model=order_model)
    def orders(order: order_model):
        return order_response(order) if order_response else order

    @app.post("/legacy/orders", response_model=legacy_model)
    def legacy_orders(order: legacy_model):
        return legacy_response(order) if legacy_response else order

    # The application already owns its public schema in the legacy stage.
    # Tests compare /openapi.json without rewriting the observed response.
    def public_openapi():
        return json.loads(
            (Path(__file__).resolve().parent / "public-openapi.json").read_text()
        )

    app.openapi = public_openapi
    return app
