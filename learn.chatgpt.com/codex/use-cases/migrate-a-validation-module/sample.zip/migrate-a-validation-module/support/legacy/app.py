"""legacy implementation; exercised through the real-route contract suite."""

from pydantic import BaseModel as LegacyBaseModel, Field as LegacyField
from pydantic import StrictStr as LegacyStrictStr

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from application import create_app


class LegacyOrder(LegacyBaseModel):
    internal_order_id: LegacyStrictStr = LegacyField(alias="order_id")
    customer_note: LegacyStrictStr | None = None

    class Config:
        extra = "forbid"
        allow_population_by_field_name = False


class OrderInput(LegacyOrder):
    pass


app = create_app(OrderInput, LegacyOrder)


def serialize_order(payload):
    return OrderInput(**payload).dict(by_alias=True)


def native_schema():
    return OrderInput.schema(by_alias=True)
