# Turn an issue into a tested pull request

This synthetic activity-feed API gives the workflow a small, reproducible issue.
It uses Node's standard library, an in-memory fixture store, and a loopback HTTP
server. No package installation, API key, database, or external service is needed.
The fixture creates fresh process-local session tokens and a cursor-signing key;
the commands never print those credentials.

## Runtime and commands

Use Node **22.6 or later**. Run these commands from this folder:

```sh
node --version
node api.mjs
node test.mjs --seeded
node test.mjs
node reproduce.mjs ./evidence
```

`node api.mjs` starts a server, makes one real HTTP request, prints the first two
public event IDs, and closes the server.

`node test.mjs --seeded` intentionally
exits nonzero: timestamp-only continuation skips rows in a timestamp tie. The
unchanged `node test.mjs` tests the corrected tuple continuation and exits zero.

`node reproduce.mjs ./evidence` runs both states and succeeds only if the seeded baseline fails and the corrected version passes. It saves the exact logs, actual HTTP bodies, runtime, commands,
and SHA-256 source hashes. Review the files in `evidence/` before sharing them.

For a syntax check:

```sh
node --check api.mjs
node --check fixtures.mjs
node --check test.mjs
node --check reproduce.mjs
```

The corrected five-event traversal with `limit=2` must be:

```text
[evt_105, evt_104]
[evt_103, evt_102]
[evt_101]
```

The first two pages return continuation cursors. The third returns `null`.
The deliberately broken baseline returns `[evt_105, evt_104]`, then `[evt_101]`.
This is a seeded demonstration of a defect, not a report of a customer incident.

## Files and contract

- `api.mjs`: authentication, project access, signed cursors, public projection,
  and corrected pagination. The explicitly named `seededBug` option selects the
  timestamp-only baseline for the reproduction; ordinary execution uses the fix.
- `fixtures.mjs`: fixed synthetic events for six tenant-A projects and one tenant-B project,
  timestamp ties, precision finer than one millisecond, empty feeds, exactly full final pages, and
  more than 100 events. Fixture data never changes during a test run.
- `openapi.json`: OpenAPI 3.1 contract for the existing project-detail route and
  the new events route. HTTP response tests use these closed public schemas.
- `test.mjs`: real HTTP assertions, an independent response-schema oracle for
  the keywords in this spec, and isolated signing fixtures for invalid payloads.
- `reproduce.mjs`: captures synthetic HTTP red/green evidence without recording sessions
  or the signing key.

Authenticate first, authorize the requested project second, then validate limit
and cursor. Inaccessible and nonexistent projects return the same generic 404,
even with a malformed cursor. Missing or invalid sessions return the same 401.

For an authorized project, validate the limit before the cursor. A malformed,
tampered, wrongly scoped, or structurally invalid cursor returns a generic 400.

Events sort by `created_at DESC, id DESC`, using exact fractional timestamp
precision and descending lexical ID order. The signed version-1 token contains
the last returned tuple and its tenant/project scope. It has no expiration and
does not establish snapshot or single-use semantics. Replay assertions apply
only while fixtures are unchanged.

A final page returns a null cursor whether it is partial or exactly full. Public events contain only `id`, `created_at`, `type`,
and `summary`; error bodies contain only the documented code and message.

## Use with Codex Cloud

Put these files in a repository selected by a prepared cloud environment. Prepare
a supported Node runtime there, publish the environment, and attach the issue packet,
contract, file boundaries, and test commands. Use your repository's actual
authentication, data store, and cursor conventions when adapting this example.

These commands exercise the synthetic fixture locally or in Cloud. For a Cloud
run, retain the task and environment setup reference alongside the generated
evidence. Verify repository integration and CI separately.
