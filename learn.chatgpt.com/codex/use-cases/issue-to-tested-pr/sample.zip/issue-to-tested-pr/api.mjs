import { createHmac, timingSafeEqual } from "node:crypto";
import { createServer } from "node:http";
import { pathToFileURL } from "node:url";

import { createFixtures } from "./fixtures.mjs";

/** @type {Record<string, [number, string]>} */
const errors = {
  invalid_cursor: [400, "Invalid cursor."],
  invalid_limit: [400, "Limit must be an integer from 1 through 100."],
  unauthenticated: [401, "Authentication required."],
  not_found: [404, "Project not found."],
};

// Parse UTC timestamps without rounding the fractional part to milliseconds.
function timestampValue(value) {
  if (typeof value !== "string") throw new Error("Invalid timestamp");
  const match = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d{1,9}))?Z$/.exec(
    value
  );
  if (!match) throw new Error("Invalid timestamp");
  const milliseconds = Date.parse(`${match[1]}Z`);
  if (
    !Number.isFinite(milliseconds) ||
    new Date(milliseconds).toISOString().slice(0, 19) !== match[1]
  ) {
    throw new Error("Invalid timestamp");
  }
  return (
    BigInt(milliseconds) * 1_000_000n + BigInt((match[2] ?? "").padEnd(9, "0"))
  );
}

function compareEvents(left, right) {
  const leftTime = timestampValue(left.created_at);
  const rightTime = timestampValue(right.created_at);
  if (leftTime !== rightTime) return leftTime > rightTime ? -1 : 1;
  return left.id === right.id ? 0 : left.id > right.id ? -1 : 1;
}

function encodeCursor(event, tenantId, projectId, signingKey) {
  const payload = Buffer.from(
    JSON.stringify({
      version: 1,
      tenant_id: tenantId,
      project_id: projectId,
      created_at: event.created_at,
      id: event.id,
    })
  ).toString("base64url");
  const signature = createHmac("sha256", signingKey)
    .update(payload)
    .digest("base64url");
  return `${payload}.${signature}`;
}

function decodeCursor(token, tenantId, projectId, signingKey) {
  if (typeof token !== "string" || token.length > 2048)
    throw new Error("Invalid cursor");
  const parts = token.split(".");
  if (
    parts.length !== 2 ||
    parts.some((part) => !/^[A-Za-z0-9_-]+$/.test(part))
  ) {
    throw new Error("Invalid cursor");
  }
  const [payload, signature] = parts;
  const decoded = Buffer.from(payload, "base64url");
  const actual = Buffer.from(signature, "base64url");
  const expected = createHmac("sha256", signingKey).update(payload).digest();
  if (
    decoded.toString("base64url") !== payload ||
    actual.toString("base64url") !== signature ||
    actual.length !== expected.length ||
    !timingSafeEqual(actual, expected)
  ) {
    throw new Error("Invalid cursor");
  }
  const cursor = JSON.parse(decoded.toString("utf8"));
  const fields = ["version", "tenant_id", "project_id", "created_at", "id"];
  if (
    cursor === null ||
    typeof cursor !== "object" ||
    Array.isArray(cursor) ||
    Object.keys(cursor).length !== fields.length ||
    fields.some((field) => !Object.hasOwn(cursor, field)) ||
    cursor.version !== 1 ||
    cursor.tenant_id !== tenantId ||
    cursor.project_id !== projectId ||
    typeof cursor.id !== "string" ||
    cursor.id.length === 0
  ) {
    throw new Error("Invalid cursor");
  }
  timestampValue(cursor.created_at);
  return cursor;
}

// docs:start node-example
export function createApi({
  sessions,
  projects,
  events,
  signingKey,
  seededBug = false,
}) {
  return createServer((request, response) => {
    const send = (status, body) => {
      response.writeHead(status, { "content-type": "application/json" });
      response.end(JSON.stringify(body));
    };
    const fail = (code) => {
      const [status, message] = errors[code];
      send(status, { error: { code, message } });
    };
    // Authenticate, then authorize. Malformed parameters must not change these results.
    const authorization = request.headers.authorization ?? "";
    const bearer = /^Bearer ([A-Za-z0-9_-]+)$/.exec(authorization);
    const tenantId = bearer ? sessions.get(bearer[1]) : undefined;
    if (!tenantId) return fail("unauthenticated");

    const url = new URL(request.url ?? "/", "http://127.0.0.1");
    const route = /^\/v1\/projects\/([^/]+)(\/events)?$/.exec(url.pathname);
    let projectId;
    try {
      projectId = route ? decodeURIComponent(route[1]) : undefined;
    } catch {
      return fail("not_found");
    }
    const project = projectId ? projects.get(projectId) : undefined;
    if (
      request.method !== "GET" ||
      !project ||
      project.tenant_id !== tenantId
    ) {
      return fail("not_found");
    }
    // Existing project-detail behavior remains independent of pagination parameters.
    if (!route[2]) return send(200, { id: projectId, name: project.name });

    const rawLimit = url.searchParams.get("limit");
    const limit = rawLimit === null ? 25 : Number(rawLimit);
    if (
      url.searchParams.getAll("limit").length > 1 ||
      (rawLimit !== null && !/^\d+$/.test(rawLimit)) ||
      !Number.isInteger(limit) ||
      limit < 1 ||
      limit > 100
    ) {
      return fail("invalid_limit");
    }
    let cursor;
    if (url.searchParams.has("cursor")) {
      try {
        if (url.searchParams.getAll("cursor").length !== 1)
          throw new Error("Invalid cursor");
        cursor = decodeCursor(
          url.searchParams.get("cursor"),
          tenantId,
          projectId,
          signingKey
        );
      } catch {
        return fail("invalid_cursor");
      }
    }

    const matching = events
      .filter(
        (event) =>
          event.tenant_id === tenantId && event.project_id === projectId
      )
      .sort(compareEvents)
      .filter((event) => {
        if (!cursor) return true;
        // Deliberate baseline defect: timestamp-only continuation loses tied rows.
        if (seededBug)
          return (
            timestampValue(event.created_at) < timestampValue(cursor.created_at)
          );
        return compareEvents(event, cursor) > 0;
      });
    const selected = matching.slice(0, limit);
    const items = selected.map(({ id, created_at, type, summary }) => ({
      id,
      created_at,
      type,
      summary,
    }));
    const nextCursor =
      matching.length > limit
        ? encodeCursor(selected.at(-1), tenantId, projectId, signingKey)
        : null;
    return send(200, { items, next_cursor: nextCursor });
  });
}

export async function startApi(fixtures, options = {}) {
  const server = createApi({ ...fixtures, ...options });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => resolve(undefined));
  });
  const address = server.address();
  if (!address || typeof address === "string")
    throw new Error("No listening address");
  return {
    baseUrl: `http://127.0.0.1:${address.port}`,
    close: () =>
      new Promise((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve(undefined)))
      ),
  };
}
// docs:end node-example

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(process.argv[1]).href
) {
  const fixtures = createFixtures();
  const api = await startApi(fixtures);
  try {
    const response = await fetch(
      `${api.baseUrl}/v1/projects/feed/events?limit=2`,
      {
        headers: { authorization: `Bearer ${fixtures.tokenA}` },
      }
    );
    const body = await response.json();
    console.log(
      JSON.stringify({
        status: response.status,
        ids: body.items.map((item) => item.id),
        has_next_page: body.next_cursor !== null,
      })
    );
  } finally {
    await api.close();
  }
}
