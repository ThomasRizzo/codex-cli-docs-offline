import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { startApi } from "./api.mjs";
import { createFixtures } from "./fixtures.mjs";

const directory = fileURLToPath(new URL(".", import.meta.url));
const output = resolve(process.argv[2] ?? "./evidence");
const writeJson = (name, value) =>
  writeFileSync(resolve(output, name), `${JSON.stringify(value, null, 2)}\n`);

async function observe(seededBug) {
  const fixtures = createFixtures();
  const api = await startApi(fixtures, { seededBug });
  try {
    const pages = [];
    let cursor;
    do {
      if (pages.length >= 3)
        throw new Error("Traversal exceeded the fixed-fixture request bound");
      const parameters = new URLSearchParams({
        limit: "2",
        ...(cursor ? { cursor } : {}),
      });
      const response = await fetch(
        `${api.baseUrl}/v1/projects/feed/events?${parameters}`,
        {
          headers: { authorization: `Bearer ${fixtures.tokenA}` },
        }
      );
      const body = await response.json();
      pages.push({ status: response.status, body });
      cursor = body.next_cursor;
    } while (cursor !== null);
    const errors = [];
    for (const [project, parameters, authenticated] of [
      ["feed", { cursor: "broken" }, true],
      ["feed", { cursor: "broken" }, false],
      ["private", { cursor: "broken" }, true],
    ]) {
      const response = await fetch(
        `${api.baseUrl}/v1/projects/${project}/events?${new URLSearchParams(parameters)}`,
        {
          headers: authenticated
            ? { authorization: `Bearer ${fixtures.tokenA}` }
            : {},
        }
      );
      errors.push({ status: response.status, body: await response.json() });
    }
    return { pages, errors };
  } finally {
    await api.close();
  }
}

// docs:start node-example
mkdirSync(output, { recursive: true });
const states = [];
for (const [name, arguments_] of [
  ["red", ["--seeded"]],
  ["green", []],
]) {
  const result = spawnSync(
    process.execPath,
    [resolve(directory, "test.mjs"), ...arguments_],
    {
      cwd: directory,
      encoding: "utf8",
      timeout: 30_000,
    }
  );
  writeFileSync(
    resolve(output, `${name}.log`),
    `${result.stdout ?? ""}${result.stderr ?? ""}`
  );
  states.push({
    name,
    command: `node test.mjs${arguments_.length ? " --seeded" : ""}`,
    exit_code: result.status,
    signal: result.signal,
    error: result.error?.message ?? null,
  });
}
const sources = Object.fromEntries(
  readdirSync(directory, { withFileTypes: true })
    .filter((entry) => entry.isFile())
    .map((entry) => [
      entry.name,
      createHash("sha256")
        .update(readFileSync(resolve(directory, entry.name)))
        .digest("hex"),
    ])
);
const observed = { red: await observe(true), green: await observe(false) };
writeJson("observed-http.json", observed);
writeJson("run-manifest.json", {
  execution: "Synthetic loopback HTTP fixture; no external service",
  recorded_at: new Date().toISOString(),
  node: process.version,
  minimum_node: "22.6.0",
  dependencies: "Node standard library only; no install step",
  baseline:
    "Deliberately seeded timestamp-only continuation; not a historical customer defect",
  correction:
    "Descending timestamp-and-ID tuple continuation using full fractional precision",
  source_sha256: sources,
  states,
});
if (
  states[0].exit_code === null ||
  states[0].exit_code === 0 ||
  states[1].exit_code !== 0
) {
  throw new Error(
    "Expected the unchanged tests to fail on the seeded baseline and pass on the corrected implementation. Inspect red.log and green.log."
  );
}
console.log(
  JSON.stringify(
    {
      execution: "synthetic-loopback-http",
      red_exit: states[0].exit_code,
      green_exit: states[1].exit_code,
      green_pages: observed.green.pages.map((page) =>
        page.body.items.map((item) => item.id)
      ),
      evidence_directory: output,
    },
    null,
    2
  )
);
// docs:end node-example
